/******************************************************************************
Filename   : rvccconnsms.c
Description: Implements MDM Adaptor State Machines
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_CALLCONTROL
#include "ipp_inc_std.h"
#include "rvccterminalmdm.h"
#include "rvccapi.h"
#include "rvcctext.h"
#include "mdmControlInt.h"
#include "rvccconnsip.h"

/* package name abbreviation for RvCCTerminalAudioType */
static char pkgName[4][4]=
{
    "",     /* RV_CCTERMAUDIO_NONE */
    "hs",   /* RV_CCTERMAUDIO_HANDSET */
    "hf",   /* RV_CCTERMAUDIO_HANDSFREE */
    "ht"    /* RV_CCTERMAUDIO_HEADSET */
};

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/

static void rvCCTerminalEventSetActiveAudio(
                RvCCTerminalEvent   eventId,
                int                 termState,
                RvCCTerminal*       t)
{

    RvCCTerminalAudioType termAudioType;

    termAudioType = rvCCTerminalMdmGetActiveAudio(t);

    switch (eventId)
    {
        case RV_CCTERMEVENT_HANDSFREE:
            switch(termAudioType)
            {
                case RV_CCTERMAUDIO_HANDSET:
                case RV_CCTERMAUDIO_HEADSET:
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSFREE);
                    break;
                case RV_CCTERMAUDIO_HANDSFREE:
                    if (termState & RV_CCAUDIOTERM_HT_ACTIVE)
                        rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HEADSET);
                    else if (termState & RV_CCAUDIOTERM_HS_ACTIVE)
                        rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSET);
                    break;
                case RV_CCTERMAUDIO_NONE:
                default:
                    RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalEventSetActiveAudio() -  returned RV_CCTERMAUDIO_NONE for terminal %p",t ));
            }
            break;
        case RV_CCTERMEVENT_HEADSET:
            switch(termAudioType)
            {
                case RV_CCTERMAUDIO_HANDSET:
                case RV_CCTERMAUDIO_HANDSFREE:
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HEADSET);
                    break;
                case RV_CCTERMAUDIO_HEADSET:
                    if (termState & RV_CCAUDIOTERM_HF_ACTIVE)
                    {
                        rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSFREE);
                    }
                    else
                    {
                        if (termState & RV_CCAUDIOTERM_HS_ACTIVE)
                        {
                            rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSET);
                        }
                    }
                    break;
                case RV_CCTERMAUDIO_NONE:
                default:
                    RvLogError(ippLogSource,
                        (ippLogSource,"rvCCTerminalEventSetActiveAudio() -  returned RV_CCTERMAUDIO_NONE for Terminal=%s",
                        rvCCTerminalGetId(t)));
            }
            break;
        default:
            /*rvCCTerminalEventSetActiveAudio */
            RvLogError(ippLogSource,
                (ippLogSource,"rvCCTerminalEventSetActiveAudio() -  passed illegal parameter %s as eventId for Terminal=%s",
                rvCCTextEvent(eventId), rvCCTerminalGetId(t)));
    /*lint -e{788}  all relevant cases are accounted for */
    }
}


static void rvInitNewCall(
                RvCCCallMgr*    callMgr,
                RvCCConnection* conn)
{
    RvCCCall* call;

    call = rvCCCallMgrCreateCall(callMgr);
    rvCCCallAddParty(call, conn);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvInitNewCall() -  New call (%p) was initiated for conn=%p, Line=%d",
        call, conn, rvCCConnectionGetLineId(conn)));
}

/* This function sends event to MDM state machines, and locks/unlocks call
    before and after processing */
static void rvProcessEvent(
                RvCCConnection*     c,
                RvCCTerminalEvent   eventId,
                RvCCEventCause      reason)
{
    RvBool          callStillAlive = RV_TRUE;
    RvCCCall*       call = rvCCConnectionGetCall(c);

    /* Lock the call if one already exists (it may have not been created yet) */
    if (call != NULL)
    {
        rvCCCallLock(call);
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvProcessEvent() -  Sending <event (%s) reason (%s)> to MDM State machines for conn=%p, Line=%d",
         rvCCTextEvent(eventId), rvCCTextCause(reason), c, rvCCConnectionGetLineId(c)));

    rvCCConnectionProcessTermEvent(c, eventId, &callStillAlive, reason);

    if (call != NULL)
    {
            rvCCCallUnlock(call);
    }
}

/*===============================================================================*/
/*========    T E R M - C O N N   S T A T E   M A C H I N E    ==================*/
/*===============================================================================*/

RvCCTerminalEvent rvCCTermConnProcessEvents(
                RvCCConnection*     conn,
                RvCCTerminalEvent   eventId,
                RvCCEventCause*     cause)
{
    RvCCTerminal*   t = rvCCConnectionGetTerminal(conn);
    RvCCCall*       call;

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCTermConnProcessEvents() -  Processing <event (%s) reason (%s)> for  conn=%p, Line=%d, termConnState=%s, connState=%s",
         rvCCTextEvent(eventId), rvCCTextCause(*cause), conn, rvCCConnectionGetLineId(conn),
         rvCCTextTermConnState(rvCCConnectionGetTermState(conn)), rvCCTextConnState(rvCCConnectionGetState(conn))));

    switch(eventId)
    {
        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_LINE          */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_LINE:
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_IDLE:
                case RV_CCTERMCONSTATE_RINGING:
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_BRIDGED);
                    /* Before call was established...*/
                    if ( (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DIALING) ||
                         (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CALL_DELIVERED) ||
                         /* ... and during Transfer... */
                         (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DISCONNECTED))
                    {
                        /*Line key disconnects */
                        return RV_CCTERMEVENT_ONHOOK;
                    }
                    else
                    {
                        /*In other cases, Line key starts a new line */
                        return RV_CCTERMEVENT_OFFHOOK;
                    }

                case RV_CCTERMCONSTATE_BRIDGED:
                    /* Before call was established...*/
                    if ((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DIALING) ||
                        (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_INPROCESS) ||
                        (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CALL_DELIVERED) ||
                        (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_FAILED))
                    {
                        t->audioTermState &= ~RV_CCAUDIOTERM_HS_ACTIVE;
                        /*Line key disconnects*/
                        return RV_CCTERMEVENT_ONHOOK;
                    }
                    else
                    {
                        /*In other cases, Line key starts a new line */
                        return RV_CCTERMEVENT_OFFHOOK;
                    }

                case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_REMOTE_HELD);
                    return RV_CCTERMEVENT_UNHOLD;

                case RV_CCTERMCONSTATE_HELD:
                    /* First, turn indicator off */
                    rvCCConnectionTermSetHoldIndicator(conn, RV_FALSE);
                    /* ---- Blind transfer - user A pressed LINE ------*/
                    if (rvCCCallGetTransferType(rvCCConnectionGetCall(conn)) == RV_CCCALL_TRANSFER_BLIND)
                    {
                        if ((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED) &&
							(strlen(conn->thirdPartyDestAddress) > 0))
                        {
                            rvCCCallTransferCompletedCB(rvCCConnectionGetConnectParty(conn), RV_TRUE);
                            return RV_CCTERMEVENT_ONHOOK;
                        }
                        else
                        {
                            /* Call is disconnected, Blind Transfer was completed, connection should be released*/
                            if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DISCONNECTED)
                            {
                                RvLogInfo(ippLogSource,
                                    (ippLogSource, "rvCCTermConnProcessEvents() -  Blind Transfer is completed, disconnecting conn=%p, Line=%d",
                                    conn, rvCCConnectionGetLineId(conn)));
                                return RV_CCTERMEVENT_ONHOOK;
                            }
                            /* Blind Transfer not completed - user A pressed Line to return
                               to original call before Transfer was completed (either dialed wrong number
                               regret, failure, etc.)*/
                            else
                            {
                                /* Stop warning tone that was started in case of wrong number or
                                   other failure. Since there is no function to stop warning signal,
                                   we stop all signals*/
                                rvCCTerminalMdmStopSignals(t);
                                /* Reset Transfer states, return to Normal call */
                                rvCCConnectionSetTransferType(conn, RV_CCCALL_TRANSFER_NONE);
                                rvCCConnectionSetTransferState(conn, RV_CCCONNSTATE_TRANSFER_IDLE);

                                RvLogInfo(ippLogSource,
                                    (ippLogSource, "rvCCTermConnProcessEvents() -  Blind Transfer is cancelled, back to Normal call for conn=%p, Line=%d",
                                    conn, rvCCConnectionGetLineId(conn)));
                            }
                        }
                    }
                    /* ----  Normal call - Line key Unholds the call  -----*/
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
                    return RV_CCTERMEVENT_UNHOLD;

                case RV_CCTERMCONSTATE_MUTE:
                    rvCCConnectionTermSetMuteIndicator(conn, RV_FALSE);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        /* Pressing Line during a Muted call, need to Unmute the call
                           before disconnecting */
                        rvCCConnectionTermUnmute(conn);
                    }
                    return RV_CCTERMEVENT_ONHOOK;

                case RV_CCTERMCONSTATE_TALKING:
                case RV_CCTERMCONSTATE_REMOTE_HELD:
                case RV_CCTERMCONSTATE_DROPPED:
                    /* In case of connected call, Held call by remote, or failure,
                       pressing Line key will disconnect*/
                    return RV_CCTERMEVENT_ONHOOK;

                default:
                    break;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_LINEOTHER     */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_LINEOTHER:

            /* Line key was pressed while another Line key was active for CFW
               CFW process which wasn't completed yet (for example, user pressed CFW
               which activated Line 1, and before he completed dialing CFW address,
               he pressed another Line key) */
            if (rvCCTerminalGetState(t) == RV_CCTERMINAL_CFW_ACTIVATING_STATE)
            {
                /* Cancel CFW process */
                rvCCCfwHandleActivationCompleted(t, RV_FALSE, RV_IPP_CFW_CANCELLED_BY_USER);
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  CFW Activation is cancelled, another Line was pressed, conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));
            }
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_HELD:
                    call = rvCCConnectionGetCall(conn);
                    if ((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DISCONNECTED) &&
                        (call != NULL) &&
                        (rvCCCallGetTransferType(call) == RV_CCCALL_TRANSFER_BLIND))
                    {
                        /* User A pressed second Line after Blind Transfer completed
                           successfully, it is needed to disconnect first Line which
                           was on Hold*/
                        return RV_CCTERMEVENT_ONHOOK;
                    }
                    break;

                case RV_CCTERMCONSTATE_IDLE:
                case RV_CCTERMCONSTATE_RINGING:
                    /* Don't disconnect a ringing line */
                    if (rvCCConnectionGetState(conn) != RV_CCCONNSTATE_ALERTING)
                    {
                        return RV_CCTERMEVENT_ONHOOK;
                    }
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_BRIDGED);
                    return RV_CCTERMEVENT_NONE;

                case RV_CCTERMCONSTATE_BRIDGED:
                    /* This state indicates that this is not the active connection.
                       Anyway, don't disconnect a ringing line */
                    if (rvCCConnectionGetState(conn) != RV_CCCONNSTATE_ALERTING)
                    {
                        return RV_CCTERMEVENT_ONHOOK;
                    }
                    break;

                case RV_CCTERMCONSTATE_TALKING:
                case RV_CCTERMCONSTATE_REMOTE_HELD:
                case RV_CCTERMCONSTATE_DROPPED:
                    /* User pressed second Line while first Line is active
                       Disconnect first Line before we are moving to the second one */
                    return RV_CCTERMEVENT_ONHOOK;

                case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:
                case RV_CCTERMCONSTATE_MUTE:
                default:
                    break;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_HANDSFREE     */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_HANDSFREE:
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_IDLE :
                case RV_CCTERMCONSTATE_BRIDGED :
                case RV_CCTERMCONSTATE_DROPPED :
                    rvCCTerminalEventSetActiveAudio(eventId, t->audioTermState, t);
                    break;

                case RV_CCTERMCONSTATE_TALKING:
					{
					/* HF was pressed during Conference, we need to disconnect and
						re-connect media with new termination for all active connections */

						RvInt maxConnections = rvCCTerminalGetNumberOfLines(t);
						RvInt i;
#ifndef RV_MTF_N_LINES
						RvCCConnection *disconnected[RV_CCTERMINAL_MAXCONNS] = {0};
#else
						RvCCConnection **disconnected;
						rvMtfAllocatorAlloc(sizeof(RvCCConnection), (void**)&disconnected);
#endif /* RV_MTF_N_LINES */

						/* 1. Disconnect media for all connections */
						for (i=0; i<maxConnections; i++)
						{
							conn = t->connections[i];
							if ((conn->state == RV_CCCONNSTATE_CONNECTED) &&
								(conn->mediaState == RV_CCMEDIASTATE_CONNECTED))
							{
								disconnected[i] = conn;
								rvCCConnectionTermDisconnectMedia(conn);
							}
						}

						/* 2. Switch to new termination */
						rvCCTerminalEventSetActiveAudio(eventId, t->audioTermState, t);

						/* 3. Connect media for all connections */
						for (i=0; i<maxConnections; i++)
						{
							if ((conn = disconnected[i]) != 0)
								rvCCConnectionTermConnectMedia(conn);
						}
#ifndef RV_MTF_N_LINES
						rvMtfAllocatorDealloc((void*)&disconnected, sizeof(RvCCConnection));
#endif /* RV_MTF_N_LINES */
						break;
					}

                /* User pressed HF while in Mute, this will Unmute the call */
                case RV_CCTERMCONSTATE_MUTE:
                    rvCCConnectionTermSetMuteIndicator(conn, RV_FALSE);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSFREE);
                    rvCCTerminalMdmSetAudioInd(t, "hf", RV_INDSTATE_ON);
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        rvCCConnectionTermUnmute(conn);
                    }
                    return RV_CCTERMEVENT_NONE;

                case RV_CCTERMCONSTATE_RINGING:
                case RV_CCTERMCONSTATE_HELD:
                case RV_CCTERMCONSTATE_REMOTE_HELD:
                case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:
                default:
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSFREE);
                    break;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_AUDIOHANDSET  */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_AUDIOHANDSET:
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_TALKING:
                    rvCCConnectionTermDisconnectMedia(conn);
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSET);
                    rvCCConnectionTermConnectMedia(conn);
                    break;


                case RV_CCTERMCONSTATE_MUTE:
                    rvCCConnectionTermSetMuteIndicator(conn, RV_FALSE);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSET);
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        rvCCConnectionTermUnmute(conn);
                    }
                    return RV_CCTERMEVENT_NONE;

                default:
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSET);
                    break;
            /*lint -e{788}  all relevant cases are accounted for */
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_HEADSET       */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_HEADSET:
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_IDLE:
                    rvCCTerminalEventSetActiveAudio(eventId, t->audioTermState, t);
                    break;
                case RV_CCTERMCONSTATE_TALKING:
                    rvCCConnectionTermDisconnectMedia(conn);
                    rvCCTerminalEventSetActiveAudio(eventId, t->audioTermState, t);
                    rvCCConnectionTermConnectMedia(conn);
                    break;

                case RV_CCTERMCONSTATE_MUTE:
                    rvCCConnectionTermSetMuteIndicator(conn, RV_FALSE);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HEADSET);
                    rvCCTerminalMdmSetAudioInd(t, "ht", RV_INDSTATE_ON);
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        rvCCConnectionTermUnmute(conn);
                    }
                    return RV_CCTERMEVENT_NONE;

                default:
                    rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HEADSET);
                    break;
            /*lint -e{788}  all relevant cases are accounted for */
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_MUTE          */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_MUTE:
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_TALKING:
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        rvCCConnectionTermMute(conn);
                    }
                    return RV_CCTERMEVENT_NONE;

                case RV_CCTERMCONSTATE_HELD:/*Ignore mute if call is on hold*/
                    return RV_CCTERMEVENT_NONE;

                case RV_CCTERMCONSTATE_MUTE:
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        rvCCConnectionTermUnmute(conn);
                    }

                    return RV_CCTERMEVENT_NONE;

                default:
                    break;
            /*lint -e{788}  all relevant cases are accounted for */
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_HOLDKEY       */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_HOLDKEY:
            switch(rvCCConnectionGetTermState(conn))
            {
                /* Local user put the call on Hold, while call was already Held by remote party */
                case RV_CCTERMCONSTATE_REMOTE_HELD:
                    /*Will be used if Transfer or Conference are pressed later*/
                    rvCCTerminalMdmSetHoldingConn(t, conn);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD);
                    return RV_CCTERMEVENT_HOLD;

                /* User pressed Hold while call is connected, set some states before
                   processing Hold*/
                case RV_CCTERMCONSTATE_TALKING:
                    /*Will be used if Transfer or Conference are pressed later*/
                    
                #ifndef USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/11/22 */
                    if(rvCCTerminalMdmOtherHeldConnExist(t, conn) == RV_FALSE)
                    {
                        rvCCTerminalMdmSetHoldingConn(t, conn);
                    }
                #else
                    rvCCTerminalMdmSetHoldingConn(t, conn);
                #endif
					
                    /* No break! */

                case RV_CCTERMCONSTATE_BRIDGED:
                    rvCCConnectionTermSetHoldIndicator(conn, RV_TRUE);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_HELD);
                    return RV_CCTERMEVENT_HOLD;

                case RV_CCTERMCONSTATE_DROPPED:
                    rvCCConnectionTermSetHoldIndicator(conn, RV_TRUE);
                    return RV_CCTERMEVENT_HOLD;

                /* User pressed Hold while call is Muted, need to Unmute the call before
                   processing the Hold */
                case RV_CCTERMCONSTATE_MUTE:
                    rvCCConnectionTermSetHoldIndicator(conn, RV_TRUE);
                    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_HELD);
                    rvCCConnectionTermSetMuteIndicator(conn, RV_FALSE);
                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        rvCCConnectionTermUnmute(conn);
                    }
                    return RV_CCTERMEVENT_HOLD;

                case RV_CCTERMCONSTATE_IDLE:
                case RV_CCTERMCONSTATE_RINGING:
                case RV_CCTERMCONSTATE_HELD:
                case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:
                default:
                    break;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_HOLD          */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_HOLD:
            if (rvCCConnectionGetTermState(conn) == RV_CCTERMCONSTATE_TALKING)
            {
                rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_HELD);
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_TRANSFER      */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_TRANSFER:
            if (rvCCConnectionGetTermState(conn) == RV_CCTERMCONSTATE_TALKING)
            {
                *cause = RV_CCCAUSE_TRANSFER;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_DIGITS        */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_DIGITS:
   //Leibt         break;    //when talking, gw send digit with RV_CCTERMEVENT_DIGITS,but we need deal it with RV_CCTERMEVENT_DIGIT_END  

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_DIGIT_END     */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_DIGIT_END:
            /* Hanlde digits as DTMF only if call is connected and we are not during
               Blind Transfer process */
            if ((rvCCConnectionGetTermState(conn) == RV_CCTERMCONSTATE_TALKING) &&
                (rvCCCallGetTransferType(rvCCConnectionGetCall(conn)) != RV_CCCALL_TRANSFER_BLIND))
            {
                RvCCTerminalMdm*            x = rvCCTerminalMdmGetImpl(t);
                RvMdmParameterList*         args = &(x->lastEvent.parameters);
                const RvMdmParameterValue*  pVal = rvMdmParameterListGet2(args, "duration");
                int                         duration = DEFAULT_DTMF_DURATION;
                const char*                 dialString;
                const char*                 strVal;
                char                        digit;

                if (pVal)
                {
                    strVal = rvMdmParameterValueGetValue(pVal);
                    sscanf(strVal,"%d",&duration);
                }

                dialString = rvCCTerminalMdmGetDialString(t);
                if ((dialString != NULL) && dialString[0])
                {
                digit = dialString[strlen(dialString)-1];

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  Handle DTMF, digit=%c, conn=%p, Line=%d",
                     digit, conn, rvCCConnectionGetLineId(conn)));

                /* Send DTMF to remote party */
                rvCCCallHandleOutOfBandDTMF(conn, digit, duration);
                }
                else
                {
                    RvLogError(ippLogSource,
                        (ippLogSource, "rvCCTermConnProcessEvents() -  Handle DTMF: empty dial string. conn=%p, Line=%d",
                         conn, rvCCConnectionGetLineId(conn)));
                }

                /* Pass the event on for display */
                return RV_CCTERMEVENT_DIGIT_END;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_RINGING       */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_RINGING:
            if (rvCCConnectionGetTermState(conn) == RV_CCTERMCONSTATE_BRIDGED)
            {
                /* Incoming call while another call is connected */
                *cause = RV_CCCAUSE_CALL_WAITING;
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_MAKECALL      */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_MAKECALL:
            if (rvCCConnectionGetTermState(conn) == RV_CCTERMCONSTATE_BRIDGED)
            {
				RvCCTerminal*           t = rvCCConnectionGetTerminal(conn);
				RvCCTerminalMdm*        term = rvCCTerminalMdmGetImpl(t);
				RvCCProvider*			p = rvCCTerminalMdmGetProvider(term);
				RvCCProviderMdm*		provider = rvCCProviderMdmGetImpl(p);

                		*cause = RV_CCCAUSE_CALL_WAITING;
		
				/* zhuzhh, 2011/05/27, disable cwt for line, modify, start */
				// if (provider->disableCallWaiting == RV_TRUE)
				if ( term->disableCallWaiting)
				/* zhuzhh, 2011/05/27, disable cwt for line, modify, end */
				{
					//Leibt
					*cause = RV_CCCAUSE_BUSY;
					RvLogInfo(ippLogSource,(ippLogSource, "rvCCTermConnProcessEvents() - disableCallWaiting is on - call is rejected, conn=%p  %d", conn));
					return RV_CCTERMEVENT_REJECTCALL;
				}
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_ONHOOK_OTHER  */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_ONHOOK_OTHER:
            if (rvCCConnectionGetTermState(conn) == RV_CCTERMCONSTATE_BRIDGED)
            {
                if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_ALERTING)
                {
                    rvCCTerminalMdmStartRingingSignal(t);
                }
            }
            break;

        /*----------------------------------------------------------*/
        /*  rvCCTermConnProcessEvents: RV_CCTERMEVENT_ONHOOK        */
        /*----------------------------------------------------------*/
        case RV_CCTERMEVENT_ONHOOK:
            switch(rvCCConnectionGetTermState(conn))
            {
                case RV_CCTERMCONSTATE_HELD:
                case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:
                    /* Only in case of Blind Transfer, it is possible to disconnect a
                       Held call... */
                    if (rvCCCallGetTransferType(rvCCConnectionGetCall(conn)) == RV_CCCALL_TRANSFER_BLIND)
                    {
                        rvCCTerminalMdmStopSignals(t);
                        rvCCConnectionSetTransferType(conn, RV_CCCALL_TRANSFER_NONE);
                        rvCCConnectionSetTransferState(conn, RV_CCCONNSTATE_TRANSFER_IDLE);
                        return RV_CCTERMEVENT_ONHOOK;
                    }
                    /*...in all other cases, ignore On Hook if local user put the call
                      on Hold*/
                    return RV_CCTERMEVENT_NONE;

                case RV_CCTERMCONSTATE_MUTE:
                    rvCCConnectionTermSetMuteIndicator(conn, RV_FALSE);

                    if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
                    {
                        /* User pressed On Hook while call is Muted, need to Unmute
                           the call first (TODO: do we?)*/
                        rvCCConnectionTermUnmute(conn);
                    }

                    return RV_CCTERMEVENT_ONHOOK;

                default:
                    break;
            /*lint -e{788}  all relevant cases are accounted for */
            }
            break;

        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    return eventId;
}

/*===============================================================================*/
/*========    C O N N E C T I O N   S T A T E   M A C H I N E    ================*/
/*===============================================================================*/

RvCCTerminalEvent rvCCConnectionStateMachine(
                RvCCConnection*     conn,
                RvCCTerminalEvent   event,
                RvCCEventCause*     cause,
                RvBool*             stillAlive)
{
    RvCCTerminal*           t = rvCCConnectionGetTerminal(conn);
    RvCCTerminalMdm*        term = rvCCTerminalMdmGetImpl(t);
    RvCCConnection*         otherParty = rvCCConnectionGetConnectParty(conn); /* could be NULL */
    RvCCConnection *        transferLineConnection = NULL;
    RvCCCall*               call = NULL;
	RvCCProvider*			p = rvCCTerminalMdmGetProvider(term);
	RvCCProviderMdm*		provider = rvCCProviderMdmGetImpl(p);

	RvBool                  isUpdatePermitted = RV_FALSE;

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCConnectionStateMachine() -  Processing <event (%s) reason (%s)> for  conn=%p, Line=%d, termConnState=%s, connState=%s",
        rvCCTextEvent(event), rvCCTextCause(*cause), conn, rvCCConnectionGetLineId(conn),
        rvCCTextTermConnState(rvCCConnectionGetTermState(conn)), rvCCTextConnState(rvCCConnectionGetState(conn))));


    switch (event)
    {
    case RV_CCTERMEVENT_NONE:
    case RV_CCTERMEVENT_UNKNOWN:
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_OFFHOOK      */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_OFFHOOK:
        switch (rvCCConnectionGetState(conn))
        {
        /*Start a new Outgoing call*/
        case RV_CCCONNSTATE_IDLE:

            rvCCConnectionSetState(conn, RV_CCCONNSTATE_INITIATED);
            rvCCConnectionInitiatedCB(conn);

            /* Notify user new connection is created */
            rvIppMdmExtConnectionCreatedCB(conn);

            /* Reset the dial string before start dialing */
            rvCCTerminalMdmResetDialString(t);
            return RV_CCTERMEVENT_DIALTONE;

        /*Incoming call during Transfer*/
        case RV_CCCONNSTATE_TRANSFER_ALERTING:
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_DELIVERED);
            /*No break*/
        /*Incoming normal call*/
        case RV_CCCONNSTATE_ALERTING:
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_CALL_DELIVERED);
            *cause = RV_CCCAUSE_INCOMING_CALL;
            if (rvCCConnectionCallAnsweredCB(conn) == RV_TRUE)
            {
                /* Call was answered successfully */
                return RV_CCTERMEVENT_CALLANSWERED;
            }
            else
            {
                /* We probably failed opening media for the new call */
                return RV_CCTERMEVENT_MEDIAFAIL;
            }
        default:
            break;
        /*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_DIALTONE     */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_DIALTONE:
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_INITIATED)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_DIALING);
            return RV_CCTERMEVENT_NONE; /* wait for RV_CCTERMEVENT_DIGITS event*/
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_DIGITS       */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_DIGITS:
        /* Allow collecting digits in the following cases:
            1. Call establishment
            2. Blind Transfer */
        if ((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DIALING) ||
            ((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED) &&
            (rvCCCallGetTransferType(rvCCConnectionGetCall(conn)) == RV_CCCALL_TRANSFER_BLIND)))

        {
            rvCCConnectionNewDigitCB(conn, RV_CCCAUSE_EVENT_BEGIN);
            return RV_CCTERMEVENT_NONE;
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_DIGIT_END    */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_DIGIT_END:
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_DIALING)
        {
            rvCCConnectionNewDigitCB(conn, RV_CCCAUSE_EVENT_END);
            return RV_CCTERMEVENT_NONE;
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_DIALCOMPLETED*/
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_DIALCOMPLETED:
        /* User completed dialing, need to find destination address */
        switch(rvCCConnectionGetState(conn))
        {
            case RV_CCCONNSTATE_IDLE:
                break;
            case RV_CCCONNSTATE_INITIATED:
            case RV_CCCONNSTATE_DIALING:
                /* Get destination address that matches this dial string. If address
                   is not found, function returns NULL */
                otherParty = rvCCConnectionAddressAnalyze(conn, cause);
                transferLineConnection = rvCCConnectionGetTransferLine(conn);

                /* Address Analyze succeeded */
                /* ------------------------- */
                if (otherParty != NULL)
                {
                    /* During CFW activation */
                    /* --------------------- */
                    if (rvCCTerminalGetState(t) == RV_CCTERMINAL_CFW_ACTIVATING_STATE)
                    {
                        RvCCTerminalEvent cfwEvent;

                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTermConnProcessEvents() -  Dialing for CFW Activation Completed, conn=%p, Line=%d",
                             conn, rvCCConnectionGetLineId(conn)));

                        cfwEvent = rvCCCfwHandleActivationCompleted(t, RV_TRUE, RV_IPP_CFW_SUCCESS);
                        /* During CFW activation SIP connection was created, we destruct
                           it now, since it is not needed after CFW is completed. This
                           must be done here since later we will loose info about the connection */
                        rvProcessEvent(otherParty, RV_CCTERMEVENT_DISCONNECTED, RV_CCCAUSE_NORMAL);

                        return cfwEvent;
                    }
                    /* During Blind Transfer */
                    /* --------------------- */
                    else
                    {
                        if ((transferLineConnection != NULL) &&
                            ((call = rvCCConnectionGetCall(transferLineConnection)) != NULL) &&
                             (rvCCCallGetTransferType(call) == RV_CCCALL_TRANSFER_BLIND))
                        {
                            RvLogInfo(ippLogSource,
                                (ippLogSource, "rvCCTermConnProcessEvents() -  Dialing for Blind Transfer Completed, conn=%p, Line=%d",
                                conn, rvCCConnectionGetLineId(conn)));

                            /* Disconnect MDM connection that was used only for collecting digits */
                            rvCCConnectionSetTransferLine(conn, NULL);
                            rvProcessEvent(conn,RV_CCTERMEVENT_DISCONNECTING, RV_CCCAUSE_TRANSFER);
                            /* Release SIP connection here otherwise we won't be able to do it later */
                            rvProcessEvent(otherParty, RV_CCTERMEVENT_DISCONNECTED, RV_CCCAUSE_NORMAL);

                            /* No real use for the transfer line field in the transfer line connection,
                               since it was disconnecting before */
                            rvCCConnectionSetTransferLine(transferLineConnection, NULL);
                            /* Continue Transfer process on the line with the original call */
                            rvProcessEvent(transferLineConnection, RV_CCTERMEVENT_TRANSFER, RV_CCCAUSE_TRANSFER);
                            return RV_CCTERMEVENT_NONE;
                        }
                        /* All other cases */
                        /* --------------- */
                        else
                        {
                            RvCCMediaState mediaState;
							RvMtfOfferAnswerState oldOfferAnswerState;

                            RvLogInfo(ippLogSource,
                                (ippLogSource, "rvCCTermConnProcessEvents() -  Dialing Completed, About to Create Media for conn=%p, Line=%d",
                                conn, rvCCConnectionGetLineId(conn)));

                            rvCCConnectionSetConnectParty(conn, otherParty);

							/* Change offer_answer state to offer_building. This is done in the otherParty object */
							oldOfferAnswerState = rvCCConnSipGetOfferAnswerState(otherParty);
							rvCCConnSipSetOfferAnswerState(otherParty, RV_MTF_OFFERANSWER_OFFER_BUILDING);

							/* Open outgoing media stream */
                            mediaState = rvCCConnectionCreateMedia(conn, NULL);
                            rvCCConnectionSetMediaState(conn, mediaState);
                            if (mediaState == RV_CCMEDIASTATE_FAILED)
                            {
                                RvLogError(ippLogSource,
                                    (ippLogSource, "rvCCTermConnProcessEvents() -  Failed to Create Media for conn=%p, Line=%d",
                                    conn, rvCCConnectionGetLineId(conn)));

								/* Failed to build an offer - change offer_answer state back to its
								   previous state */
								rvCCConnSipSetOfferAnswerState(otherParty, oldOfferAnswerState);

                                return RV_CCTERMEVENT_MEDIAFAIL;
                            }

                            rvCCConnectionSetState(conn, RV_CCCONNSTATE_ADDRESS_ANALYZE);
                            if (mediaState == RV_CCMEDIASTATE_CREATED)
                            {
                                RvLogInfo(ippLogSource,
                                    (ippLogSource, "rvCCTermConnProcessEvents() -  Media Was Created Successfully for conn=%p, Line=%d",
                                    conn, rvCCConnectionGetLineId(conn)));
                                return RV_CCTERMEVENT_MEDIAOK;
                            }
                        }
                    }
                }

                /* Address Analyze failed */
                /* -----------------------*/
                else
                {
                    /* During CFW activation */
                    /* --------------------- */
                    if (rvCCTerminalGetState(t) == RV_CCTERMINAL_CFW_ACTIVATING_STATE)
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTermConnProcessEvents() -  No Destination Address was Found for CFW Activation for conn=%p, Line=%d",
                            conn, rvCCConnectionGetLineId(conn)));

                        /* User dialed wrong number while activating CFW, complete CFW with failure*/
                        return (rvCCCfwHandleActivationCompleted(t, RV_FALSE, RV_IPP_CFW_ADDRESS_NOT_FOUND));

                    }
                    /* All other cases */
                    /* --------------- */
                    else
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTermConnProcessEvents() -  No Destination Address was Found for conn=%p, Line=%d",
                            conn, rvCCConnectionGetLineId(conn)));

                        if (*cause == RV_CCCAUSE_BUSY)
                        {
                            rvCCTerminalMdmStartBusySignal(t);
                        }
                        else
                        {
                            rvCCTerminalMdmStartWarningSignal(t);
                        }

                        rvCCConnectionSetState(conn, RV_CCCONNSTATE_FAILED);

                        return RV_CCTERMEVENT_NONE;
                    }
                }

                break;

            default:
                break;
        /*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MAKECALL     */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_MAKECALL:
        /* New call is established */
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_IDLE)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_OFFERED);
            /* Open media stream */
            if (rvCCConnectionOfferedCB(conn, *cause) == RV_CCMEDIASTATE_CREATED)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  Media was created successfully for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));

                return RV_CCTERMEVENT_MEDIAOK;
            }
            else
            {
                /* Remote media capabilities are not supported */
                if (conn->mediaState == RV_CCMEDIASTATE_NOTSUPPORTED)
                {
                    return RV_CCTERMEVENT_MEDIANOTACCEPTED;
                }
                /* We failed creating media for some reason */
                else
                {
                    return RV_CCTERMEVENT_MEDIAFAIL;
                }
            }
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_RINGBACK     */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_RINGBACK:
        /* Outgoing call before remote party answered */
        if ((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_INPROCESS) ||
            (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CALL_DELIVERED) ||
            /* In case of Blind or Semi-Attended Transfer allow user B to play ringback tone
               until C answers  although its state is Connected.*/
            (rvCCConnectionGetTransferLine(conn) != NULL))
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_CALL_DELIVERED);
            rvCCConnectionCallDeliveredCB(conn, *cause);
            return RV_CCTERMEVENT_NONE; /* Wait for RV_CCTERMEVENT_CALLANSWERED event*/
        }
        else
        {
            /* During Attended-Transfer, user B is waiting for C to answer */
            if(rvCCConnectionGetState(conn) == RV_CCCONNSTATE_TRANSFER_INPROCESS)
            {
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_DELIVERED);
                rvCCConnectionCallDeliveredCB(conn, RV_CCCAUSE_TRANSFER);
                return RV_CCTERMEVENT_NONE; /* Wait for RV_CCTERMEVENT_CALLANSWERED event*/
            }
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_RINGING      */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_RINGING:
        /* Incoming call before local party answered */
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_OFFERED)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_ALERTING);
            /* Check if there is a free connection to take the call */
            if (rvCCTerminalGetNumActiveConnections(t) > rvCCTerminalGetNumberOfLines(t))
            {
                RvLogWarning(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  No free connection was found, Rejecting call for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));

                /* Call is rejected, no free line */
                *cause = RV_CCCAUSE_BUSY;
                return RV_CCTERMEVENT_REJECTCALL;
            }
            rvCCCallAlerting(conn, *cause);
			if ((provider->autoAnswer == RV_TRUE) && (*cause != RV_CCCAUSE_CALL_WAITING))
			{
				RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  auto answer is on, answering call for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));
				return RV_CCTERMEVENT_OFFHOOK; /* Auto answer */
			}
			else
			{
				RvLogDebug(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  either auto answer is off or this is call waiting, waiting for user to answer call for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));
				return RV_CCTERMEVENT_NONE; /* Wait for RV_CCTERMEVENT_OFFHOOK event*/
			}
        }
        else
        {
            /* During Transfer, user C received a call from user B */
            if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_TRANSFER_OFFERED)
            {
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_ALERTING);
                rvCCCallAlerting(conn, RV_CCCAUSE_TRANSFER);
                return RV_CCTERMEVENT_OFFHOOK;
            }
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_CALLANSWERED */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_CALLANSWERED:
        switch (rvCCConnectionGetState(conn))
        {
        case RV_CCCONNSTATE_CALL_DELIVERED: /*for outgoing call*/
        case RV_CCCONNSTATE_TRANSFER_DELIVERED: /*for outgoing call*/
        case RV_CCCONNSTATE_INPROCESS:
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_CONNECTED);
            rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
            rvCCCallConnected(conn, *cause);
            break;

        case RV_CCCONNSTATE_CONNECTED:
            rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
            break;

        default:
            break;
        /*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_ONHOOK       */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_ONHOOK:
        /*Local side disconnected the call*/
        if (rvCCConnectionGetState(conn) != RV_CCCONNSTATE_DISCONNECTED)
        {
            /*Local side was the first to disconnect the call*/
            return RV_CCTERMEVENT_DISCONNECTING;
        }
        else
        {
            /*Remote side already disconnected */
            return RV_CCTERMEVENT_DISCONNECTED;
        }

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_FAILGENERAL  */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_FAILGENERAL:
        return RV_CCTERMEVENT_NONE;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MEDIAOK      */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_MEDIAOK:
        switch (rvCCConnectionGetState(conn))
        {
            case RV_CCCONNSTATE_ADDRESS_ANALYZE:
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_INPROCESS);
                rvCCConnectionInProcessCB(conn, RV_CCCAUSE_NEW_CALL);
                return RV_CCTERMEVENT_NONE; /* wait for RV_CCTERMEVENT_RINGBACK event*/

            case RV_CCCONNSTATE_TRANSFER_INIT:
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_INPROCESS);
                rvCCConnectionTransferInProcessCB(conn);
                return RV_CCTERMEVENT_NONE; /* wait for RV_CCTERMEVENT_RINGBACK event*/

            case RV_CCCONNSTATE_CONNECTED:
                /* Media was created after call was connected */
                rvCCConnectionMediaCreatedCB(conn);
                return RV_CCTERMEVENT_NONE;

            case RV_CCCONNSTATE_OFFERED:
                return RV_CCTERMEVENT_RINGING;

            case RV_CCCONNSTATE_TRANSFER_OFFERED:
                return RV_CCTERMEVENT_RINGING;

            default:
                break;
            /*lint -e{788}  all relevant cases are accounted for */
        }
        break;
	/*----------------------------------------------------------*/
	/*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MODIFYMEDIA_BY_UPDATE  */
    /*----------------------------------------------------------*/
	case RV_CCTERMEVENT_MODIFYMEDIA_BY_UPDATE:/*Outgoing request for dynamic media change*/
		{
			isUpdatePermitted = rvCCConnSipIsUpdatePermitted(otherParty);
			/* verify that update can be sent */
			if (isUpdatePermitted == RV_FALSE)
			{
				RvLogError(ippLogSource,
					(ippLogSource, "rvCCConnectionStateMachine() -  Can not send UPDATE request, UPDATE is not permitted at this stage for conn=%p, Line=%d",
					conn, rvCCConnectionGetLineId(conn)));

				break;
			}
		}
		/* else don't break !!!!  */
    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MODIFYMEDIA  */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_MODIFYMEDIA:/*Outgoing request for dynamic media change*/
	{
		RvCCMediaState mediaState = rvCCConnectionGetMediaState(conn);
		RvMdmMediaStreamInfo* newMedia = rvCCConnectionGetNewMedia(conn);

        if  (( isUpdatePermitted &&  (rvCCConnectionGetState(conn) != RV_CCCONNSTATE_CONNECTED))||
			((rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED) &&
            (mediaState != RV_CCMEDIASTATE_MODIFYING)&&
            (mediaState != RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED)&&
			(rvCCConnGetUpdateState(otherParty) ==  RV_CCUPDATESTATE_NONE)))
        {
			RvMtfOfferAnswerState oldOfferAnswerState;

            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCConnectionStateMachine() -  Dynamic Media Change was requested by Local user for conn=%p, Line=%d",
                 conn, rvCCConnectionGetLineId(conn)));

			/* if we got here due to UPDATE send request mark that we are sending UPDATE */
			if (isUpdatePermitted)
			{
				rvCCConnSetUpdateState(otherParty, RV_CCUPDATESTATE_SENT);
			}

            rvCCTextPrintMedia(conn, newMedia, "Dynamic Media Change Request", RV_LOGLEVEL_INFO);

			/* Change offer_answer state to offer_building */
			oldOfferAnswerState = rvCCConnSipGetOfferAnswerState(otherParty);
			rvCCConnSipSetOfferAnswerState(otherParty, RV_MTF_OFFERANSWER_OFFER_BUILDING);

            /* Send signaling message to remote party */
            if (rvCCCallModifyMediaCB(conn, newMedia) == RV_FALSE)
            {
                RvLogError(ippLogSource,
                    (ippLogSource, "rvCCConnectionStateMachine() -  Failed to send Dynamic Media Change to remote party for conn=%p, Line=%d",
                     conn, rvCCConnectionGetLineId(conn)));

				/* Failed to build an offer - change offer_answer state back to its
				   previous state */
				rvCCConnSipSetOfferAnswerState(otherParty, oldOfferAnswerState);

                rvCCConnectionModifyMediaDone(conn, RV_FALSE, newMedia, RV_MDMTERMREASON_LOCAL_FAILED);

				/* if it was UPDATE  request that failed reset the UPDATE state */
				if (isUpdatePermitted)
				{
					rvCCConnSetUpdateState(otherParty, RV_CCUPDATESTATE_NONE);
				}
            }
            else
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCConnectionStateMachine() -  Dynamic Media Change was sent - waiting for remote party reply, conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));

                /* We stay in this state until reply from remote party is received */
				if (mediaState == RV_CCMEDIASTATE_CREATED)
                    /* if a created media is modified we need to move to the modify before
					   connected media state so that in the end of the modify process we
					   move back to created and not to connected */
				    rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED);
				else
					rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_MODIFYING);
            }
        }
        else
        {
            /* A previous process of dynamic media change was not completed yet, can't start a
               new process until previous one completes */
            if ((mediaState == RV_CCMEDIASTATE_MODIFYING) ||
			    (mediaState == RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED))
            {
                RvLogWarning(ippLogSource,
                    (ippLogSource, "rvCCConnectionStateMachine() -  Request for Dynamic Media Change is ignored, previous process was not completed, conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));

                rvCCConnectionModifyMediaDone(conn, RV_FALSE, newMedia, RV_MDMTERMREASON_IN_PROCESS);
            }
        }
	}
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MODIFYMEDIA_DONE  */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_MODIFYMEDIA_DONE:/* Remote party reply was received */
        rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_CONNECTED);
        if (*cause == RV_CCCAUSE_OPERATION_FAILED)
        {
            RvLogWarning(ippLogSource,
                (ippLogSource, "rvCCConnectionStateMachine() -  Request for Dynamic Media Change was not accepted by remote party, conn=%p, Line=%d",
                conn, rvCCConnectionGetLineId(conn)));

            /* Remote party rejected our request to modify media during the call */
            rvCCCallModifyMediaDoneCB(conn, RV_FALSE, rvCCConnectionGetNewMedia(conn), RV_MDMTERMREASON_REMOTE_REJECTED);
        }
        else
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCConnectionStateMachine() -  Request for Dynamic Media Change was accepted by remote party, conn=%p, Line=%d",
                conn, rvCCConnectionGetLineId(conn)));

            /* Remote party accepted our request to modify media during the call */
            rvCCCallModifyMediaDoneCB(conn, RV_TRUE, rvCCConnectionGetNewMedia(conn), RV_MDMTERMREASON_SUCCESS);
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MEDIANOTACCEPTED  */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_MEDIANOTACCEPTED: /* We don't support media capabilities of remote party*/
        *cause = RV_CCCAUSE_MEDIA_NOT_SUPPORTED;
        /* no break!!! */
    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_MEDIAFAIL    */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_MEDIAFAIL: /* We failed to open local media */

        RvLogError(ippLogSource,
            (ippLogSource, "rvCCConnectionStateMachine() -  Failed to open local media for conn=%p, Line=%d",
            conn, rvCCConnectionGetLineId(conn)));

        rvCCConnectionSetState(conn, RV_CCCONNSTATE_FAILED);
        rvCCConnectionReject(conn, *cause);
        return RV_CCTERMEVENT_DISCONNECTING;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_REJECTCALL   */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_REJECTCALL: /* Local party rejected incoming new call */
        if(rvCCConnectionGetState(conn) == RV_CCCONNSTATE_ALERTING)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_ALERTING_REJECTED);
        }
        else
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_REJECTED);
        }

        rvCCCallDisconnectedRemote(conn, *cause);
        return RV_CCTERMEVENT_NONE;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_REJECT_KEY   */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_REJECT_KEY:
        /* We can reject calls only if they are alerting */
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_ALERTING)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCConnectionStateMachine() -  Processing Reject key for conn=%p, Line=%d",
                 conn, rvCCConnectionGetLineId(conn)));

            *cause = RV_CCCAUSE_BUSY;
            return RV_CCTERMEVENT_REJECTCALL;
        }
        return RV_CCTERMEVENT_NONE;

    /*------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_DISCONNECTING  */
    /*------------------------------------------------------------*/
    case RV_CCTERMEVENT_DISCONNECTING:
        if (rvCCConnectionGetState(conn) != RV_CCCONNSTATE_DISCONNECTED)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_DISCONNECTED);
            /*Reset digitmap only if local party hanged up (since there is one digitmap for each
              termination, we don't want that when remote party disconnects a
              call which is not the active one, it will effect digitmap of the active connection). */
            rvMdmTermDeactivateDigitMap(term);
            rvCCCallDisconnectedRemote(conn, *cause);
        }

        /* Remote side has already disconnected*/
        return RV_CCTERMEVENT_DISCONNECTED;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_DISCONNECTED */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_DISCONNECTED:
        rvCCConnectionSetState(conn, RV_CCCONNSTATE_DISCONNECTED);

        if (rvCCConnectionGetCall(conn) != NULL)
        {
            /* Inform the call that this connection was released before we release it*/
            *stillAlive = rvCCCallPartyReleased(conn);
        }
        else
        {
            /* In Blind Transfer call is NULL at this point */
            *stillAlive = RV_FALSE;
        }
		/* Release connection resources */
		rvCCConnectionRelease(conn);

        return RV_CCTERMEVENT_NONE;

	/*-----------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_REMOTE_DISCONNECTED */
    /*-----------------------------------------------------------------*/
	case RV_CCTERMEVENT_REMOTE_DISCONNECTED:
        if ((provider->autoDisconnect == RV_TRUE) && (conn->termState == RV_CCTERMCONSTATE_TALKING))
		{
			/* If autoDisconnect is on, go on hook after remote party disconnected.*/
			RvLogInfo(ippLogSource,
				(ippLogSource, "rvCCTermConnProcessEvents() -  auto disconnect is on, disconnecting line for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));
			return RV_CCTERMEVENT_ONHOOK;
        }
		else
		{
			RvLogDebug(ippLogSource,
				(ippLogSource, "rvCCTermConnProcessEvents() -  auto disconnect is off, waiting for user to disconnect line for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));
		}
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_HOLD         */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_HOLD:
        switch (rvCCConnectionGetState(conn))
        {
			case RV_CCCONNSTATE_INITIATED:
			case RV_CCCONNSTATE_DIALING:    /* when call failed or busy, */
			case RV_CCCONNSTATE_CALL_DELIVERED:  /* Hold is pressed on A while B is alerting */
			case RV_CCCONNSTATE_DISCONNECTED: /*Pressing on Hold will disconnect*/
			case RV_CCCONNSTATE_FAILED:
				return RV_CCTERMEVENT_DISCONNECTING;

			case RV_CCCONNSTATE_CONNECTED:
				/* Send signaling message for Hold to remote party */
				if (rvCCCallHold(conn, RV_CCCAUSE_LOCAL_HOLD) == RV_TRUE)
				{
					/* Modify media of local party to be on Hold */
					rvCCConnectionTermHold(conn);
				}
				else
				{
					/* Local party failed to put media on Hold, Hold is not processed*/
					rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_TALKING);
					return RV_CCTERMEVENT_NONE;
				}
				break;

			default:
				break;
			/*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_UNHOLD       */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_UNHOLD:
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
        {
			RvMdmMediaStreamInfo   streamDescr;

            /* Modify local media to be connected again */
            rvCCConnectionTermUnhold(conn, &streamDescr);
            /* Send signaling message of Unhold to remote party */
            rvCCCallTalking(conn, &streamDescr, RV_CCCAUSE_NORMAL);
        }
        break;

    /*----------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_TRANSFER     */
    /*----------------------------------------------------------*/
    case RV_CCTERMEVENT_TRANSFER:
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED ||
            rvCCConnectionGetState(conn) == RV_CCCONNSTATE_INPROCESS ||
            rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CALL_DELIVERED)
        {
            /* This function will cause Transfer process to start... */
            rvCCCallDisconnectedRemote(conn, RV_CCCAUSE_TRANSFER);
            return RV_CCTERMEVENT_NONE;
        }
        break;

    /*-------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_TRANSFER_INIT   */
    /*-------------------------------------------------------------*/
    case RV_CCTERMEVENT_TRANSFER_INIT: /* TODO: Do we ever get here?? */
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_INIT);
            rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_CREATING);
            if (rvCCConnectionTransferInitCB(conn) == RV_CCMEDIASTATE_CREATED)
            {
                return RV_CCTERMEVENT_MEDIAOK;
            }
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_TRANSFER_OFFERED  */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_TRANSFER_OFFERED:
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_OFFERED);
            rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_CREATING);
            if (rvCCConnectionTransferOfferedCB(conn) == RV_CCMEDIASTATE_FAILED)
            {
                RvLogError(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  Failed to Create Media During Transfer for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));

                return RV_CCTERMEVENT_MEDIAFAIL;
            }
            else
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTermConnProcessEvents() -  Media Created Successfully During Transfer for conn=%p, Line=%d",
                    conn, rvCCConnectionGetLineId(conn)));

                return RV_CCTERMEVENT_MEDIAOK;
            }
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCConnectionStateMachine: RV_CCTERMEVENT_CONFERENCE        */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_CONFERENCE:
        if (rvCCConnectionGetState(conn) == RV_CCCONNSTATE_CONNECTED)
        {
            /* Let the call know that there is a new call in the conference */
            rvCCConnectionConferenceJoinedCB(conn);
            return RV_CCTERMEVENT_NONE;
        }
        break;

    default:
        return RV_CCTERMEVENT_UNKNOWN;
   /*lint -e{788}  all relevant cases are accounted for */
    }

    return RV_CCTERMEVENT_NONE;
}


static RvCCTerminalEvent setActiveAudioTerminal (
                RvCCTerminal*      t,
                RvCCTerminalEvent  event)
{
    /* First press, need to check if we have the appropriate audio termination and set it*/
    switch (event)
    {
        case RV_CCTERMEVENT_OFFHOOK:
        case RV_CCTERMEVENT_LINE:
            if (rvCCTerminalMdmIsAudioTerminationExist(t, RV_CCTERMAUDIO_HANDSET) == RV_TRUE)
            {
                rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSET);
            }
            else
            {
                event = RV_CCTERMEVENT_NONE;
            }
            break;

        case RV_CCTERMEVENT_HANDSFREE:
            if (rvCCTerminalMdmIsAudioTerminationExist(t, RV_CCTERMAUDIO_HANDSFREE) == RV_TRUE)
            {
                rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HANDSFREE);
                rvCCTerminalMdmSetAudioInd(t, "hf", RV_INDSTATE_ON);
                event = RV_CCTERMEVENT_OFFHOOK;
            }
            else
            {
                event = RV_CCTERMEVENT_NONE;
            }
            break;

        case RV_CCTERMEVENT_HEADSET:
            if (rvCCTerminalMdmIsAudioTerminationExist(t, RV_CCTERMAUDIO_HEADSET) == RV_TRUE)
            {
                rvCCTerminalMdmSetActiveAudio(t, RV_CCTERMAUDIO_HEADSET);
                rvCCTerminalMdmSetAudioInd(t, "ht", RV_INDSTATE_ON);
                event = RV_CCTERMEVENT_OFFHOOK;
            }
            else
            {
                event = RV_CCTERMEVENT_NONE;
            }
            break;

        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    return event;
}



/* Process an event related to a change in the state of the active audio */
static RvCCTerminalEvent rvProcessAudioTermEvent(
                RvCCTerminal*      t,
                RvCCConnection*    c,
                RvCCTerminalEvent  event)
{
    RvCCTerminal*           newAt = NULL;
    RvCCTerminal*           oldAt = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvCCTerminalAudioType   activeAt = RV_CCTERMAUDIO_NONE;
    RvCCTerminalAudioType   atType = RV_CCTERMAUDIO_NONE;

    /* If all connections are Idle, or the active connection is in ALERTING state,
       we know that its a new call */
    if ((rvCCTerminalGetNumActiveConnections(t) == 0) ||
        (rvCCConnectionGetState(rvCCTerminalGetActiveConnection(t)) == RV_CCCONNSTATE_ALERTING))
    {
       return setActiveAudioTerminal(t, event);
    }

    activeAt = rvCCTerminalMdmGetActiveAudio(t);

    switch(event)
    {
        case RV_CCTERMEVENT_OFFHOOK:
            newAt = rvCCTerminalMdmGetHandsetTerm(t);
            event = RV_CCTERMEVENT_AUDIOHANDSET;
            if (rvCCTerminalMdmMoveSignals(oldAt, newAt) == RV_FALSE)
            {
                event = RV_CCTERMEVENT_NONE;
            }
            else
            {
                rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt], RV_INDSTATE_OFF);
            }
            break;

        case RV_CCTERMEVENT_ONHOOK:
            switch(activeAt)
            {
                case RV_CCTERMAUDIO_HANDSET:
                    break;
                case RV_CCTERMAUDIO_HANDSFREE:
                case RV_CCTERMAUDIO_HEADSET:
                    event = RV_CCTERMEVENT_NONE;
                    break;
                case RV_CCTERMAUDIO_NONE:
                default:
                    break;
            }
            break;

        case RV_CCTERMEVENT_LINE:
            rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt],
                (rvCCConnectionIsCallOnHold(c) == RV_FALSE) ? RV_INDSTATE_OFF : RV_INDSTATE_ON);
            break;

        case RV_CCTERMEVENT_HANDSFREE:
            switch(activeAt)
            {
                case RV_CCTERMAUDIO_HANDSFREE:
                    if (rvCCConnectionIsCallOnHold(c) == RV_FALSE)
                    {
                       if (t->audioTermState & RV_CCAUDIOTERM_HT_ACTIVE)
                       {
                          newAt = rvCCTerminalMdmGetHeadsetTerm(t);
                          atType = RV_CCTERMAUDIO_HEADSET;
                       }
                       else
                       {
                           if (t->audioTermState  & RV_CCAUDIOTERM_HS_ACTIVE)
                           {
                              newAt = rvCCTerminalMdmGetHandsetTerm(t);
                              atType = RV_CCTERMAUDIO_HANDSET;
                           }
                           else
                           {
                               /* There are no active HANDSET or HEADSET */
                               event = RV_CCTERMEVENT_ONHOOK; /* this time we send ONHOOK to terminate this call*/
                           }

                           if (newAt)
                           {
                                if (rvCCTerminalMdmMoveSignals(oldAt, newAt) == RV_FALSE)
                                {
                                    event = RV_CCTERMEVENT_NONE;
                                }
                           }
                           rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt], RV_INDSTATE_OFF);
                       }
                    }
                    else
                    {
                        /* if the connection is in hold state we need new line*/
                        event = RV_CCTERMEVENT_OFFHOOK;
                    }
                    break;

                case RV_CCTERMAUDIO_HEADSET:
                case RV_CCTERMAUDIO_HANDSET:
                    if (rvCCConnectionIsCallOnHold(c) == RV_FALSE)
                    {
                        newAt = rvCCTerminalMdmGetHandsfreeTerm(t);
                        if (rvCCTerminalMdmMoveSignals(oldAt,newAt) == RV_FALSE)
                        {
                            event = RV_CCTERMEVENT_NONE;
                        }
                        else
                        {
                            rvCCTerminalMdmSetAudioInd(t,"hf", RV_INDSTATE_ON);
                        }
                    }
                    else
                    {
                        /*if the connection is in hold state we need new line*/
                        event = RV_CCTERMEVENT_OFFHOOK;
                        rvCCTerminalMdmSetAudioInd(t,"hf", RV_INDSTATE_ON);
                        rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt], RV_INDSTATE_OFF);
                    }
                    break;

                case RV_CCTERMAUDIO_NONE:
                default:
                    break;
            }
            break;

        case RV_CCTERMEVENT_HEADSET:
            switch(activeAt)
            {
                case RV_CCTERMAUDIO_HEADSET:
                    if (rvCCConnectionIsCallOnHold(c) == RV_FALSE)
                    {
                       /* Turn OFF HT bit */
                       t->audioTermState &= ~RV_CCAUDIOTERM_HT_ACTIVE;

                       if (t->audioTermState & RV_CCAUDIOTERM_HS_ACTIVE)
                       {
                          newAt = rvCCTerminalMdmGetHandsetTerm(t);
                          atType = RV_CCTERMAUDIO_HANDSET;
                       }
                       else
                       {
                           if (t->audioTermState & RV_CCAUDIOTERM_HF_ACTIVE)
                           {
                              newAt = rvCCTerminalMdmGetHandsfreeTerm(t);
                              atType = RV_CCTERMAUDIO_HANDSFREE;
                           }
                           else
                           {
                               /* There are no active HANDSET or HEADSET */
                                event = RV_CCTERMEVENT_ONHOOK; /* this time we send ONHOOK to terminate this call*/
                           }

                           if (newAt)
                           {
                              if (rvCCTerminalMdmMoveSignals(oldAt,newAt) == RV_FALSE)
                              {
                                 event = RV_CCTERMEVENT_NONE;
                              }
                           }

                           rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt], RV_INDSTATE_OFF);
                       }
                    }
                    else
                    {
                        /* if the connection is in hold state we need new line*/
                        event = RV_CCTERMEVENT_OFFHOOK;
                        rvCCTerminalMdmSetAudioInd(t, "ht", RV_INDSTATE_ON);
                    }
                    break;

                case RV_CCTERMAUDIO_HANDSFREE:
                case RV_CCTERMAUDIO_HANDSET:
                    if (rvCCConnectionIsCallOnHold(c) == RV_FALSE)
                    {
                        newAt = rvCCTerminalMdmGetHeadsetTerm(t);
                        if (rvCCTerminalMdmMoveSignals(oldAt,newAt) == RV_FALSE)
                        {
                            event = RV_CCTERMEVENT_NONE;
                        }
                        else
                        {
                            rvCCTerminalMdmSetAudioInd(t,"ht", RV_INDSTATE_ON);
                            rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt], RV_INDSTATE_OFF);
                        }
                    }
                    else
                    {
                        /*if the connection is in hold state we need new line*/
                        event = RV_CCTERMEVENT_OFFHOOK;
                        rvCCTerminalMdmSetAudioInd(t,"ht", RV_INDSTATE_ON);
                        rvCCTerminalMdmSetAudioInd(t, pkgName[activeAt], RV_INDSTATE_OFF);
                    }
                    break;

                case RV_CCTERMAUDIO_NONE:
                default:
                    break;
            }
            break;

        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    /* returned event maybe changed */
    return event;
}

/*===============================================================================*/
/*========    T E R M I N A L   S T A T E   M A C H I N E    ====================*/
/*===============================================================================*/

/* First processing of event, decide is active connection has to change
   translate event if needed and propagate it*/
void rvCCTerminalProcessEventId(
                RvCCTerminal*           t,
                RvCCTerminalEvent       eventId,
                char*                   keyId,
                RvCCCallMgr*            callMgr,
                RvMdmMediaStreamInfo*   media)
{
    RvCCConnection*         c;
    RvCCConnection*         otherConn = NULL;
    RvCCConnection*         transferLineConnection = NULL;
    RvCCCallTransferType    transferType;
    RvCCCall*               call;
    RvCCCallState           callState = RV_CCCALLSTATE_NORMAL;
    RvCCTerminalEvent       origEventId = eventId;
    RvCCEventCause          reason = RV_CCCAUSE_NORMAL;
	RvInt                   lineId;
	RvInt					maxConnections = rvCCTerminalGetNumberOfLines(t);
#ifdef RV_MTF_H323
	int						protocolId;
	RvCCConnection*			netConn = NULL;
#endif
#ifdef USE_GPON_OVERSEA_VERSION
    RvSipStackHandle hStack;
    RvCountryId   countryId;
    hStack=rvMtfBaseGetSipStack();
    countryId=RvSipStackGetRegionId(hStack);  
#endif	
    c = rvCCTerminalGetActiveConnection(t);

	if(NULL == c)
	{
		RvLogWarning(ippLogSource,
			(ippLogSource, "rvCCTerminalProcessEventId() - rvCCTerminalGetActiveConnection return NULL! term=%p",t));
		return;
	}

    RvMutexLock(&t->activeConnMutex, IppLogMgr());

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCTerminalProcessEventId() -  Processing <event (%s) reason (%s)> for  conn=%p, Line=%d, termConnState=%s, connState=%s",
        rvCCTextEvent(eventId), rvCCTextCause(reason), c, rvCCConnectionGetLineId(c),
        rvCCTextTermConnState(rvCCConnectionGetTermState(c)), rvCCTextConnState(rvCCConnectionGetState(c))));

    switch(eventId)
    {
    case RV_CCTERMEVENT_NONE:
    case RV_CCTERMEVENT_UNKNOWN:
        RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
        return;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_BLIND_TRANSFER    */
    /*                              RV_CCTERMEVENT_TRANSFER          */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_BLIND_TRANSFER:
    case RV_CCTERMEVENT_TRANSFER:

        call = rvCCConnectionGetCall(c);

        /* Ignore Transfer keys if:
            o Call is not in Normal or Transfer state (for example, in Conference state)
            o Connection does not belong to the active call
            o Call is on Hold */
        if ((call == NULL) ||
             // YOCHI h.e: try to remove this condition: (rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_HELD)||
            ((rvCCCallGetState(call) != RV_CCCALLSTATE_NORMAL) &&
             (rvCCCallGetState(call) != RV_CCCALLSTATE_TRANSFER_INIT)
#ifdef  USE_GPON_OVERSEA_VERSION		/*add by Happy Su*/	 
			 &&(rvCCCallGetState(call) != RV_CCCALLSTATE_CONFERENCE_COMPLETED&&countryId==COUNTRY_NORTH_AMERICA)
#endif			 
			 ))
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer key is ignored for conn=%p, Line=%d",
                 c, rvCCConnectionGetLineId(c)));

            RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
            return;
        }

        /* Second pressing on Transfer key, second part of Transfer process */

        if (eventId == RV_CCTERMEVENT_BLIND_TRANSFER)
        {
        /* Ignore Blind Transfer key if:
            o Call is not Connected, i.e, user B didn't answer.
            o Transfer line is not NULL, may happen if by mistake user press Transfer button,
              and then pressed Blind Transfer button */
            if ((rvCCConnectionGetState(c) != RV_CCCONNSTATE_CONNECTED) ||
                ((transferLineConnection = rvCCConnectionGetTransferLine(c)) != NULL))
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Blind Transfer key is ignored for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                return;
            }
            rvCCCallSetTransferType(call, RV_CCCALL_TRANSFER_BLIND);
        }
        else
        {
            /* ATTENDED TRANSFER */
            /* ----------------- */
            switch (rvCCConnectionGetState(c))
            {
            case RV_CCCONNSTATE_INPROCESS:
            case RV_CCCONNSTATE_CALL_DELIVERED:
                /* Semi-Attended Transfer */
                /* ---------------------- */

                /* Since call with C is not connected, this is Semi-Attended Transfer */

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Semi-Attended Transfer for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                /* Save the transfer line, since it becomes NULL when terminating line 2 */
                transferLineConnection = rvCCConnectionGetTransferLine(c);
                if (transferLineConnection == NULL)
                {
                    /* "New" Transfer (Transfer on a Held Call) */
                    /*----------------------------------------- */
                    /* If another call exists and its on Hold, store all information needed
                       and start a Transfer process (as if Transfer key was press second time) */
                    if (rvCCTerminalMdmOtherHeldConnExist(t, c))
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Semi-Attended Transfer on a Held Call for conn=%p, Line=%d",
                             c, rvCCConnectionGetLineId(c)));

                        transferLineConnection = rvCCTerminalMdmGetHoldingConn(t);
                        if (transferLineConnection == NULL)
                        {
                            RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                            return;
                        }
                    }
                    else
                    {
                        RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                        return;
                    }
                }
                else
                {
                 /* Ignore Transfer key if user B presses Transfer while he's already involved
                    in Transfer process which was initiated by remote party.
                    Note: we know we're in this state when transferLineConnection is not NULL,
                    and Transfer type of transferLineConnection is RV_CCCALL_TRANSFER_NONE, until
                    we have an appropriate state for user B*/
                    if (((transferLineConnection->call)->transferType) == RV_CCCALL_TRANSFER_NONE)
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer key is ignored for conn=%p, Line=%d",
                             c, rvCCConnectionGetLineId(c)));

                        RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                        return;
                    }
                }


                 /*zxs mod */
                /* Now we want Semi-Attended Transfer to continue as Blind Transfer process */
                #if USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/11/22 */
                rvCCConnectionSetTransferType(transferLineConnection, RV_CCCALL_TRANSFER_BLIND);
                #else
                rvCCConnectionSetTransferType(transferLineConnection, RV_CCCALL_TRANSFER_FULL);
                #endif

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Semi-Attended Transfer - Cancelling Second Call, conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                /*zxs mod */
                #if USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/11/22 */
                /* Send Cancel to user C to terminate the call with him */
                rvProcessEvent(c,RV_CCTERMEVENT_REJECTCALL, RV_CCCAUSE_CALL_CANCELLED);
                #endif 

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Continue Semi-Attended Transfer for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));


                /* Continue with processing line 1 as Blind Transfer */
                rvProcessEvent(transferLineConnection, RV_CCTERMEVENT_TRANSFER, RV_CCCAUSE_TRANSFER);

                break;
            case RV_CCCONNSTATE_CONNECTED:
                /* Full-Attended Transfer */
                /* ---------------------- */

                /* Since call with C is connected, this is Full-Attended Transfer */

#ifdef RV_MTF_H323

				/*Attended transfer is not supported for H323. In order to know the used protocol*/
				/*Check the protocol of the connected call */

				netConn = rvCCConnectionGetConnectParty(c);
				if (netConn != NULL)
				{
					if (netConn->funcs->getProtocolIdF()!= 0)
					{
						protocolId =  netConn->funcs->getProtocolIdF();
						if (protocolId == RV_MTF_PROTOCOL_H323)
						{
						   RvLogInfo(ippLogSource,
						   (ippLogSource, "rvCCTerminalProcessEventId() -  Attended Transfer is not supported for H323 protocol"));

						   RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
						   return;
						}
					}
				}
#endif
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Attended Transfer for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                rvCCCallSetTransferType(call, RV_CCCALL_TRANSFER_FULL);
                break;
            default:
                RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                return;
                /*lint -e{788}  all relevant cases are accounted for */
            }
        }

        /*ALL TRANSFER TYPES*/
        /*------------------*/

        /* First pressing on Transfer key, first part of Transfer process */

        if (rvCCCallGetState(call) == RV_CCCALLSTATE_NORMAL
/*add by Happy Su 2011-11-25*/
#if USE_GPON_OVERSEA_VERSION
		||rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED&&countryId==COUNTRY_NORTH_AMERICA
#endif
	)
        {
         RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCTerminalProcessEventId() -  Processing <event (%s) reason (%s)> for  conn=%p, Line=%d, termConnState=%s, connState=%s",
                rvCCTextEvent(eventId), rvCCTextCause(reason), c, rvCCConnectionGetLineId(c),
                rvCCTextTermConnState(rvCCConnectionGetTermState(c)), rvCCTextConnState(rvCCConnectionGetState(c))));

            /* "New" Transfer (Transfer on a Held Call) */
            /*----------------------------------------- */
            /* If another call exists on Hold, store all information needed and start a Transfer
               process (as if Transfer key was press second time) */
            if ( rvCCTerminalMdmOtherHeldConnExist(t, c) /*&&*/
                /* We don't want to handle Transfer on a held call when its a Blind Transfer */
                /*(rvCCCallGetTransferType(call) != RV_CCCALL_TRANSFER_BLIND)*/)
            {
                otherConn = rvCCTerminalMdmGetHoldingConn(t);
                if (otherConn != NULL)
                {
                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Transfer on a Held Call for conn=%p, Line=%d and conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c), otherConn, rvCCConnectionGetLineId(otherConn)));

                    rvCCCallSetTransferParties(otherConn, c);
                    rvCCConnectionSetTransferState(otherConn, RV_CCCONNSTATE_TRANSFERROR_1ST_CALL);
                    rvCCConnectionSetTransferState(c, RV_CCCONNSTATE_TRANSFERROR_2ND_CALL);
                }
            }
#if USE_GPON_OVERSEA_VERSION	 /*Add by Happy Su*/		
            else if(rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED&&countryId==COUNTRY_NORTH_AMERICA)/*Add by Happy Su 2011-11-25*/
            {
            	  int i=0;
		  i=rvCCTerminalFindNextActiveConnection(t,c);
		  if(i!=-1)
		  {
                    otherConn=rvCCTerminalGetConnectionByIndex(t,i);
		  }
                if (otherConn!=NULL)
                {

                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Transfer on a conference Call for conn=%p, Line=%d and conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c), otherConn, rvCCConnectionGetLineId(otherConn)));

                    rvCCCallSetTransferParties(otherConn, c);
                    rvCCConnectionSetTransferState(otherConn, RV_CCCONNSTATE_TRANSFERROR_1ST_CALL);
                    rvCCConnectionSetTransferState(c, RV_CCCONNSTATE_TRANSFERROR_2ND_CALL);
                }
            }
#endif			
	     else
            {
                if((otherConn = rvCCTerminalFindFreeConnection(t)) == NULL)
                {
                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer key ignored, no free connection was found, conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));

                    /*No more free connections are available*/
                    RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                    return;
                }

                rvCCConnectionSetTransferState(c, RV_CCCONNSTATE_TRANSFERROR_1ST_CALL);

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer Process - put first call on Hold, conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                /* Put previous active connection on Hold */
                rvProcessEvent(c, RV_CCTERMEVENT_HOLD, RV_CCCAUSE_NORMAL);

                if ((rvCCConnectionGetTermState(c) != RV_CCTERMCONSTATE_HELD) &&
				    (rvCCConnectionGetTermState(c) != RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD))
                {
                    RvLogError(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer Process - failed to put call on Hold, conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));

                    /*In case remote Hold failed*/
                    RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                    return;
                }

                if (rvCCCallGetTransferType(call) != RV_CCCALL_TRANSFER_BLIND)
                {
                    rvCCCallSetTransferParties(c, otherConn);
                    rvCCConnectionSetTransferState(otherConn, RV_CCCONNSTATE_TRANSFERROR_2ND_CALL);
                }
                else
                {
                    rvCCConnectionSetTransferLine(c, otherConn);
                    rvCCConnectionSetTransferLine(otherConn, c);
                    if (rvCCConnectionGetCall(otherConn) == NULL)
                    {
                        rvInitNewCall(callMgr, otherConn);
                    }
                }
                rvCCTerminalSetActiveConnectionId(t, rvCCConnectionGetLineId(otherConn)-1);
                c = otherConn;
                eventId = RV_CCTERMEVENT_LINE;
            }
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_CONFERENCE        */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_CONFERENCE:
	{
		RvBool noAvailableConn = rvTrue;

		/* Ignore Conference key if connection is not in an active call, or if call is on Hold*/
        call = rvCCConnectionGetCall(c);
		if (((rvCCConnectionGetState(c) != RV_CCCONNSTATE_CONNECTED) ||
			 (rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_HELD )) &&
			 (call == NULL))

        {
            RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
            return;
        }
     /*Happy su add for FUJIAN, before come into conference, two line is on hold state*/
    RvLogInfo(ippLogSource,(ippLogSource,"for FUJIAN conference,must unhold the second call,otherwise the second call will keep hold\n"));
    if(rvCCConnectionGetTermState(c)==RV_CCTERMCONSTATE_HELD)
        rvProcessEvent(c, RV_CCTERMEVENT_UNHOLD, RV_CCCAUSE_NORMAL);
    /*add end*/
#ifndef RV_MTF_N_LINES
        if (rvCCCallGetState(call) == RV_CCCALLSTATE_NORMAL)
        {
#else
		if ((rvCCCallGetState(call) == RV_CCCALLSTATE_NORMAL) ||
			(rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED))
		{

		/* Perform "conference on a held" call only for Analog lines, or ipphones with 2 lines */
		if (rvCCTerminalGetNumberOfLines(t) <= RV_CCTERMINAL_ANALOG_MAX_LINES)
		{
#endif /* RV_MTF_N_LINES */

            /* "New" Conference (Conference on a Held Call) */
            /*--------------------------------------------- */
            /* If another call exists on Hold, store all information needed and start a Conference
               process (as if Conference key was press second time)*/
            if (rvCCTerminalMdmOtherHeldConnExist(t, c))
            {
                otherConn = rvCCTerminalMdmGetHoldingConn(t);
                if (otherConn != NULL)
                {
                    RvCCCall*       otherConnCall = rvCCConnectionGetCall(otherConn);
                    RvCCConnection* otherConnParty = rvCCConnectionGetConnectParty(otherConn);

                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Conference on a Held Call for conn=%p, Line=%d and conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c), otherConnParty, rvCCConnectionGetLineId(otherConnParty)));

                    /*Move the held connection and its party to the active call*/
                    rvCCCallMgrMoveConnection(callMgr, otherConnCall, call, otherConn);
                    rvCCCallMgrMoveConnection(callMgr, otherConnCall, call, otherConnParty);

                    /* The new connection goes into the same call as the existing connection */
                    rvCCCallSetConference(call, otherConn);

                }
				noAvailableConn = rvFalse;
            }
#ifdef RV_MTF_N_LINES
		}
		if (noAvailableConn == rvTrue)
		{
#else
		else
        {
#endif /* RV_MTF_N_LINES */

            /* First part of Conference */
            /*------------------------- */

                if ((rvCCTerminalGetNumActiveConnections(t) == rvCCTerminalGetNumberOfLines(t)) ||
                    ((otherConn = rvCCTerminalFindFreeConnection(t)) == NULL))
                {
                    RvLogWarning(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Conference key is ignored, no free connection was found, conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));

                    /*No more connections are available*/
                    RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                    return;
                }

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Starting Conference, putting first call on Hold for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                /* First we need to put first call on Hold */
                rvProcessEvent(c, RV_CCTERMEVENT_HOLD, RV_CCCAUSE_NORMAL);

                /* The new connection goes into the same call as the existing connection */
                rvCCCallAddConferenceParty(call, otherConn);

                /* Select the new active connection */
                rvCCTerminalSetActiveConnectionId(t, rvCCConnectionGetLineId(otherConn)-1);
                c = otherConn;

                eventId = RV_CCTERMEVENT_LINE;
            }
        }
        /* Second part of Conference */
        /*------------------------- */
#ifdef RV_MTF_N_LINES
        else
        {
            if (rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Disconnecting Conference for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                /*Conference key will disconnect the conference call if it's active already*/
                eventId = RV_CCTERMEVENT_ONHOOK;
                /* The active indicator should be set to off */
                rvCCTerminalMdmSetAudioInd(t, pkgName[rvCCTerminalMdmGetActiveAudio(t)], RV_INDSTATE_OFF);
            }
#endif /* RV_MTF_N_LINES */
            /* Keep processing only to complete conference, ignore in every other case */
            else
            {
                if (rvCCCallGetState(call) != RV_CCCALLSTATE_CONFERENCE_INIT)
                {
                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Conference key is ignored for conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));

                    RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                    return;
                }
            }
        }
#ifdef RV_MTF_N_LINES
		}
#endif /* RV_MTF_N_LINES */

        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_LINE              */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_LINE:  /* Select the active connection */
        /*??? Let's assume that Active Line means Active HandSet */
        t->audioTermState |= RV_CCAUDIOTERM_HS_ACTIVE;
        rvProcessAudioTermEvent(t, c, eventId);

        lineId = rvCCTerminalParseConnectionId(keyId);
        /* Make sure we don't try to open more lines than we have... */
        if (lineId > maxConnections)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCTerminalProcessEventId() -  Line key is ignored, all connections are busy conn=%p, Line=%d, Max Connections=%d",
                 c, lineId, maxConnections));
            RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
            return;
        }

        call = rvCCConnectionGetCall(c);
        if (call == NULL)
        {
            /* In this case there is no call up, but still the line pressed may not be the
               default active one - need to check */
            if (rvCCConnectionGetLineId(c) != lineId)
            {
                rvCCTerminalSetActiveConnectionId(t, lineId-1);
                c = rvCCTerminalGetActiveConnection(t);
            }
            rvInitNewCall(callMgr, c);
            break;
        }
        transferType = rvCCCallGetTransferType(call);

        /* If line is not the active one, change the active line */
        if (rvCCConnectionGetLineId(c) != lineId)
        {
            callState = rvCCCallGetState(call);

            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCTerminalProcessEventId() -  Other Line was Pressed, Disconnecting Active Line=%d, conn=%p, Line=%d",
                 rvCCConnectionGetLineId(c), c, lineId));

            /* Disconnect previous active connection */
            rvProcessEvent(c,RV_CCTERMEVENT_LINEOTHER, RV_CCCAUSE_NORMAL);

            /* Select the new active connection */
            rvCCTerminalSetActiveConnectionId(t, lineId-1);
            otherConn = rvCCTerminalGetActiveConnection(t);

            switch (callState)
            {

            case RV_CCCALLSTATE_NORMAL:
                if (rvCCConnectionGetTermState(otherConn) == RV_CCTERMCONSTATE_HELD)
                {
                    call = rvCCConnectionGetCall(otherConn);
                    if (rvCCCallGetState(call) == RV_CCCALLSTATE_TRANSFER_INIT)
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer was Cancelled by User, conn=%p, Line=%d",
                             c, rvCCConnectionGetLineId(c)));

                       /*Undo Transfer process, if LineOther key was pressed during setting a
                        Transfer call to go back to the original call*/
                        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);

                        /* Return to original call after dialing wrong number*/
                        if (rvCCConnectionGetTransferLine(otherConn) != NULL)
                        {
                            /*Set other party's Transfer line to NULL too*/
                            rvCCConnectionSetTransferLine(rvCCConnectionGetTransferLine(otherConn), NULL);
                        }
                    }
                }
                break;

            case RV_CCCALLSTATE_CONFERENCE_INIT:
                if (rvCCConnectionGetTermState(otherConn) == RV_CCTERMCONSTATE_HELD)
                {
                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Conference was Cancelled by User, conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));
#ifdef RV_MTF_N_LINES
					 /* If it is more then 3-way conference, it means that the cancel was done on adding
					    a line to an existent conference. Therefore, in this case, the call state should changed
				        to conference_completed and not to normal.
					    In addition, in this case RemoveConferenceParties should not be done */

					if (rvListSize(&call->connections) != 0) /* There is an already an existing conference */
					{
						rvCCCallSetState(call, RV_CCCALLSTATE_CONFERENCE_COMPLETED);
					}
					else
					{
					  /*Undo Conference process, if LineOther key was pressed during setting a
						Conference call to go back to the original call*/
						rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
						/*Remove all other unsuccessful connections from the call, leave
						only the active connection and its party*/

						rvCCCallRemoveConferenceParties(otherConn);
					}
#else
					/*Undo Conference process, if LineOther key was pressed during setting a
				      Conference call to go back to the original call*/
                    rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
                    /*Remove all other unsuccessful connections from the call, leave
				      only the active connection and its party*/
                    rvCCCallRemoveConferenceParties(otherConn);
#endif /* RV_MTF_N_LINES */
                }
                else
                {
                    /*LineOther was pressed to add another call while setting a Conference call*/
                    rvCCCallAddConferenceParty(call, otherConn);
                }
                break;

            case RV_CCCALLSTATE_TRANSFER_INIT:
                if (rvCCConnectionGetTermState(otherConn) == RV_CCTERMCONSTATE_HELD)
                {
                    call = rvCCConnectionGetCall(otherConn);

                    RvLogInfo(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer was Cancelled by User, conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));

                    /*Undo Transfer process, if LineOther key was pressed during setting a
                    transfer call to go back to the original call*/
                    rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
                    rvCCConnectionSetTransferState(otherConn, RV_CCCONNSTATE_TRANSFER_IDLE);

                    /* Return to original call after dialing wrong number */
                    if (rvCCConnectionGetTransferLine(otherConn) != NULL)
                    {
                        /*Set other party's Transfer line to NULL too*/
                        rvCCConnectionSetTransferLine(rvCCConnectionGetTransferLine(otherConn), NULL);
                        rvCCConnectionSetTransferState(rvCCConnectionGetTransferLine(otherConn), RV_CCCONNSTATE_TRANSFER_IDLE);


                    }
                }
                else
                {
                    /* LineOther was pressed to set up another call during Transfer process
                       OR - Transfer was completed and is using the line to hang up -
                       in this case is disconnected, do nothing */
                    if (rvCCConnectionGetTermState(c) != RV_CCTERMCONSTATE_IDLE ||
                        rvCCConnectionGetTermState(otherConn) != RV_CCTERMCONSTATE_IDLE)
                    {
                        if (rvCCConnectionGetCall(c) != NULL)
                        {
                            rvCCCallSetTransferParties(c, otherConn);
                        }
                    }
                    else
                    {
                        if (rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_IDLE &&
                           (rvCCConnectionGetTermState(otherConn) == RV_CCTERMCONSTATE_IDLE))
                        {
                            if (transferType == RV_CCCALL_TRANSFER_NONE)
                            {
                                eventId = RV_CCTERMEVENT_NONE;
                            }
                        }
                    }
                }
                break;

            case RV_CCCALLSTATE_CONFERENCE_COMPLETED:
            default:
                break;
            }

            call = rvCCConnectionGetCall(otherConn);
            if (call == NULL)
            {
                rvInitNewCall(callMgr, otherConn);
            }
        }
        else
        {
            call = rvCCConnectionGetCall(c);
            if (call != NULL)
            {
                callState = rvCCCallGetState(call);
                /* Cancel Conference/Transfer by going back to the original call after the second
                   after second line was already disconnected */
                switch (callState)
                {
                case RV_CCCALLSTATE_CONFERENCE_INIT:
                /* If the line is in Hold, it must be the original call (similar to previous case)
                   but here it is the active one because second call already disconnected */
                    if (rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_HELD)
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTerminalProcessEventId() -  Conference was Cancelled by User, conn=%p, Line=%d",
                             c, rvCCConnectionGetLineId(c)));

                        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
                    }
                    break;

                case RV_CCCALLSTATE_TRANSFER_INIT:
                    if (rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_HELD)
                    {
                        RvLogInfo(ippLogSource,
                            (ippLogSource, "rvCCTerminalProcessEventId() -  Transfer was Cancelled by User, conn=%p, Line=%d",
                             c, rvCCConnectionGetLineId(c)));

                        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
                    }
                    break;

                case RV_CCCALLSTATE_NORMAL:
                case RV_CCCALLSTATE_CONFERENCE_COMPLETED:
                default:
                    break;
                }
            }
            if (call == NULL)
            {
                rvInitNewCall(callMgr, c);
                break;
            }
        }
        if (otherConn != NULL)
        {
            c = otherConn;
        }

        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_OFFHOOK           */
    /*                              RV_CCTERMEVENT_HEADSET           */
    /*                              RV_CCTERMEVENT_HANDSFREE         */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_OFFHOOK:
    case RV_CCTERMEVENT_HEADSET:
    case RV_CCTERMEVENT_HANDSFREE:
        if (eventId==RV_CCTERMEVENT_HEADSET)
        {
            t->audioTermState |= RV_CCAUDIOTERM_HT_ACTIVE;
        }
        else
        {
            if (eventId==RV_CCTERMEVENT_OFFHOOK)
            {
                t->audioTermState |= RV_CCAUDIOTERM_HS_ACTIVE;
            }
        }

        eventId = rvProcessAudioTermEvent(t, c, eventId);
        call = rvCCConnectionGetCall(c);
        if (call == NULL)
        {
            /* Create a new call for it when going off - hook (if there is no call) */
            rvInitNewCall(callMgr, c);
            break;
        }
        if ((rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_HELD) ||
            (rvCCConnectionGetTermState(c) == RV_CCTERMCONSTATE_REMOTE_HELD))
        {
            /* Find a free connection */
            if ((otherConn = rvCCTerminalFindFreeConnection(t)) == NULL)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Off Hook key is ignored, no free connection was found, conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                return;
            }
            /* Select the new active connection */
            rvCCTerminalSetActiveConnectionId(t, rvCCConnectionGetLineId(otherConn)-1);
        }

        /*Trying to set a call with a third party as part of the Conference/Transfer
          process (second time or more), add the new party to the call*/
        switch (rvCCCallGetState(call))
        {
        case RV_CCCALLSTATE_CONFERENCE_INIT:
            if (otherConn != NULL)
            {
                rvCCCallAddConferenceParty(call, otherConn);
            }
            else
            {
                rvCCCallAddConferenceParty(call, c);
            }
            break;
        case RV_CCCALLSTATE_TRANSFER_INIT:
            if (otherConn != NULL)
            {
                rvCCCallSetTransferParties(c, otherConn);
            }
            break;
        case RV_CCCALLSTATE_NORMAL:
        case RV_CCCALLSTATE_CONFERENCE_COMPLETED:
        default:
            break;
        }

        if (otherConn != NULL)
        {
            if (rvCCConnectionGetCall(otherConn) == NULL)
            {
                rvInitNewCall(callMgr, otherConn);
            }
            c = otherConn;
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_ONHOOK            */
    /*---------------------------------------------------------------*/
    /* If there is more than one active connection, pass the event to the active one and make the
       one on hold active. Then OffHook will act as unhold */
    case RV_CCTERMEVENT_ONHOOK:

        /*In case of Incoming call and hook is up, On-Hook event should be ignored*/
        if (rvCCConnectionGetState(c) == RV_CCCONNSTATE_ALERTING)
        {
            RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
            return;
        }

        call = rvCCConnectionGetCall(c);

        /* In case user disconnected a Conference call by going on hook, keep processing as
           regular on hook event*/
        if ((call != NULL) && (rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED))
        {
            break;
        }

        t->audioTermState &= ~RV_CCAUDIOTERM_HS_ACTIVE;
        eventId = rvProcessAudioTermEvent(t,c,eventId);

        if ((lineId = rvCCTerminalFindNextActiveConnection(t, c)) >= 0)
        {
           /* If after rvProcessAudioTermEvent the event is still ONHOOK which means there are
              no other active terminals (HF or HT) let's Disconnect previous active connection */
            if (eventId == RV_CCTERMEVENT_ONHOOK)
            {
                rvProcessEvent(c, RV_CCTERMEVENT_ONHOOK, RV_CCCAUSE_NORMAL);
                /* Select the new active connection */
                rvCCTerminalSetActiveConnectionId(t, lineId);
                c = rvCCTerminalGetActiveConnection(t);
                eventId = RV_CCTERMEVENT_NONE;
            }
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_HOLDKEY           */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_HOLDKEY:
        call = rvCCConnectionGetCall(c);
        if (call != NULL)
        {
            /* Ignore Hold during Transfer or Conference process */
            if ((rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_INIT) ||
                (rvCCCallGetState(call) == RV_CCCALLSTATE_TRANSFER_INIT) )
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Hold key is ignored, call is in process of Transfer or Conference for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
                return;
            }
        }
        /* Ignore Hold if Call was not established yet*/
        if ((rvCCConnectionGetState(c) == RV_CCCONNSTATE_DIALING) ||
			(rvCCConnectionGetState(c) == RV_CCCONNSTATE_INPROCESS))
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCTerminalProcessEventId() -  Hold key is ignored, call is not connected yet for conn=%p, Line=%d",
                 c, rvCCConnectionGetLineId(c)));

            RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
            return;
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_REJECT_KEY        */
    /*---------------------------------------------------------------*/
        /* This is always processed by the rejected line, regardless of which one
        is the active one */
    case RV_CCTERMEVENT_REJECT_KEY:
        lineId = rvCCTerminalParseConnectionId(keyId);
        otherConn = rvCCTerminalGetConnectionByIndex(t, lineId-1);

        RvLogInfo(ippLogSource,
            (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Reject key for conn=%p, Line=%d",
             otherConn, rvCCConnectionGetLineId(otherConn)));

        rvProcessEvent(otherConn, RV_CCTERMEVENT_REJECT_KEY, RV_CCCAUSE_NORMAL);
        eventId = RV_CCTERMEVENT_NONE;
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_MUTE              */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_MUTE:
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_MODIFYMEDIA       */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_MODIFYMEDIA: /* Dynamic media change */
	case RV_CCTERMEVENT_MODIFYMEDIA_BY_UPDATE:
        call = rvCCConnectionGetCall(c);
        if ((call != NULL)) /*&&
            (rvCCCallGetState(call) == RV_CCCALLSTATE_NORMAL) &&
            (rvCCCallGetTransferType(call) == RV_CCCALL_TRANSFER_NONE))*/
        {
			/* don't clear new media if it was already set. It could be that a previous modify
			   is in process. The current modify process will be rejected later on. In
			   the mean time we don't want to override newMedia. */
			if ((rvMdmMediaStreamInfoIsLocalDescriptorSet(&c->newMediaStream) == RV_FALSE) &&
				(rvMdmMediaStreamInfoIsRemoteDescriptorSet(&c->newMediaStream) == RV_FALSE))
			{
                 /* Store new media in connection*/

				   rvCCConnectionSetNewMedia(c, media);
			}
        }
        else
        {
            eventId = RV_CCTERMEVENT_NONE;
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_CFW               */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_CFW:
        switch(rvCCConnectionGetState(c))
        {
         /* Accept CFW event only when the connection is IDLE or in Dialing state so CFW can
             be canceled.*/
        case RV_CCCONNSTATE_IDLE:
        case RV_CCCONNSTATE_DIALING: /* In dialing process */
        case RV_CCCONNSTATE_FAILED:  /* Dialing failed */
            call = rvCCConnectionGetCall(c);
            if(call == NULL)
            {
                rvInitNewCall(callMgr, c);
            }
            else
            {
                /* Ignore CFW event in case call is in Transfer or Conference process */
                if (rvCCCallGetState(call) != RV_CCCALLSTATE_NORMAL)
                {
                    RvLogWarning(ippLogSource,
                        (ippLogSource, "rvCCTerminalProcessEventId() -  CFW key is ignored, call is in process of Transfer or Conference, conn=%p, Line=%d",
                         c, rvCCConnectionGetLineId(c)));

                    eventId = RV_CCTERMEVENT_NONE; /* Nothing to continue processing...*/
                    break;
                }
            }
            rvCCTerminalMdmStopSignals(t); /* Stop warning signal, if any */
            /* Process CFW event */
            eventId = rvCCCfwHandleCallForwardTerminalEvent(t);
            if (rvCCConnectionGetState(c) == RV_CCCONNSTATE_FAILED)
            {
                RvLogError(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Failed to process CFW for conn=%p, Line=%d",
                     c, rvCCConnectionGetLineId(c)));

                /* CFW activation failed */
                eventId = RV_CCTERMEVENT_DISCONNECTING;
            }
            break;
        default:
            RvLogWarning(ippLogSource,
                (ippLogSource, "rvCCTerminalProcessEventId() -  CFW key is ignored during a connected call, conn=%p, Line=%d",
                 c, rvCCConnectionGetLineId(c)));

            eventId = RV_CCTERMEVENT_NONE; /* Nothing to continue processing...*/
            /*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    /*---------------------------------------------------------------*/
    /*  rvCCTerminalProcessEventId: RV_CCTERMEVENT_REDIAL            */
    /*---------------------------------------------------------------*/
    case RV_CCTERMEVENT_REDIAL:
        {
            RvCCTerminalMdm*    term = rvCCTerminalMdmGetImpl(t);
            RvMdmTerm*          mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
            RvMdmParameterList  params;
            char                digitStr[5];
            int                 i;

            for (i=0 ; i<(int)rvStringGetSize(&term->redialString) ; ++i)
            {
                /*Get each digit from redial string*/
                RvSprintf(digitStr, "k%c", term->redialString[i]);

                /* Build parameters list */
                rvMdmParameterListConstruct(&params);
                rvCCCallAddEventParam(&params, "keyid", digitStr);

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalProcessEventId() -  Processing Redial - sending digit: %c (event=%s), conn=%p, Line=%d",
                     term->redialString[i], digitStr, c, rvCCConnectionGetLineId(c)));

                /* Send keyup & keydown events for each digit */
                rvMdmTermProcessEvent(mdmTerm, "kp", "kd", NULL, &params);
                rvMdmTermProcessEvent(mdmTerm, "kp", "ku", NULL, &params);

                rvMdmParameterListDestruct(&params);

            }
            eventId = RV_CCTERMEVENT_NONE;
        }

        break;

    default:
        break;
        /*lint -e{788}  all relevant cases are accounted for */
    }

    rvProcessEvent(c, eventId, reason);

    /* Check if the line got disconnected. In this case, propagate an event to the active line
       so it can ring if is in alerting state */
    if ((origEventId == RV_CCTERMEVENT_LINE)    ||
        (origEventId == RV_CCTERMEVENT_ONHOOK)  ||
        (origEventId == RV_CCTERMEVENT_REJECT_KEY))
    {
        /* TODO: why does this code has to be out of the state machine? */
        c = rvCCTerminalGetActiveConnection(t);
        call = rvCCConnectionGetCall(c);
        if (call && rvCCCallGetState(call) == RV_CCCALLSTATE_NORMAL)
        {
            rvProcessEvent(c, RV_CCTERMEVENT_ONHOOK_OTHER, RV_CCCAUSE_NORMAL);
        }
    }

    RvMutexUnlock(&t->activeConnMutex, IppLogMgr());
}
