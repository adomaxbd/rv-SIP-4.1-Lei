/******************************************************************************
Filename   : rvccterminalsip.c
Description: Implements Sip Terminal Object
******************************************************************************
                Copyright (c) 2004 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:	 09.08.04$
$Author: Yochi Moran$
******************************************************************************/
#define LOGSRC	LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "rvccprovidersip.h"
#include "rvccterminalsip.h"
#include "rvccconnsip.h"
#include "sipMgr.h"
#include "rvmdm.h"
#include "sipRegClient.h"

#ifdef RV_SIP_IMS_ON
#include "RvSipRegClient.h"
#include "mtfImsSecAgree.h"
#endif
extern HRPOOL        g_appPool;
extern RvSipControl* g_sipControl;

RvUint32         g_dwHeartbeatCycle  = 60;
RvUint32         g_dwHeartbeatSwitch = 1;

RvUint32 PSip_GetHeartbeatCycle()
{
    return g_dwHeartbeatCycle;
}

RvUint32 PSip_GetHeartbeatSwitch()
{
    return g_dwHeartbeatSwitch;
}

void PSip_SetHeartbeatCycle(RvUint32 dwHeartbeatCycle)
{
    g_dwHeartbeatCycle = dwHeartbeatCycle;
}

void PSip_SetHeartbeatSwitch(RvUint32 dwHeartbeatSwitch)
{
    g_dwHeartbeatSwitch = dwHeartbeatSwitch;
}

extern RvBool PSip_HeartbeatTimeOut( void* data);


/*===============================================================================*/
/*================== I N T E R N A L	F U N C T I O N S	=====================*/
/*===============================================================================*/

/******************************************************************************
*  registerTimerExpire
*  ----------------------------
*  General :        This callback will be called when registration/Unregistration time expires.
*					For Registration it will send a registration request for this termination.
*					For Unregistration it will accomplish Deregistration process.
*                   Registration time is configured by the user in registrationExpire
*					parameter in RvMtfSipPhoneCfg.
*
*  Return Value:    rvTrue
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          data               a pointer to SIP Terminal object.
*  Output:         none.
******************************************************************************/
RvBool registerTimerExpire( void* data)
{
	RvCCTerminal*		xTerm = (RvCCTerminal*)data;
	RvCCTerminalSip*    term =  rvCCTerminalSipGetImpl(xTerm);

	if (term->networkRegisterType == RV_TERM_NETWORK_REG_TYPE_REGISTERING)
	{
		rvSipControlRegisterClient(term);
	}
	else /*if (term->networkRegisterType == RV_TERM_NETWORK_REG_TYPE_UNREGISTERING) */
    {
		/* we do not retry to unregister */
		rvCCSipPhoneFinishTermUnregistrationProcess(xTerm);
	}

	return rvTrue;
}

/*===============================================================================*/
/*======================= T E R M I N A L	A P I ===============================*/
/*===============================================================================*/



/******************************************************************************
*  rvCCTerminalSipConstruct
*  ----------------------------
*  General :        Constructs the SIP Terminal object.
*
*  Return Value:   pointer to SIP Terminal object
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xTerm			pointer to CC Terminal object
*                  p				pointer to CC Provider object
*                  id               termination id
*                  termProperties   termination configuration parameters
*                  a                pointer to allocation
*  Output:         none.
******************************************************************************/
RvCCTerminalSip* rvCCTerminalSipConstruct(RvCCTerminal*					xTerm,
										  RvCCProvider*					p,
										  const char*					id,
										  RvMdmTermDefaultProperties*	termProperties,
										  RvAlloc*						a)
{
	RvSipControl* sipControl = rvCCProviderSipGetSipMgr(p);
	RvCCTerminalSip* term = NULL;
	char          *termData;
	RvUint16      numData;
	RvUint32      numData32;
	RvUint32      dwHeartBeatCycle;
	RvChar        displayName[RV_NAME_STR_SZ];
#ifdef RV_SIP_IMS_ON
	RvUint32      numDataLong;
#endif
	dwHeartBeatCycle = PSip_GetHeartbeatCycle();
	rvMtfAllocatorAlloc(sizeof(RvCCTerminalSip), (void**)&term);

	RvLogInfo(ippLogSource,(ippLogSource,"rvCCTerminalSipConstruct: registering termId %s with termProperties: displayName=%s username=%s pswd=%s registrar=%s:%d outbproxy=%s:%d ",
		                      id,  rvSipControlGetDisplayName(sipControl), termProperties->username, termProperties->password, termProperties->registrarAddress,
							  termProperties->registrarPort, termProperties->outboundProxyAddress, termProperties->outboundProxyPort));

	memset(term, 0, sizeof(RvCCTerminalSip));
	term->provider = p;

	term->alloc = a;

    strncpy(term->terminalId, id, sizeof(term->terminalId)-1);
    term->terminalId[sizeof(term->terminalId)-1] = '\0';

	/* Copy terminal data from the termProperties. Fields with no terminalProperties data
	   get the data from the configuration file data that is stored in the sipControl object */

	/* get terminal transport type */
	/* --------------------------- */
	/* If transport type is undefined in terminal level, take it from application level */
	if (termProperties->transportType == RVSIP_TRANSPORT_UNDEFINED)
	{
		term->transportType = rvSipControlGetTransportType(sipControl);
	}
	else
	{
		term->transportType = termProperties->transportType;
	}

	/* get displayName */
	/* ------------ */
	if ((rvMdmTermPresentationInfoGetName(&termProperties->presentationInfo, displayName, sizeof(displayName))) == rvFalse)
	{
		termData = rvSipControlGetDisplayName(sipControl);
	}
	else
	{
		termData = displayName;
	}

	strncpy(term->displayName, termData, sizeof(term->displayName)-1);
	term->displayName[sizeof(term->displayName)-1] = '\0';

	/* get username */
	/* ------------ */
	termData = termProperties->username;
	if ((termData == NULL) || (!strcmp(termData, "")))
	{
		termData = rvSipControlGetUsername(sipControl);
	}

	strncpy(term->username, termData, sizeof(term->username)-1);
	term->username[sizeof(term->username)-1] = '\0';

	/* get password */
	/* ------------ */
	termData = termProperties->password;
	if ((termData == NULL) || (!strcmp(termData, "")))
	{
		termData = rvSipControlGetPassword(sipControl);
	}
	strncpy(term->password, termData, sizeof(term->password)-1);
	term->password[sizeof(term->password)-1] = '\0';

	/* get registrar address */
	/* --------------------- */
	termData = termProperties->registrarAddress;
	if ((termData == NULL) || (!strcmp(termData, "")))
	{
		termData = rvSipControlGetRegistrarAddress(sipControl);
	}
	strncpy(term->registrarAddress, termData, sizeof(term->registrarAddress)-1);
	term->registrarAddress[sizeof(term->registrarAddress)-1] = '\0';

	/* get registrar port */
	/* ------------------ */
	if ((numData = termProperties->registrarPort) == 0)
	{
		numData = (RvUint16)rvSipControlGetRegistrarPort(sipControl);
	}
	term->registrarPort = numData;

	/* get outbound proxy address */
	/* -------------------------- */
	termData = termProperties->outboundProxyAddress;
	if ((termData == NULL) || (!strcmp(termData, "")))
	{
		termData = rvSipControlGetOutboundProxyAddress(sipControl);
	}
	strncpy(term->outboundProxyAddress, termData, sizeof(term->outboundProxyAddress)-1);
	term->outboundProxyAddress[sizeof(term->outboundProxyAddress)-1] = '\0';

#ifdef RV_CFLAG_TLS
	/* get registrar Tls port	   */
	/* --------------------------- */
	if ((numData = termProperties->registrarTlsPort) == 0)
	{
		numData = (RvUint16)rvSipControlGetRegistrarTlsPort(sipControl);
	}
	term->registrarTlsPort  = numData;
#endif

#ifdef RV_SIP_IMS_ON
	/* get P-Access-Network-Info */
	/* -------------------------- */
	termData = termProperties->PAccessNetworkInfo;
	if ((termData == NULL) || (!strcmp(termData, "")))
	{
		termData = sipControl->imsControl.PAccessNetworkInfo;
	}
	strncpy(term->imsTerminalSip.PAccessNetworkInfo, termData, sizeof(term->imsTerminalSip.PAccessNetworkInfo)-1);
	term->imsTerminalSip.PAccessNetworkInfo[sizeof(term->imsTerminalSip.PAccessNetworkInfo)-1] = '\0';
	/* get IPSec port C			   */
	/* --------------------------- */
	if ((numDataLong = termProperties->ipsecPortC) == 0)
	{
		numDataLong = rvSipControlGetIpSecPortC(sipControl);
	}
	term->imsTerminalSip.ipsecPortC = numDataLong;
	/* get IPSec port S			   */
	/* --------------------------- */
	if ((numDataLong = termProperties->ipsecPortS) == 0)
	{
		numDataLong = rvSipControlGetIpSecPortS(sipControl);
	}
	term->imsTerminalSip.ipsecPortS = numDataLong;
#endif
	/* get outbound proxy port */
	/* ----------------------- */
	if ((numData = termProperties->outboundProxyPort) == 0)
	{
		numData = (RvUint16)rvSipControlGetOutboundProxyPort(sipControl);
	}
	term->outboundProxyPort  = numData;


	/* get register expires data */
	/* ----------------------- */
	if ((numData32 = termProperties->registerExpires) == 0)
	{
		numData32 = (RvUint32)rvSipControlGetRegisterExpires(sipControl);
	}
	term->registerExpires  = numData32;

	term->nonce[0]='\0';

	rvCCTerminalSipSetRegState(term, RV_TERM_NETWORK_REG_STATE_UNREGISTERED);
	rvCCTerminalSipSetToolkitRegisterState(term, RV_TERM_TOOLKIT_REG_STATE_NONE);

    term->mdmXTerm = NULL;

	/* xTerm must be initialized before we create RegClientObject */
	rvCCTerminalInit(xTerm, term, NULL);

	if (!rvSipControlIsAddressEmpty(term->registrarAddress))
	{
		RvUint32 regTimout;
        const RvChar *userScheme = "sip";

#ifdef RV_CFLAG_TLS
		/* use the sips scheme only if TLS was enabled */
	if (rvSipControlIsTlsEnabled(sipControl))
	{
#ifdef RV_SIP_IMS_ON
		/* in a TLS and IMS configuration don't change the scheme to "sip:"
		   if secAgree is enabled */
		if (g_sipControl->imsControl.disableSecAgree == RV_TRUE)
#endif /* RV_SIP_IMS_ON */
		{
              userScheme = "sips";
		}
	}
#endif /* RV_CFLAG_TLS */

		/*
		 *	initialize regExpires from sipMgr object
		 */
		rvCCTerminalSipSetUnregisterExpires( term, sipControl->unregisterExpires);
		rvCCTerminalSipSetClientRegisterExpires(term , sipControl->clientRegisterExpires);
		regTimout = rvCCTerminalSipGetRegisterTimeout( term);

		IppTimerConstruct(&term->registerTimer, regTimout/2, registerTimerExpire, (void *)xTerm);
		/* Create and build RegClient object for Registration request*/
		
		/*zhangcg: 20110428 added heartbeatTimer*/
		dwHeartBeatCycle = PSip_GetHeartbeatCycle();

		
		term->dwHeartbeatSwitch = PSip_GetHeartbeatSwitch();
        /*zhangcg: even cycle is invalid,we construct the timer cos of destrcuction*/
        term->dwHeartbeatCycle = dwHeartBeatCycle;
		IppTimerConstruct(&term->tHeartbeatTimer, dwHeartBeatCycle*1000, PSip_HeartbeatTimeOut, (void *)xTerm);



#ifdef RV_CFLAG_TLS
		/* use the tls port only if TLS was enabled */
		if ( rvSipControlIsTlsEnabled(sipControl))
		{
			rvSipControlRegClientCreateObject( p, xTerm, userScheme, rvIppTlsGetPort(), &term->regClientObject);
		}
		else
#endif
		rvSipControlRegClientCreateObject( p, xTerm, userScheme, sipControl->stackPort, &term->regClientObject);
#ifdef RV_SIP_IMS_ON
		/* build security agreement information, and attach it to term->regClientObject */
		if (sipControl->imsControl.disableSecAgree == RV_FALSE)
		{
			term->imsTerminalSip.SecAgreeInitiated = rvFalse;
			term->imsTerminalSip.chosenSecurity = RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED;
			if ((rvSecAgreeInitiate(p, term) == RV_OK))
			{
				term->imsTerminalSip.SecAgreeInitiated = rvTrue;
				RvSipRegClientSetSecAgree(term->regClientObject, term->imsTerminalSip.hSecAgree);
				RvLogDebug(ippLogSource,(ippLogSource,"rvCCTerminalSipConstruct:: Client sec-agree was created for terminal %s",
					term->terminalId));
			}
			else
			{
				rvCallSecAgreeUserCallback(term, rvFalse, RV_MTF_SEC_AGREE_INIT_FAILED, RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED);
				RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipConstruct: Failed to init client security-agreement for terminal %s",
					term->terminalId));
			}
		}
#endif
	}

	return term;
}

/******************************************************************************
*  rvCCTerminalSipDestruct
*  ----------------------------
*  General :        Destructs the SIP Terminal object.
*
*  Return Value:   pointer to CC Terminal object
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal object
*  Output:         none.
******************************************************************************/
void rvCCTerminalSipDestruct(RvCCTerminal * x)
{
	RvCCTerminalSip* term = rvCCTerminalSipGetImpl(x);

	if ((term->termType==RV_CCTERMINALTYPE_UI) || (term->termType==RV_CCTERMINALTYPE_ANALOG)) {

	}

	IppTimerDestruct(&term->registerTimer);

#ifdef RV_SIP_IMS_ON
	/* terminate security agreement object if it has been initialized when terminal was created */
	if (term->imsTerminalSip.SecAgreeInitiated == RV_TRUE)
	{
		RvStatus   rc;

		rc = rvSecAgreeTerminate(term->imsTerminalSip.hSecAgree);
		if (rc == RV_OK)
		{
			RvLogInfo(ippLogSource,(ippLogSource,"rvCCTerminalSipDestruct: Security object successfully terminated for terminal %s",
					  term->terminalId));
		}
		else
		{
			RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipDestruct: Failed to terminate the security-agreement for Client %p",
					   term->imsTerminalSip.hSecAgree));
		}
	}
#endif
	/*put app handle to 0 in order to break relation between hregClient in stack and application*/
	RvSipRegClientSetAppHandle(term->regClientObject, 0);
	RvSipRegClientTerminate(term->regClientObject);
	rvCCTerminalSipResetRouteHopHeaderList(term);

	RvMutexDestruct(&x->activeConnMutex, IppLogMgr());

	rvMtfAllocatorDealloc(term, sizeof(RvCCTerminalSip));
}

/******************************************************************************
*  rvCCTerminalSipSetNonce
*  ----------------------------
*  General :        copy nonce into RvCCTerminalSip object.
*
*  Return Value:
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal Sip object
*				   nonce			nonce string
*  Output:         none.
******************************************************************************/
void rvCCTerminalSipSetNonce(IN RvCCTerminalSip* x,IN char* nonce)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipSetNonce fail x = NULL"));
	}
	else
	{
		if (nonce!=NULL)
		{
			strncpy(x->nonce, nonce, sizeof(x->nonce)-1);
			x->nonce[sizeof(x->nonce)- 1] = '\0';
		}
		else
		{
			x->nonce[0] = '\0';
		}
	}
}

/******************************************************************************
*  rvCCTerminalSipGetNonce
*  ----------------------------
*  General :        get nonce string from RvCCTerminalSip object.
*
*  Return Value:   nonce string
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal Sip object
*
*  Output:         none.
******************************************************************************/
const char* rvCCTerminalSipGetNonce(RvCCTerminalSip* x)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipGetNonce fail nonce = NULL"));
		return (char*)NULL;
	}
	else
	{
		return x->nonce;
	}
}

/******************************************************************************
*  rvCCTerminalSipGetRegistrarAddress
*  ----------------------------------
*  General :        get registrarAddress string from RvCCTerminalSip object.
*
*  Return Value:   registrarAddress string
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal Sip object
*
*  Output:         none.
******************************************************************************/
const char* rvCCTerminalSipGetRegistrarAddress(IN RvCCTerminalSip* x)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipGetRegistrarAddress fail Reg Addr = NULL"));
		return (char*)NULL;
	}
	else
	{
		return x->registrarAddress;
	}
}

/******************************************************************************
*  rvCCTerminalSipGetRegistrarPort
*  ----------------------------------
*  General :        get registrarPort number from RvCCTerminalSip object.
*
*  Return Value:   port number
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal Sip object
*
*  Output:         none.
******************************************************************************/
RvUint16 rvCCTerminalSipGetRegistrarPort(IN RvCCTerminalSip* x)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipGetRegistrarPort fail Reg port = 0"));
		return 0 ;
	}
#ifdef RV_CFLAG_TLS
#ifdef RV_SIP_IMS_ON
    /* case 1: TLS, IMS but not secAgree - use registrarTlsPort if TLS is enabled */
	if (g_sipControl->imsControl.disableSecAgree == RV_TRUE)
	{
		if (rvSipControlIsTlsEnabled(g_sipControl))
		{
			return x->registrarTlsPort;
		}
	}
#else  /* not defined RV_SIP_IMS_ON */
	/* case2: TLS and not IMS - use registrarTlsPort if TLS is enabled */
	if (rvSipControlIsTlsEnabled(g_sipControl))
	{
		return x->registrarTlsPort;
	}
#endif /* RV_SIP_IMS_ON */
#endif /* RV_CFLAG_TLS */
	  /* If we got so far we need to use the registrarPort */
	  return x->registrarPort;

}

/******************************************************************************
*  rvCCTerminalSipGetOutboundProxyAddress
*  ---------------------------------------
*  General :        get OutboundProxyAddress string from RvCCTerminalSip object.
*
*  Return Value:   OutboundProxy address string
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal Sip object
*
*  Output:         none.
******************************************************************************/
const char* rvCCTerminalSipGetOutboundProxyAddress(IN RvCCTerminalSip* x)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipGetOutboundProxyAddress fail OutboundProxy addr = NULL"));
		return (char*)NULL;
	}
	else
	{
		return x->outboundProxyAddress;
	}
}

/******************************************************************************
*  rvCCTerminalSipGetOutboundProxyPort
*  ------------------------------------
*  General :        get OutboundProxyPort number from RvCCTerminalSip object.
*
*  Return Value:   port number
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to CC Terminal Sip object
*
*  Output:         none.
******************************************************************************/
RvUint16 rvCCTerminalSipGetOutboundProxyPort(IN RvCCTerminalSip* x)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipGetOutboundProxyPort fail- Null term"));
		return 0 ;
	}
	else
	{
		return x->outboundProxyPort;
	}
}

/******************************************************************************
*  rvCCTerminalSipResetRouteHopHeaderList
*  --------------------------------------
*  General :        resets the routeListData of the RvCCTerminalSip object.
*
*  Return Value:   none
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          term				pointer to sip terminal
*
*  Output:         none.
******************************************************************************/

void rvCCTerminalSipResetRouteHopHeaderList(INOUT RvCCTerminalSip* term)
{
    RvInt               index = 0;
	RouteListDataType*  routeList = rvCCTerminalSipGetRouteListData(term);

    for(index=0; index<routeList->numOfRouteHopHeadersInList; index++)
    {
        routeList->routeHopHeaderList[index] = NULL;
    }
    routeList->numOfRouteHopHeadersInList = 0;
	/* Note that there is no need to destruct routeHop header
       (though it was constructed) since this header is release when its Page is released */
	if(routeList->serviceRouteListPage != NULL_PAGE)
	{
		RPOOL_FreePage(g_appPool,routeList->serviceRouteListPage);
	}
	routeList->serviceRouteListPage = NULL;

}

/******************************************************************************
*  rvCCTerminalSipGetTransportType
*  ----------------------------------------
*  General :        returns the transport type of the rvCCTerminalSip object
*
*  Return Value:   transport type
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x				pointer to sip terminal
*
*  Output:        none
******************************************************************************/
RvSipTransport rvCCTerminalSipGetTransportType(IN RvCCTerminalSip* x)
{
	if (x==NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSipGetTransportType failed- Null term"));
		return RVSIP_TRANSPORT_UNDEFINED ;
	}

	return x->transportType;
}

/******************************************************************************
*  rvCCTerminalSipGetTransportByConnection
*  ----------------------------------------
*  General :        retrieves the transport type of the rvCCTerminalSip object
*                   that is attached to a sip connection
*
*  Return Value:   transport type
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x 		rvCCConnection
*
*  Output:        none
******************************************************************************/
RvSipTransport rvCCTerminalSipGetTransportByConnection(IN RvCCConnection* c)
{
	RvCCTerminal*           term = rvCCConnSipGetTerminal(c);
	RvCCTerminalSip* sipTerminal = rvCCTerminalSipGetImpl(term);

	return sipTerminal->transportType;
}



