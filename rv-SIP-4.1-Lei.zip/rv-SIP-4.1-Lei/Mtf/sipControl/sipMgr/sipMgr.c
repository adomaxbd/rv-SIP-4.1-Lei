/******************************************************************************
Filename   : sipControl.c
Description:
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL

#include <ctype.h>
#include "IppStdInc.h"
#include "ippthread.h"
#ifdef _WIN32_WCE
#endif
#include "sipphone.h"
#include "sipMgr.h"
#include "mtfBaseInt.h"
#include "rvccterminalmdm.h"
#include "sipControlInt.h"
#include "RvSipContactHeader.h"
#include "RvSipViaHeader.h"
#include "RvSipReferredByHeader.h"
#include "RvSipReferToHeader.h"
#include "RvSipCSeqHeader.h"
#include "RvSipOtherHeader.h"
#include "RvSipAllowHeader.h"
#include "RvSipMinSEHeader.h"
#include "RvSipRouteHopHeader.h"
#include "RvSipRetryAfterHeader.h"
#include "RvSipSubscription.h"
#include "RvSipCallLegTypes.h"
#include "ippevexchange.h"
#include "rvccapi.h"
#include "ippmisc.h"
#include "rvselect.h"
#include "AdsRpool.h"
#include "RvSipAuthenticationHeader.h"
#include "rvccprovidersip.h"
#include "rvccconnsip.h"
#include "RvSipTransmitter.h"
#include "MsgTypes.h"

#ifdef SIP_DEBUG
/*#include "rpool.h"*/
#include "RvSipStack.h"
#include "RvSipResourcesTypes.h"
#endif

#ifdef RV_CFLAG_TLS
#include "sipTls.h"
#endif

#ifdef RV_MTF_VIDEO
#include "fastUpdateInfo.h"
#endif
#ifdef RV_SIP_IMS_ON
#include "rvAkaAuth.h"
#include "AKA_Auc.h"
#include "mtfImsSecAgree.h"
#endif

#ifdef RV_MTF_SIMPLE_ON
#include "RvSipSubscription.h"
#include "RvSipPubClient.h"
#endif

#if defined(RV_OS_WIN32) /*Wince uses unix seli*/
#define RV_SIPMGR_MSG_DATAMARK WM_USER+200
#define RV_SIPMGR_MSG_TERMINATE     WM_USER+400
#define IPP_SOCK_CLASS "IPP MSG WIN CLASS"
#define IPP_SOCK_WINDOW "IPP MSG WIN"
HWND sipIPPhWnd;
#else
#define RV_SIPMGR_MSG_DATAMARK 0x5A5A
#define RV_SIPMGR_MSG_TERMINATE     0x5A6A
#endif
#define IPP_EVQUEUESIZE         32
#define MAX_SIP_CALL_LEGS       5
#define MAX_REGISTER_CLIENTS    5
#define RV_SIP_COMMAND_QUEUE_SIZE   MAX_SIP_CALL_LEGS*5
#define MIN_NUM_AUTH_RETRIES    4    /* how many times we must re-try to send suthorization request */


/***** GLOBALS********/

HRPOOL  g_appPool = NULL;       /*(is it necessary?)memory pool for the application (used for encoding messages)*/

RvSipControl* g_sipControl;            /*Used for Register client with proxy*/

extern RvMtfBaseMgr* g_mtfMgr;


static struct
{
    RvSipStackCfg           *stackCfg;
    RvSipStackHandle        stackHndl;     /*Handle to stack manager*/
    RvSemaphore             semStackConstructed;
} g_threadData;

extern void PSip_AppPrintMessage(IN RvSipMsgHandle hMsg,unsigned int dwDirection); 
extern int PSip_HandleNotifyReqOutOfSub(RvSipTranscHandle                 hTransc);       

extern RvStatus RVCALLCONV vpsip_sipctrl_Subs_StateChangedEvHandler(
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipTranscOwnerHandle            hAppTransc,
                                   IN  RvSipTransactionState             eState,
                                   IN  RvSipTransactionStateChangeReason eReason);

#ifndef  USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/12/12 */

extern void RVCALLCONV PSip_AppSubsStateChangedEv(
                                           IN  RvSipSubsHandle            hSubs,
                                           IN  RvSipAppSubsHandle         hAppSubs,
                                           IN  RvSipSubsState             eState,
                                           IN  RvSipSubsStateChangeReason eReason);
                                           
extern void RVCALLCONV PSip_AppSubsExpirationAlertEv(
                                               IN  RvSipSubsHandle            hSubs,
                                               IN  RvSipAppSubsHandle         hAppSubs);
                                                                                          
extern RvStatus RVCALLCONV PSip_AppSubsMsgReceivedEv(
                                                IN  RvSipSubsHandle      hSubs,
                                                IN  RvSipAppSubsHandle   hAppSubs,
                                                IN  RvSipNotifyHandle    hNotify,
                                                IN  RvSipAppNotifyHandle hAppNotify,
                                                IN  RvSipMsgHandle       hMsg);
                                                
extern RvStatus RVCALLCONV PSip_AppSubsMsgToSendEv(
                                            IN    RvSipSubsHandle      hSubs,
                                            IN    RvSipAppSubsHandle   hAppSubs,
                                            IN    RvSipNotifyHandle    hNotify,
                                            IN    RvSipAppNotifyHandle hAppNotify,
                                            IN    RvSipMsgHandle       hMsg) ;
                                            
extern void RVCALLCONV PSip_AppSubsSubscriptionExpiredEv(
                                                   IN  RvSipSubsHandle            hSubs,
                                                   IN  RvSipAppSubsHandle         hAppSubs);
                                                   
                                                   
extern void RVCALLCONV PSip_AppSubsNotifyEv(
                                       IN  RvSipSubsHandle			hSubs,
                                       IN  RvSipAppSubsHandle		hAppSubs,
                                       IN  RvSipNotifyHandle		hNotification,
                                       IN  RvSipAppNotifyHandle		hAppNotification,
                                       IN  RvSipSubsNotifyStatus	eNotifyStatus,
                                       IN  RvSipSubsNotifyReason	eNotifyReason,
                                       IN  RvSipMsgHandle			hNotifyMsg);
                                                                                                                                                                                       
extern RvStatus RVCALLCONV PSip_AppSubsCreatedDueToForkingEv(
                                                      IN        RvSipSubsHandle    hSubs,
                                                      INOUT     RvInt32            *pExpires,
                                                      OUT       RvSipAppSubsHandle *phAppSubs,
                                                      OUT       RvUint16           *pRejectStatus);
#endif

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/


/***************************************************************************
 * printMessage
 * ------------------------------------------------------------------------
 * General: Prints a message to the log. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
static void printMessage(IN RvSipMsgHandle hMsg)
{
    RvStatus   rv= RV_OK;
    HPAGE      hPage =NULL_PAGE, hPageConsec =NULL_PAGE;
    RvInt32    offset;
    RV_CHAR    *msgBuf;
    RV_UINT32  msgSize;
    
    

    /* getting the encoded message on an rpool page.*/
    rv = RvSipMsgEncode(hMsg, g_appPool, &hPage, &msgSize);
    if (rv != RV_OK)
    {
        hPage =NULL_PAGE;
        RvLogError(ippLogSource,(ippLogSource, "SipMgr::Message encoding failed"));
        goto errExit;
    }

    /*allocate a consecutive buffer*/
    rv = RPOOL_GetPage(g_appPool, 0, &hPageConsec);
    if (rv != RV_OK)
    {
        hPageConsec =NULL_PAGE;
        RvLogError(ippLogSource,(ippLogSource, "SipMgr::RPOOL_GetPage()  failed"));
        goto errExit;
    }

    rv = RPOOL_Append( g_appPool, hPageConsec, msgSize+1, rvTrue, &offset);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "SipMgr::Allocation of consecutiveMemory for encoded message failed"));
        goto errExit;
    }
    msgBuf = RPOOL_GetPtr( g_appPool, hPageConsec, offset);


    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appPool,
        hPage,
        0,
        (void*)msgBuf,
        msgSize);

    /*terminate the buffer with null*/
    msgBuf[msgSize] = '\0';
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "SipMgr::Message encoding failed"));
        goto errExit;
    }
    RvLogInfo(ippLogSource,(ippLogSource,"%s", msgBuf));


/*okExit:*/
errExit:
    /*free the page the encode function allocated*/
    if(hPage != NULL_PAGE)          RPOOL_FreePage(g_appPool, hPage);
    if(hPageConsec != NULL_PAGE)    RPOOL_FreePage(g_appPool, hPageConsec);
}

/***************************************************************************
* resetUpdateState
* ------------------------------------------------------------------------
* General: Resets UPDATE state and media state upon success or failure
*          of UPDATE message handling.
* ------------------------------------------------------------------------
* Arguments:
* Input:   hMsg -  Handle to the message.
***************************************************************************/
static void resetUpdateState(RvCCConnection* c)
{
	RvCCConnection* party = rvCCConnectionGetConnectParty(c);
	RvCCMediaState  mediaState = rvCCConnectionGetMediaState(party);

	rvCCConnSetUpdateState(c, RV_CCUPDATESTATE_NONE);

	/* Move to the right media state as it was before the last UPDATE */
	if (mediaState == RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED)
	{
		rvCCConnectionSetMediaState(party, RV_CCMEDIASTATE_CREATED);
		rvCCConnectionSetMediaState(c, RV_CCMEDIASTATE_CREATED);
	}
	else
	{
		rvCCConnectionSetMediaState(party, RV_CCMEDIASTATE_CONNECTED);
		rvCCConnectionSetMediaState(c, RV_CCMEDIASTATE_CONNECTED);
	}
}

/***************************************************************************
 * AppHandleTypeName
 * ------------------------------------------------------------------------
 * General: Returns a type of object.
 * Return Value: The string with object type name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The direction as enum
 ***************************************************************************/
static const RV_CHAR*  AppHandleTypeName(   IN HandleType type)
{
    switch(type)
    {
        case CallHandle:
            return "CallHandle";
        case RegHandle:
            return "RegHandle";
        default:
            return "Undefined";
    }
}

/***************************************************************************
 * AppGetDirectionName
 * ------------------------------------------------------------------------
 * General: Returns a call-leg direction as a string.
 * Return Value: The string with the direction name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The direction as enum
 ***************************************************************************/
static const RV_CHAR*  AppGetDirectionName(
                        IN RvSipCallLegDirection eDirection)
{
    switch(eDirection)
    {
    case RVSIP_CALL_LEG_DIRECTION_INCOMING:
        return "INCOMING";
    case RVSIP_CALL_LEG_DIRECTION_OUTGOING:
        return "OUTGOING";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * rvSipControlGetCallLegStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
const RV_CHAR*  rvSipControlGetCallLegStateName (
                          IN  RvSipCallLegState  eState)
{
    switch(eState)
    {
    case RVSIP_CALL_LEG_STATE_ACCEPTED:
        return "Accepted";
    case RVSIP_CALL_LEG_STATE_CONNECTED:
        return "Connected";
    case RVSIP_CALL_LEG_STATE_DISCONNECTED:
        return "Disconnected";
    case RVSIP_CALL_LEG_STATE_DISCONNECTING:
        return "Disconnecting";
    case RVSIP_CALL_LEG_STATE_IDLE:
        return "Idle";
    case RVSIP_CALL_LEG_STATE_INVITING:
        return "Inviting";
    case RVSIP_CALL_LEG_STATE_OFFERING:
        return "Offering";
    case RVSIP_CALL_LEG_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_CALL_LEG_STATE_TERMINATED:
        return "Terminated";
    case RVSIP_CALL_LEG_STATE_UNAUTHENTICATED:
        return "UnAuthenticated";
    case RVSIP_CALL_LEG_STATE_REMOTE_ACCEPTED:
        return "Remote Accepted";
    case RVSIP_CALL_LEG_STATE_CANCELLED:
        return "Cancelled";
    case RVSIP_CALL_LEG_STATE_CANCELLING:
        return "Cancelling";
    case RVSIP_CALL_LEG_STATE_PROCEEDING:
        return "Proceeding";
    case RVSIP_CALL_LEG_STATE_PROCEEDING_TIMEOUT:
        return "Proceeding Timeout";
    case RVSIP_CALL_LEG_STATE_MSG_SEND_FAILURE:
        return "Msg Send Failure";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * rvSipControlGetCallLegReferStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
const RV_CHAR*  rvSipControlGetCallLegReferStateName (
                          IN  RvSipCallLegReferState  eState)
{

    switch(eState)
    {
    case RVSIP_CALL_LEG_REFER_STATE_REFER_UNDEFINED:
        return "refer undefined";
    case RVSIP_CALL_LEG_REFER_STATE_REFER_IDLE:
        return "refer idle";
    case RVSIP_CALL_LEG_REFER_STATE_REFER_SENT:
        return "refer sent";
    case RVSIP_CALL_LEG_REFER_STATE_REFER_CANCELLING:
        return "refer cancelling";
    case RVSIP_CALL_LEG_REFER_STATE_REFER_UNAUTHENTICATED:
        return "refer unauthenticated";
    case RVSIP_CALL_LEG_REFER_STATE_REFER_REDIRECTED:
        return "refer redirected";
    case RVSIP_CALL_LEG_REFER_STATE_REFER_RCVD:
        return "refer rcvd";
    case RVSIP_CALL_LEG_REFER_STATE_MSG_SEND_FAILURE:
        return "send failure";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * rvSipControlGetCallLegModifyStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   modifyState - The state as enum
 ***************************************************************************/
const RV_CHAR* rvSipControlGetCallLegModifyStateName(IN RvSipCallLegModifyState modifyState)
{
    switch(modifyState)
    {
        case RVSIP_CALL_LEG_MODIFY_STATE_UNDEFINED:
            return "modify undefine";
        case RVSIP_CALL_LEG_MODIFY_STATE_IDLE:
            return "modify idle";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RCVD:
            return "reinvite rcvd";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RESPONSE_SENT:
            return "reinvite response sent";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_SENT:
            return "reinvite sent";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RESPONSE_RCVD:
            return "reinvite response rcvd";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_CANCELLING:
            return "reinvite cancelling";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_PROCEEDING:
            return "reinvite proceeding";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_CANCELLED:
            return "reinvite cancelled";
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_PROCEEDING_TIMEOUT:
            return "reinvite proceeding timeout";
        case RVSIP_CALL_LEG_MODIFY_STATE_MSG_SEND_FAILURE:
            return "modify msg send failure";
        default:
            return "Undefined";
    }
}

 /***************************************************************************
 * rvSipControlGetCallLegStateChangeName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
const RV_CHAR*  rvSipControlGetCallLegStateChangeName (
                          IN  RvSipCallLegStateChangeReason  eState)
{

    switch(eState)
    {
    case RVSIP_CALL_LEG_REASON_UNDEFINED:
        return "undefined";
    case RVSIP_CALL_LEG_REASON_LOCAL_INVITING:
        return "local inviting";
    case RVSIP_CALL_LEG_REASON_REMOTE_INVITING:
        return "remote inviting";
    case RVSIP_CALL_LEG_REASON_LOCAL_REFER:
        return "local refer";
    case RVSIP_CALL_LEG_REASON_REMOTE_REFER:
        return "remote refer";
    case RVSIP_CALL_LEG_REASON_LOCAL_REFER_NOTIFY:
        return "local refer notify";
    case RVSIP_CALL_LEG_REASON_REMOTE_REFER_NOTIFY:
        return "remote refer notify";
    case RVSIP_CALL_LEG_REASON_REMOTE_ACCEPTED:
        return "remote accepted";
    case RVSIP_CALL_LEG_REASON_REMOTE_ACK:
        return "remote ack";
    case RVSIP_CALL_LEG_REASON_REDIRECTED:
        return "redirected";
    case RVSIP_CALL_LEG_REASON_LOCAL_REJECT:
        return "local reject";
    case RVSIP_CALL_LEG_REASON_REQUEST_FAILURE:
        return "request failure";
    case RVSIP_CALL_LEG_REASON_SERVER_FAILURE:
        return "server failure";
    case RVSIP_CALL_LEG_REASON_GLOBAL_FAILURE:
        return "global failure";
    case RVSIP_CALL_LEG_REASON_LOCAL_DISCONNECTING:
        return "local disconnecting";
    case RVSIP_CALL_LEG_REASON_DISCONNECTED:
        return "disconnected";
    case RVSIP_CALL_LEG_REASON_REMOTE_DISCONNECTED:
        return "remote disconnected";
    case RVSIP_CALL_LEG_REASON_LOCAL_FAILURE:
        return "local failure";
    case RVSIP_CALL_LEG_REASON_LOCAL_TIME_OUT:
        return "local time out";
    case RVSIP_CALL_LEG_REASON_CALL_TERMINATED:
        return "call terminated";
    case RVSIP_CALL_LEG_REASON_AUTH_NEEDED:
        return "auth needed";
    case RVSIP_CALL_LEG_REASON_UNSUPPORTED_AUTH_PARAMS:
        return "unsupported auth params";
    case RVSIP_CALL_LEG_REASON_LOCAL_CANCELLING:
        return "local cancelling";
    case RVSIP_CALL_LEG_REASON_REMOTE_CANCELED:
        return "remote canceled";
    case RVSIP_CALL_LEG_REASON_ACK_SENT:
        return "ack sent";
    case RVSIP_CALL_LEG_REASON_CALL_CONNECTED:
        return "call connected";
    case RVSIP_CALL_LEG_REASON_REMOTE_PROVISIONAL_RESP:
        return "remote provisional resp";
    case RVSIP_CALL_LEG_REASON_REMOTE_REFER_REPLACES:
        return "refer replaces";
    case RVSIP_CALL_LEG_REASON_REMOTE_INVITING_REPLACES:
        return "remote inviting replaces";
    case RVSIP_CALL_LEG_REASON_REMOTE_DISCONNECT_REQUESTED:
        return "remote disconnect requested";
    case RVSIP_CALL_LEG_REASON_DISCONNECT_LOCAL_REJECT:
        return "disconnect local reject";
    case RVSIP_CALL_LEG_REASON_DISCONNECT_REMOTE_REJECT:
        return "disconnect remote reject";
    case RVSIP_CALL_LEG_REASON_DISCONNECT_LOCAL_ACCEPT:
        return "disconnect local accpet";
    case RVSIP_CALL_LEG_REASON_NETWORK_ERROR:
        return "network error";
    case RVSIP_CALL_LEG_REASON_503_RECEIVED:
        return "503 received";
    case RVSIP_CALL_LEG_REASON_GIVE_UP_DNS:
        return "give up dns";
    case RVSIP_CALL_LEG_REASON_CONTINUE_DNS:
        return "continue dns";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * rvSipControlGetErrorCodeName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given error code
 * Return Value: The string with the error name name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   errorC - The Error code (sip\core\common)
 ***************************************************************************/
const RV_CHAR* rvSipControlGetTransactionStateName(RvSipTransactionState eState)
{
    switch(eState)
    {
    case RVSIP_TRANSC_STATE_UNDEFINED:
        return "Undefined";
    case RVSIP_TRANSC_STATE_IDLE:
        return "Idle";
    case RVSIP_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:
        return "Server gen rcvd ";
    case RVSIP_TRANSC_STATE_SERVER_GEN_FINAL_RESPONSE_SENT:
        return "Server gen final response sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_REQUEST_SENT:
        return "Client gen request sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_PROCEEDING:
        return "Client gen proceeding";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_CALLING:
        return "Client invite calling";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_PROCEEDING:
        return "Client invite proceeding";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_FINAL_RESPONSE_RCVD:
        return "Client invite final response rcvd";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_ACK_SENT:
        return "Client invite ack sent";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_REQUEST_RCVD:
        return "Server invite requst rcvd";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_FINAL_RESPONSE_SENT:
        return "Server invide final response sent";
    case RVSIP_TRANSC_STATE_TERMINATED:
        return "Server invite final response sent";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_REL_PROV_RESPONSE_SENT:
        return "Server invite rel prov response sent";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_PRACK_COMPLETED:
        return "Server invite prack completed";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_PROXY_2XX_RESPONSE_RCVD:
        return "Client invite proxy 2xx response rcvd";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_PROXY_2XX_RESPONSE_SENT:
        return "Server invite proxy 2xx response sent";
    case RVSIP_TRANSC_STATE_SERVER_CANCEL_REQUEST_RCVD:
        return "Server cancel request rcvd";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_CANCELLING:
        return "Client invite cancelling";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_CANCELLING:
        return "Client gen cancelling";
    case RVSIP_TRANSC_STATE_CLIENT_CANCEL_SENT:
        return "Client cancel sent";
    case RVSIP_TRANSC_STATE_CLIENT_CANCEL_PROCEEDING:
        return "Client cancle proceeding";
    case RVSIP_TRANSC_STATE_SERVER_CANCEL_FINAL_RESPONSE_SENT:
        return "Srever cancel final response sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_FINAL_RESPONSE_RCVD:
        return "Client gen final response rcvd";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_PROCEEDING_TIMEOUT:
        return "Client invite proceeding timeout";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_ACK_RCVD:
        return "Server invite ack rcvd";
    case RVSIP_TRANSC_STATE_CLIENT_CANCEL_FINAL_RESPONSE_RCVD:
        return "Client cancle final response rcvd";
    case RVSIP_TRANSC_STATE_CLIENT_MSG_SEND_FAILURE:
        return "hg";
    default:
        return "Undefined";
    }
}
/***************************************************************************
 * rvSipControlGetErrorCodeName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given error code
 * Return Value: The string with the error name name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   errorC - The Error code (sip\core\common)
 ***************************************************************************/
const RV_CHAR* rvSipControlGetErrorCodeName(IN RvStatus errorC)
{
    switch (errorC)
    {
    case RV_OK:                             return "OK";
    case RV_ERROR_UNKNOWN:                  return "ERR_UNKNOWN";
    case RV_ERROR_ILLEGAL_ACTION:           return "ERR_ILLEGAL_ACTION";
    case RV_ERROR_BADPARAM:                 return "ERR_BADPARAM";
    case RV_ERROR_OUTOFRESOURCES:           return "ERR_OUTOFRESOURCES";
    case RV_ERROR_NETWORK_PROBLEM:          return "ERR_NETWORK_PROBLEM";
    case RV_ERROR_TRY_AGAIN:                return "ERR_TRY_AGAIN";
    case RV_ERROR_NUM_OF_THREADS_DECREASED: return "ERR_NUM_OF_THREADS_DECREASED";
    default:                                return "UNKNOWN ERROR CODE";
    }
}

/**************************************************************************
* callLegStateChangedToCallStateChangedReason
* ------------------------------------------------------------------------
* General: Converts RvSipCallLegStateChangeReason value to RvMtfCallStateChangedReason
*		   in order to keep the cause to states in a common way for all
*          protocols. The cause is stored in the MDM connection.
* ------------------------------------------------------------------------
* Arguments:
* Input:
***************************************************************************/
static void callLegStateChangedToCallStateChangedReason(RvCCConnection* c, RvSipCallLegStateChangeReason callLegReason)
{
	RvMtfCallStateReason reason;
	RvCCConnection* party = rvCCConnectionGetConnectParty(c);

	if (party != NULL)
	{
		switch(callLegReason)
		{
		case RVSIP_CALL_LEG_REASON_LOCAL_TIME_OUT:
			reason = RV_MTF_CALL_STATE_REASON_TIME_OUT;
			break;
		case RVSIP_CALL_LEG_REASON_LOCAL_DISCONNECTING:
		case RVSIP_CALL_LEG_REASON_DISCONNECTED:
			reason = RV_MTF_CALL_STATE_REASON_LOCAL_DISCONNECT;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_DISCONNECT_REQUESTED:
		case RVSIP_CALL_LEG_REASON_REMOTE_DISCONNECTED:
		case RVSIP_CALL_LEG_REASON_DISCONNECT_LOCAL_ACCEPT:
			reason = RV_MTF_CALL_STATE_REASON_REMOTE_DISCONNECTED;
			break;

		case RVSIP_CALL_LEG_REASON_LOCAL_INVITING:
			reason = RV_MTF_CALL_STATE_REASON_LOCAL_INVITING;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_INVITING:
			reason = RV_MTF_CALL_STATE_REASON_REMOTE_INVITING;
			break;

		case RVSIP_CALL_LEG_REASON_LOCAL_REFER:
			reason = RV_MTF_CALL_STATE_REASON_REFER_SENT;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_REFER:
			reason = RV_MTF_CALL_STATE_REASON_REFER_RECEIVED;
			break;

		case RVSIP_CALL_LEG_REASON_LOCAL_REFER_NOTIFY:
			reason = RV_MTF_CALL_STATE_REASON_REFER_NOTIFY_SENT;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_REFER_NOTIFY:
			reason = RV_MTF_CALL_STATE_REASON_REFER_NOTIFY_RECEIVED;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_ACCEPTED:
			reason = RV_MTF_CALL_STATE_REASON_CALL_ACCEPTED;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_ACK:
			reason = RV_MTF_CALL_STATE_REASON_ACK_RECEIVED;
			break;

		case RVSIP_CALL_LEG_REASON_REDIRECTED:
			reason = RV_MTF_CALL_STATE_REASON_REDIRECTED;
			break;

		case RVSIP_CALL_LEG_REASON_LOCAL_REJECT:
			reason = RV_MTF_CALL_STATE_REASON_LOCAL_REJECTED;
			break;

		case RVSIP_CALL_LEG_REASON_REQUEST_FAILURE:
			reason = RV_MTF_CALL_STATE_REASON_REQUEST_FAILURE;
			break;

		case RVSIP_CALL_LEG_REASON_SERVER_FAILURE:
			reason = RV_MTF_CALL_STATE_REASON_SERVER_FAILURE;
			break;

		case RVSIP_CALL_LEG_REASON_GLOBAL_FAILURE:
			reason = RV_MTF_CALL_STATE_REASON_GLOBAL_FAILURE;
			break;



		case RVSIP_CALL_LEG_REASON_LOCAL_FAILURE:
			reason = RV_MTF_CALL_STATE_REASON_OPERATION_FAILED;
			break;

		case RVSIP_CALL_LEG_REASON_CALL_TERMINATED:
			reason = RV_MTF_CALL_STATE_REASON_CALL_TERMINATED;
			break;

		case RVSIP_CALL_LEG_REASON_AUTH_NEEDED:
		case RVSIP_CALL_LEG_REASON_UNSUPPORTED_AUTH_PARAMS:
			reason = RV_MTF_CALL_STATE_REASON_AUTHENTICATION_FAILURE;
			break;

		case RVSIP_CALL_LEG_REASON_LOCAL_CANCELLING:
			reason = RV_MTF_CALL_STATE_REASON_LOCAL_CANCELLING;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_CANCELED:
			reason = RV_MTF_CALL_STATE_REASON_REMOTE_CANCELED;
			break;

		case RVSIP_CALL_LEG_REASON_ACK_SENT:
			reason = RV_MTF_CALL_STATE_REASON_ACK_SENT;
			break;

		case RVSIP_CALL_LEG_REASON_CALL_CONNECTED:
			reason = RV_MTF_CALL_STATE_REASON_CALL_CONNECTED;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_PROVISIONAL_RESP:
			reason = RV_MTF_CALL_STATE_REASON_PROVISIONAL_RESP_RECEIVED;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_REFER_REPLACES:
			reason = RV_MTF_CALL_STATE_REASON_REFER_REPLACES_RECEIVED;
			break;

		case RVSIP_CALL_LEG_REASON_REMOTE_INVITING_REPLACES:
			reason = RV_MTF_CALL_STATE_REASON_INVITING_REPLACES_RECEIVED;
			break;

		case RVSIP_CALL_LEG_REASON_DISCONNECT_LOCAL_REJECT:
			reason = RV_MTF_CALL_STATE_REASON_DISCONNECT_LOCAL_REJECT;
			break;

		case RVSIP_CALL_LEG_REASON_DISCONNECT_REMOTE_REJECT:
			reason = RV_MTF_CALL_STATE_REASON_DISCONNECT_REMOTE_REJECT;
			break;
		case RVSIP_CALL_LEG_REASON_NETWORK_ERROR:
			reason = RV_MTF_CALL_STATE_REASON_NETWORK_ERROR;
			break;

		case RVSIP_CALL_LEG_REASON_503_RECEIVED:
			reason = RV_MTF_CALL_STATE_REASON_SERVER_UNAVAILABLE;
			break;

		case RVSIP_CALL_LEG_REASON_GIVE_UP_DNS:
			reason = RV_MTF_CALL_STATE_REASON_GIVE_UP_DNS;
			break;

		case RVSIP_CALL_LEG_REASON_CONTINUE_DNS:
			reason = RV_MTF_CALL_STATE_REASON_CONTINUE_DNS;
			break;

		case RVSIP_CALL_LEG_REASON_UNDEFINED:
		default:
			reason = RV_MTF_CALL_STATE_REASON_UNKNOWN;
		}

		rvCCConnectionSetLastReceivedCallStateReason(party, reason);
	}
}

/***************************************************************************
 * printSipResourceObject
 * ------------------------------------------------------------------------
 * General: print the content of RvSipResource object
 *
 *
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   moduleName  - module name
 *          resource    - resource object
 *
 ***************************************************************************/
void printSipResourceObject(IN char* moduleName,RvSipResource resource)
{
    RvLogInfo(ippLogSource,(ippLogSource,"%s NumOfAlloc = %3d, CurrNumOfUsed = %3d, MaxUsage = %3d\n",
        moduleName,
        resource.numOfAllocatedElements,
        resource.currNumOfUsedElements,
        resource.maxUsageOfElements));
}

/***************************************************************************
 * printResources
 * ------------------------------------------------------------------------
 * General: print all stack resources
 *
 *           .
 * Return Value: True - success, False - fail.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   data    - sip provider handle
 *
 *
 ***************************************************************************/
RvBool printResources(void *data)
{
    RvCCProviderSip*            providerSip =(RvCCProviderSip*)data;
    RvSipControl*               sipMgr      = &(providerSip->sipMgr);
    RvSipStackHandle            stackHndl   = rvSipControlGetStackHandle(sipMgr);
    RvStatus                    status      =RV_OK;
    StackResources              pCurRes;

#ifdef RV_MTF_USE_CACHE_ALLOCATOR

    RvLogInfo(ippLogSource,(ippLogSource,"\t\t=========== START MTF RESOURCE PRINT ==========\n"));

    rvAllocCacheEmitStats(rvMtfAllocatorGet());

    RvLogInfo(ippLogSource,(ippLogSource,"\t\t=========== END MTF RESOURCE PRINT ==========\n"));

#endif /* RV_MTF_USE_CACHE_ALLOCATOR*/

    memset(&pCurRes,0,sizeof(StackResources) );

    RvLogInfo(ippLogSource,(ippLogSource,"\t\t=========== START SIP RESOURCES PRINT ==========\n"));

    RPOOL_GetResources ( g_appPool,
                         &pCurRes.sipResource.numOfAllocatedElements,
                         &pCurRes.sipResource.currNumOfUsedElements,
                         &pCurRes.sipResource.maxUsageOfElements );
    printSipResourceObject("SIP                     ",pCurRes.sipResource);

#ifndef RV_SIP_PRIMITIVES
    status = RvSipStackGetResources(stackHndl, RVSIP_CALL, (void *)&pCurRes.CallLegResources);
    if (status == RV_OK) {
        printSipResourceObject("CALL calls              ",pCurRes.CallLegResources.calls);
        printSipResourceObject("CALL transcHansles      ",pCurRes.CallLegResources.transcHandles);
        printSipResourceObject("CALL transLists         ",pCurRes.CallLegResources.transcLists);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get CALL RESOURCES stackHndl = %x,error = %d\n",stackHndl,status));
    }

    status = RvSipStackGetResources(stackHndl, RVSIP_REGCLIENT, (void *)&pCurRes.RegClientResources);
    if (status == RV_OK) {
        printSipResourceObject("REGCLIENT               ",pCurRes.RegClientResources.regClients);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get REGCLIENT RESOURCES error = %d\n",status));
    }

    status = RvSipStackGetResources(stackHndl, RVSIP_REGCLIENT, (void *)&pCurRes.SubsResources);
    if (status == RV_OK) {
        printSipResourceObject("SUBS notifications      ",pCurRes.SubsResources.notifications);
        printSipResourceObject("SUBS notifyLists        ",pCurRes.SubsResources.notifyLists);
        printSipResourceObject("SUBS subscriptions      ",pCurRes.SubsResources.subscriptions);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get SUBS RESOURCES error = %d\n",status));
    }

#endif /*RV_SIP_PRIMITIVES*/

    status = RvSipStackGetResources(stackHndl, RVSIP_STACK, (void *)&pCurRes.SipStackResources);
    if (status == RV_OK) {
        printSipResourceObject("STACK generalPoolElemen ",pCurRes.SipStackResources.generalPoolElements);
        printSipResourceObject("STACK headerPoolElement ",pCurRes.SipStackResources.headerPoolElements);
        printSipResourceObject("STACK msgPoolElements   ",pCurRes.SipStackResources.msgPoolElements);
        printSipResourceObject("STACK timerPool         ",pCurRes.SipStackResources.timerPool);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get STACK RESOURCES error = %d\n",status));
    }

    status = RvSipStackGetResources(stackHndl, RVSIP_TRANSACTION, (void *)&pCurRes.TransactionResources);
    if (status == RV_OK) {
        printSipResourceObject("TRANSACTION             ",pCurRes.TransactionResources.transactions);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get TRANSACTION RESOURCES error = %d\n",status));
    }

    status = RvSipStackGetResources(stackHndl, RVSIP_TRANSACTION, (void *)&pCurRes.TransmitterResources);
    if (status == RV_OK) {
        printSipResourceObject("TRANSMITTERS            ",pCurRes.TransmitterResources.transmitters);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get TRANSMITTERS RESOURCES error = %d\n",status));
    }

    status = RvSipStackGetResources(stackHndl, RVSIP_TRANSPORT, (void *)&pCurRes.TransportResources);
    if (status == RV_OK) {
        printSipResourceObject("TRANSP connections      ",pCurRes.TransportResources.connections);
        printSipResourceObject("TRANSP connHash         ",pCurRes.TransportResources.connHash);
        printSipResourceObject("TRANSP oorEvents        ",pCurRes.TransportResources.oorEvents);
        printSipResourceObject("TRANSP ownersHash       ",pCurRes.TransportResources.ownersHash);
        printSipResourceObject("TRANSP pQueElements     ",pCurRes.TransportResources.pQueueElements);
        printSipResourceObject("TRANSP pQueueEvents     ",pCurRes.TransportResources.pQueueEvents);
        printSipResourceObject("TRANSP readBuffers      ",pCurRes.TransportResources.readBuffers);
        printSipResourceObject("TRANSP tlsEngines       ",pCurRes.TransportResources.tlsEngines);
        printSipResourceObject("TRANSP tlsSessions      ",pCurRes.TransportResources.tlsSessions);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get TRANSMITTERS RESOURCES error = %d\n",status));
    }
#ifdef RV_SIGCOMP_ON
    status = RvSipStackGetResources(stackHndl, RVSIP_TRANSACTION, (void *)&pCurRes.CompartmentResources);
    if (status == RV_OK) {
        printSipResourceObject("COMPARTMENTS            ",pCurRes.CompartmentResources.compartments);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to get COMPARTMENTS RESOURCES\n\n"));
    }
#endif /* RV_SIGCOMP_ON */

    status = IppTimerStart(&providerSip->watchdogTimer, IPP_TIMER_DONT_CHECK_IF_STARTED, providerSip->watchdogTimeout*1000);
    if(status!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"printResources::IppTimerStart error = %d\n",status));
    }
    RvLogInfo(ippLogSource,(ippLogSource,"\t\t=========== END SIP RESOURCES PRINT ==========\n\n"));
    return status;
}


static RvStatus getToHeader(RvSipPartyHeaderHandle hTo, char* address)
{
    RvSipAddressHandle hAddress = RvSipPartyHeaderGetAddrSpec(hTo);
    RV_UINT len = 0;

    /*Get user name*/
    len = RvSipAddrGetStringLength(hAddress, RVSIP_ADDRESS_USER);
    return RvSipAddrUrlGetUser(hAddress, address, len, &len);
}

static RvStatus getToAddressByCallLeg(RvSipCallLegHandle hCallLeg, char *address)
{
    RvSipPartyHeaderHandle hTo;
    RvStatus rv;

    /*Get "To" Address*/
    rv = RvSipCallLegGetToHeader (hCallLeg, &hTo);
    if (rv != RV_OK)
        return rv;

    return getToHeader(hTo, address);

}


/***************************************************************************
 * getHeaderSipUriFromCallLeg
 * ------------------------------------------------------------------------
 * General: copies a CallLeg header (To or From) address sip uri
 *          (e.g. sip:myphone@mydomain).
 *          The result is stored in the strUri string.
 * Return Value: RvStatus.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg - handle to the callLeg
 *          strUri - string with the returned uri
 *          maxLen - maximum length of the toUri string
 ***************************************************************************/
static RvStatus getHeaderSipUriFromCallLeg(
    IN  RvSipCallLegHandle  hCallLeg,
    OUT RvChar*             strUri,
    IN  RvUint32            maxLen,
    IN  RvSipHeaderType    headerType)
{
    RvSipPartyHeaderHandle hHeader = NULL;
    RvSipAddressHandle     hAddress = NULL;
    RV_UINT                len = 0;
    HPAGE                  hAddrPage;
    RvStatus               rv = RV_ERROR_OUTOFRANGE;

    switch (headerType)
    {
    case RVSIP_HEADERTYPE_FROM:
        rv = RvSipCallLegGetFromHeader(hCallLeg, &hHeader);
        break;

    case RVSIP_HEADERTYPE_TO:
        rv = RvSipCallLegGetToHeader(hCallLeg, &hHeader);
        break;
    case RVSIP_HEADERTYPE_CONTACT:
        rv = RvSipCallLegGetRemoteContactAddress (hCallLeg,&hAddress);
        break;

    default:
        break;
    }
    if (rv != RV_OK)
        return rv;

    if (hHeader != NULL)
    hAddress = RvSipPartyHeaderGetAddrSpec(hHeader);

    /*encode the address to buffer*/
    rv = RvSipAddrEncode(hAddress, g_appPool, &hAddrPage, &len);
    if (rv == RV_OK)
    {
        len = (len < maxLen)? len: (maxLen-1);
        RPOOL_CopyToExternal(g_appPool,
                            hAddrPage,
                            0,
                            (void*)strUri,
                            len);
        /*terminate the buffer with null*/
        strUri[len] = '\0';
    }

    RPOOL_FreePage(g_appPool, hAddrPage);

    return rv;
}


static RV_Status getCallerParamsAddress(RvSipMsgHandle  hMsg,
                                        RvSipCallLegHandle hCallLeg,
                                        char *fromAddress,
                                        RvUint32    fromAddressMaxLen,
                                        char *contactAddress,
                                        RvUint32    contactAddressMaxLen,
                                        char *name,
                                        RvUint32    nameMaxLen,
                                        char *displayName,
                                        RvUint32    displayNameMaxLen
                                        )
{
    RvSipPartyHeaderHandle hFrom;
    RvSipAddressHandle hAddress;
    RvStatus rv;
    RV_UINT len = 0;
    unsigned int actlen;

    if ((rv = RvSipCallLegGetFromHeader (hCallLeg, &hFrom)) != RV_OK)
        return rv;

    hAddress = RvSipPartyHeaderGetAddrSpec(hFrom);

	/* check the type of address received from FROM header */
	/* if the SIP URL address get the data according to RVSIP_ADDRESS_HOST */

    if(RvSipAddrGetAddrType(hAddress)== RVSIP_ADDRTYPE_URL)
	{
    len = RvSipAddrGetStringLength(hAddress,RVSIP_ADDRESS_HOST);
    len = (len <= fromAddressMaxLen)? len: fromAddressMaxLen;
    if ((rv = RvSipAddrUrlGetHost(hAddress, fromAddress, len, &actlen)) != RV_OK)
        return rv;
	}
	else
	{
		/* if the TEL URL address get the data according to RVSIP_ADDRESS_TEL_URI_NUMBER */
		if (RvSipAddrGetAddrType(hAddress) == RVSIP_ADDRTYPE_TEL)
		{

			len = RvSipAddrGetStringLength(hAddress,RVSIP_ADDRESS_TEL_URI_NUMBER);

			len = (len <= fromAddressMaxLen)? len: fromAddressMaxLen;
			rv= RvSipAddrTelUriGetPhoneNumber(hAddress,fromAddress,len, &actlen);
			if (rv != RV_OK )
			return rv;
		}
	}
    len = RvSipAddrGetStringLength(hAddress,RVSIP_ADDRESS_USER);
    len = (len <= nameMaxLen)? len: nameMaxLen;
    if ((rv = RvSipAddrUrlGetUser(hAddress, name, len, &actlen)) != RV_OK)
        name[0] = '\0';

    len = RvSipPartyHeaderGetStringLength(hFrom, RVSIP_PARTY_DISPLAY_NAME);
    len = (len <= displayNameMaxLen)? len: displayNameMaxLen;
    if ((rv = RvSipPartyHeaderGetDisplayName(hFrom, displayName, len, &actlen)) != RV_OK)
        displayName[0] = '\0';

    {
        RvSipAddressHandle   hContactAddress;
        RvSipContactHeaderHandle    hContact;
        RvSipHeaderListElemHandle hPos;


        hContact = (RvSipContactHeaderHandle)RvSipMsgGetHeaderByType(
                                                 hMsg,
                                                 RVSIP_HEADERTYPE_CONTACT,
                                                 RVSIP_FIRST_HEADER, &hPos);
        if(hContact)
        {
            hContactAddress = RvSipContactHeaderGetAddrSpec(hContact);
            len = RvSipAddrGetStringLength(hContactAddress, RVSIP_ADDRESS_HOST);
            len = (len <= contactAddressMaxLen)? len: contactAddressMaxLen;
            RvSipAddrUrlGetHost(hContactAddress, contactAddress, len, &actlen);
        }
		else
		{
			contactAddress[0] = '\0';
		}
    }
    return RV_OK;
}

RvStatus getToAddressReqUri(RvSipMsgHandle hMsg, char *address, RvUint32 maxLen)
{
    RvSipAddressHandle hAddress;
    RvSipAddressType    addressType;
    RvStatus rv;
    RV_UINT len = 0;

    hAddress = RvSipMsgGetRequestUri(hMsg);

    addressType = RvSipAddrGetAddrType(hAddress);

    /* handle tel-uri address*/
    if (addressType == RVSIP_ADDRTYPE_TEL)
    {
        /*Get phone number*/
        rv = RvSipAddrTelUriGetPhoneNumber(hAddress, address, maxLen, &len);
    }
    /* Handle url address */
    else /*RVSIP_ADDRTYPE_URL*/
    {
    /*Get user name*/
    len = RvSipAddrGetStringLength(hAddress, RVSIP_ADDRESS_USER);
    len = (len <=maxLen)? len: maxLen;
    rv = RvSipAddrUrlGetUser(hAddress, address, len, &len);
    }

    return rv;
}

static RvBool getAlertInfoData(RvSipMsgHandle hMsg,char* ringInfo)
{
    RvSipOtherHeaderHandle          hHeader = NULL;
    RvSipHeaderListElemHandle       hElement;
    char                            strValue[RV_SHORT_STR_SZ];
    RvUint                          stringLength = sizeof(strValue);
    RvStatus                        rv;

    hHeader =  RvSipMsgGetHeaderByName(hMsg,"Alert-Info", RVSIP_FIRST_HEADER,&hElement);
    if (hHeader != NULL)
    {
        rv = RvSipOtherHeaderGetValue(hHeader,strValue,stringLength,&stringLength);
        if (rv == RV_OK)
        {
            strncpy(ringInfo, strValue, stringLength);
            return RV_TRUE;
        }
    }
    return RV_FALSE;
}

static void storeDistinctiveRingFromMsg(RvSipAppCallLegHandle hAppCallLeg,
                                    RvSipMsgHandle        hMsg,
                                    RvDistinctiveRingType ringType)
{
    char ringInfo[RV_SHORT_STR_SZ];
    RvCCConnection* c =     (RvCCConnection*)hAppCallLeg;

    if (getAlertInfoData(hMsg, ringInfo))
    {
        if (ringType == RvDistinctiveRinging)
            rvCCConnectionSetDistinctiveRinging(c, ringInfo);
        else if (ringType == RvDistinctiveRingback)
                rvCCConnectionSetDistinctiveRingback(c, ringInfo);
    }
    else
    {
        if (ringType == RvDistinctiveRinging)
            rvCCConnectionResetDistinctiveRinging(c);
        else if (ringType == RvDistinctiveRingback)
                rvCCConnectionResetDistinctiveRingback(c);
    }
}

static RV_Status getCallParams(RvSipCallLegHandle   hCallLeg,
                               RvSipAppCallLegHandle hAppCallLeg,
                               RvSipMsgHandle  hMsg)
{
    RvStatus rv;

    char to[RV_SIPCTRL_ADDRESS_SIZE];
    char from[RV_SIPCTRL_ADDRESS_SIZE];
    char contact[RV_SIPCTRL_ADDRESS_SIZE];
    char callerName[RV_SIPCTRL_ADDRESS_SIZE];
    char callerDisplayName[RV_SIPCTRL_ADDRESS_SIZE];

    /* Get destination address from incoming SIP message */
    rv = getToAddressReqUri(hMsg, to, sizeof(to) -1);
    if (rv != RV_OK)
	{
		strcpy(to, "");
	}

    /* Get source address from incoming SIP message*/
    rv = getCallerParamsAddress(hMsg, hCallLeg,
        from, sizeof(from)-1,
        contact,  sizeof(contact)-1,
        callerName,  sizeof(callerName)-1,
        callerDisplayName, sizeof(callerDisplayName)-1);
    if (rv != RV_OK)
        return rv;

    /* Store all information in MTF database*/
    rv = rvCCProviderSipSetCallParams(hAppCallLeg, hCallLeg, to, from, contact, callerName, callerDisplayName);
	if (rv != RV_OK)
		return rv;

    storeDistinctiveRingFromMsg(hAppCallLeg, hMsg, RvDistinctiveRinging);

    return RV_OK;
}

/***************************************************************************
 * getCseqMethod
 * ------------------------------------------------------------------------
 * General:   Gets the method of a Cseq  header.
 *            If the method type is RVSIP_METHOD_OTHER the method string
 *            is got
 *
 * Return Value: RV_TRUE if the item was found, RV_FALSE otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg        - The msg handle
 *          methodType  - The reuest method type
 *          nameStr     - A string to look for if there is no method type for it
 ***************************************************************************/
static void getCseqMethod(RvSipMsgHandle   hMsg, RvSipMethodType *method, RvChar* methodStr, RvUint32 szMethodStr)
{
    RvSipCSeqHeaderHandle hCSeq = RvSipMsgGetCSeqHeader(hMsg);

    *method = RvSipCSeqHeaderGetMethodType(hCSeq);
    if (*method == RVSIP_METHOD_OTHER)
	{
		RvUint                       actualLen;

		RvSipCSeqHeaderGetStrMethodType(hCSeq, methodStr, szMethodStr, &actualLen);
		if (actualLen > 0)
		{
			methodStr[actualLen] = '\0';
		}
	}
}

/***************************************************************************
 * isCSeqMethod
 * ------------------------------------------------------------------------
 * General:   Checks if the method of a Cseq header equals a requested method.
 *            The requested method can be a specific method of type
 *            RvSipMethodType or a RVSIP_METHOD_OTHER which is also specified
 *            by a method string (e.g. UPDATE, INFO, etc.)
 *
 * Return Value: RV_TRUE if the item was found, RV_FALSE otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg        - The msg handle
 *          methodType  - The specific method type or RVSIP_METHOD_OTHER
 *          methodStr   - A method string specifier in case the method type is
 *                        RVSIP_METHOD_OTHER
 ***************************************************************************/

/* Check if the message CSeq method equals methodStr */
static RvBool isCSeqMethod(RvSipMsgHandle   hMsg, RvSipMethodType methodType, RvChar* methodStr)
{
	RvSipMethodType cseqMethod = RVSIP_METHOD_UNDEFINED;
	RvChar          cseqMethodStr[16];

	getCseqMethod(hMsg, &cseqMethod, cseqMethodStr, sizeof(cseqMethodStr));

	if (methodType != RVSIP_METHOD_OTHER)
	{
		/* This is a query about a specific method (e.g. INVITE, BYE, rtc.) */
		return (methodType == cseqMethod);
	}

	/* non specific method, compare the method strings */
	if ((cseqMethod == RVSIP_METHOD_OTHER) && (!strcmp(cseqMethodStr, methodStr)))
		return RV_TRUE;

	return RV_FALSE;
}

/* add a Retry-After header to a message */
static void addRetryAfterHeaderToMsg(RvSipMsgHandle hMsg, RvUint8  retryTime)
{
	RvSipRetryAfterHeaderHandle hRetryAfter;
	RvStatus   rv = RV_OK;

	rv = RvSipRetryAfterHeaderConstructInMsg(hMsg, RV_FALSE, &hRetryAfter);
	if (rv == RV_OK)
	{
		RvSipRetryAfterHeaderSetDeltaSeconds(hRetryAfter, retryTime);
	}
	else
	{
		RvLogError(ippLogSource,(ippLogSource,"addRetryAfterHeaderToMsg:: failed to add Retry-After header to msg %p", hMsg));
	}
}

/***************************************************************************
 * handleUpdateResponse
 * ------------------------------------------------------------------------
 * General:   A response for UPDATE request has been received.
 *            If the response code is 500 or 491, a timer is started for
 *            resending the UPDATE.
 *
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg       - The callLeg of the call
 *          hMsg           - The msg handle
 *          c              - Pointer to the connection object
 *          responseCode   - The response code
 ***************************************************************************/
static void handleUpdateResponse(RvSipCallLegHandle            hCallLeg,
								 RvSipMsgHandle                hMsg,
								 RvCCConnection*               c,
								 RvInt16                       responseCode)
{
	RvSipRetryAfterHeaderHandle    hRetryAfter;
	RvSipHeaderListElemHandle      hListElem;
	RvUint32                       retryTime = 0;
	RvSipCallLegDirection          eDirection;
	RvSdpMsg*                      lastUpdateSdp;
	RvUint                         strlen = 0;


	/* Change the offer/answer state even if there is no SDP in the response, because a response to
	   UPDATE completes an offer/aswer session. */
	rvCCConnSipSetOfferAnswerState(c, RV_MTF_OFFERANSWER_OFFER_ANSWERED);

	if (responseCode == RV_SIPCTRL_STATUS_OK /* 200 */)
	{
		strlen = RvSipMsgGetStringLength(hMsg,RVSIP_MSG_BODY);

		if (strlen > 0)
		{
			/* response for UPDATE is handled like a response fot re-invite */
			rvCCProviderSipHandleReinviteResponse(c, hMsg,RVSIP_CALL_LEG_REASON_REMOTE_ACCEPTED);
        }
	}
	else
	{
		if (responseCode == RV_SIPCTRL_STATUS_REQ_PENDING /* 491 */)
		{
			RvSipCallLegGetDirection(hCallLeg,&eDirection);

			switch (eDirection)
			{
				case RVSIP_CALL_LEG_DIRECTION_INCOMING:
				/*incoming call-leg*/
					retryTime = g_sipControl->calleeUpdateResendTimeout;
					if ( g_sipControl->calleeUpdateResendTimeout != (RvUint16)UNDEFINED)
					{
						retryTime = g_sipControl->calleeUpdateResendTimeout;
					}
					else
					{
						/* no value assinged to calleeUpdateResendTimeout.*/
						/* Get a random value in the range [0..2000] milliseconds, in units of 10 msec. */
						RvRandomGeneratorGetInRange(&g_mtfMgr->randomGenerator,200, &retryTime);
						retryTime = retryTime * 10;   /* get 10 msec units */
					}
					break;

				case RVSIP_CALL_LEG_DIRECTION_OUTGOING:
				/*outgoing call-leg */
					if ( g_sipControl->callerUpdateResendTimeout != (RvUint16)UNDEFINED)
					{
						retryTime = g_sipControl->callerUpdateResendTimeout;
					}
					else
					{
						/* no value assinged to callerUpdateResendTimeout.*/
						/* Get a random value in the range [2100..4000] milliseconds, in units of 10 msec. */
						/* Since the ramdom generator generates numbers starting from 0, 2100 is added to the result */
						RvRandomGeneratorGetInRange(&g_mtfMgr->randomGenerator,190, &retryTime);
						retryTime = (retryTime + 210) * 10;   /* get 10 msec units */
					}
					break;

				default:
					break;
			}
		}
		else
			if (responseCode == RV_SIPCTRL_STATUS_SERVERERR /* 500 */)
			{
				hRetryAfter = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_RETRY_AFTER,
													  RVSIP_FIRST_HEADER, &hListElem);
				RvSipRetryAfterHeaderGetDeltaSeconds(hRetryAfter, &retryTime);
				retryTime = retryTime * 1000 ;  /* change to milliseconds */
			}
			else
			{
				if ((responseCode == RV_SIPCTRL_STATUS_UNAUTHORIZED) ||
					(responseCode == RV_SIPCTRL_STATUS_PROXYAUTHREQ))
				{
					RvBool       rc;

					/* 401/407 response -  need to authenticate the request */

					/* Call rvCCProviderSipHandleUnauthenticateState to update the authorization header
					   with real credentials without resending the msg because the SIP stack won't
					   send it if the callLeg state is CONNECTED.
					*/
					rc = rvCCProviderSipHandleUnauthenticateState(c, hCallLeg, RV_FALSE);
					if (rc == RV_TRUE)
					{

						/*  Reset the UPDATE and media state  because UPDATE starts all over again */
						resetUpdateState(c);

						/*  resend the msg */
						rvCCConnSipResendUpdate(c);
						/* return because we must not clear the stored SDP or override the
						  UPDATE and media states. These values are have just been set by
						 rvCCConnSipResendUpdate proc */
						return;
					}
					else
					{
						 RvLogError(ippLogSource,(ippLogSource,"handleUpdateResponse:: failed to authenticate UPDATE, conn = %p", c));
						 /* don't return, there are some cleaning to do */
					}
				}
			}

		/* todo here: */
		/* get back to the media before the UPDATE transmission */
	}

	if (retryTime > 0)
	{
		/* Start a timer. When it expires UPDATE will be sent again */
		IppTimerStart(rvCCConnSipGetUpdateResendTimer(c), IPP_TIMER_RESTART_IF_STARTED, retryTime);
	}
	else
	{
		/* There is no need to store the UPDATE sdp since it is not going to be re-sent. */
		lastUpdateSdp = rvCCConnSipGetUpdateSdp(c);
		if (lastUpdateSdp != NULL)
		{
			/* destruct the stored SDP */
			rvSdpMsgDestruct(lastUpdateSdp);
			rvCCConnSipSetUpdateSdp(c, NULL);
		}
	}

	/*  Reset the UPDATE state */
	resetUpdateState(c);
}

#if 0
static void setAllowHeaderSipVer2_2(RvSipMsgHandle hSipMsg)
{
    RvSipAllowHeaderHandle hAllow;
    RvStatus rv;

    /*All will be concatenated to one Allow header */
    rv = RvSipAllowHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);
    rv = RvSipAllowHeaderSetMethodType(hAllow, RVSIP_METHOD_INVITE, NULL);

    rv = RvSipAllowHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);
    rv = RvSipAllowHeaderSetMethodType(hAllow, RVSIP_METHOD_ACK, NULL);

    rv = RvSipAllowHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);
    rv = RvSipAllowHeaderSetMethodType(hAllow, RVSIP_METHOD_BYE, NULL);

    rv = RvSipAllowHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);
    rv = RvSipAllowHeaderSetMethodType(hAllow, RVSIP_METHOD_REFER, NULL);

    rv = RvSipAllowHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);
    rv = RvSipAllowHeaderSetMethodType(hAllow, RVSIP_METHOD_NOTIFY, NULL);

    rv = RvSipAllowHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);
    rv = RvSipAllowHeaderSetMethodType(hAllow, RVSIP_METHOD_CANCEL, NULL);


}

#endif /*ifdef 0*/

/*This function adds an "Allow" header to the message. Used for SIP version 2.1 only.
  In Sip version 2.2 - use above function "setAllowHeaderSipVer2_2" */
static void setAllowHeader(RvSipMsgHandle hSipMsg)
{

    RvSipOtherHeaderHandle hAllow;

    RvSipOtherHeaderConstructInMsg(hSipMsg, RV_FALSE, &hAllow);

    RvSipOtherHeaderSetName(hAllow, "Allow");

	if (g_sipControl->addUpdateSupport)
	{
		RvSipOtherHeaderSetValue(hAllow, "INVITE, ACK, BYE, REFER, NOTIFY, INFO, CANCEL, UPDATE");
	}
	else
	{
		RvSipOtherHeaderSetValue(hAllow, "INVITE, ACK, BYE, REFER, NOTIFY, INFO, CANCEL");
	}
}

static void setTransportType( RvSipCallLegHandle     hCallLeg,
                              RvSipAppCallLegHandle  hAppCallLeg)
{
    RvSipAddressHandle      hContactAddress;
    RvCCConnection*         conn = (RvCCConnection*)hAppCallLeg;
    RvSipTransport          termtransport = rvCCTerminalSipGetTransportByConnection(conn);

    RvSipCallLegGetLocalContactAddress (hCallLeg, &hContactAddress);
    rvSipControlSetTransportType(hContactAddress, termtransport);

    RvSipCallLegGetRemoteContactAddress (hCallLeg, &hContactAddress);
    rvSipControlSetTransportType(hContactAddress, termtransport);
}



void rvSipControlTerminateEvent(void)
{
    sendEventToMsgSocket(NULL);
}

/***************************************************************************
* rvSipMgrSetUserAgentHeader
* ------------------------------------------------------------------------
* General:  adds a "User-Agent" header to the message.e.
* Return Value: None
* ------------------------------------------------------------------------
* Arguments:
* Input:   hSipMsg  - Handle to a message
*
***************************************************************************/
void rvSipMgrSetUserAgentHeader(RvSipMsgHandle hSipMsg)
{
	if (g_sipControl->addUserAgentHeader)
	{
		RvSipOtherHeaderHandle hUserAgent;

		RvSipOtherHeaderConstructInMsg(hSipMsg, RV_FALSE, &hUserAgent);

		RvSipOtherHeaderSetName(hUserAgent, "User-Agent");

		RvSipOtherHeaderSetValue(hUserAgent, g_sipControl->userAgentStr);
	}

}
/***************************************************************************
 * rvSipControlIsStaleTrue
 * ------------------------------------------------------------------------
 * General: returns value of "Stale" in received message
 *          "Stale" is a flag which indicates whether the previous request
 *           from the client was rejected because the nonce value was stale.
 * Return Value: True - if stale is true, False - if stale is false.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   handle  - Handle to object
 *          type    - type of object
 *
 ***************************************************************************/
RvBool rvSipControlIsStaleTrue(IN void* handle,IN HandleType type)
{
    RvSipAuthenticationHeaderHandle authHeader;
    RvSipHeaderListElemHandle       hListElem;
    RvSipMsgHandle                  hMsg = NULL;
    RvBool                          stale = RV_TRUE;

    RvLogEnter(ippLogSource,(ippLogSource,"rvSipControlIsStaleTrue(handle=%p,type=%s)", handle, AppHandleTypeName(type)));

    if (type == CallHandle)
    {
        if (RvSipCallLegGetReceivedMsg((RvSipCallLegHandle)handle, &hMsg) != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"fail to get RecvMsg Handle callHandel = %p",handle));
            stale = RV_FALSE;
        }
    }
    else if (type == RegHandle)
    {
        if (RvSipRegClientGetReceivedMsg((RvSipRegClientHandle)handle, &hMsg) != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"fail to get RecvMsg Handle callHandel = %p",handle));
            stale = RV_FALSE;
        }
    }

    if (stale != RV_FALSE)
    {
        RvSipAuthStale sipStale;
        authHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_AUTHENTICATION,
                            RVSIP_FIRST_HEADER, &hListElem);

        sipStale = RvSipAuthenticationHeaderGetStale(authHeader);
        stale = (sipStale == RVSIP_AUTH_STALE_TRUE);
    }


    RvLogLeave(ippLogSource,(ippLogSource,"rvSipControlIsStaleTrue()=%d", stale));

    return stale;
}


/*===============================================================================*/
/*========== E V E N T    H A N D L E R S   I M P L M E N T A T I O N S =========*/
/*===============================================================================*/

/***************************************************************************
 * AppCallLegCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new call-leg was created, and exchanges handles
 *           with the call-leg.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg - The new sip stack call-leg handle
 * Output:  phAppCallLeg - The application handle for this call-leg.
 ***************************************************************************/
static void RVCALLCONV AppCallLegCreatedEvHandler(
                           IN  RvSipCallLegHandle            hCallLeg,
                           OUT RvSipAppCallLegHandle         *phAppCallLeg)
{
    RvSipControl* sipMgr = rvCCSipPhoneGetSipMgr();

    RvLogInfo(ippLogSource,(ippLogSource, "New call-leg %p was created", hCallLeg));

    if (rvIppSipExtPreCallLegCreatedIncomingCB((RvIppSipControlHandle)sipMgr, hCallLeg, phAppCallLeg) == RV_FALSE)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"New call-leg %p -> ignored by user request", hCallLeg));
        return;
    }

    /* Continue as usual. We grab this call and set an application handle for the leg on our own */
    *phAppCallLeg = rvCCProviderSipNewCallLeg();

    rvIppSipExtPostCallLegCreatedIncomingCB((RvIppSipControlHandle)sipMgr, hCallLeg,
            (RvIppConnectionHandle)*phAppCallLeg);

}

/***************************************************************************
 * AppCallLegCreatedDueToForkingEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new call-leg was created due to forking. This
 *           call leg has a different to-tag than the original call leg.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg - The new sip stack call-leg handle
 * Output:  phAppCallLeg - The application handle for this call-leg.
 ***************************************************************************/
static void RVCALLCONV AppCallLegCreatedDueToForkingEvHandler(
							IN  RvSipCallLegHandle           hNewCallLeg,
							OUT RvSipAppCallLegHandle        *phNewAppCallLeg,
                            OUT RvBool                       *pbTerminate)
{
	RV_UNUSED_ARG(hNewCallLeg);
    RV_UNUSED_ARG(phNewAppCallLeg);

    *pbTerminate = RV_FALSE;
}

/***************************************************************************
 * RvSipCallLegStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a call-leg state change.
 *          If the new state is Offering - accept the call with
 *          RvSipCallLegAccept().
 *          If and incoming call-leg reached the Connected state, disconnect
 *          the call with RvSipCallLegDisconnect().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eState -      The new call-leg state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppCallLegStateChangedEvHandler(
                                   IN  RvSipCallLegHandle            hCallLeg,
                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                   IN  RvSipCallLegState             eState,
                                   IN  RvSipCallLegStateChangeReason eReason)
{
    RvSipControl* sipMgr = rvCCSipPhoneGetSipMgr();
    RvSipCallLegDirection   eDirection;
    RvSipCallLegHandle      hOrigCallLeg=NULL;
	RvCCConnection* c = (RvCCConnection*)hAppCallLeg;

    RvLogEnter(ippLogSource,(ippLogSource,"AppCallLegStateChangedEvHandler thread %d call-leg %p - State changed to %s, reason:%s",

                        (int)RvThreadCurrentId(),hCallLeg,rvSipControlGetCallLegStateName(eState), rvSipControlGetCallLegStateChangeName(eReason)));

    RvSipCallLegGetDirection(hCallLeg,&eDirection);

	callLegStateChangedToCallStateChangedReason(c, eReason);

    /*print the new state on screen*/
    RvLogInfo(ippLogSource,(ippLogSource, "%s call-leg %p - State changed to %s, reason:%s",
                        AppGetDirectionName(eDirection),
                        hCallLeg,rvSipControlGetCallLegStateName(eState), rvSipControlGetCallLegStateChangeName(eReason)));

    /* Check if this is a forked call-leg. If so disconnect non-original callLes */
	RvSipCallLegGetOriginalCallLeg(hCallLeg,&hOrigCallLeg);
	if ((hOrigCallLeg != hCallLeg) && (eState == RVSIP_CALL_LEG_STATE_CONNECTED))
	{
		RvLogInfo(ippLogSource,(ippLogSource, "AppCallLegStateChangedEvHandler: Disconnecting forked call-leg %p - it is different from original call-leg %p. ",
                        hCallLeg, hOrigCallLeg ));
		RvSipCallLegDisconnect(hCallLeg);
		return ;
	}

    if (rvIppSipExtPreStateChangedCB((RvIppSipControlHandle)sipMgr, hCallLeg, hAppCallLeg,
                                eState, eReason) == RV_FALSE)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"call-leg %p - State changed to %s -> Ignored by User Request",
                        hCallLeg,rvSipControlGetCallLegStateName(eState)));
        return;
    }


    rvCCProviderSipProcessEvent(hAppCallLeg, hCallLeg, eState, eReason);

    /* Note: if eState = RVSIP_CALL_LEG_STATE_DISCONNECTED or RVSIP_CALL_LEG_STATE_TERMINATED,
       hAppCallLeg is not valid anymore */
	if (eState != RVSIP_CALL_LEG_STATE_TERMINATED)
	{
		rvIppSipExtPostStateChangedCB((RvIppSipControlHandle)sipMgr, hCallLeg, hAppCallLeg,
								    	eState, eReason);
	}

    RvLogLeave(ippLogSource,(ippLogSource,"AppCallLegStateChangedEvHandler -->"));

}

/***************************************************************************
 * parseDTMFBody
 * ------------------------------------------------------------------------
 * General: Parses DTMF OOB message from message body. This function assumes one digit.
 *
 * Return Value: RV_OK on success, Negative value on failure
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          hAppCallLeg - The application handle for this call-leg.
 *          buffer      - Buffer containing message body
 *          bodyLength -   length of message body.
 ***************************************************************************/
static RvStatus parseDTMFBody(
    IN RvSipAppCallLegHandle    hAppCallLeg,
    IN RvChar*                  buffer,
    IN RvUint                   bodyLength)
{

    RvDtmfParameters dtmfParam;
    RvChar dtmfNumber[3];
    int duration = DEFAULT_DTMF_DURATION;
    RvChar* dtmfStr = strstr(buffer,"Signal=");

    RV_UNUSED_ARG(bodyLength);

	/* Handle "Signal=" */
	/* ---------------- */

    if (dtmfStr != NULL)
    {
        dtmfStr += 7 /*strlen("Signal=")*/;
        while (isspace((int)*dtmfStr))         /* TODO: limit based on bodyLength */
            dtmfStr++;
		if ((isdigit(dtmfStr[0]) == RV_FALSE) && (dtmfStr[0] != '*') && (dtmfStr[0] != '#'))
		{
			/* Invalid DTMF body - "Signal=" appears with no digit or with invalid digit  */
			RvLogError(ippLogSource,(ippLogSource, "parseDTMFBody() - failed to parse DTMF body, digit is missing or invalid in Signal line (%s)", buffer));
			return RV_ERROR_BADPARAM;
		}
        RvSscanf(dtmfStr, "%3s", &dtmfNumber);
    }
	else
	{
		/* Invalid DTMF body - "Signal=" is missing in body */
		RvLogError(ippLogSource,(ippLogSource, "parseDTMFBody() - failed to parse DTMF body, Signal line is missing (%s)", buffer));
		return RV_ERROR_BADPARAM;
	}

	/* Handle "Duration=" */
	/* ------------------ */

    dtmfStr = strstr(buffer,"Duration=");
	if (dtmfStr != NULL)
	{
		dtmfStr += 9; /* strlen("Duration=")*/
		while (isspace((int)*dtmfStr))        /* TODO: limit based on bodyLength */
			dtmfStr++;
		if (isdigit(dtmfStr[0]) == RV_FALSE)
		{
			/* Invalid DTMF body - "Duration=" appears with no digit or with invalid digit */
			RvLogError(ippLogSource,(ippLogSource, "parseDTMFBody() - failed to parse DTMF body, digit is missing or invalid in Duration line (%s)", buffer));
			return RV_ERROR_BADPARAM;
		}
		RvSscanf(dtmfStr, "%d", &duration);
	}
	else
	{
		/* Invalid DTMF body - "Duration=" is missing in body */
		RvLogError(ippLogSource,(ippLogSource, "parseDTMFBody() - failed to parse DTMF body (%s)", buffer));
		return RV_ERROR_BADPARAM;
	}

    rvDtmfParametersInit(&dtmfParam);
    dtmfParam.digit = (RvChar)dtmfNumber[0]; /* We assume 1 digit */
    dtmfParam.duration = duration;

    rvCCCallDtmfPressed((RvCCConnection *)hAppCallLeg, &dtmfParam);

    return RV_OK;
}

/***************************************************************************
 * isItemInAllowHeader
 * ------------------------------------------------------------------------
 * General:   Checks if a method or a string is part of the Allow header.
 *            When there are several allowed items, each item is stored
 *            in a seperated allow header. If the searched item is a method type
 *            this function should be called with the method type as the
 *            second argument, e.g.:
 *            isItemInAllowHeader(hMsg, RVSIP_METHOD_ACK, NULL);
 *            If another name is being searched the second
 *            argument must be RVSIP_METHOD_OTHER and the third one the
 *            name string, e.g.:
 *            isItemInAllowHeader(hMsg, RVSIP_METHOD_OTHER, "UPDATE");
 * Return Value: RV_TRUE if the item was found, RV_FALSE otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg        - The msg handle
 *          methodType  - The reuest method type
 *          nameStr     - A string to look for if there is no method type for it
 ***************************************************************************/
static RvBool isItemInAllowHeader(RvSipMsgHandle           hMsg,
								  RvSipMethodType          methodType,
								  RvChar*                  nameStr)
{
	RvSipAllowHeaderHandle       hHeader;
	RvSipHeaderListElemHandle    listElem;
	RvChar                       buffer[16];
	RvUint                       actualLen;
	RvBool                       lookForMethodType = RV_TRUE;
	RvSipMethodType              tempMethod;

	if (methodType == RVSIP_METHOD_OTHER)
	{
		if (nameStr == NULL)
			return RV_FALSE;

		lookForMethodType = RV_FALSE;
	}

	/* Get the first Allow header */
	hHeader = (RvSipAllowHeaderHandle)RvSipMsgGetHeaderByType(
		hMsg,RVSIP_HEADERTYPE_ALLOW,RVSIP_FIRST_HEADER,&listElem);

	while  (NULL != hHeader)
	{
		tempMethod = RvSipAllowHeaderGetMethodType(hHeader);

		if (lookForMethodType)
		{
			if(methodType == tempMethod)
			{
				return RV_TRUE;
			}
		}
		else
		if (tempMethod == RVSIP_METHOD_OTHER)
		{
			RvSipAllowHeaderGetStrMethodType(hHeader, buffer, sizeof(buffer), &actualLen);
			if (!strncmp(buffer, nameStr, actualLen))
			{
				return RV_TRUE;
			}
		}

		hHeader = (RvSipAllowHeaderHandle)RvSipMsgGetHeaderByType(
			hMsg,RVSIP_HEADERTYPE_ALLOW,RVSIP_NEXT_HEADER,&listElem);
	}

	return RV_FALSE;
}



/***************************************************************************
 * handle18xResponseWithMedia
 * ------------------------------------------------------------------------
 * General: Handling reception of a session progress (183) or ringing (180)
 *          message.
 *          The media is connected immediately and not after reception of OK
 *          for the initiating INVITE
 *
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAppCallLeg - The application handle for this call-leg.
 *
 ***************************************************************************/
static RvBool handle18xResponseWithMedia(RvSipAppCallLegHandle         hAppCallLeg)
{
    RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
    RvCCTerminal* term;
    RvCCTerminal* mdmTerm;
    RvCCTerminalSip* terminal;
    RvCCConnection * mdmConn;

    /*This will stop signals and connect media*/
    if (c == NULL)
        return RV_FALSE;

    if ((term = rvCCConnSipGetTerminal(c)) == NULL)
        return RV_FALSE;

    if ((terminal = rvCCTerminalSipGetImpl(term)) == NULL)
        return RV_FALSE;

    if ((mdmTerm = rvCCTerminalSipGetMdmTerminal(terminal)) == NULL)
        return RV_FALSE;

    if ((mdmConn = rvCCConnectionGetConnectParty(c)) == NULL)
        return RV_FALSE;

    /* if we got so far the media can be connected */
    rvCCTerminalMdmStopSignals(mdmTerm);
    rvCCTerminalMdmStopRingingSignal(mdmTerm);
    return rvCCConnMdmConnectMedia(mdmConn);
}

/***************************************************************************
 * AppCallLegMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the incoming message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppCallLegMsgReceivedEvHandler(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipMsgHandle                hMsg)
{
    RvSipControl* sipMgr = rvCCSipPhoneGetSipMgr();
    RvSipCallLegState state;
    RvSipMethodType     msgType;
    RvInt16 code;
    RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
    RvSipCallLegHandle  hOrigCallLeg=NULL;
    RvMtfMsgProcessType procType;
	RvBool              rc;
	RvBool              sdpInMsg;


    RvLogInfo(ippLogSource,(ippLogSource,"<-- Message Received (call-leg %p)", hCallLeg));

    printMessage(hMsg);
    
    PSip_AppPrintMessage(hMsg,1);

	/* Check if this is a forked call-leg. If so ignore non-original callLeg since there is no
	   application handle attached to it. The Sip Stack will handle this callLeg. */
	RvSipCallLegGetOriginalCallLeg(hCallLeg,&hOrigCallLeg);
	if (hOrigCallLeg != hCallLeg)
	{
		RvLogInfo(ippLogSource,(ippLogSource, "AppCallLegMsgReceivedEvHandler: Ignoring forked call-leg %p - it is different from original call-leg %p. ",
			hCallLeg, hOrigCallLeg ));
		return RV_OK;
	}

    /* Inform user application about the incoming message, check if application
       prefers this message to be processed or ignored */
    procType = rvIppSipExtPreMsgReceivedCB(
                (RvIppSipControlHandle)sipMgr, hCallLeg, hAppCallLeg, hMsg);

    if (procType == RV_MTF_IGNORE_BY_STACK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Message Received (call-leg %x) -> Ignored by SIP stack and by MTF (User Request)", hCallLeg));
        return RV_ERROR_UNKNOWN;
    }

    else if (procType == RV_MTF_IGNORE_BY_MTF)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Message Received (call-leg %x) -> Ignored by MTF, will be processed by SIP stack (User Request)", hCallLeg));
        return RV_OK;
    }

    msgType = RvSipMsgGetRequestMethod(hMsg);
    RvSipCallLegGetCurrentState (hCallLeg, &state);

    if ((state == RVSIP_CALL_LEG_STATE_DISCONNECTED) ||
        (state == RVSIP_CALL_LEG_STATE_DISCONNECTING) ||
        (state == RVSIP_CALL_LEG_STATE_TERMINATED))
            return RV_OK;

	if (state != RVSIP_CALL_LEG_STATE_CONNECTED)
	{
		RvSipAllowHeaderHandle       hHeader;
		RvSipHeaderListElemHandle    listElem;

		/* Get the first Allow header */
		hHeader = (RvSipAllowHeaderHandle)RvSipMsgGetHeaderByType(
					hMsg,RVSIP_HEADERTYPE_ALLOW,RVSIP_FIRST_HEADER,&listElem);
		/* If there is an allow header in the message and it does not contain UPDATE
		   it means that the other party does not accept UPDATE messages   */
		if (hHeader != NULL)
		{
			if (isItemInAllowHeader(hMsg, RVSIP_METHOD_OTHER, "UPDATE"))
			{
				rvCCConnSipSetUpdateAllowedByRemoteParty(c, RV_TRUE);
			}
			else
			{
				rvCCConnSipSetUpdateAllowedByRemoteParty(c, RV_FALSE);
			}
		}
	}

	sdpInMsg = rvSipControlIsMediaBody(hMsg);

    switch (msgType)
    {
        case RVSIP_METHOD_INVITE:

			if (state == RVSIP_CALL_LEG_STATE_IDLE)
            {
                /*Get call-leg parameters*/
                if (getCallParams(hCallLeg, hAppCallLeg, hMsg) != RV_OK)
                {
                    return RV_OK; /*Bad syntax, don't proceed*/
                }
            }

			/* If there is no SDP in the INVITE message, an SDP will be added to the OK
			   response. Therefore the offer/answer state is set to offer_building */
			if (sdpInMsg == RV_FALSE)
			{
				rvCCConnSipSetOfferAnswerState(c, RV_MTF_OFFERANSWER_OFFER_BUILDING);
			}

            /*No break*/

        case RVSIP_METHOD_PRACK:
        case RVSIP_METHOD_ACK:
		{
			/* When both (re)Invite and ACK messages contain SDP body ,the SDP in ACK will be ignored,
			   because  the offer-answer proses is already completed */
			if ((msgType == RVSIP_METHOD_ACK) && (sdpInMsg == RV_TRUE))
			{
				if (rvCCConnSipGetOfferAnswerState(c) == RV_MTF_OFFERANSWER_OFFER_ANSWERED)
				{	
					RvLogInfo(ippLogSource, (ippLogSource,
						"AppCallLegMsgReceivedEvHandler: can't handle SDP in ACK when call in ANSWERED state, conn %p", c));

					break;
				}
			}
			if (sdpInMsg == RV_TRUE)
			{
				rvCCConnSipChangeOfferAnswerState(c, RV_FALSE, (msgType == RVSIP_METHOD_ACK));
			}
			else
			/* Always change the offer-answer state when ACK is received  */
			if (msgType == RVSIP_METHOD_ACK)
			{
				rvCCConnSipChangeOfferAnswerState(c, RV_FALSE, RV_TRUE);
			}

            if (state != RVSIP_CALL_LEG_STATE_CONNECTED)
            {
				if (sdpInMsg == RV_TRUE)
				{
					/* When the callLeg state is connected the media is handled by procs in rvccconnmdm.c */
					rvCCProviderSipProcessIncomingSdp(hMsg, hAppCallLeg);
				}
            }
            else if (msgType == RVSIP_METHOD_ACK)
			{
				/* handle an ACK message with SDP after an empty Re-invite */

				if (sdpInMsg == RV_TRUE)
				{
					rvCCConnectionSetMediaState(c, RV_CCMEDIASTATE_MODIFYING);
					rvCCProviderSipProcessIncomingSdp(hMsg, hAppCallLeg);
					rvCCProviderSipHandleReinviteResponse(c, hMsg,RVSIP_CALL_LEG_REASON_REMOTE_ACCEPTED);
				}
            }
		}
            break;
        case RVSIP_METHOD_UNDEFINED:

            code = RvSipMsgGetStatusCode(hMsg);

			/* Is it a 2xx response ? */
			if ((code >= 200) && (code <300))
			{
				/* Check if there is a need to reset some authorization parameters */
				rvCCProviderSipResetAuthParams(c);
			}

            if (code == RV_SIPCTRL_STATUS_RINGING)
            {
                /* check if there is an alert-info header with distinctive ringback info */
                storeDistinctiveRingFromMsg(hAppCallLeg, hMsg, RvDistinctiveRingback);
			}

			if (sdpInMsg == RV_TRUE)
			{
				rvCCConnSipChangeOfferAnswerState(c, RV_FALSE, RV_FALSE);
				rc = rvCCProviderSipProcessIncomingSdp(hMsg, hAppCallLeg);

				if (rc == RV_TRUE)
				{
					/* Connect media when 183 is received or when 180 is received and connectMediaOn180 is set true */
					if (((code == RV_SIPCTRL_STATUS_RINGING) &&(sipMgr->connectMediaOn180 == RV_TRUE))||
						(code == RV_SIPCTRL_STATUS_SESSIONPROGRESS))
					{
						if (handle18xResponseWithMedia(hAppCallLeg) != RV_TRUE)
							return RV_OK;
					}
				}
			}

            break;

		case RVSIP_METHOD_OTHER:
			break;

        default:
            break;
    }

    rvCCProviderSipMsgReceived(hMsg, hAppCallLeg);

    rvIppSipExtPostMsgReceivedCB((RvIppSipControlHandle)sipMgr, hCallLeg, hAppCallLeg, hMsg);

    return RV_OK;
}


/***************************************************************************
 * modifyReferMsg
 * ------------------------------------------------------------------------
 * General: REFER message created by TK based on RV SIP stack v3 is incompatible
 *          with REFER messages created by TK based on SIP erlier versions.
 *          To maintain compatibility with previous version ReferTo field
 *          of REFER message is modified by this function.
 *          The result - modified message is written in internal SIP stack memory.
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   IN hMsg -    The sip message handle
 ***************************************************************************/
void modifyReferMsg(IN  RvSipMsgHandle  hMsg)
{
        RvSipAddressHandle        hAdd;
        RvSipReferToHeaderHandle  hReferTo;
        RvSipHeaderListElemHandle listElem;
        RvSipOtherHeaderHandle    hOther;
        RV_CHAR                   encodedAddr[150];
        HPAGE                     hAddrPage;
        RV_UINT32                 len;

        /*take refer-to from message*/
        hReferTo = (RvSipReferToHeaderHandle)RvSipMsgGetHeaderByType(
                             hMsg,RVSIP_HEADERTYPE_REFER_TO,RVSIP_FIRST_HEADER,&listElem);

        /*take the address from the refer-to*/
        hAdd = RvSipReferToHeaderGetAddrSpec(hReferTo);

        /*remove the refer-to header from message*/
        RvSipMsgRemoveHeaderAt(hMsg,listElem);

        /*encode the address to buffer*/
        RvSipAddrEncode(hAdd, g_appPool, &hAddrPage, &len);
        RPOOL_CopyToExternal(g_appPool,
                                  hAddrPage,
                                 0,
                                 (void*)encodedAddr,
                                  len);
            /*terminate the buffer with null*/
            encodedAddr[len] = '\0';


        /*set the refer-to in the message as other header*/
        RvSipOtherHeaderConstructInMsg(hMsg,RV_TRUE, &hOther);
        RvSipOtherHeaderSetName(hOther,"Refer-To");
        RvSipOtherHeaderSetValue(hOther,encodedAddr);

        RPOOL_FreePage(g_appPool, hAddrPage);
        return;
}



/***************************************************************************
* insertRouteHeaderInMsg
* ------------------------------------------------------------------------
* General: copy the Route header from the routeList of the terminal object to the
*          call-leg invite message.
*----------------------------------------------------------------------
*
***************************************************************************/
static RvStatus insertRouteHeaderInMsg(
                                        IN  RvSipMsgHandle   hOutBoundMsg,
                                        IN  RvInt            index,
                                        IN  RouteListDataType*  routeList)

{
    RvSipRouteHopHeaderHandle    hNewRouteHeaderHandle = NULL;
    RvStatus                     rv;

    rv = RvSipRouteHopHeaderConstructInMsg(hOutBoundMsg,
        RV_FALSE, /*push at head*/
        &hNewRouteHeaderHandle);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"insertRouteHeaderInMsg():: RvSipRouteHopHeaderConstructInMsg() failed."));
    }

    RvSipRouteHopHeaderCopy(hNewRouteHeaderHandle,
        routeList->routeHopHeaderList[index]);
    return rv;
}
/***************************************************************************
* insertRouteHeaderInMsg
* ------------------------------------------------------------------------
* General: Checks if the outgoing INVITE message is addressed to
*          a registrar and if there are Route headers to add to this
*          message. Route header/s are added if the registrar reply
*          to a previous REGISTER request contained Service-Route header/s.
*          The registrar Service-Route data is stored in the registering
*          RvvCCTerminal object routeList struct to be later used in the
*          INVITE Route headers.
*
*----------------------------------------------------------------------
*
* Arguments:
* Input:   hCallLeg -    The sip stack call-leg handle
*          hAppCallLeg - The application handle for this call-leg.
*          hMsg -        Handle to the outgoing message.
***************************************************************************/

RvStatus rvSipControlSetRouteHeaderInMsg(
                                    RvSipCallLegHandle hCallLeg,
                                    RvCCConnection    *c,
                                    RvSipMsgHandle    hMsg)
{
    RvCCTerminal*       term      = rvCCConnSipGetTerminal(c);
    RvCCTerminalSip*    terminal  = rvCCTerminalSipGetImpl(term);
    RouteListDataType*  routeList = rvCCTerminalSipGetRouteListData(terminal);
    RvStatus  rv = RV_OK;
    RvInt32   i = 0, routeCount = 0;

    /* Check wether there is data for Route header in the first place */
    if (routeList->numOfRouteHopHeadersInList == 0)
    {
        return RV_OK;
    }

    /* add route header with all registrar service-route addresses */

    /*----------------------------------------------------------------
    Insert the route header list (if exist) to the outbound message
    ------------------------------------------------------------------*/
    routeCount = routeList->numOfRouteHopHeadersInList;

    for (i=0; i<routeCount; i++)
    {
        rv = insertRouteHeaderInMsg(hMsg, i, routeList);
        if(rv != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlSetRouteHeaderInMsg():: failed to insert Route header to msg"));
        }
    }
    /*----------------------------------------------------------------
    set the stack to handle ROUTE header list
    ------------------------------------------------------------------*/
    rv = RvSipCallLegUseFirstRouteForInitialRequest(hCallLeg);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlSetRouteHeaderInMsg():: RvSipCallLegUseFirstRouteForInitialRequest failed "));
    }

    return rv;
}

/***************************************************************************
 * RvSipCallLegMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppCallLegMsgToSendEvHandler(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipMsgHandle                hMsg)
{
    RvSipControl* sipMgr = rvCCSipPhoneGetSipMgr();
    RvSipMethodType     msgType;
    RvSipCallLegState   state;
	RvCCConnection*     c = (RvCCConnection*)hAppCallLeg;
	RvBool              sdpInMsg = RV_FALSE;
	RvSipCallLegHandle  hOrigCallLeg=NULL;
	RvInt16             code;
	RvUint32            timeDelay;

    RvLogDebug(ippLogSource,(ippLogSource,"About to Send Message BEFORE Processing (call-leg %p)", hCallLeg));

#if 0
#ifdef RV_SIP_IMS_ON
       RvSipPUriHeaderHandle  hPPrefId;
	RvChar                 helper[256];
	RvStatus               rv;

	rv = RvSipPUriHeaderConstructInMsg(hMsg, RV_FALSE, &hPPrefId);
	if (RV_OK != rv)
	{
              RvLogDebug(ippLogSource,(ippLogSource, "Failed to construct P-Asserted-Identity header. "));
	}
	
	sprintf(helper, "P-Asserted-Identity: <sip:1100@192.168.1.239>");

	rv = RvSipPUriHeaderParse(hPPrefId, helper);
#endif
#endif
    
    printMessage(hMsg);
    
    PSip_AppPrintMessage(hMsg,0);


	/* Check if this is a forked call-leg. If so ignore non-original callLeg since there is no
	   application handle attached to it. The Sip Stack will handle this callLeg. */
	 RvSipCallLegGetOriginalCallLeg(hCallLeg,&hOrigCallLeg);
	if (hOrigCallLeg != hCallLeg)
	{
		RvLogInfo(ippLogSource,(ippLogSource, "AppCallLegMsgToSendEvHandler: Ignoring forked call-leg %p - it is different from original call-leg %p. ",
			hCallLeg, hOrigCallLeg ));
		return RV_OK;
	}

    if (rvIppSipExtPreMsgToSendCB((RvIppSipControlHandle)sipMgr, hCallLeg, hAppCallLeg,
                                    hMsg) == RV_FALSE)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Message To Send (call-leg %p) -> Ignored by User Request", hCallLeg));
        return RV_OK;
    }

    msgType = RvSipMsgGetRequestMethod(hMsg);

	if (msgType == RVSIP_METHOD_ACK)
	{
		/*  about to send ACK - change the offer/answer state
		    even if there is no SDP in the message. */
		rvCCConnSipChangeOfferAnswerState(c, RV_TRUE, RV_TRUE);
	}

	if (msgType == RVSIP_METHOD_UNDEFINED)
	{
	    code = RvSipMsgGetStatusCode(hMsg);

		if ((code == RV_SIPCTRL_STATUS_SERVERERR /* 500 */) &&
			(isCSeqMethod(hMsg, RVSIP_METHOD_INVITE, "") == RV_TRUE))
		{
			/* get a random delay value in the range [0..10] seconds */
			RvRandomGeneratorGetInRange(&g_mtfMgr->randomGenerator,10,&timeDelay);
			/* Add a Retry-After header to the message */
			addRetryAfterHeaderToMsg(hMsg, (RvUint8)timeDelay);
		}
	}

	setAllowHeader(hMsg);   /*Add Allow header with all supported methods*/
	rvSipMgrSetUserAgentHeader(hMsg);

    RvSipCallLegGetCurrentState (hCallLeg, &state);

    switch (state){

        case RVSIP_CALL_LEG_STATE_IDLE:
        /* Before sending Invite*/
        case RVSIP_CALL_LEG_STATE_OFFERING:
        /* Before sending authenticated Invite (response for 407)*/
        case RVSIP_CALL_LEG_STATE_UNAUTHENTICATED:
        case RVSIP_CALL_LEG_STATE_REDIRECTED:
            if (msgType != RVSIP_METHOD_BYE)
			{
				/* add sdp to message if there is one */
                if (rvCCProviderSipSetMedia(hMsg, hAppCallLeg) == RV_TRUE)
				{
					rvCCConnSipChangeOfferAnswerState(c, RV_TRUE, RV_FALSE);
				}
			}

            break;

		case RVSIP_CALL_LEG_STATE_INVITING:
		case RVSIP_CALL_LEG_STATE_PROCEEDING:

			sdpInMsg = rvSipControlIsMediaBody(hMsg);
			if ((sdpInMsg == RV_TRUE) &&
				(msgType != RVSIP_METHOD_ACK))   /* ACK was handled earlier */
			{
				rvCCConnSipChangeOfferAnswerState(c, RV_TRUE, RV_FALSE);
			}

			break;

        case RVSIP_CALL_LEG_STATE_MSG_SEND_FAILURE:
            /* we may get here after DNS failure to send Invite to one IP dest, trying to
               send the Invite to other IP dest. In this case SDP should be added to the
               message */
            /* don't break !! */
        case RVSIP_CALL_LEG_STATE_CONNECTED:
			{
				sdpInMsg = rvSipControlIsMediaBody(hMsg);

				if (msgType == RVSIP_METHOD_INVITE)
				{
					if (sdpInMsg == RV_FALSE)
					{
					/*  Don't send an INVITE without SDP. The session timer refresh mechanism
						generates INVITE messages without SDP, need to add it here.
						The SDP is taken from the SIP media caps which stores the last
						invite msg that was sent */
						if (rvCCProviderSipSetMedia(hMsg, hAppCallLeg) == RV_TRUE)
						{
							sdpInMsg = RV_TRUE;
							rvCCConnSipChangeOfferAnswerState(c, RV_TRUE, RV_FALSE);
						}
					}
				}

				if ((sdpInMsg == RV_TRUE) &&
                    (msgType != RVSIP_METHOD_ACK))   /* ACK was handled earlier */
				{
					rvCCConnSipChangeOfferAnswerState(c, RV_TRUE, RV_FALSE);
				}
			}
            break;
        default:
            break;
    }

#ifdef RV_SIP_IMS_ON
	if ((!g_sipControl->imsControl.disableAkaAuthentication) &&
		(msgType != RVSIP_METHOD_ACK))
	{
		/* Check if there is a need to add an empty authorization header to an outgoing request message.
		   This may happen if the call was originated by the other endpoint and the request about to
		   be sent is the first outgoing request of this endpoint (e.g. sending BYE in an incoming call)  */

		if (RvSipMsgGetMsgType(hMsg) == RVSIP_MSG_REQUEST)
		{
			RvSipHeaderListElemHandle hListElem;

			if ((RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_AUTHORIZATION,
			                                 RVSIP_FIRST_HEADER, &hListElem)== NULL) &&
											 c != NULL)
			{
				RvCCTerminal* t   = rvCCConnSipGetTerminal(c);
				RvCCTerminalSip*  term = rvCCTerminalSipGetImpl(t);

				rvAkaAuthCallLegBuildInitialId(hCallLeg, hMsg, term);
				/* clear the nonce so that on first 401/407 (unauthorized) reply there will be another registartion
				  attempt */
				rvCCConnSipSetNonce(c,"");
			}
		}
	}

#endif

    rvIppSipExtPostMsgToSendCB((RvIppSipControlHandle)sipMgr, hCallLeg, hAppCallLeg, hMsg);

	printMessage(hMsg);
	
	PSip_AppPrintMessage(hMsg,0);

    return RV_OK;
}

/***************************************************************************
 * RvSipCallLegModifyStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application that a the Modify state was changed.
 *          The modify state is related to a re-Invite on a connected call.
 *          before the call is connected the modify state will be undefined.
 *          When the call assumes the connected state the modify state will
 *          assume the idle state. Only when the modify state is Idle the
 *          call can initiate or receive a re-Invite request.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eModifyState -The new modify state.
 *          eReason     - The reason for the new state.
 ***************************************************************************/
static void RVCALLCONV  AppCallLegModifyStateChangedEv(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipCallLegModifyState       eModifyState,
                                    IN  RvSipCallLegStateChangeReason eReason)
{
    RvLogEnter(ippLogSource,(ippLogSource,"AppCallLegModifyStateChangedEv(hCallLeg=%p, hAppCallLeg=%p, eModifyState=%s, eReason=%s",
                      hCallLeg,hAppCallLeg,rvSipControlGetCallLegModifyStateName(eModifyState),rvSipControlGetCallLegStateChangeName(eReason)));

	/* Set the call state changed reason to inform about it later on */
	callLegStateChangedToCallStateChangedReason((RvCCConnection*)hAppCallLeg, eReason);

    rvCCProviderSipProcessEventModify(hAppCallLeg, hCallLeg, eModifyState, eReason);

    RvLogLeave(ippLogSource,(ippLogSource,"AppCallLegModifyStateChangedEv -->"));
}

static RvStatus handleReferReceived( RvSipCallLegHandle       hCallLeg,
                                     RvSipAppCallLegHandle    hAppCallLeg)
{
    RvSipAppCallLegHandle hNewAppCallLeg;
    RvSipCallLegHandle  hNewCallLeg;
    RvSipMsgHandle      hMsg, outbMsg;
    RvSipOtherHeaderHandle hHeader = NULL;
    RvSipReplacesHeaderHandle  hReplacesHeader;
    RvSipHeaderListElemHandle hElement;
    RvSipCallLegReplacesStatus statusReplaces = RVSIP_CALL_LEG_REPLACES_UNDEFINED;
    RvChar strValue[RV_MEDIUM_STR_SZ];
    RvUint stringLength = sizeof(strValue);
    RvChar to[RV_SIPCTRL_ADDRESS_SIZE];
    RvChar from[RV_SIPCTRL_ADDRESS_SIZE];
    RvChar contact[RV_SIPCTRL_ADDRESS_SIZE];
    RvChar callerName[RV_SIPCTRL_ADDRESS_SIZE];
    RvChar callerDisplayName[RV_SIPCTRL_ADDRESS_SIZE];
    RV_Status               rv;
    RvSipReferToHeaderHandle hReferToHeader = NULL;

    /* Call this callback to create a new SIP connection */
    hNewAppCallLeg = rvCCProviderSipNewCallLeg();
    if ((rv = RvSipCallLegReferAccept (hCallLeg, hNewAppCallLeg, &hNewCallLeg)) != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Failed to Accept Referred call-leg %p", hCallLeg));
        return RV_ERROR_NOT_FOUND; /* The same behave */
    }
    /* RVrep00040508 solve crash of incoming refer and out of call resource in sip stack */
    if (hNewCallLeg == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"Failed to Accept Referred call-leg %p hNewCallLeg = NULL", hCallLeg));
        return RV_ERROR_NULLPTR;
    }
    /* Get the rcvd REFER message */
    rv = RvSipCallLegGetReceivedMsg(hCallLeg, &hMsg);
    if ((rv != RV_OK) || (hMsg == NULL))
    {
        RvLogError(ippLogSource,(ippLogSource,"RvSipCallLegGetReceivedMsg Failed call-leg %p", hCallLeg));
        return RV_ERROR_NOT_FOUND; /*TBD: The same behave */
    }

    /* Check if "Supported: Replaces" header exists in the REFER message */
    hHeader =  RvSipMsgGetHeaderByName(hMsg,"Supported", RVSIP_FIRST_HEADER,&hElement);
    while(hHeader != NULL)
    {
        rv = RvSipOtherHeaderGetValue(hHeader,strValue,stringLength,&stringLength);
        if (rv != RV_OK)
        {
            /* We failed to get this value for some reason, maybe we'll have more luck with next one */
            RvLogError(ippLogSource,(ippLogSource,"handleReferReceived: Getting value from Supported header failed, try the next one, call-leg %p", hCallLeg));
            continue;
        }

        if(strcmp(strValue,"replaces") == 0)
        {
            statusReplaces = RVSIP_CALL_LEG_REPLACES_SUPPORTED;
            break;
        }
        hHeader =  RvSipMsgGetHeaderByName(hMsg,"Supported", RVSIP_NEXT_HEADER,&hElement);
        /* Reset string length for next value */
        stringLength = sizeof(strValue);
    }

    if (statusReplaces == RVSIP_CALL_LEG_REPLACES_SUPPORTED)
    {
        /* Check if Replaces header exist as part of Refer-to header */

        hReferToHeader =  RvSipMsgGetHeaderByType(hMsg,RVSIP_HEADERTYPE_REFER_TO, RVSIP_FIRST_HEADER,&hElement);
        rv = RvSipReferToHeaderGetReplacesHeader(hReferToHeader, &hReplacesHeader);
        /* TBD: What if ((rc == RV_BadPointer) || (RV_InvalidHandle))?????
        TBD: Note that rc = BadPointer in case pCallLeg == NULL || phReplacesHeader == NULL,
        and it can be a problem to get BadPointer in case phReplacesHeader == NULL,
        because it is valid....*/
        if (hReplacesHeader != NULL)
        {
            ; /* DO NOTHING */
            /* the invite should include the following headers:
            Supported: Replaces, replaces, Referred-by
            no Changes are required to send these headers
            since the stack will add them automatically in CallLegReferAccept.
            Note that Supported header is added in the stack in the transaction layer, if addSupportedListToMsg is configured to 1 in the sip configuration. */
        }
        else /* hReplacesHeader == NULL */
        {
            ; /* DO NOTHING */
            /* Add to INVITE the following headers:
            Supported: Replaces, Referred-by
            The Replaces header is not included.
            no changes are required to send these headers
            since the stack won't add Replaces header if it doesn't exist
            SEE CallLegReferAccept */
        }
    }
    else /* Assume RVSIP_CALL_LEG_REPLACES_UNDEFINED */
    {
        /* Check if Referred-by header exist */
        RvSipReferredByHeaderHandle hReferredByHeader;
        RvSipHeaderListElemHandle   hListElem = NULL;
        hReferredByHeader = (RvSipReferredByHeaderHandle)RvSipMsgGetHeaderByType(
                                                    hMsg, RVSIP_HEADERTYPE_REFERRED_BY,
                                                    RVSIP_FIRST_HEADER, &hListElem);
        if (hReferredByHeader != NULL)
        {
            ; /* DO NOTHING */
            /* Add to INVITE the referred-by header.
            This header is already added to current code.
            Changes required are to remove Supported header
            since it is added by stack automatically to every INVITE */
        }
        else
        {
            ; /* DO NOTHING */
            /* The invite shouldn't include any of these headers.
            Supported header will need to be removed since it is added
            by the stack in every INVITE.
            Replaces and Referred-by headers will not be added if they don't
            exist in the incoming message */
        }
        /* In both cases it is needed to remove Supported header */
        rv = RvSipMsgRemoveHeaderAt(hMsg,hElement);
        /* if (rv != RV_OK)  RV_InvalidHandle */
            /* TBD: What if failed to remove supported header */
    }

    rv = getToAddressByCallLeg(hNewCallLeg, to);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppCallLegReferStateChangedEv: Failed to getToAddressByCallLeg"));
        return RV_ERROR_NOT_FOUND;/* TBD: What if failed */
    }

	rv = getCallerParamsAddress(hMsg, hNewCallLeg,
        from, sizeof(from) -1,
        contact,  sizeof(contact) -1,
        callerName,  sizeof(callerName) -1,
        callerDisplayName, sizeof(callerDisplayName) -1);

    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppCallLegReferStateChangedEv: Failed to getCallerParamsAddress"));
        return RV_ERROR_NOT_FOUND;/* TBD: What if failed */
    }

    rv = rvCCProviderSipSetCallParams(hNewAppCallLeg, hNewCallLeg, to, from, contact, callerName, callerDisplayName);
	if (rv != RV_OK)
	{
		RvLogWarning(ippLogSource,(ippLogSource,"AppCallLegReferStateChangedEv: Failed to set Call Params"));
		RvSipCallLegDisconnect(hNewCallLeg);
		return RV_ERROR_NOT_FOUND;
	}

    setTransportType(hNewCallLeg, hAppCallLeg);

    /* Complete the refer process of the transfer */
    rvCCProviderSipReferConnected(hAppCallLeg, hNewAppCallLeg);

    /* Add route headers if needed */
    RvSipCallLegGetOutboundMsg(hNewCallLeg, &outbMsg);
    rvSipControlSetRouteHeaderInMsg(hNewCallLeg, (RvCCConnection*)hNewAppCallLeg, outbMsg);
#ifdef RV_SIP_IMS_ON
	/* Calling this API will force all outgoing messages to be sent to the Outbound Proxy that was configured
	   locally + transport type configured locally and not to the address included in Service-Route header returned from Registrar. */
	RvSipCallLegSetForceOutboundAddrFlag(hCallLeg, RV_TRUE);
#endif /* RV_SIP_IMS_ON */

    /*Send Invite to C - the referenced agent*/
    if ((rv = RvSipCallLegConnect (hNewCallLeg)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"Failed to Connect Referred call-leg %p", hCallLeg));
        return RV_ERROR_ILLEGAL_ACTION;
    }

    RvLogInfo(ippLogSource,(ippLogSource,"Refer is Connected, call-leg %p -> new call-leg %p",
                hCallLeg, hNewCallLeg));
    return RV_OK;
}

/***************************************************************************
 * AppCallLegReferStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a call-leg refer state change.
 *          For each state change the new state is supplied and the
 *          reason for the state change is also given.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eState -      The new call-leg refer state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
/* Transfer-Replaces feature */
static void RVCALLCONV AppCallLegReferStateChangedEv(
                            IN  RvSipCallLegHandle                    hCallLeg,
                            IN  RvSipAppCallLegHandle                 hAppCallLeg,
                            IN  RvSipCallLegReferState                eState,
                            IN  RvSipCallLegStateChangeReason         eReason)
{
    RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
    RvCCConnSip* conn = rvCCConnSipGetIns(c);
    RvCCTerminal* t   = rvCCConnSipGetTerminal(c);
    RV_Status rv;

    RvLogInfo(ippLogSource,(ippLogSource,"call-leg %p - Refer State changed to %s, reason:%s",
                hCallLeg,rvSipControlGetCallLegReferStateName(eState), rvSipControlGetCallLegStateChangeName(eReason)));

	/* Set the call state changed reason to inform about it later on */
    callLegStateChangedToCallStateChangedReason(c, eReason);

    switch (eState)
            {
                case RVSIP_CALL_LEG_REFER_STATE_REFER_RCVD:
                    /* On B: Refer request was received */
                    handleReferReceived(hCallLeg, hAppCallLeg);
                    break;

                case RVSIP_CALL_LEG_REFER_STATE_REFER_UNAUTHENTICATED:
                    if (t != NULL)
                    {
                        RvSipCallLegAuthenticate(hCallLeg);
                    }
                    else
                    {
                        RvLogError(ippLogSource,(ippLogSource,"AppCallLegReferStateChangedEv:: Null terminal"));
                    }

                    break;

    default:
        switch (eReason)
        {
            /* Check for failed reasons. */
            /* meaning, in idle state with the specific reasons in A:
            When it is succeeded, the reason is RVSIP_CALL_LEG_REASON_REMOTE_ACCEPTED,
            and there is nothing to do. It is needed to wait for Notify.
            Otherwise, there is a failure. for example, A sent REFER msg  to B,
            but didn't get any response yet.
            In this case the reason is LOCAL_TIMEOUT. */
        case RVSIP_CALL_LEG_REASON_LOCAL_TIME_OUT:
        case RVSIP_CALL_LEG_REASON_NETWORK_ERROR:
        case RVSIP_CALL_LEG_REASON_503_RECEIVED:
        case RVSIP_CALL_LEG_REASON_REQUEST_FAILURE: /* for 4xx response */
        case RVSIP_CALL_LEG_REASON_SERVER_FAILURE:  /* for 5xx response */
        case RVSIP_CALL_LEG_REASON_GLOBAL_FAILURE:  /* for 6xx response */
            /* Pay attention that B side won't go to this code */
            /* The transfer process had not completed successfully.
            Go back from the transfer process: */
            /* stop refer timer */
            rv = IppTimerStop(&conn->referTimer);
            rvCCCallTransferCompletedCB(c, RV_FALSE);
            break;
        default:
            break;
        }
    }

}



/***************************************************************************
 * AppCallLegReferNotifyEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a refer-notify related event (a
 *          refer-notify is a NOTIFY request that is a part of a refer process).
 *          The callback supplies the event that occured and the reason for the
 *          event occurence. RvSipCallLegReferNotifyEv() will supply you the
 *          final status of the connect attempt in the Refer-Notify Ready event
 *          indication, using the responseCode parameter. If you call Notify()
 *          with this status, an appropriate status line is set to the body of
 *          the NOTIFY request message. RvSipCallLegReferNotifyEv() will supply
 *          you the response code found in the refer-notify body in the Notify
 *          Received or Notify Sent indication, using the responseCode parameter.
 *          This way you will not need to parse the body that is received in the
 *          NOTIFY request.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eNotification - The refer notify event.
 *          eReason -     The reason for the event occurence.
 *          responseCode - This parameter has different meaning for
 *                         different events.
 *                         for RVSIP_CALL_LEG_REFER_NOTIFY_READY event the
 *                         response code represent the final status of the
 *                         connect attempt.
 *                         for the events RVSIP_CALL_LEG_REFER_NOTIFY_RECVD and
 *                         RVSIP_CALL_LEG_REFER_NOTIFY_SENT the response code
 *                         represents the status code found in the
 *                         NOTIFY request message body. In all other states
 *                         the response code represents the status code
 *                         of the response to the NOTIFY request.
 ***************************************************************************/
void RVCALLCONV AppCallLegReferNotifyEv(
                            IN  RvSipCallLegHandle              hCallLeg,
                            IN  RvSipAppCallLegHandle           hAppCallLeg,
                            IN  RvSipCallLegReferNotifyEvents   eNotification,
                            IN  RvSipCallLegStateChangeReason   eReason,
                            IN  RV_INT16                        responseCode,
                            IN  RV_INT32                        cSeqStep)
{
    RvCCConnection*        c = (RvCCConnection*)hAppCallLeg;
    RvStatus               rv;
    RvStatus               status;

	/* Set the call state changed reason to inform about it later on */
	callLegStateChangedToCallStateChangedReason(c, eReason);

    if (eNotification == RVSIP_CALL_LEG_REFER_NOTIFY_READY)
    {
        if (responseCode == RVSIP_CALL_LEG_REASON_UNDEFINED) /* i.e 'C' EP didn't answer */
        {
            /* Set the response code to be a value between (200 <= status && 700 < status) */
            responseCode = RV_SIPCTRL_STATUS_DECLINE; /* 603 */
        }
        rv = RvSipCallLegReferNotify (hCallLeg, responseCode,cSeqStep);
        if (rv != RV_OK)
        {
            RvLogInfo(ippLogSource,(ippLogSource, "Failure: Notify was NOT Sent for call leg: %p, Code %d, ", hCallLeg, responseCode));
        }
        else
        {
            RvLogInfo(ippLogSource,(ippLogSource, "Notify was Sent for call leg: %p, Code %d, ", hCallLeg, responseCode));
        }
    }
    else if (eNotification == RVSIP_CALL_LEG_REFER_NOTIFY_RCVD)
    {
        /* NOTIFY message was received by the call-leg. */
        if ((responseCode >= 100) && (responseCode < 200)) /* Provisional notify response */
        {
            ; /* Do nothing. The stack should send automatically OK */
        }
        else if (responseCode == 200) /* OK */
        {
            rvCCProviderSipTransferNotified(hAppCallLeg, RV_TRUE);
            RvLogInfo(ippLogSource,(ippLogSource, "Notify was Received for call leg: %p, Code %d, ", hCallLeg, responseCode));
        }
        else if (responseCode >= 300) /* Any Failure */
        {
            RvCCConnection* c = (RvCCConnection*)hAppCallLeg;

            RvCCConnSip* conn = rvCCConnSipGetIns(c);

            status = IppTimerStop(&conn->referTimer);
#ifdef USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/11/23 */
            /* transfer is actioned by on hook, so, even it is failed to transfer, 
            it will be release connections */
            rvCCProviderSipTransferNotified(hAppCallLeg, RV_TRUE);
#else
            rvCCCallTransferCompletedCB(c, RV_FALSE);
#endif
        }
    }


}


/***************************************************************************
 * AppCallLegSessionTimerNotificationEvHandler
 * ------------------------------------------------------------------------
 * General:  Handles notifications sent by the SIP Stack about session timer
 *           events:
 *           RVSIP_CALL_LEG_SESSION_TIMER_NOTIFY_REASON_SESSION_EXPIRES -
 *           the session timer interval expired with no new refresh msg.
 *           The call is disconnected.
 *           RVSIP_CALL_LEG_SESSION_TIMER_NOTIFY_REASON_422_RECEIVED -
 *           A 422 Interval too small response was received. In this case
 *           nothing should be done, the call is dropped elsewhere.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg    - The sip stack call-leg handle
 * Output:  hhAppTransc - The application handle for this call-leg.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegSessionTimerNotificationEvHandler(
									IN    RvSipCallLegHandle                         hCallLeg,
                                    IN    RvSipAppCallLegHandle                      hAppCallLeg,
                                    IN    RvSipCallLegSessionTimerNotificationReason eReason)
{
	RvStatus rv = RV_OK;

	RV_UNUSED_ARG(hAppCallLeg);

	switch (eReason)
	{
	case RVSIP_CALL_LEG_SESSION_TIMER_NOTIFY_REASON_SESSION_EXPIRES:
		{
			RvCCConnection*   party;

			/* Session timer refresh-time expired and no refresh message has been sent/received */
			/* The call will be disconnected */
			RvLogInfo(ippLogSource,(ippLogSource, "AppCallLegSessionTimerNotificationEvHandler: timer expired without refresh, diconnecting callLeg %p, connection %p",
									hCallLeg, hAppCallLeg));
			/* disconnectthe MDM connection */
			party = rvCCConnectionGetConnectParty((RvCCConnection *)hAppCallLeg);
			rvCCConnectionDisconnect(party, RV_CCCAUSE_NORMAL);
			/* disconnect the SIP connection */
			rvCCConnectionDisconnect((RvCCConnection *)hAppCallLeg, RV_CCCAUSE_NORMAL);

			break;
		}
	case RVSIP_CALL_LEG_SESSION_TIMER_NOTIFY_REASON_422_RECEIVED:
		/* Received 422 (Interval too small) reply. The call is dropped, no action is taken here */
		break;

	default:
		RvLogError(ippLogSource,(ippLogSource, "AppCallLegSessionTimerNotificationEvHandler: unspecified reason %d", eReason));
		break;
	}
	return rv;
}

/***************************************************************************
 * getSessionTimerActualValues
 * ------------------------------------------------------------------------
 * General:  Get the actual sessionExpires, MinSE and refresherType as they are
 *           stored in pCallLeg->pSessionTimer. Note that the SIP Stack proc
 *           RvSipCallLegSessionTimerGetNegotiationParams() gets the configuration
 *           values. The actual values are a result of negotiation between both
 *           call parties values and may differ from the configured values.
 *
 * Return Value: RV_OK on success, error code otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg    - The sip stack call-leg handle
 * Output:  sessionExpires - session Expires value of the call
 *          minSE          - minSE value of the call
 *          eRefresherType - the refresher party
 ***************************************************************************/
static RvStatus getSessionTimerActualValues(
									   IN   RvSipCallLegHandle                             hCallLeg,
									   OUT  RvInt32                                       *sessionExpires,
									   OUT  RvInt32                                       *minSE,
									   OUT  RvSipSessionExpiresRefresherType              *eRefresherType)
{
	RvStatus rv;

	rv = RvSipCallLegSessionTimerGetSessionExpiresValue(hCallLeg, sessionExpires);
	if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "getSessionTimerActualValues: Failed to get session expired val for callLeg %p",
			hCallLeg));
		return rv;
	}

	/* The following params are optional therefore the proc will not return error code even if one/all of them
	   don't exist */
	rv = RvSipCallLegSessionTimerGetMinSEValue(hCallLeg, minSE);
	if (rv != RV_OK)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "getSessionTimerActualValues: Failed to get minSE val for callLeg %p",
			hCallLeg));
	}

	rv = RvSipCallLegSessionTimerGetRefresherType(hCallLeg, eRefresherType);
	if (rv != RV_OK)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "getSessionTimerActualValues: Failed to get refresher type for callLeg %p",
			hCallLeg));
	}

	RvLogDebug(ippLogSource,(ippLogSource, "getSessionTimerActualValues: session timer value for callLeg %p: sessionExpires: %d, minSE: %d: refresherType %d",
		                                    hCallLeg, *sessionExpires, *minSE, *eRefresherType));
	return RV_OK;
}

/***************************************************************************
 * sendUpdateWithSessionTimerHeaders
 * ------------------------------------------------------------------------
 * General:  Sends an UPDATE message with session timer headers
 *
 * Return Value: RV_OK on success, error code otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg    - The sip stack call-leg handle
 *          hTransc     - The sip stack transaction handle
 ***************************************************************************/
static RvStatus sendUpdateWithSessionTimerHeaders(
												  IN    RvSipCallLegHandle       hCallLeg,
												  INOUT RvSipTranscHandle        hTransc)
{
	RvInt32                                     sessionExpires;
	RvInt32                                     minSE = 0;
	RvSipSessionExpiresRefresherType            eRefresherType = RVSIP_SESSION_EXPIRES_REFRESHER_NONE;
    RvStatus                                    rv = RV_OK;
	RvSipCallLegSessionTimerRefresherPreference eRefresherPref;

	rv = getSessionTimerActualValues(hCallLeg, &sessionExpires, &minSE, &eRefresherType);
	if (rv != RV_OK)
	{
		/* Couldn't get the actual session timer values from the callLeg. */
		/* Get the session timer parameters as configured by the user     */
		rv = RvSipCallLegSessionTimerGetNegotiationParams(hCallLeg, &sessionExpires, &minSE, &eRefresherType,
			&eRefresherPref);
		if (rv != RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource, "sendUpdateWithSessionTimerHeaders: can't send UPDATE. no session timer params for callLeg %p",
					                                    hCallLeg));
			return rv;
		}
	}
	/* call the following proc with a default refresher type to let the SIP Stack decide */
	rv = RvSipCallLegTranscSessionTimerGeneralRefresh(hCallLeg, "UPDATE", sessionExpires,
		                                              minSE, RVSIP_SESSION_EXPIRES_REFRESHER_NONE, &hTransc);

	if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "sendUpdateWithSessionTimerHeaders: failed to send UPDATE for callLeg %p",
			                                    hCallLeg));
		return rv;
	}

	RvLogInfo(ippLogSource,(ippLogSource, "sendUpdateWithSessionTimerHeaders:UPDATE sent for callLeg %p, Transc %p",
		                                   hCallLeg, hTransc));

	return rv;
}

/***************************************************************************
 * sendReInviteWithSessionTimerHeaders
 * ------------------------------------------------------------------------
 * General:  Sends  Re-INVITE message with session timer headers
 *
 * Return Value: RV_OK on success, error code otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg    - The sip stack call-leg handle
 ***************************************************************************/
static RvStatus sendReInviteWithSessionTimerHeaders(RvSipCallLegHandle       hCallLeg)
{
	RvInt32                                   sessionExpires;
	RvInt32                                   minSE = 0;
	RvSipSessionExpiresRefresherType          eRefresherType = RVSIP_SESSION_EXPIRES_REFRESHER_NONE;
	RvStatus                                  rv;

	rv = getSessionTimerActualValues(hCallLeg, &sessionExpires, &minSE, &eRefresherType);
	if (rv == RV_OK)
	{
		/* Set the actual session timer values before sending a refresh re-invite */
		RvSipCallLegSessionTimerSetPreferenceParams(hCallLeg,sessionExpires, minSE,
			                                        RVSIP_SESSION_EXPIRES_REFRESHER_NONE /* let the SIPStack decide */);
	}

	/* Even if we failed to get the actual values we can still send a refresh.
	   It will be sent with session timer values as configured by the user */
	rv = RvSipCallLegSessionTimerRefresh(hCallLeg);
	if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "sendReInviteWithSessionTimerHeaders: failed to send Re-INVITE for callLeg %p",
					                                hCallLeg));
	}

	RvLogInfo(ippLogSource,(ippLogSource, "sendReInviteWithSessionTimerHeaders:INVITE sent for callLeg %p",hCallLeg));

	return rv;
}

/***************************************************************************
 * AppCallLegSessionTimerRefreshAlertEvHandler
 * ------------------------------------------------------------------------
 * General:  SessionExpires time is about to expire. Send another refresh
 *           message by UPDATE or Re-Invite. The method is determined
 *           upon configuration parameter.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg    - The sip stack call-leg handle
 * Output:  hhAppTransc - The application handle for this call-leg.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegSessionTimerRefreshAlertEvHandler(
									IN    RvSipCallLegHandle       hCallLeg,
                                    IN    RvSipAppCallLegHandle    hAppCallLeg)
{
    RvStatus rv = RV_OK;

	RV_UNUSED_ARG(hAppCallLeg);

	if (g_sipControl->sessionTimerRefreshByUpdate == RV_TRUE)
	{
		RvSipTranscHandle     hTransc = NULL;

		rv = sendUpdateWithSessionTimerHeaders(hCallLeg, hTransc);
	}
	else
	{
		rv = sendReInviteWithSessionTimerHeaders(hCallLeg);
	}

	return rv;
}

/***************************************************************************
 * AppTranscCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new non call-leg related transaction was created
 *           This application does not exchange handles with the transaction.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc - The new sip stack transaction handle
 *          context - The application context given in the
 *                    RvSipTransactionMgrSetEvHandlers function. (In this
 *                    example it is null but applications can use this
 *                    parameters as referecne to their database.
 * Output:  phAppTransc - The application handle for this call-leg.
 *          b_handleTransc - Indicates whether the application wishes to handle
 *                           this transaction. I False the transcation will
 *                           be a stand alone transaction.
 ***************************************************************************/
static void RVCALLCONV AppTranscCreatedEvHandler(
                           IN  RvSipTranscHandle            hTransc,
                           IN  void                         *context,
                           OUT RvSipTranscOwnerHandle       *phAppTransc,
                           OUT RvBool                      *b_handleTransc)
{

    RV_UNUSED_ARG(hTransc);
    RV_UNUSED_ARG(context);

    *phAppTransc = NULL;       /*the application handle is set to NULL*/
    *b_handleTransc = RV_TRUE; /*the application wishes to handle the transaction*/

}


/***************************************************************************
 * AppTranscOpenCallLegEvHandler
 * ------------------------------------------------------------------------
 * General: When a request that is suitable for opening a dialog is received
 *          (INVITE/ REFER/SUBSCRIBE�with no To tag), the Transaction layer
 *          asks the application whether to open a call-leg for this transaction.
 *          For a proxy application, the callback is called for INVITE/REFER/
 *          SUBSCRIBE methods.
 *          This function can be used by proxies that wish to handle specific
 *          requests in a call-leg context by themselves. For UA applications,
 *          the callback is called only for initial REFER/SUBSCRIBE methods.
 *          An application that does not want the Stack implementation that
 *          opens a new dialog for REFER and SUBSCRIBE should implement
 *          this callback.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTranscMgr  - The handle of the new server transaction.
 *          pAppMgr     - The application context. You supply this context
 *                        when setting the event handles.
 *          hTransc     - The handle of the new server transaction.
 * OUT:     bOpenCalled - RV_TRUE if the application wishes that the stack
 *                        will handle the transaction in a call-leg context.
 *                        RV_FALSE otherwise.
 ***************************************************************************/
static RvStatus RVCALLCONV AppTranscOpenCallLegEvHandler(
                     IN RvSipTranscMgrHandle    hTranscMgr,
                     IN void                    *pAppMgr,
                     IN  RvSipTranscHandle      hTransc,
                     OUT RvBool                 *bOpenCalled)
{
    RvChar strMethod[20];

    RV_UNUSED_ARG(hTranscMgr);
    RV_UNUSED_ARG(pAppMgr);

    RvSipTransactionGetMethodStr(hTransc, sizeof(strMethod), strMethod);
    *bOpenCalled = RV_FALSE;

    if (strcmp(strMethod, "INVITE") == 0)
        *bOpenCalled = RV_TRUE;

    return RV_OK;
}
/***************************************************************************
 * AppCallLegTranscCreatedEv
 * ------------------------------------------------------------------------
 * General:Notifies the application that a new and relates to the specified
 *         call-leg. In this callback the application can replace handles
 *         with the call-leg transaction and specify whether it wishes to
 *         handle the transaction's request. If so it will be informed of
 *         transaction states with the RvSipCallLegTranscStateChangedEv()
 *         callback  where it will have to respond to the request.
 *         If the application indicates that it does not wish to handle the
 *         request, the call-leg will apply its default behavior according
 *         to the request method. For example requests such as REFER and
 *         SUBSCRIBE will be handled using dedicated state machines and
 *         callbacks. Unknown requests will be responded with 501.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hTransc -     The handle to the new transaction
 * Output:  hAppTransc - The application handle to the transaction
 *          bAppHandleTransc -  RV_TRUE if the application wishes to handle the
 *                           request. RV_FALSE is the application wants the
 *                           call-leg to handle the request.
 ***************************************************************************/
void RVCALLCONV AppCallLegTranscCreatedEv(
                                   IN  RvSipCallLegHandle            hCallLeg,
                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                   IN  RvSipTranscHandle             hTransc,
                                   OUT RvSipAppTranscHandle         *hAppTransc,
                                   OUT RvBool                       *bAppHandleTransc)
{
    RvStatus             rv;
    RvChar methodStr[20] = {0};
    RV_UNUSED_ARG(hCallLeg);
    RV_UNUSED_ARG(hAppCallLeg);
    RV_UNUSED_ARG(hAppTransc);

    rv = RvSipTransactionGetMethodStr(hTransc, (RvUint32)sizeof(methodStr), methodStr);
    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource, "%p RvSipTransactionGetMethodStr() failed in AppCallLegTranscCreatedEv() (rv=%d)",  hTransc, rv));
    }

	if (g_sipControl->addUpdateSupport)
	{
	    *bAppHandleTransc = ((strcmp(methodStr,"INFO")==0) || (strcmp(methodStr,"UPDATE")==0));
	}
	else
	{
		*bAppHandleTransc = (strcmp(methodStr,"INFO")==0);
	}
}






/***************************************************************************
 * handleCallLegTranscRequestRcvd
 * ------------------------------------------------------------------------
 * General: The application has been notified of a of a state change for a general
 *          transaction that belongs to the supplied call-leg.
 *          This proc handles call leg transaction received requests.
 *          The application can call RvSipCallLegTranscResponse() and respond
 *          to the request. If the application does not want to handle
 *          the request, it should set the bHandleRequest to RV_FALSE.
 *          In this case, the Stack will either handle the transaction by itself or
 *          respond with a 501 not implemented.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg -    The sip stack call-leg handle
 *            hAppCallLeg - The application handle for this call-leg.
 *            hTransc -     The stack handle to the transaction.
 * Output: (-).
 ***************************************************************************/
static void handleCallLegTranscRequestRcvd(
                                   IN  RvSipCallLegHandle                hCallLeg,
                                   IN  RvSipAppCallLegHandle             hAppCallLeg,
                                   IN  RvSipTranscHandle                 hTransc)
{
    RvStatus        rv;
    RvChar          methodStr[20] = {0};
    RvSipMsgHandle  hMsg;
	RvUint          bodylen;
	RvCCConnection* c = (RvCCConnection*)hAppCallLeg;

    rv = RvSipTransactionGetMethodStr(hTransc, (RvUint32)sizeof(methodStr), methodStr);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,"handleCallLegTranscRequestRcvd: RvSipTransactionGetMethodStr failed with err %d",rv));
        return;
    }

    rv = RvSipTransactionGetReceivedMsg(hTransc, &hMsg);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,"handleCallLegTranscRequestRcvd: RvSipTransactionGetReceivedMsg failed with err %d",rv));
        return;
    }

	/*---------------------------------*/
	/*             INFO                */
	/*---------------------------------*/
    if (!strcmp(methodStr,"INFO"))
    {
        char        *buf=NULL;
        RvUint      actlen=0;

        bodylen = RvSipMsgGetStringLength(hMsg,RVSIP_MSG_BODY);
        if(bodylen == 0)
        {
            RvLogInfo(ippLogSource, (ippLogSource,"handleCallLegTranscRequestRcvd: No BODY in INFO message %p",hMsg));
            RvSipCallLegTranscResponse(hCallLeg, hTransc, RV_SIPCTRL_STATUS_OK);
                return; /* there is no body in the message */
        }

        rvMtfAllocatorAlloc(bodylen*sizeof(RV_CHAR), (void**)&buf);
        if (buf == NULL)
        {
            RvLogError(ippLogSource, (ippLogSource,"handleCallLegTranscRequestRcvd:: Failed to allocate memory to get a BODY of INFO message %p",hMsg));
        }

        rv = RvSipMsgGetBody(hMsg, buf, bodylen, &actlen);

        if (rv == RV_OK && actlen!=0)
        {
            char        contentTypeBuf[30];
            RvUint      len=0;

            /* Process the body of the message */
            RvSipMsgGetContentTypeHeader(hMsg,contentTypeBuf,sizeof(contentTypeBuf),&len);
#ifdef RV_MTF_VIDEO
            if (!strncmp(contentTypeBuf, "application/media_control+xml", len))
            {
                    rv = rvSipVideoProcessInfo((RvCCConnection*)hAppCallLeg, buf, bodylen);
                    if (rv != RV_OK)
                          RvLogError(ippLogSource,(ippLogSource,"parseDTMFBody(hAppCallLeg=%p,hTransc=%p",hAppCallLeg,hTransc));
            }
            else
#endif
            if (!strncmp(contentTypeBuf,"application/dtmf-relay", len))
            {
                rv = parseDTMFBody(hAppCallLeg, buf, bodylen);
                if (rv != RV_OK)
                {
                    RvLogError(ippLogSource,(ippLogSource,"handleCallLegTranscRequestRcvd() - failed to parse INFO body (hAppCallLeg=%p,hTransc=%p",hAppCallLeg,hTransc));
					rv = RvSipCallLegTranscResponse(hCallLeg, hTransc, RV_SIPCTRL_STATUS_NOTACCEPT_HERE);
					if (rv != RV_OK)
					{
						RvLogError(ippLogSource,(ippLogSource,"handleCallLegTranscRequestRcvd() - failed to send 488 Not Acceptable Here (hCallLeg=%p,hTransc=%p)=%d",hCallLeg,hTransc,rv));
					}
					return;
				}
            }

            /* Release allocated memory */
            if (buf != NULL)
                rvMtfAllocatorDealloc(buf, bodylen*sizeof(RvChar));
        }
    }/* method INFO*/
	else
	/*---------------------------------*/
	/*             UPDATE              */
	/*---------------------------------*/
	if (!strcmp(methodStr,"UPDATE"))
	{
		/* don't do anything if UPDATE is not supported */
		if (g_sipControl->addUpdateSupport)
		{

			RvMtfUpdateState         updateState;
			RvMtfOfferAnswerState    offerAnswerState;

			/* Check if the message contains an SDP body. If it does not we don't have to deal
			   with it*/

			if (!rvSipControlIsMediaBody(hMsg))
			{
				goto OK_exit;
			}

			updateState      = rvCCConnGetUpdateState(c);
			offerAnswerState = rvCCConnSipGetOfferAnswerState(c);

			if ((updateState == RV_CCUPDATESTATE_SENT) ||
				 (offerAnswerState == RV_MTF_OFFERANSWER_OFFER_SENT))
			{
				/* we received UPDATE before receiving an answer to another offer we
				   have already sent - send reject response with code 491 */
				rvSipControlRejectUpdate(hCallLeg, hTransc,RV_SIPCTRL_STATUS_REQ_PENDING);
				return;
			}
			else
				if ((updateState ==  RV_CCUPDATESTATE_RECEIVED) ||
					(offerAnswerState == RV_MTF_OFFERANSWER_OFFER_RECEIVED))
				{
					/* we received UPDATE before answering an offer we
					   have already received - send reject response with code 500*/
					  rvSipControlRejectUpdate(hCallLeg, hTransc,RV_SIPCTRL_STATUS_SERVERERR);
					  return;
				}

		/*  If we got so far it is time to handle the media in the UPDATE message */

			rvCCConnSetUpdateState(c, RV_CCUPDATESTATE_RECEIVED);
			rvCCConnSipChangeOfferAnswerState(c, RV_FALSE, RV_FALSE);
			rvCCProviderSipProcessIncomingSdp(hMsg, hAppCallLeg);
			/* handle UPDATE request like a re-invite */
			rvCCProviderSipHandleReInviteReceived(hMsg, hCallLeg, hAppCallLeg);
			rvCCConnSetUpdateState(c, RV_CCUPDATESTATE_NONE);
			return;

		}
	}
OK_exit:
    rv = RvSipCallLegTranscResponse(hCallLeg, hTransc, RV_SIPCTRL_STATUS_OK);
    if (rv != RV_OK)
    {
         RvLogError(ippLogSource,(ippLogSource,"handleCallLegTranscRequestRcvd(hCallLeg=%p,hTransc=%p)=%d",hCallLeg,hTransc,rv));
	}
}

/***************************************************************************
 * handleCallLegTranscMsgSendFailure
 * ------------------------------------------------------------------------
 * General: The application has been notified of a of a state change for a general
 *          transaction that belongs to the supplied call-leg.
 *          This proc handles call leg transaction message sent failure.
 *          In case of a failure to send an UPDATE response the update state
 *          should be cleared.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hAppCallLeg - The application handle for this call-leg.
 *            hTransc -     The stack handle to the transaction.
 * Output: (-).
 ***************************************************************************/
static void handleCallLegTranscMsgSendFailure(
											   IN  RvSipAppCallLegHandle             hAppCallLeg,
											   IN  RvSipTranscHandle                 hTransc)
{
    RvStatus        rv;
    RvChar          methodStr[20] = {0};
	RvCCConnection* c = (RvCCConnection*)hAppCallLeg;

    rv = RvSipTransactionGetMethodStr(hTransc, (RvUint32)sizeof(methodStr), methodStr);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,"handleCallLegTranscMsgSendFailure: RvSipTransactionGetMethodStr failed with err %d",rv));
        return;
    }

	if (!strcmp(methodStr,"UPDATE"))
	{

		RvMtfUpdateState          updateState;

		updateState  = rvCCConnGetUpdateState(c);

		if (updateState != RV_CCUPDATESTATE_NONE)
		{

			RvLogError(ippLogSource, (ippLogSource,"handleCallLegTranscMsgSendFailure: UPDATE failed for connection: %p, update state: %d ",
				                       c, updateState));
			resetUpdateState(c);

		}
	}
}

/***************************************************************************
 * AppCallLegTranscStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application about of a state change for a general
 *          transaction that belongs to the supplied call-leg.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hTransc -     The handle to the transaction.
 *          hAppTransc -  The application handle to the transaction.
 *          eTranscState - The call-leg transaction new state.
 *          eReason      - The reason for the new state.
 * Output: (-).
 **************************************************************************/
static void  RVCALLCONV  AppCallLegTranscStateChangedEvHandler(
                                   IN  RvSipCallLegHandle                hCallLeg,
                                   IN  RvSipAppCallLegHandle             hAppCallLeg,
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipAppTranscHandle              hAppTransc,
                                   IN  RvSipCallLegTranscState           eTranscState,
                                   IN  RvSipTransactionStateChangeReason eReason)
{
    RvLogInfo(ippLogSource, (ippLogSource,"AppCallLegTranscStateChangedEvHandler: %d",eTranscState));

    switch(eTranscState)
    {
    case RVSIP_CALL_LEG_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:

		handleCallLegTranscRequestRcvd(hCallLeg, hAppCallLeg, hTransc);
        break;
    case RVSIP_CALL_LEG_TRANSC_STATE_SERVER_GEN_FINAL_RESPONSE_SENT:
       /* to do: addcode */
        break;
    case RVSIP_CALL_LEG_TRANSC_STATE_CLIENT_GEN_FINAL_RESPONSE_RCVD:
		{
			RvSipMsgHandle       hMsg;

			RvSipTransactionGetReceivedMsg(hTransc, &hMsg);

			/* handle UPDATE response  */
			if (isCSeqMethod(hMsg, RVSIP_METHOD_OTHER, "UPDATE"))
			{
				RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
				RvUint16             responseCode;

				RvSipTransactionGetResponseCode(hTransc,&responseCode);
				handleUpdateResponse(hCallLeg, hMsg, c, responseCode);
			}
		}
        break;
	case RVSIP_CALL_LEG_TRANSC_STATE_CLIENT_MSG_SEND_FAILURE:
		handleCallLegTranscMsgSendFailure(hAppCallLeg, hTransc);
		break;
    default:
        break;
    }

	RV_UNUSED_ARG(hAppTransc);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppTranscStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a transaction state changed.
 *          If the new state is GENERAL_REQUEST_RCVD - accept the request
 *          with RvSipTransactionRespond(200) for OPTIONS request.
 *          Respond with 501 not implemented to any other request.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -     The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction
 *          eState -      The new transaction state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppTranscStateChangedEvHandler(
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipTranscOwnerHandle            hAppTransc,
                                   IN  RvSipTransactionState             eState,
                                   IN  RvSipTransactionStateChangeReason eReason)
{
    RvStatus             rv;

    
    RV_CHAR methodStr[20]       = {0};
    RvCCTerminalSip *  ptTermSip = NULL;

    RV_UNUSED_ARG(eReason);

    switch (eState)
    {
        case RVSIP_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:
        {
            
            RvSipTransactionGetMethodStr(hTransc, (RvUint32)sizeof(methodStr), methodStr);
            
            if(strcmp(methodStr,"OPTIONS") == 0)
            {
                rv = RvSipTransactionRespond(hTransc,RV_SIPCTRL_STATUS_OK,NULL);
            }
            else if(strcmp(methodStr,"NOTIFY") == 0)
            {
                PSip_HandleNotifyReqOutOfSub(hTransc);
                vpsip_sipctrl_Subs_StateChangedEvHandler(hTransc, hAppTransc, eState, eReason);
                rv = RvSipTransactionRespond(hTransc,RV_SIPCTRL_STATUS_OK,NULL);     
                
            }
            else
            {
                rv = RvSipTransactionRespond(hTransc,RV_SIPCTRL_STATUS_NOTIMPLEMENT,NULL);
            }
            if(rv != RV_OK)
            {
                RvLogInfo(ippLogSource,(ippLogSource, "Failed to respond to the request"));
            }
        }
        break;
        case RVSIP_TRANSC_STATE_CLIENT_GEN_FINAL_RESPONSE_RCVD:
        {
            RvSipTransactionGetMethodStr(hTransc, (RvUint32)sizeof(methodStr), methodStr);
            
            if(strcmp(methodStr,"OPTIONS") == 0)
            {
                /*zhangcg: */
                ptTermSip = (RvCCTerminalSip *)hAppTransc;
                ptTermSip->dwHeartbeatResult = PSIP_HEARTBEAT_SUCCESSFUL;
            }
            
        }
        break;
        default:
            break;
    }
}

/***************************************************************************
 * AppTranscMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -    The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction.
 *          hMsg -        Handle to the incoming message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppTranscMsgReceivedEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg)
{
    RV_UNUSED_ARG(hTransc);
    RV_UNUSED_ARG(hAppTransc);
    RV_UNUSED_ARG(hMsg);
    

    
    PSip_AppPrintMessage(hMsg,1);

    return RV_OK;
}

/***************************************************************************
 * RvSipTranscMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -    The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppTranscMsgToSendEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg)
{
    /*RvLogInfo(ippLogSource,(ippLogSource,"--> Message Sent (call-leg %x)\n"),(int)hTransc);*/
    RV_UNUSED_ARG(hTransc);
    RV_UNUSED_ARG(hAppTransc);
    RV_UNUSED_ARG(hMsg);
    

    
    PSip_AppPrintMessage(hMsg,0);

    return RV_OK;
}

/***************************************************************************
 * AppRegExpResolutionNeededEvHandler
 * ------------------------------------------------------------------------
 * General: Asks the application to resolve a regular expression and fill
 *          the pMatchArray
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: hTrxAppMgr    - A handle to an application's context
 *        strRegexp      - a regular expression from NAPTR query.
 *        strString      - the string to apply the regexp on
 *        matchSize      - the size of the pMatchArray
 *        eFlags         - flags to take in account when applying the
 *                         regular expression
 * Output:pMatches       - The pMatchArray should be filled in by
 *                         RvSipTransmitterRegExpResolutionNeededEv with substring
 *                         match addresses.  Any unused structure elements
 *                         should contain the value -1.
 *                         Each startOffSet element that is not -1 indicates
 *                         the start offset of the next largest substring match
 *                         within the string. The relative endOffSet element
 *                         indicates the end offset of the match.
 ***************************************************************************/
static RvStatus RVCALLCONV AppRegExpResolutionNeededEvHandler(
                     IN  RvSipTransmitterMgrHandle      hTrxMgr,
                     IN  void*                          pAppTrxMgr,
                     IN  RvSipTransmitterHandle         hTrx,
                     IN  RvSipAppTransmitterHandle      hAppTrx,
                     INOUT RvSipTransmitterRegExpResolutionParams* pRegExpParams)
{
    RvSipControl*   sipMgr = rvCCSipPhoneGetSipMgr();
    RvStatus        rv = RV_OK;

    IppLogMessage(RV_FALSE, "AppRegExpResolutionNeededEvHandler: regexp:%s string:%s\n\n",
                    pRegExpParams->strRegExp,pRegExpParams->strString);

    rv = RvIppSipExtRegExpResolutionNeededCB(
                (RvIppSipControlHandle)sipMgr,
                hTrxMgr,
                pAppTrxMgr,
                hTrx,
                hAppTrx,
                pRegExpParams);

    return rv;
}



/***************************************************************************
* AppSipSubsCreatedEvHandler
* ------------------------------------------------------------------------
* General: Notifies the application about a creation of a new subscription.
* Return Value: None
* ------------------------------------------------------------------------
* Arguments:
* Input: hSubs     - The new sip stack subscription handle
*        hCallLeg  - Handle to the related call-leg. NULL if this is a subscription
*                    outside of a call-leg.
*        hAppCallLeg - Handle to the related application call-leg. NULL if this is a
*                      subscription outside of a call-leg.
* Output:     phAppSubs - The application handle for this subscription.
***************************************************************************/
static void RVCALLCONV AppSipSubsCreatedEvHandler(
								  IN  RvSipSubsHandle    hSubs,
								  IN  RvSipCallLegHandle hCallLeg,
								  IN  RvSipAppCallLegHandle hAppCallLeg,
								  OUT RvSipAppSubsHandle *phAppSubs)
{


	RV_UNUSED_ARG(hCallLeg);
	RV_UNUSED_ARG(hAppCallLeg);
	RV_UNUSED_ARG(phAppSubs);


	if (hCallLeg == NULL)
	{
		/* This proc handles only callLeg subscriptions */
		return;
	}

	/* We don't handle callLeg Subs events. The subs should be rejected, otherwise the callLeg will not be
	destructed when the call is terminated (as long as subscriptions are attached to it). */
	RvSipSubsSetRejectStatusCodeOnCreation(hSubs, RV_SIPCTRL_STATUS_FORBIDDEN);

	/* The following code demonstrates how to get the event package from the subscribe message -
	   for future use */
	/*
	{
		RvSipEventHeaderHandle hEvent;
		RvChar   eventId[RV_NAME_STR_SZ];
		RvUint   actualLen;
		RvStatus rv;

		rv = RvSipSubsGetEventHeader( hSubs, &hEvent);
		if (rv != RV_OK)
		{
			return;
		}

		rv = RvSipEventHeaderGetEventPackage(hEvent, eventId, sizeof(eventId), &actualLen);
		if (rv != RV_OK)
		{
			return;
		}

		RvLogDebug(ippLogSource, (ippLogSource,"AppSipSubsCreatedEvHandler: received subs %p with event %s, hCallLeg=%p, hAppCallLeg=%p",
					hSubs, eventId, hCallLeg, hAppCallLeg));
	}
	*/


}

/***************************************************************************
 * void rvSipControlSetCfgLogFilters
 * ------------------------------------------------------------------------
 * General: Supports setting SIP log filters at startup
 *
 * Return Value: N/A
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   stackCfg -    The sip configuration structure
 *                  logOptions  -    Array of moduleIds and filters
 ***************************************************************************/
void rvSipControlSetCfgLogFilters(RvSipStackCfg* stackCfg, RvIppSipLogOptions*   logOptions)
{
    int i;

    /* Error checking of input parameters: */

    if (stackCfg == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource, "stackCfg=NULL"));
        return;
    }

    if (logOptions == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource, "logOptions=NULL"));
        return;
    }

    /* Verify num is valid value */
    if (logOptions->num > SIP_NUM_OF_MODULES)
    {
        RvLogError(ippLogSource,(ippLogSource, "logOptions->num > SIP_NUM_OF_MODULES" ));
        return;
    }

    for (i=0; i < logOptions->num;i++)
    {
        switch (logOptions->filters[i].moduleId)
        {
            case RVSIP_CALL:
                stackCfg->callLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_TRANSACTION:
                stackCfg->transactionLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_MESSAGE:
                stackCfg->msgLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_TRANSPORT:
                stackCfg->transportLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_PARSER:
                stackCfg->parserLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_STACK:
                stackCfg->stackLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_MSGBUILDER:
                stackCfg->msgBuilderLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_TRANSCCLIENT:
                stackCfg->transcClientLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_AUTHENTICATOR:
                stackCfg->authenticatorLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_REGCLIENT:
                stackCfg->regClientLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_PUBCLIENT:
                stackCfg->pubClientLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_SUBSCRIPTION:
                stackCfg->subscriptionLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_COMPARTMENT:
                stackCfg->compartmentLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_RESOLVER:
                stackCfg->resolverLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_TRANSMITTER:/* new - THIS ONE IS STILL NEW? */
                stackCfg->transmitterLogFilters = logOptions->filters[i].filter;
                break;

#ifdef RV_SIP_IMS_ON
            case RVSIP_SECURITY:
                stackCfg->securityLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_SEC_AGREE:
                stackCfg->secAgreeLogFilters = logOptions->filters[i].filter;
                break;
#endif /* #ifdef RV_SIP_IMS_ON */

            case RVSIP_ADS_RLIST:
                stackCfg->adsFiltersCfg.adsRListLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_ADS_RA:
                stackCfg->adsFiltersCfg.adsRaLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_ADS_RPOOL:
                stackCfg->adsFiltersCfg.adsRPoolLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_ADS_HASH:
                stackCfg->adsFiltersCfg.adsHashLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_ADS_PQUEUE:
                stackCfg->adsFiltersCfg.adsPQueueLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_SEMAPHORE:
                stackCfg->coreFiltersCfg.coreSemaphoreLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_MUTEX:
                stackCfg->coreFiltersCfg.coreMutexLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_LOCK:
                stackCfg->coreFiltersCfg.coreLockLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_MEMORY:
                stackCfg->coreFiltersCfg.coreMemoryLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_THREAD:
                stackCfg->coreFiltersCfg.coreThreadLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_QUEUE:
                stackCfg->coreFiltersCfg.coreQueueLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_TIMER:
                stackCfg->coreFiltersCfg.coreTimerLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_TIMESTAMP:
                stackCfg->coreFiltersCfg.coreTimestampLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_CLOCK:
                stackCfg->coreFiltersCfg.coreClockLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_TM:
                stackCfg->coreFiltersCfg.coreTmLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_SOCKET:
                stackCfg->coreFiltersCfg.coreSocketLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_PORTRANGE:
                stackCfg->coreFiltersCfg.corePortRangeLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_SELECT:
                stackCfg->coreFiltersCfg.coreSelectLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_HOST:
                stackCfg->coreFiltersCfg.coreHostLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_TLS:
                stackCfg->coreFiltersCfg.coreTlsLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_ARES:
                stackCfg->coreFiltersCfg.coreAresLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_RCACHE:
                stackCfg->coreFiltersCfg.coreRcacheLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_EHD:
                stackCfg->coreFiltersCfg.coreEhdLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE_IMSIPSEC:
                stackCfg->coreFiltersCfg.coreImsipsecLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_CORE:
                stackCfg->coreLogFilters = logOptions->filters[i].filter;
                break;

            case RVSIP_ADS:
                stackCfg->adsLogFilters = logOptions->filters[i].filter;
                break;

            default:
                RvLogError(ippLogSource,(ippLogSource, "unknown SIP moduleID %d", logOptions->filters[i].moduleId));


        } /* switch */


    } /* for */

    return;
}

/***************************************************************************
 * rvMdmUtilSetSIPLogFilters
 * ------------------------------------------------------------------------
 * General: Supports setting SIP log filters at run time
 *
 * Return Value: N/A
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   stackHandle -    The sip stack  handle
 *                  logOptions  -    Array of moduleIds and filters
 ***************************************************************************/
void RVCALLCONV rvMdmUtilSetSIPLogFilters(RvSipStackHandle stackHandle, RvIppSipLogOptions* logOptions)
{
    int i;
    /* we override the log settings of the stack when we set the default filters
      so now we set them again */
    /* error check: verify num is valid value */
    if (logOptions->num > SIP_NUM_OF_MODULES)
    {
        RvLogError(ippLogSource,(ippLogSource, "logOptions->num > SIP_NUM_OF_MODULES" ));
      return;
    }
    for (i=0; i < logOptions->num;i++)
    {
        RvSipStackSetNewLogFilters(stackHandle, logOptions->filters[i].moduleId, logOptions->filters[i].filter);
    }
}

#ifdef RV_SIP_IMS_ON
#ifdef RV_CFLAG_TLS
/***************************************************************************
* setCallLegOutboundPort
* ------------------------------------------------------------------------
* General:  Sets the outbound port of a call leg
*           This is needed when TLS security mechanism is chosen.
* Return Value: N/A
* ------------------------------------------------------------------------
* Arguments:
* input   : outboundAddress - the outbound address in IP or name format
*			registrarTlsPort - the new outbound port
*
* output  : hCallLeg - Handle to the call leg whose settings are changed.
***************************************************************************/
static void setCallLegOutboundPort(INOUT   RvSipCallLegHandle hCallLeg,
							  IN	  RvChar* outboundAddress,
							  IN	  RvUint16 outboundPort)
{

	if (IppUtilIsIpAddress(outboundAddress))
	{
		RvSipCallLegSetOutboundAddress(hCallLeg, outboundAddress, outboundPort);
	}
	else
	{
		RvSipCallLegSetOutboundHostName(hCallLeg, outboundAddress, outboundPort);
	}
}
#endif /* RV_CFLAG_TLS */
#endif
/*===============================================================================*/
/*===================== I N T E R N A L     F U N C T I O N S ===================*/
/*===============================================================================*/


#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS)
/***************************************************************************
* IppPrintLogEntryEv
* ------------------------------------------------------------------------
*      *** this function needs PORTING for different OSes. ***
* General: Notifies the application each time a line should be printed to
*          the log. The application can decide whether to print the line
*          to the screen, file or other output device.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:    filter -    The filter that this message is using (info, error..)
*           formattedText - The text to be printed to the log. The text
*                          is formatted as follows:
*                          <filer> - <module> - <message>
*                          for example:
*                          "INFO  - STACK - Stack was constructed successfully"
***************************************************************************/
static void RVCALLCONV IppPrintLogEntryEv(
    IN void*                 context,
    IN RvSipLogFilters       filter,
    IN const RV_CHAR*        formattedText)
{
    RV_UNUSED_ARG(context);
    RV_UNUSED_ARG(filter);
    RvLogInfo(ippLogSource,(ippLogSource,formattedText));
}
#endif /* (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) */


static void sipStackProcessInit(IN void* data)
{
    RvStatus status;

#ifndef RV_CFLAG_TLS
    RV_UNUSED_ARG(data);
#endif

    status = RvSipStackConstruct(sizeof(RvSipStackCfg), g_threadData.stackCfg, &g_threadData.stackHndl);
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Application failed to construct the stack error = %d", status));
		g_threadData.stackHndl = NULL;
        RvSemaphorePost(&g_threadData.semStackConstructed, IppLogMgr());
        return;
    }

#ifdef RV_CFLAG_TLS
    /*Check if TLS is enabled*/
    if ((((RvMtfSipPhoneCfg *)data)->transportTlsCfg.stackNumOfTlsAddresses) > 0)
    {
        status = rvIppTlsInit(&((RvMtfSipPhoneCfg *)data)->transportTlsCfg, g_threadData.stackHndl);
        if (status != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource, "Application failed to initialize the TLS = %d", status));
        }
    }
#endif

#ifdef RV_MTF_VIDEO
    /* Initiate XML parser configuration and construct xml parser manager */
    status = rvSipVideoFastUpdateInit();
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Application failed to initialize the XML parser"));
    }
#endif
	RvSemaphorePost(&g_threadData.semStackConstructed, IppLogMgr());
}

static void sipStackProcessEnd(IN void* data)
{

    RV_UNUSED_ARG(data);
#ifdef RV_MTF_VIDEO
    rvSipVideoFastUpdateEnd();
#endif

    RvSipStackDestruct(g_threadData.stackHndl);
}

/***************************************************************************************
 * rvIppSipStackInitialize
 * -------------------------------------------------------------------------------------
 * General:   Configuration and Initialization of the stack.
 *            1. Configuration - we use default values, and user parameters (if exists).
 *            2. Initialization - this function creates a thread that will initialize
 *               and start the stack.
 * Return Value: True - if stack was constructed successfully, False - if failed.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:    RvSipStackHandle - stack handle
 *           RvMtfSipPhoneCfg - configuration structure
 * Output:   None
 **************************************************************************************/
RVAPI RvBool RVCALLCONV rvIppSipStackInitialize(
    OUT RvSipStackHandle* stackHandle,
    IN  RvMtfSipPhoneCfg* cfg)
{
    RvSipStackCfg   stackCfg;
    RvChar          tempList[128];

    if ((stackHandle == NULL) || (cfg == NULL))
    {
        RvLogError(ippLogSource,(ippLogSource, "Received NULL pointers, can't initialize stack!"));
        return RV_FALSE;
    }

    *stackHandle = NULL;


    /*Constructs Semaphores*/
    RvSemaphoreConstruct(0,IppLogMgr(),&g_threadData.semStackConstructed);

    /*Stack Configuration*/
    /*-------------------*/

    /*load user values if exist, if not, use default values.*/

    /*Initialize the configuration structure with default values*/
    RvSipStackInitCfg(sizeof(stackCfg), &stackCfg);

    /*Local address - mandatory parameter (can't use default value)*/
    if (!rvSipControlIsAddressEmpty(cfg->localAddress))
    {
        strncpy(stackCfg.localTcpAddress, cfg->localAddress, sizeof(stackCfg.localTcpAddress)-1);
        stackCfg.localTcpAddress[sizeof(stackCfg.localTcpAddress)-1] = '\0';
        strncpy(stackCfg.localUdpAddress, cfg->localAddress, sizeof(stackCfg.localUdpAddress)-1);
        stackCfg.localUdpAddress[sizeof(stackCfg.localUdpAddress)-1] = '\0';
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource, "Local Address is not configured, can't initialize stack!"));
        return RV_FALSE;
    }
    //Leibt add
    stackCfg.tos = cfg->tos;

    /* Outbound Proxy address*/
    if (!rvSipControlIsAddressEmpty(cfg->outboundProxyAddress))
    {
        if (IppUtilIsIpAddress(cfg->outboundProxyAddress))
        {

            strncpy(stackCfg.outboundProxyIpAddress, cfg->outboundProxyAddress, sizeof(stackCfg.outboundProxyIpAddress)-1);
            stackCfg.outboundProxyIpAddress[sizeof(stackCfg.outboundProxyIpAddress)-1]= '\0';
        }
        else
        {
            stackCfg.outboundProxyHostName = cfg->outboundProxyAddress;
        }
    }

    /* Outbound Proxy port*/
    stackCfg.outboundProxyPort = cfg->outboundProxyPort;

    /* TCP port*/
    stackCfg.localTcpPort = cfg->stackTcpPort;

    /* UDP Port */
    stackCfg.localUdpPort = cfg->stackUdpPort;

    /*Transport type for outbound Proxy*/
    stackCfg.eOutboundProxyTransport = cfg->transportType;

    /* Maximum number of simultaneous calls*/
    if (cfg->maxCallLegs > 0)
      stackCfg.maxCallLegs = cfg->maxCallLegs;

    /* Maximum number of simultaneous clients to send Proxy registration*/
    if (cfg->maxRegClients > 0)
      stackCfg.maxRegClients = cfg->maxRegClients;

    /* TCP support*/
    if (cfg->tcpEnabled == RV_TRUE)
      stackCfg.tcpEnabled = RV_TRUE;

    /* Log Filter Settings - load default first and add user configuration (if exists)*/
    stackCfg.defaultLogFilters =  RVSIP_LOG_ERROR_FILTER |
                                    RVSIP_LOG_EXCEP_FILTER |
                                    RVSIP_LOG_WARN_FILTER |
                                    RVSIP_LOG_INFO_FILTER;

    if (cfg->logOptions != NULL)
        rvSipControlSetCfgLogFilters(&stackCfg, cfg->logOptions);

#ifdef RV_CFLAG_TLS
    sipStackTlsConfigInit(&stackCfg, &cfg->transportTlsCfg);
#endif

    stackCfg.maxTransactions = stackCfg.maxCallLegs * 5;
    stackCfg.maxConnections = 25;
    stackCfg.messagePoolNumofPages = 100;
    stackCfg.messagePoolPageSize = 2048;
    stackCfg.generalPoolNumofPages = 100;
    stackCfg.generalPoolPageSize = 2048;
    stackCfg.sendReceiveBufferSize = 4096;
    /*The following values are recommended for a proper functioning of the CallControl application*/
    /*Causes Cancel to be sent if no response to Invite was received*/
    stackCfg.enableInviteProceedingTimeoutState = RV_TRUE;
    /*Timeout to terminate the call after Cancel for Invite was sent */
    /*Should be big enough to let message be sent before call-leg is terminated*/
/*  stackCfg.cancelInviteNoResponseTimer = 1000;*/
    stackCfg.processingTaskPriority = 2;
    /*order to aid in traversing symmetrical NATS*/
    stackCfg.bUseRportParamInVia = RV_TRUE;
    g_threadData.stackCfg = &stackCfg;
    g_threadData.stackHndl= NULL;
/* porting*/
    stackCfg.bDisableRefer3515Behavior = RV_TRUE;
    stackCfg.maxSubscriptions = 5;
    stackCfg.subsAutoRefresh = RV_FALSE;
    stackCfg.bOldInviteHandling = RV_TRUE;
    /*Must be true for Tel-URI to work */
	stackCfg.bResolveTelUrls = RV_TRUE;
    /*Our default for Tel-URI feature, application should override it*/
	stackCfg.strDialPlanSuffix = "e164.arpa";
	/* When an MTF message is forked (sent to several endpoints) it may be responded by
	   several endpoints. Only the first response is handled. In order to cope with
	   multiple responses there is a need to enable forking in the Sip Stack. */
	stackCfg.bEnableForking = RV_TRUE;

	/* To be compliant with RFC 3261, section 8.2.2.3 */
	stackCfg.rejectUnsupportedExtensions = RV_TRUE;

#ifdef RV_SIP_IMS_ON
	stackCfg.maxSecAgrees = stackCfg.maxRegClients;
	/* for each terminal we will need no more than one secAgree object */

	stackCfg.spiRangeStart = cfg->imsSipPhoneCfg.ipsecSpiRangeStart;
	stackCfg.spiRangeEnd = cfg->imsSipPhoneCfg.ipsecSpiRangeEnd;

#endif

/* Causes the logget to ignore the print.
To print SIP logs to terminal, user should change type to TERMINAL only */
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS)
  stackCfg.pfnPrintLogEntryEvHandler = IppPrintLogEntryEv;
#endif

    /* build the supportedExtensionList according to some config values, not only
    according to the user configuration of this field  */

    /* Transfer-Replaces and PRACK features: use replaces and 100rel extensions  */
#ifdef RV_SIP_IMS_ON
	/* for IMS, security agreement should be supported, too */
	strcpy(tempList, "replaces,100rel,path,sec-agree");
#else
    strcpy(tempList, "replaces,100rel");
#endif
    stackCfg.supportedExtensionList = tempList;

	/* Initialize the SIPStack with the MTF config session timer params */
	/* If the user has configured these parameters also in the SIP Stack configuration,
	   the MTF configuration parameters are preferred. In any case force the manual session timer behavior */

	if (cfg->sessionTimerSessionExpires > 0)
	{
		stackCfg.sessionExpires     = cfg->sessionTimerSessionExpires;
		stackCfg.minSE              = cfg->sessionTimerMinimumAllowed;
	}
	stackCfg.manualSessionTimer = RV_TRUE;


	/* Configure T1 and provisional timers in the stack. These valus may also be configured
       directly by the user as part of the SIP stack parameters configuration. The SIP configuration
	   values, if configured, will override the MTF config values  */

	stackCfg.retransmissionT1 = cfg->outgoingRequestNoResponseTimeout/64;
	stackCfg.provisionalTimer = cfg->outgoingCallNoAnswerTimeout;
#ifdef USE_GPON_OVERSEA_VERSION	
	stackCfg.region = RvSipStackGetRegionIdByTxt(cfg->countryName);
#endif
	/*User extension - call user callback to change stack configuration*/
    rvIppSipExtStackConfigCB(&stackCfg);

	if (stackCfg.minSE > 0)
    {
        /* session timer is supported, add timer to the supported extension list */
		strcpy(&tempList[0], stackCfg.supportedExtensionList);
        strcat(tempList, ",timer");
		stackCfg.supportedExtensionList = tempList;
    }

#ifdef RV_CFLAG_TLS
    /* Initialize the SIPStack with the IpPhone config param stackNumOfTlsAddresses
       if IpPhone config does not contain stackNumOfTlsAddresses, the Sip Config value will stay
    */
    if (cfg->transportTlsCfg.stackNumOfTlsAddresses != 0)
        stackCfg.numOfTlsAddresses = (RvInt32)(cfg->transportTlsCfg.stackNumOfTlsAddresses);

    /* In case of TLS, add TCP support. This way the user can initiate regular calls
      over UDP(if UDP is configured) and TLS calls over TCP*/
    if ((stackCfg.numOfTlsAddresses > 0) && (stackCfg.tcpEnabled != RV_TRUE))
    {
        stackCfg.tcpEnabled = RV_TRUE;
        RvLogInfo(ippLogSource,(ippLogSource,"rvIppSipStackInitialize::tcpEnabled changed to 1 since TLS is enabled"));
    }
#endif

    /*Stack Initialization*/
	ProtocolThreadConstruct(cfg->priority, sipStackProcessInit, sipStackProcessEnd,cfg, PROTOCOL);

    /*Wait until the stack thread constructed the stack*/
    RvSemaphoreWait(&g_threadData.semStackConstructed, IppLogMgr());
    if (g_threadData.stackHndl == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"Error initializing SIP Stack - no handle"));
		/* Failed to initialize SIP, stop the thread */
		ProtocolThreadStop();
        return RV_FALSE;
    }

    *stackHandle = g_threadData.stackHndl;

    RvLogInfo(ippLogSource,(ippLogSource,"The SIP Stack was constructed successfully. Version - %s", RvSipStackGetVersion()));
    return RV_TRUE;
}

/***************************************************************************
 * setCallBackFunctions
 * ------------------------------------------------------------------------
 * General: Set application call back functions for all main stack manager objects.
 ***************************************************************************/
static RvStatus setCallBackFunctions( IN RvSipStackHandle stackHndl, OUT RvIppSipStackCallbacks* stackCallbacks)
{
    RvStatus rv;
    RvSipCallLegMgrHandle       hCallLegMgr;
    RvSipTransportMgrHandle     hTransportMgr;
    RvSipTranscMgrHandle        hTranscMgr;
    RvSipRegClientMgrHandle     hRegClientMgr;
    RvSipAuthenticatorHandle    hAuth;
    RvSipTransmitterMgrHandle   hTransmitterMgr;
    RvSipSubsMgrHandle          hSubsMgr;
#ifdef RV_MTF_SIMPLE_ON
	RvSipPubClientMgrHandle     hPubClientMgr;
#endif /* RV_MTF_SIMPLE_ON */

#ifdef RV_SIP_IMS_ON
	RvSipSecAgreeMgrHandle		hSecAgreeMgr;
#endif

    RvSipStackGetCallLegMgrHandle(stackHndl,        &hCallLegMgr);
    RvSipStackGetTransportMgrHandle(stackHndl,  &hTransportMgr);
    RvSipStackGetTransactionMgrHandle(stackHndl,    &hTranscMgr);
    RvSipStackGetRegClientMgrHandle(stackHndl,  &hRegClientMgr);
    RvSipStackGetAuthenticatorHandle(stackHndl, &hAuth);
    RvSipStackGetTransmitterMgrHandle(stackHndl, &hTransmitterMgr);
	RvSipStackGetSubsMgrHandle(stackHndl, &hSubsMgr);

#ifdef RV_MTF_SIMPLE_ON

	/* Get stack managers for SIMPLE client co-existence only */
	RvSipStackGetPubClientMgrHandle(stackHndl, &hPubClientMgr);
#endif /* RV_MTF_SIMPLE_ON */

#ifdef RV_SIP_IMS_ON
	RvSipStackGetSecAgreeMgrHandle(stackHndl, &hSecAgreeMgr);
#endif

#ifdef RV_CFLAG_TLS
    /* Set transport tls call back functions */
    rv = rvIppTLSSetCallBackFunctions(hTransportMgr, &stackCallbacks->sipTransportEvHandlers);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set application transport callbacks"));
        return rv;
    }
#endif


    /*Set CallLeg callbacks in the structure*/
    stackCallbacks->sipCallLegEvHandlers.pfnCallLegCreatedEvHandler = AppCallLegCreatedEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnCallLegCreatedDueToForkingEvHandler = AppCallLegCreatedDueToForkingEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnStateChangedEvHandler   = AppCallLegStateChangedEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnMsgReceivedEvHandler    = AppCallLegMsgReceivedEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnMsgToSendEvHandler      = AppCallLegMsgToSendEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnModifyStateChangedEvHandler = AppCallLegModifyStateChangedEv;
    stackCallbacks->sipCallLegEvHandlers.pfnReferStateChangedEvHandler = AppCallLegReferStateChangedEv;
    stackCallbacks->sipCallLegEvHandlers.pfnReferNotifyEvHandler = AppCallLegReferNotifyEv;
	stackCallbacks->sipCallLegEvHandlers.pfnSessionTimerRefreshAlertEvHandler = AppCallLegSessionTimerRefreshAlertEvHandler;
	stackCallbacks->sipCallLegEvHandlers.pfnSessionTimerNotificationEvHandler = AppCallLegSessionTimerNotificationEvHandler;

    stackCallbacks->sipCallLegEvHandlers.pfnTranscCreatedEvHandler= AppCallLegTranscCreatedEv;
    /* The following handlers are mutually exclusive: If StateChanged is set, then RequestRcvd isnt called */

    stackCallbacks->sipCallLegEvHandlers.pfnTranscStateChangedEvHandler = AppCallLegTranscStateChangedEvHandler;
/*  stackCallbacks->sipCallLegEvHandlers.pfnTranscRequestRcvdEvHandler = AppCallLegTranscRequestRcvdEvHandler; */

    rv = RvSipCallLegMgrSetEvHandlers( hCallLegMgr,
                                      &stackCallbacks->sipCallLegEvHandlers,
                                      sizeof(RvSipCallLegEvHandlers));
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set application call leg callbacks"));
        return rv;
    }


    /*Set Transaction callbacks in the structure*/
    stackCallbacks->sipTransEvHandlers.pfnEvTransactionCreated  =       AppTranscCreatedEvHandler;
    stackCallbacks->sipTransEvHandlers.pfnEvMsgReceived         =       AppTranscMsgReceivedEvHandler;
    stackCallbacks->sipTransEvHandlers.pfnEvMsgToSend           =       AppTranscMsgToSendEvHandler;
    stackCallbacks->sipTransEvHandlers.pfnEvStateChanged        =       AppTranscStateChangedEvHandler;
    stackCallbacks->sipTransEvHandlers.pfnEvOpenCallLeg         =       AppTranscOpenCallLegEvHandler;

    rv = RvSipTransactionMgrSetEvHandlers( hTranscMgr,
                                            NULL,
                                            &stackCallbacks->sipTransEvHandlers,
                                            sizeof(RvSipTransactionEvHandlers));
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set application transaction callbacks"));
        return rv;
    }

    /*Set RegClient callbacks in the structure*/
    stackCallbacks->sipRegClientEvHandlers.pfnStateChangedEvHandler   = AppRegClientStateChangedEvHandler;
    stackCallbacks->sipRegClientEvHandlers.pfnMsgReceivedEvHandler    = AppRegClientMsgReceivedEvHandler;
    stackCallbacks->sipRegClientEvHandlers.pfnMsgToSendEvHandler      = AppRegClientMsgToSendEvHandler;

    rv = RvSipRegClientMgrSetEvHandlers( hRegClientMgr,
                                        &stackCallbacks->sipRegClientEvHandlers,
                                        sizeof(RvSipRegClientEvHandlers));

    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set register client callbacks"));
        return rv;
    }


    /*Set Authentication callbacks in the structure*/
    stackCallbacks->sipAuthEvHandlers.pfnMD5AuthenticationHandler = AppAuthenticationMD5Ev;
    stackCallbacks->sipAuthEvHandlers.pfnSharedSecretAuthenticationHandler = AppAuthenticationSharedSecretEv;
    stackCallbacks->sipAuthEvHandlers.pfnGetSharedSecretAuthenticationHandler = AppAuthenticatorGetSharedSecretEv;

#ifdef RV_MTF_SIMPLE_ON
	/* Set Authentication callbacks for SIMPLE client co-existence only */
 	stackCallbacks->sipAuthEvHandlers.pfnMD5AuthenticationExHandler                = AppAuthenticatorMD5ExEv;
 	stackCallbacks->sipAuthEvHandlers.pfnAuthorizationReadyAuthenticationHandler   = AppAuthenticatorAuthorizationReadyEv;
 	stackCallbacks->sipAuthEvHandlers.pfnMD5EntityBodyAuthenticationHandler        = AppAuthenticatorMD5EntityBodyEv;
 	stackCallbacks->sipAuthEvHandlers.pfnNonceCountUsageAuthenticationHandler      = AppAuthenticatorNonceCountUsageEv;
 	stackCallbacks->sipAuthEvHandlers.pfnUnsupportedChallengeAuthenticationHandler = AppAuthenticatorUnsupportedChallengeEv;
#endif /* RV_MTF_SIMPLE_ON */
    /*Set the structure in the authenticator manager*/
    rv = RvSipAuthenticatorSetEvHandlers( hAuth,
                                        &stackCallbacks->sipAuthEvHandlers,
                                        sizeof(RvSipAuthenticatorEvHandlers));

    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set application callbacks for authentication"));
        return rv;
    }

    /*Set Transmitter callbacks in the structure*/
    stackCallbacks->sipTransmitterEvHandlers.pfnRegExpResolutionNeededEvHandler = AppRegExpResolutionNeededEvHandler;

    /*Set the structure in the transmitter manager*/
    rv = RvSipTransmitterMgrSetEvHandlers( hTransmitterMgr,
        &stackCallbacks->sipTransmitterEvHandlers,
        sizeof(RvSipTransmitterMgrEvHandlers));

    if (rv != RV_OK)
	{
	    RvLogError(ippLogSource,(ippLogSource, "Failed to set application callbacks for transmitter manager"));
	    return rv;
    }

 #ifndef  USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/12/12 */
   
    
    /*zhangcg: 20110527*/
    #if 1
    
    stackCallbacks->sipSubsEvHandlers.pfnStateChangedEvHandler				= PSip_AppSubsStateChangedEv;
	stackCallbacks->sipSubsEvHandlers.pfnExpirationAlertEvHandler			= PSip_AppSubsExpirationAlertEv;
	stackCallbacks->sipSubsEvHandlers.pfnMsgReceivedEvHandler				= PSip_AppSubsMsgReceivedEv;
	stackCallbacks->sipSubsEvHandlers.pfnMsgToSendEvHandler					= PSip_AppSubsMsgToSendEv;
	stackCallbacks->sipSubsEvHandlers.pfnSubsCreatedDueToForkingEvHandler	= PSip_AppSubsCreatedDueToForkingEv;
	stackCallbacks->sipSubsEvHandlers.pfnSubsExpiredEvHandler				= PSip_AppSubsSubscriptionExpiredEv;
	stackCallbacks->sipSubsEvHandlers.pfnNotifyEvHandler					= PSip_AppSubsNotifyEv;
	
	#endif
#endif

#ifdef RV_MTF_SIMPLE_ON

	/* Subscription callbacks - currently for SIMPLE client co-existence only*/
	stackCallbacks->sipSubsEvHandlers.pfnStateChangedEvHandler				= AppSubsStateChangedEv;
	stackCallbacks->sipSubsEvHandlers.pfnExpirationAlertEvHandler			= AppSubsExpirationAlertEv;
	stackCallbacks->sipSubsEvHandlers.pfnMsgReceivedEvHandler				= AppSubsMsgReceivedEv;
	stackCallbacks->sipSubsEvHandlers.pfnMsgToSendEvHandler					= AppSubsMsgToSendEv;
	stackCallbacks->sipSubsEvHandlers.pfnSubsCreatedDueToForkingEvHandler	= AppSubsCreatedDueToForkingEv;
	stackCallbacks->sipSubsEvHandlers.pfnSubsExpiredEvHandler				= AppSubsSubscriptionExpiredEv;
	stackCallbacks->sipSubsEvHandlers.pfnNotifyEvHandler					= AppSubsNotifyEv;



	/* Pub-Client callbacks - currently for SIMPLE client co-existence only*/
	stackCallbacks->sipPubClientEvHandlers.pfnStateChangedEvHandler			= AppPubClientStateChangedEv;
	stackCallbacks->sipPubClientEvHandlers.pfnObjExpiredEvHandler			= AppPubClientExpiredEv;
	stackCallbacks->sipPubClientEvHandlers.pfnMsgReceivedEvHandler			= AppPubClientMsgReceivedEv;
	stackCallbacks->sipPubClientEvHandlers.pfnMsgToSendEvHandler			= AppPubClientMsgToSendEv;

	rv = RvSipPubClientMgrSetEvHandlers(hPubClientMgr, &stackCallbacks->sipPubClientEvHandlers, sizeof(RvSipPubClientEvHandlers));
	if(rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "Failed to set application callbacks for PubClient events"));
		return rv;
	}

#endif /* RV_MTF_SIMPLE_ON */
	stackCallbacks->sipSubsEvHandlers.pfnSubsCreatedEvHandler				= AppSipSubsCreatedEvHandler;
	rv = RvSipSubsMgrSetEvHandlers(hSubsMgr, &stackCallbacks->sipSubsEvHandlers, sizeof(RvSipSubsEvHandlers));

	if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set application callbacks for subscription manager"));
		 return rv;
    }

#ifdef RV_SIP_IMS_ON
	/*Set SecAgree callbacks */
	stackCallbacks->sipSecAgreeEvHandlers.pfnSecAgreeStatusEvHandler = rvSecAgreeStatusEvHandler;
	rv = RvSipSecAgreeMgrSetSecAgreeEvHandlers(hSecAgreeMgr,
		                                       &stackCallbacks->sipSecAgreeEvHandlers, 
											   sizeof(RvSipSecAgreeEvHandlers));

	if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "Failed to set application callbacks for secAgree manager"));
		return rv;
	}
#endif

    return rv;
}



/*-------------------------------------------------------------------*/


/*-------------------------------------------------------------------*/

RvBool rvSipControlIsNameEmpty(IN const RvChar* name)
{
    return ( (name == NULL) || !strcmp(name, "") );
}






/*===============================================================================*/
/*======================= S I P   C O N T R O L   A P I =========================*/
/*===============================================================================*/

void rvSipControlConstruct(RvSipControl* x,
                           RvSipStackHandle stackHandle,
                           RvMtfSipPhoneCfg* cfg)
{
    g_sipControl = x;

    x->stackHndl = stackHandle;

	x->stackTcpPort = cfg->stackTcpPort;
	x->stackUdpPort = cfg->stackUdpPort;
    if (cfg->transportType == RVSIP_TRANSPORT_TCP)
        x->stackPort = cfg->stackTcpPort;
    else /* RVSIP_TRANSPORT_UDP or RVSIP_TRANSPORT_UDEFINED*/
        x->stackPort = cfg->stackUdpPort;

    x->transportType = cfg->transportType;
    /* this field is the timer value */
    x->registerExpires = cfg->registrationExpire;
    x->unregisterExpires = cfg->unregistrationExpire;
	x->maxAuthenticateRetries = cfg->maxAuthenticateRetries;
	x->removeOldAuthHeaders = cfg->removeOldAuthHeaders;

	if (x->maxAuthenticateRetries < MIN_NUM_AUTH_RETRIES)
	{
		x->maxAuthenticateRetries = MIN_NUM_AUTH_RETRIES;
		RvLogInfo(ippLogSource,(ippLogSource,  "rvSipControlConstruct: MaxAuthenticateRetries is set to a minimum value of %d", MIN_NUM_AUTH_RETRIES));
	}
    /* this field will be sent in the register message*/
    x->clientRegisterExpires = cfg->registrationExpire;
#ifdef RV_SIP_IMS_ON
    x->imsControl.disableAkaAuthentication = cfg->disableAkaAuthentication;
    if (cfg->akaAuth_op != NULL)
	{
		AkaUseConfiguredOP(cfg->akaAuth_op);
	}
	x->imsControl.disableSecAgree = cfg->imsSipPhoneCfg.disableSecAgree;
	strcpy(x->imsControl.PAccessNetworkInfo, cfg->imsSipPhoneCfg.PAccessNetworkInfo);
	x->imsControl.ipsecPortC = cfg->imsSipPhoneCfg.ipsecPortC;
	x->imsControl.ipsecPortS = cfg->imsSipPhoneCfg.ipsecPortS;
#endif

    x->connectMediaOn180         = cfg->connectMediaOn180;
	x->addUserAgentHeader        = cfg->addUserAgentHeader;
	x->sessionTimerRefreshByUpdate = cfg->sessionTimerRefreshByUpdate;
	x->sendOldHoldFormat         = cfg->sendOldHoldFormat;
	x->addUpdateSupport          = cfg->addUpdateSupport;
	x->updateRetryAfterTimeout   = cfg->updateRetryAfterTimeout;
	x->callerUpdateResendTimeout = cfg->callerUpdateResendTimeout;
    x->calleeUpdateResendTimeout = cfg->calleeUpdateResendTimeout;

    /*Reset the EvHandlers since not all callbacks are set by this application*/
    memset(&x->stackCallbacks, 0, sizeof(x->stackCallbacks));

    /*Set Callbacks*/
    /*-------------*/
    setCallBackFunctions( rvSipControlGetStackHandle(x), &x->stackCallbacks);

    rvIppSipExtRegisterStackEventsCB(x, stackHandle);

    /*Set registrar parameters*/
    /*--------------------*/
    if (!rvSipControlIsAddressEmpty(cfg->registrarAddress))
    {
        strncpy(x->registrarAddress, cfg->registrarAddress, sizeof(x->registrarAddress)-1);
        x->registrarAddress[sizeof(x->registrarAddress)-1] = '\0';

        x->registrarPort = cfg->registrarPort;
    }
    else
    {
        x->registrarAddress[0] = '\0';
        x->registrarPort = RVSIPCTRL_DEFAULT_PORT;
    }

    /*Set User parameters*/
    /*--------------------*/
	if (!rvSipControlIsNameEmpty(cfg->userDomain))
	{
		strncpy(x->userDomain, cfg->userDomain, sizeof(x->userDomain)-1);
		x->userDomain[sizeof(x->userDomain)-1] = '\0';
	}
	else
	{
		x->userDomain[0] = '\0';
	}

	if (!rvSipControlIsNameEmpty(cfg->displayName))
	{
		strncpy(x->displayName, cfg->displayName, sizeof(x->displayName)-1);
		x->displayName[sizeof(x->displayName)-1] = '\0';
	}
	else
	{
		x->displayName[0] = '\0';
	}

    /*Set outbound proxy parameters*/
    /*--------------------*/
    if (!rvSipControlIsAddressEmpty(cfg->outboundProxyAddress))
    {
        strncpy(x->outboundProxyAddress, cfg->outboundProxyAddress, sizeof(x->outboundProxyAddress)-1);
        x->outboundProxyAddress[sizeof(x->outboundProxyAddress)-1] = '\0';
    }
    else
    {
        x->outboundProxyAddress[0] = '\0';
    }

    x->outboundProxyPort = cfg->outboundProxyPort;

    if (!rvSipControlIsNameEmpty(cfg->username))
    {
        strncpy(x->username, cfg->username, sizeof(x->username)-1);
        x->username[sizeof(x->username)-1] = '\0';
    }
    else
    {
        x->username[0] = '\0';
    }

    if (!rvSipControlIsNameEmpty(cfg->password))
    {
        strncpy(x->password, cfg->password, sizeof(x->password)-1);
        x->password[sizeof(x->password)-1] = '\0';
    }
    else
    {
        x->password[0] = '\0';
    }

    x->contact[0] = '\0';

	/*Construct a pool of memory for the application*/
    g_appPool = RPOOL_Construct(2048, 10, (RV_LOG_Handle)IppLogMgr(), RV_FALSE, "ApplicationPool");

	/* build the User-Agent string */
	x->userAgentStr[0] = '\0';
	if (cfg->addUserAgentHeader == RV_TRUE)
	{
		if (cfg->manufacturerId != NULL)
		{
			strcat(x->userAgentStr, cfg->manufacturerId);
			strcat(x->userAgentStr, " ");
		}
		if  (cfg->productId != NULL)
		{
			strcat(x->userAgentStr, cfg->productId);
			strcat(x->userAgentStr, " ");
		}

		if  (cfg->productVersion != NULL)
		{
			strcat(x->userAgentStr, cfg->productVersion);
		}

		if (x->userAgentStr[0] == '\0')
		{
			/* set a default UserAgent */
			sprintf(x->userAgentStr, "RADVISION MTF %s", RV_MTF_VERSION);
		}
	}

#ifdef RV_CFLAG_TLS
    x->isTlsEnabled = (cfg->transportTlsCfg.stackNumOfTlsAddresses > 0);
	x->registrarTlsPort = cfg->transportTlsCfg.registrarTlsPort;
#endif
}

void rvSipControlDestruct(RvSipControl* x)
{
    x->stackHndl = NULL;

	RPOOL_Destruct(g_appPool);
    RvSemaphoreDestruct(&g_threadData.semStackConstructed, IppLogMgr());
}

/***************************************************************************
 * rvSipControlWatchDogTimerConstruct
 * ------------------------------------------------------------------------
 * General: print all stack resources
 *
 *           .
 * Return Value: True - success, False - fail.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   provider    - sip provider handle
 *
 *
 ***************************************************************************/
RvStatus rvSipControlWatchDogTimerConstruct(RvCCProvider* provider)
{
    RvStatus            status = RV_OK;
    RvCCProviderSip*    providerSip=(RvCCProviderSip*)provider;

    status = IppTimerConstruct(&providerSip->watchdogTimer,1000,printResources,(void*)providerSip);
    if(status!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlWatchDogTimerConstruct::failed to construct TIMER %x ",providerSip->watchdogTimer));
    }

    status = IppTimerStart(&providerSip->watchdogTimer, IPP_TIMER_RESTART_IF_STARTED, 0);
    if(status!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlWatchDogTimerConstruct::failed to start TIMER %x ",providerSip->watchdogTimer));
    }
    return status;
}

/***************************************************************************
 * rvSipControlCallAccept
 * ------------------------------------------------------------------------
 * General: This function handles acceptance of an incoming request
 *          by sending OK (200) response.
 *          Note: When this proc is called directly and not through
 *          rvCCConnSipAccept() it means that the accepted request is
 *          surely not UPDATE.
 *
 * Return Value: -
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         hCall         handle to a callLeg
 *                 sdpMsg        Sdp that will be inserted to the OK message
 *  Output:        None
***************************************************************************/
RV_Status rvSipControlCallAccept(RvSipCallLegHandle hCall, RvSdpMsg* sdpMsg)
{
    RV_Status rc = RV_OK;
    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvSipControlCallAccept callLeg %p, sdp %p",hCall, sdpMsg));

    if (sdpMsg != NULL)
    {
        RvSipMsgHandle hOutBoundMsg;

        /* Get the Reply message object*/
        rc = RvSipCallLegGetOutboundMsg(hCall, &hOutBoundMsg);
        if (rc == RV_OK)
        {
            /* Add SDP to the Reply message */
            if ((rc =  rvSipControlMsgSetBody(hOutBoundMsg, sdpMsg)) != RV_OK)
            {
                RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallAccept:rvSipControlMsgSetBody Failed to set body for OK Reply, call-leg:%p", hCall));
            }
        }
        else
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallAccept:RvSipCallLegGetOutboundMsg failed, call-leg:%p, rc:%d", hCall,rc));
        }
    }

    if (rc == RV_OK)
    {
        rc=RvSipCallLegAccept(hCall);
        if (rc != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallAccept:RvSipCallLegAccept failed, call-leg:%p, rc:%d", hCall,rc));
        }
    }

    RvLogDebug(ippLogSource,(ippLogSource,"--> rvSipControlCallAccept %d ",rc));
    return rc;

}
/***************************************************************************
 * rvSipControlUpdateAccept
 * ------------------------------------------------------------------------
 * General: This function handles acceptance of an incoming Update request
 *          by sending OK (200) response.
 *
 * Return Value: -
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         hCall         handle to a callLeg
 *                 sdpMsg        Sdp that will be inserted to the OK message
 *  Output:        None
***************************************************************************/
RV_Status rvSipControlUpdateAccept(RvSipCallLegHandle hCall, RvSdpMsg* sdpMsg)
{
    RV_Status           rc = RV_OK;
	RvSipMsgHandle      reqMsg;
	RvSipTranscHandle   hTransc = NULL;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvSipControlUpdateAccept callLeg %p, sdp %p",hCall, sdpMsg));

	/* UPDATE request is handled as a call leg transaction. Get the request transaction */
	RvSipCallLegGetReceivedMsg(hCall, &reqMsg);
	RvSipCallLegGetTranscByMsg(hCall, reqMsg, RV_TRUE, &hTransc);

    if (sdpMsg != NULL)
    {
        RvSipMsgHandle hOutBoundMsg;

        /* Get the Reply message object*/
		rc = RvSipTransactionGetOutboundMsg(hTransc, &hOutBoundMsg);

        if (rc == RV_OK)
        {
            /* Add SDP to the Reply message */
            if ((rc =  rvSipControlMsgSetBody(hOutBoundMsg, sdpMsg)) != RV_OK)
            {
                RvLogError(ippLogSource,(ippLogSource,"rvSipControlUpdateAccept:rvSipControlMsgSetBody Failed to set body for OK Reply, call-leg:%p", hCall));
            }
        }
        else
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlAccept:RvSipCallLegGetOutboundMsg failed, call-leg:%p, rc:%d", hCall,rc));
        }
    }

    if (rc == RV_OK)
    {

		rc = RvSipCallLegTranscResponse(hCall, hTransc, RV_SIPCTRL_STATUS_OK);


        if (rc != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlUpdateAccept:RvSipCallLegTranscResponse failed, call-leg:%p, rc:%d", hCall,rc));
        }
    }

    RvLogDebug(ippLogSource,(ippLogSource,"--> rvSipControlUpdateAccept %d ",rc));

    return rc;

}


/******************************************************************************
 * rvIppGetUserScheme - define a user scheme "secure "sips" or not "sip"
 * ------------------------------------------------------------------------
 * parameters:
 *  IN      str  -    the TO string to analyze
 *  OUT     scheme -  the result scheme string.
 ********************************************************************************/
void rvIppGetUserScheme(char* str, char* scheme)
{
    /* Looking for known schemes: "sip", "sips" before the first ":" char.
       In case the ":" char comes with port the scheme should be null
    */

    char *p;
    char searchStr[RV_IPP_ADDRESS_SIZE];

    strncpy(searchStr, str, sizeof(searchStr)-1);
    searchStr[sizeof(searchStr)-1] = '\0';

    p = strchr(searchStr, ':');

    if (p)
    {
        *p='\0'; /* Set '\0' instead of ":" char */
        if (!strcmp(searchStr, "sip") || !strcmp(searchStr, "sips") ||
            !strcmp(searchStr, "tel"))
            strcpy(scheme, searchStr); /* Will not copy the ':' char */
    }
    else
    {
        scheme[0]='\0';
    }
}


/***************************************************************************
 * rvSipMgrGetUserNameFromUrl
 * ------------------------------------------------------------------------
 * General: Get user name from a URL address
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   str         - pointer to url
 * output:  scheme      - the user name string
 * Return:  None
 ***************************************************************************/
void rvSipMgrGetUserNameFromUrl(char* str, char* username)
{
    RvUint32 length;
    char *s = str;
    char *p = strchr(str, ':')+1;

    length = (RvUint32)(p-str);
    s += length;

    p = strchr(p, '@');
    if (p)
    {
        memcpy(username, s, p-s);
        username[p-s]='\0';

    }
    else
        username[0]='\0';
}

/***************************************************************************
 * rvSipMgrGetHostFromUrl
 * ------------------------------------------------------------------------
 * General: Get host name (ip address or domain) from URL address
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   str         - pointer to url
 *          addressLen  - size of address
 * output:  address     - the address string
 * Return:  None
 ***************************************************************************/
void rvSipMgrGetHostFromUrl(char* str, char* address, int addressLen)
{
    char *s = str;
    char *p = strchr(str, ':')+1;
    char* y;
#if (RV_NET_TYPE & RV_NET_IPV6)
	char *bracesEnd;
#endif /* RV_NET_IPV6 */

    /* Skip the scheme*/
    s += (p-str);

    /* Skip username*/
    p = strchr(p, '@');
    if (p == NULL) /*No username*/
        p = s;
    else
        p += 1;

    /* Skip port number*/
#if (RV_NET_TYPE & RV_NET_IPV6)
    if (IppUtilIsIpV4(p) == RV_FALSE)
    {
		/* IPV6 addresses should be treated differently, because they have ':' in various places */
		y = strrchr(p, ':');
		bracesEnd = strrchr(p, ']');
		if ((bracesEnd == NULL) || (y < bracesEnd))
		{
			y = NULL; /* all the ':' characters are part of the address, not start of port number */
		}
	}
	else
	{
		y = strchr(p, ':');
	}
#else
    y = strchr(p, ':');
#endif
    if (y)
    {
        memcpy(address, p, y-p);
        address[y-p]='\0';
    }
    else /* No port number*/
    {
        y = strchr(p, '?'); /* In case that in the Url, after the port or address there is a nother header.
                            For example, in case of refer-to header that supports replaces, after the url
                            of the refer-to, there is, for example,
                            "?Replaces=1596698-504610ac-13c4-45017-76a31c-656ba19" */
        if (y)
        {
            memcpy(address, p, y-p);
            address[y-p]='\0';
        }
        else /* No other additional header */
        {
            memcpy(address, p, addressLen);
            address[addressLen-1]='\0';
        }
    }
}

/***************************************************************************
 * rvSipMgrGetPortFromUrl
 * ------------------------------------------------------------------------
 * General: Get port number from URL address
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   str         - pointer to url
 *
 * output:  None
 * Return:  port number
 ***************************************************************************/
RvUint16 rvSipMgrGetPortFromUrl(char* str)
{
    /* TODO: See if we can parse it differently. The technique below doesn't seem a good one */
    char portStr[RV_SHORT_STR_SZ];
    char *s = str;
    char *p = strchr(str, ':')+1;
    char* y, *x;

    /* Skip the scheme*/
    s += (p-str);

    /* Skip username*/
    p = strchr(p, '@');
    if (p == NULL) /*No username*/
        p = s;
    else
        p += 1;

    /* Find port number*/
    y = strchr(p, ':');
    if (y)
    {
        x = strchr(p, '\0');
        memcpy(portStr, y+1, x-y);
        portStr[x-y]='\0';
        return (RvUint16)atoi(portStr);
    }
    else /* No port number*/
    {
        return 0;
    }
}

/*************************************************************************************
 * prepareToHeaderForParsing - add To:: and display name before SIP parsing:
 *                               From: "bob"<sip:bob@domain.com>
 * ------------------------------------------------------------------------
 * parameters:
 *  IN      to  -	 string containing to address. In case of sip address, the "sip:"
 *					 part has already been added by function findDestinationAddress.
 *					 examples: tel:+1231, sip:4444@172.16.70.75, sip:172.16.70.75:6060
 *
 *  OUT:    strTo -  the destination address created from to & the user name (id exists).
 *  IN      scheme - the scheme of destination address ("tel"/"sip"/"sips").
 *************************************************************************************/

static void prepareToHeaderForParsing(char* to, char *strTo, char* scheme)
{
    /* Handle "tel:" scheme */
    if (strcmp(scheme, "tel") == 0)
	{
        sprintf(strTo, "To:<%s>", to);
    }
    /* Handle other schemes ("sip:" and "sips:") */
    else
    {
		char toUser[RV_SHORT_STR_SZ];
        memset (toUser, 0, sizeof(toUser));

		rvSipMgrGetUserNameFromUrl(to, toUser);

		/*"To: ui <sip:ui@172.20.51.216:5060>"*/
        if (toUser[0] != '\0')
		/* user name given, create strTo from address, user name */
		{
			sprintf(strTo, "To: \"%s\" <%s>", toUser,to);
		}
		else
		/* no user name, create strTo from address only. */
		{
			sprintf(strTo, "To:<%s>", to);
		}
    }
}

/*************************************************************************************
 * prepareFromHeaderForParsing - add From: and display name before SIP parsing:
 *                               From: "bob"<sip:bob@domain.com>
 * ------------------------------------------------------------------------
 * parameters:
 *  IN      sipMgr  -     pointer to RvSipControl object to get userDomain
 *  IN      displayName - display name "bob"
 *  IN      strFromIn   - the string contains : "sip:bob@172.20.1.123"
 *  OUT     strFromOut -  the string contains : From "bob"<sip:qq@domain.com>
 *************************************************************************************/
static void prepareFromHeaderForParsing(RvSipControl *sipMgr, RvCCConnection* c, RvUint16 port ,
										RvCCTerminalSip* sipTerm, char *displayName,
										char *strFromIn, char *strFromOut, char *userScheme)
{
    char fromUser[RV_SHORT_STR_SZ];
    char userDomain[128];
	int  userDomainLen = sizeof(userDomain);
	const char   *regAddr    = rvCCTerminalSipGetRegistrarAddress(sipTerm);
	RvUint16      regPort    = rvCCTerminalSipGetRegistrarPort(sipTerm);

//add by zhuhaibo 20110317 for set from's domainName
    const char   *obAddr    = rvCCTerminalSipGetOutboundProxyAddress(sipTerm);
    RvUint16      obPort    = rvCCTerminalSipGetOutboundProxyPort(sipTerm);
#if(0)
	/* The userDomain is determined according to:
	   1. Registrar name, if not configured -
	   2. configuration parameter 'userDomain', if not configured -
	   3. local address.   */

	if ((regAddr != NULL) && (strcmp(regAddr, "")))
	{
		strncpy(userDomain, regAddr, userDomainLen);

		if  ((IppUtilIsIpAddress((char*)regAddr)) && (regPort != RVSIPCTRL_DEFAULT_PORT))
		{
			sprintf(userDomain,"%s:%d", regAddr, regPort);
		}
	}
	else
	if ((sipMgr->userDomain != NULL) && (strcmp(sipMgr->userDomain, "")))
	{
		strncpy(userDomain, sipMgr->userDomain, userDomainLen);

	}
#endif
        
    /* The userDomain is determined according to:
	 1. configuration parameter 'userDomain', if not configured -
	 3. OutBound Proxy name, if not configured -
	 3. Registrar name, if not configured -
	 4. local address.   */
	 
    if ((sipMgr->userDomain != NULL) && (strcmp(sipMgr->userDomain, "")))
    {
        strncpy(userDomain, sipMgr->userDomain, userDomainLen);
    }
    else if ((regAddr != NULL) && (strcmp(regAddr, "")))
    {
        strncpy(userDomain, regAddr, userDomainLen);

        if  ((IppUtilIsIpAddress((char*)regAddr)) && (regPort != RVSIPCTRL_DEFAULT_PORT))
        {
            sprintf(userDomain,"%s:%d", regAddr, regPort);
        }
    }
    else if ((obAddr != NULL) && (strcmp(obAddr, "")))
    {
        strncpy(userDomain, obAddr, userDomainLen);

        if  ((IppUtilIsIpAddress((char*)obAddr)) && (obPort != RVSIPCTRL_DEFAULT_PORT))
        {
            sprintf(userDomain,"%s:%d", obAddr, obPort);
        }
    }
//add end
	else
	{
		/* Set the local address as userDomain */
		RvCCProvider*     p             = rvCCConnSipGetProvider(c);
		RvCCProviderSip*  provider      = rvCCProviderSipGetImpl(p);
		char*             localAddress  = rvCCProviderSipGetLocalAddress(provider);

		strncpy(userDomain, localAddress, userDomainLen);

		if  ((IppUtilIsIpAddress((char*)localAddress)) && (port != RVSIPCTRL_DEFAULT_PORT))
		{
			sprintf(userDomain,"%s:%d", localAddress, port);
		}
	}

	userDomain[userDomainLen-1] = '\0';

    rvSipMgrGetUserNameFromUrl(strFromIn, fromUser);

    /* In case the destination is based on "tel:" scheme, use "sip" scheme for the From header */
    if (strcmp(userScheme, "tel") == 0)
    {
    /*"From:  <sip:ui@domain.com>"*/
    if (fromUser[0])
            sprintf(strFromOut, "From: \"%s\" <sip:%s@%s>", displayName, fromUser, userDomain);
        else
            sprintf(strFromOut, "From:<sip:@%s>", userDomain);
    }
    else
    {
        /*"From:  <sip:ui@domain.com>"*/
        if (fromUser[0])
        sprintf(strFromOut, "From: \"%s\" <%s:%s@%s>", displayName, userScheme, fromUser, userDomain);
    else
        sprintf(strFromOut, "From:<%s:@%s>", userScheme, userDomain);
    }
}

/*************************************************************************************
 * setPortNumber - Set the right port number according to scheme
 * ------------------------------------------------------------------------
 * parameters:
 *  IN      sipMgr  -     pointer to RvSipControl object to get the configured port
 *  IN      userScheme  - scheme (tel, sip or sips)
 *  OUT     port - port number
 *  OUT     transportType   - transport type
 *************************************************************************************/
static void setPortNumber(
                      IN RvSipControl*      sipMgr,
                      IN char*              scheme,
                      OUT RvUint16*         port,
                      OUT RvSipTransport*   transportType)
{

    /*If we are sending the Invite over TLS, use TLS port and TCP*/
#ifdef RV_CFLAG_TLS
    if (strcmp(scheme, "sips") == 0)
{
        *port = rvIppTlsGetPort();
        /* TLS must be sent over TCP, and user may have configured UDP*/
        *transportType = RVSIP_TRANSPORT_TCP;
    }
    else
#else
    RV_UNUSED_ARG(transportType);
#endif

    /*If we are not sending the Invite over TLS, use the configured port */
    if ((strcmp(scheme, "sip") == 0) || (strcmp(scheme, "tel") == 0))
    {
        *port = sipMgr->stackPort;
    }
}

/*************************************************************************************
 * buildFromHeader - build a full From header out of the local address
 * ------------------------------------------------------------------------
 * parameters:
 *  IN      userScheme  - scheme (tel, sip or sips)
 *  IN      from  -  local address
 *  IN      port -  port number
 *  OUT     longFrom   - the full from header
 *  IN      longFromSize   - transport type
 *************************************************************************************/
static void buildFromHeader(char* userScheme, char* from, RvUint16 port, char* longFrom, RvUint longFromSize)
{
    /* If destination address is "tel", From header should include the default scheme "sip:"*/
    if (strcmp(userScheme, "tel") == 0)
    {
        /* No need to specify the default port*/
        if ((port != RVSIPCTRL_NO_PORT) && (port != RVSIPCTRL_DEFAULT_PORT))
            RvSnprintf(longFrom, longFromSize,"sip:%s:%u", from, port);
        else
            RvSnprintf(longFrom, longFromSize, "sip:%s", from);
    }
    /* If destination address is "sips", From header should "sips" as well,
       so that all messages will be sent over TLS */
    else
    {
        /* No need to specify the default port*/
        if ((port != RVSIPCTRL_NO_PORT) && (port != RVSIPCTRL_DEFAULT_PORT))
            RvSnprintf(longFrom, longFromSize,"%s:%s:%u", userScheme, from, port);
        else
            RvSnprintf(longFrom, longFromSize,"%s:%s", userScheme, from);
    }
}

/*************************************************************************************
 * rvSipControlForwardCall - Forward  a call
 * ------------------------------------------------------------------------
 * parameters:
 *  IN   hCallLeg    - sip call leg handle
 *  IN   x           - sip connection
 *  IN   sendToAddress - the address of the diverted-to user
 * return:
 *       RV_OK if succeeded
 *************************************************************************************/
RvStatus rvSipControlForwardCall(RvSipCallLegHandle hCallLeg,
                                 RvCCConnection*    x,
                                 RvChar             *sendToAddress)
{
    RvStatus            rc = RV_OK;
    RvSipAddressHandle  hRedirectAddress;
    RvSipTransport      termTransport = rvCCTerminalSipGetTransportByConnection(x);

    if ((rc = RvSipCallLegGetNewAddressHandle(hCallLeg, RVSIP_ADDRTYPE_URL, &hRedirectAddress)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"SipForwardCall: GetNewAddressHandle fail rc = %d", rc));
        return rc;
    }
    if ((rc = RvSipAddrParse(hRedirectAddress, sendToAddress)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"SipForwardCall: RvSipAddrParse fail, rc = %d", rc));
        return rc;
    }
    if ((rc = rvSipControlSetTransportType(hRedirectAddress, termTransport)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"SipForwardCall: UrlSetTransport fail, rc = %d", rc));
        return rc;
    }
    if ((rc = RvSipCallLegSetLocalContactAddress (hCallLeg, hRedirectAddress)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"SipForwardCall: SetLocalContactAddress fail, rc = %d", rc));
        return rc;
    }
    return rc;
}

/*************************************************************************************
 * rvSipControlCallMake - initiate a call
 * ------------------------------------------------------------------------
 * parameters:
 *  IN   x    - pointer to RvSipControl object
 *  IN   call - application call handle which is connection
 *  IN   to   - string which specifies to were the call is destined
 *  IN   from - string which specifies from were the call is originated
 * return:
 *       RV_OK if succeeded
 *************************************************************************************/
RvStatus rvSipControlCallMake(RvSipControl* x, RvSipAppCallLegHandle call, char* to, char* from)
{
    RvStatus               rv;
    RvSipCallLegHandle      hCallLeg; /*handle to the call-leg*/
    RvSipCallLegMgrHandle   hCallLegMgr;
    RvSipAddressHandle      hContactAddress;
    RvSipAddressType        addressType = RVSIP_ADDRTYPE_URL;
    RvCCConnection*         c = (RvCCConnection*)call;
    RvCCTerminal*           term      = rvCCConnSipGetTerminal(c);
    RvCCTerminalSip*        sipTerm   = rvCCTerminalSipGetImpl(term);
    RvSipTransport          transportType = rvCCTerminalSipGetTransportType(sipTerm);
    RvUint16                port = 0;
    RvSipMsgHandle          hMsg;

    char longTo[RV_NAME_STR_SZ], longFrom[RV_NAME_STR_SZ], longfromOut[RV_NAME_STR_SZ];
    char shortFrom[RV_NAME_STR_SZ];
    char displayName[RV_NAME_STR_SZ]= {""};
    char userScheme[RV_SHORT_STR_SZ]= {""};
    /* IPV6 handling*/
#if (RV_NET_TYPE & RV_NET_IPV6)
    RvBool                      bIsIpV4;

    /*Copy origin and destination addresses to local strings*/
    /* when its IPv6 address we need to remove scope id*/
    bIsIpV4 = IppUtilIsIpV4(from);
    if (bIsIpV4 == RV_FALSE)
    {
        IppUtilRemoveScopeIdFromIpv6String(from);
    }
#endif /* RV_NET_IPV6 */

    strncpy(shortFrom, from, sizeof(shortFrom)-1);
    shortFrom[sizeof(shortFrom)-1] = '\0';

    /* Set Display Name from the terminal object. If not configured, take it From header. */
	sprintf(displayName,"%s",rvCCTerminalSipGetDisplayName(sipTerm));
    if (!strcmp(displayName, ""))
    {
        RvChar *pStrEnd = NULL;
        /* set displayName from shortFrom string */
        strcpy(displayName, shortFrom);
        pStrEnd = strchr(displayName, '@');
        if (pStrEnd != NULL)
            *pStrEnd = '\0';
    }

    /*--------------------------
      creating a new call-leg
    ----------------------------*/
    rv = RvSipStackGetCallLegMgrHandle( rvSipControlGetStackHandle(x),      &hCallLegMgr);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipStackGetCallLegMgrHandle fail Status:%d",rv));
        return rv;
    }
    rv = RvSipCallLegMgrCreateCallLeg( hCallLegMgr, call,&hCallLeg);
    if(rv != RV_OK)
    {
		RvCCConnection*    party = rvCCConnectionGetConnectParty(c);
		if (party != NULL)
		{
			/* Set the reason for the failure in the party connection. It will be reported to the
			   application later on */
			party->lastReceivedCallStateReason = RV_MTF_CALL_STATE_REASON_OUT_OF_RESOURCES;
		}
        RvLogError(ippLogSource,(ippLogSource,"Failed to create new call-leg To:%s From:%s, Status:%d", to, from, rv));
        return rv;
    }

    RvLogInfo(ippLogSource,(ippLogSource,"Outgoing call-leg %p was created", hCallLeg));

	/* Assign the callLeg in the sipconn */
	rvCCConnSipSetCallLegHandle(c, hCallLeg);

#ifdef RV_SIP_IMS_ON

	if (sipTerm->imsTerminalSip.SecAgreeInitiated == RV_TRUE)
	{
		/* attach the client sec-agree object with the call-leg object, from now on the SIP stack will take the information from the sec agree object (for example, the call will be sent to the Registrar first, and the Registrar will forward it to the destination address).*/
		rv = RvSipCallLegSetSecAgree(hCallLeg, sipTerm->imsTerminalSip.hSecAgree);
		if (rv != RV_OK)
		{
			RvLogDebug(ippLogSource,(ippLogSource,"rvSipControlCallMake:: Failed to set security-agreement to call-leg %p, Status:%d",
					   hCallLeg, rv));
		}
	}
#endif

    /*Call user callback*/
    rvIppSipExtPreCallLegCreatedOutgoingCB((RvIppSipControlHandle)x, (RvIppConnectionHandle)c, hCallLeg, to, from);

    /*------------------
      Set Local Contact
    --------------------*/

    /*To receive messages in the chosen Transport type*/
    rv = RvSipCallLegGetNewAddressHandle(hCallLeg, RVSIP_ADDRTYPE_URL, &hContactAddress);
    /* add to local contact the stack port to solve the scenario that we are register to registrar
       server with default port(5060) and send invite with contact that doesn't contain the port */
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipCallLegGetNewAddressHandle, Status:%d", rv));
        return rv;
    }

    rvIppGetUserScheme(to, userScheme); /* Check only the first 5 chars */
#ifdef RV_SIP_IMS_ON
#ifdef RV_CFLAG_TLS

	if (sipTerm->imsTerminalSip.SecAgreeInitiated == RV_TRUE)
	{

		/* If TLs is chosen, set the TLS port of the Registrar */
		if (sipTerm->imsTerminalSip.chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_TLS)
		{
			/* set outbound proxy port to be the outbound TLS port */
			setCallLegOutboundPort(hCallLeg, sipTerm->outboundProxyAddress,
								   sipTerm->registrarTlsPort);
		}
	}
#endif /* RV_CFLAG_TLS */
#endif /* RV_SIP_IMS_ON */
    /* Set port number and transport type according to scheme*/
    setPortNumber(x, userScheme, &port, &transportType);
    /* Build the full From header based on local address */
    buildFromHeader(userScheme, from, port, longFrom, sizeof(longFrom));

    rv = RvSipAddrParse(hContactAddress, longFrom);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipCallLegGetNewAddressHandle, Status:%d", rv));
        return rv;
    }
#ifdef USE_GPON_OVERSEA_VERSION //add by Happy Su,add port to contact header
    MsgAddress* pAddress = (MsgAddress*)hContactAddress;
    MsgAddrUrl* url=pAddress->uAddrBody.hUrl;
    url->portNum = port;
#endif
    rv = rvSipControlSetTransportType(hContactAddress, transportType);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipAddrUrlSetTransport,Transport:%d Status:%d",transportType,rv));
        return rv;
    }

    rv = RvSipCallLegSetLocalContactAddress (hCallLeg, hContactAddress);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"Failed to set Local Contact header for call-leg %p", hCallLeg));
    }

    /*-------------------
      Set Remote Contact
    ---------------------*/
    if (strcmp(userScheme, "tel") == 0)
    {
        addressType = RVSIP_ADDRTYPE_TEL;
    }

    /*To send messages in the chosen Transport type*/
    rv = RvSipCallLegGetNewAddressHandle(hCallLeg, addressType, &hContactAddress);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipCallLegGetNewAddressHandle Status:%d",rv));
        return rv;
    }
    rv = RvSipAddrParse(hContactAddress, to);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipAddrParse Status:%d",rv));
        return rv;
    }

    rv = rvSipControlSetTransportType(hContactAddress, transportType);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:RvSipAddrUrlSetTransport Status:%d",rv));
        return rv;
    }

    rv = RvSipCallLegSetRemoteContactAddress (hCallLeg, hContactAddress);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:Failed to set Remote Contact header for call-leg %p",             hCallLeg));
    }

    /*------------------------------------------------------------
      Call the make function with the to and from addresses in order
      to connect the call.
    -------------------------------------------------------------*/

    RvLogInfo(ippLogSource,(ippLogSource,"rvSipControlCallMake:Connecting a call: \n\t%s -> %s", from, to));

    /* build longTo and longFrom that will be used in To and From headers of the Invite message*/
    prepareToHeaderForParsing(to, longTo, userScheme);
    prepareFromHeaderForParsing(x ,c, port, sipTerm, displayName, longFrom, longfromOut, userScheme);

    /*Call user callback*/
    rvIppSipExtPostCallLegCreatedOutgoingCB((RvIppSipControlHandle)x, (RvIppConnectionHandle)c, hCallLeg);

    /* Add route headers if needed */
    rv      = RvSipCallLegGetOutboundMsg(hCallLeg, &hMsg);
    rvSipControlSetRouteHeaderInMsg(hCallLeg, c, hMsg);

#ifdef RV_SIP_IMS_ON
	/* Calling this API will force all outgoing messages to be sent to the Outbound Proxy that was configured
	   locally + transport type configured locally and not to the address included in Service-Route header returned from Registrar. */
	RvSipCallLegSetForceOutboundAddrFlag(hCallLeg, RV_TRUE);
#endif /* RV_SIP_IMS_ON */

	/*set  data for remote party  which received from TO header */
	rvSipSetRemoteData(c,to);

    rv = RvSipCallLegMake(hCallLeg, longfromOut, longTo);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlCallMake:Call Make failed for call-leg %p", hCallLeg));
        return RV_ERROR_UNKNOWN;
    }

    /* Store original "from" address to be used by REFER msg in case of transfer */
    rvCCSipPhoneSetFromAddress(call, longFrom);

    return RV_OK;
}

void rvSipControlReject(RvSipCallLegHandle hCallLeg, int reason)
{

    RvSipCallLegState state;
    RvSipCallLegModifyState  modifyState;

    RvSipCallLegGetCurrentState (hCallLeg, &state);

    RvSipCallLegGetCurrentModifyState (hCallLeg, &modifyState);

    /* Disconnect the call only if this is a connected call, but
       not in a process of Modify (Re-Invite)*/
    if ((state != RVSIP_CALL_LEG_STATE_OFFERING) &&
        (modifyState != RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RCVD))
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Disconnecting Call (%x), state = %d, modifyState = %d, reason = %d",
                    hCallLeg, state, modifyState, reason));
        RvSipCallLegDisconnect(hCallLeg);
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Rejecting Call (%x), state = %d, modifyState = %d, reason = %d",
                    hCallLeg, state, modifyState, reason));
        RvSipCallLegReject(hCallLeg, (RV_UINT16)reason);
    }
}

/***************************************************************************
 * rvSipControlRejectUpdate
 * ------------------------------------------------------------------------
 * General: Reject an UPDATE request.
 *          UPDATE request rejection should not lead to call disconnecting,
 *          which would happen if rvSipControlReject is invoked, because
 *          the call is not in the RVSIP_CALL_LEG_STATE_OFFERING state.
 *
 *
 * Return Value:
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg   - sip callLeg handle
 *          reason     - reject reason
 *
 ***************************************************************************/
void rvSipControlRejectUpdate(RvSipCallLegHandle hCallLeg, RvSipTranscHandle   hTransc,  int reason)
{
	RvSipMsgHandle      hMsg = NULL;
	RvStatus            rv;

	RvLogInfo(ippLogSource,(ippLogSource,"rvSipControlRejectUpdate: Call (%x), reason = %d",
		    	hCallLeg,  reason));
	/* Rejecting an UPDATE request is done by the callLeg transaction reject */
	/* Get the request transaction */
	if (hTransc == NULL)
	{
		RvSipCallLegGetReceivedMsg(hCallLeg, &hMsg);
		RvSipCallLegGetTranscByMsg(hCallLeg, hMsg, RV_TRUE, &hTransc);
	}
	if (reason == RV_SIPCTRL_STATUS_SERVERERR)
	{
		/* add a Retry-After header to the 500 reject message */

		rv = RvSipTransactionGetOutboundMsg(hTransc, &hMsg);

		if (rv == RV_OK)
		{
			RvUint32      retryTime;

			/* Check if the user configured a value to updateRetryAfterTimeout */
			if ( g_sipControl->updateRetryAfterTimeout != (RvUint8)UNDEFINED)
			{
				retryTime = g_sipControl->updateRetryAfterTimeout;
			}
			else
			{
				/* no value configured to updateRetryAfterTimeout.*/
				/* Get a random value in the range [0..10] seconds. */
				RvRandomGeneratorGetInRange(&g_mtfMgr->randomGenerator,10, &retryTime);
			}

			addRetryAfterHeaderToMsg(hMsg, (RvUint8)retryTime);
		}
		else
		{
			RvLogError(ippLogSource,(ippLogSource,"rvSipControlRejectUpdate: Failed to get outbound msg from transaction %x, Call (%x)",
		    	hTransc, hCallLeg));
		}
	}

	RvSipCallLegTranscResponse(hCallLeg, hTransc, (RV_UINT16)reason);
}

void rvSipControlSendRinging(RvSipCallLegHandle hCall)
{
    RvSipCallLegProvisionalResponse ( hCall, RV_SIPCTRL_STATUS_RINGING);
}

void rvSipControlSendQueued(RvSipCallLegHandle hCall)
{
    RvSipCallLegProvisionalResponse ( hCall, RV_SIPCTRL_STATUS_QUEUED);
}

/***************************************************************************
* rvSipControlModifyOrRefresh
* ------------------------------------------------------------------------
* General: Decides which API should be invoked when a re-invite is to be sent -
*          if session timer is activated a Session-Expires header should be
*          added to the header list. This is done by RvSipCallLegSessionTimerRefresh.
*          In other cases RvSipCallLegModify is invoked.
*
*           .
* Return Value: True - success, False - fail.
* ------------------------------------------------------------------------
* Arguments:
* Input:   hCall   - sip callLeg handle
*
*
***************************************************************************/
RvStatus rvSipControlModifyOrRefresh(RvSipCallLegHandle hCall)
{
    RvStatus rv;
    RvInt32          eTime;

    /*  Check if session timer is active.                                              */
    /*  note: the following proc generates an ERROR when session timer is not active.
	It is used even so because this is the most efficient way to check it. The error
	does not affect the re-invite process
	This  call should be replaced by a more suitable API when one implemented       */
    rv = RvSipCallLegSessionTimerGetAlertTime(hCall, &eTime);

    if (rv != RV_OK)
        rv = RvSipCallLegModify (hCall);
    else
        rv = sendReInviteWithSessionTimerHeaders(hCall);

    return rv;
}

/***************************************************************************
 * rvSipControlsendUpdate
 * ------------------------------------------------------------------------
 * General: Send  UPDATE message .
 *          This proc creates a call leg transaction and sets required fields
 *          in the message.
 *
 * Return Value: RV_OK on success, Negative value on failure
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          hCallLeg    - The  handle for this call-leg.
 *          sdpMsg      - sdp to attach to the msg body
 *
 ***************************************************************************/
RvStatus rvSipControlSendUpdate(RvCCConnection* c, RvSdpMsg* sdpMsg)
{
	RvSipTranscHandle            hTransc;
	RvSipMsgHandle               hMsg;
	RvSipCallLegHandle           hCallLeg = rvCCConnSipGetCallLegHandle(c);
	RvSipPartyHeaderHandle       hFrom;
	RvSipPartyHeaderHandle       hTo;
    RvChar                       strCallId[RV_SHORT_STR_SZ];
    RvUint                       strActLen = 0;
	RvStatus                     rv;
	RvSdpMsg*                    lastUpdateSdp;
	RvInt32                      eTime = 0 ;

	/* if a timer was started because of a previously sent UPDATE, cancel it now */
	IppTimerStop(rvCCConnSipGetUpdateResendTimer(c));

	rv = RvSipCallLegTranscCreate(hCallLeg,NULL, &hTransc);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "sendUpdate:: failed to create transaction for connection %p with error=%d",c, rv));
        return rv;
    }

	rv = RvSipTransactionGetOutboundMsg(hTransc, &hMsg);

	if(rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "sendUpdate: Failed to get transc msg, connection:%p", c));
		return rv;
	}

	/* SDP msg may be NULL when the UPDATE message is a session timer refresh message.*/
	if (sdpMsg != NULL)
	{
		if ((rv =  rvSipControlMsgSetBody(hMsg, sdpMsg)) != RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource, "sendUpdate: Failed to set msg body, connection:%p", c));
			return rv;
		}
	}

	/* Copy From header from the callLeg to the transaction */
	if (RvSipCallLegGetFromHeader(hCallLeg, &hFrom))
		RvSipTransactionSetFromHeader( hTransc, hFrom);

	/* Copy To header from the callLeg to the transaction */
	if (RvSipCallLegGetToHeader(hCallLeg, &hTo))
		RvSipTransactionSetToHeader(hTransc,hTo);

	/* Copy the CallId from the callLeg to the transaction */
	if (RvSipCallLegGetCallId(hCallLeg, sizeof(strCallId), (RvChar*)strCallId, (RvInt32*) &strActLen))
		RvSipTransactionSetCallId(hTransc, strCallId);

    /*  Check if session timer is active.                                              */
    /*  note: the following proc generates an ERROR when session timer is not active.
		It is used even so because this is the most efficient way to check it. The error
		does not affect the re-invite process
		This  call should be replaced by a more suitable API when one implemented       */
    rv = RvSipCallLegSessionTimerGetAlertTime(hCallLeg, &eTime);

	if (rv == RV_OK)
	{
		rv = sendUpdateWithSessionTimerHeaders(hCallLeg, hTransc);
	}
	else
	{
		rv = RvSipCallLegTranscRequest(hCallLeg,"UPDATE", &hTransc);
	}

    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvSipCallLegTranscRequest failed to send UPDATE with error=%d",rv));
        return rv;
	}

	/* Store the SDP in the RvCCConnSip object. It might be needed if this UPDATE is rejected and needs to
	   be resent later */
	lastUpdateSdp = rvCCConnSipGetUpdateSdp(c);
	if (lastUpdateSdp != sdpMsg)
	{
		/* The SDP that was set in the UPDATE message is not already stored in the RvCCConnSip object */
		if (lastUpdateSdp != NULL)
		{
			/* destruct the stored SDP */
			rvSdpMsgDestruct(lastUpdateSdp);
			lastUpdateSdp = NULL;
			rvCCConnSipSetUpdateSdp(c, NULL);
		}
		lastUpdateSdp = rvSdpMsgConstructCopyA(lastUpdateSdp, sdpMsg, prvDefaultAlloc);
		rvCCConnSipSetUpdateSdp(c, lastUpdateSdp );
	}

    return rv;
}

RvBool rvSipControlSendModify(RvSipCallLegHandle hCall, RvCCConnection* c, RvSdpMsg* sdpMsg)
{
    RvSipMsgHandle  hMsg;
    RvSdpMsg*       sdpCaps  = NULL;
    RvSdpOrigin*    sdpMsgOrig = NULL;
    RvSdpOrigin*    sdpCapsOrig = NULL;
    RvInt32         verInt;
    RV_Status rv;
    char            verStr[48];

    sdpMsgOrig = rvSdpMsgGetOrigin(sdpMsg);
    /* The version is taken from the media capabilities in the connection object. */
    /* It is incremented by one and stored back                                   */
    sdpCaps = rvCCConnSipGetMediaCaps(c);
    sdpCapsOrig = rvSdpMsgGetOrigin(sdpCaps);


    /* Make sure that the o= field in the outgoing msg will match the one in
       the media capabilities                                              */
    rvSdpMsgSetOrigin(sdpMsg, rvSdpOriginGetUsername(sdpCapsOrig),
                              rvSdpOriginGetSessionId(sdpCapsOrig),
                              rvSdpOriginGetVersion(sdpCapsOrig),
                              rvSdpOriginGetNetType(sdpCapsOrig),
                              rvSdpOriginGetAddressType(sdpCapsOrig),
                              rvSdpOriginGetAddress(sdpCapsOrig));

    sdpMsgOrig = rvSdpMsgGetOrigin(sdpMsg);

    /* increment the version number by one and store it in the outgoing message and
        in the media caps   */
    sscanf(rvSdpOriginGetVersion(sdpCapsOrig), "%d", &verInt);
    sprintf(verStr,"%u", verInt + 1);

    rvSdpOriginSetVersion(sdpMsgOrig,verStr);
    rvSdpOriginSetVersion(sdpCapsOrig,verStr);

	if (rvCCConnGetUpdateState(c) == RV_CCUPDATESTATE_SENT)
		/* This is a state of sending UPDATE message. It wasn't sent yet, send it now */
		rvSipControlSendUpdate(c, sdpMsg);
	else
	{
		rv      = RvSipCallLegGetOutboundMsg(hCall, &hMsg);
		if ((rv =  rvSipControlMsgSetBody(hMsg, sdpMsg)) != RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource, "Failed to get Modify msg body, connection:%p", c));
		}

		if ((rv = rvSipControlModifyOrRefresh(hCall)) != RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource, "Failed to send MODIFY message for call-leg %p error=%d", hCall,rv));
			return rvFalse;
		}
	}

    return rvTrue;
}

/***************************************************************************
 * rvSipControlSendDTMF
 * ------------------------------------------------------------------------
 * General: Send  DTMF OOB message .
 *
 * Return Value: RV_OK on success, Negative value on failure
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          hCallLeg    - The  handle for this call-leg.
 *          dtmfParam   - DTMF information to send
 *
 ***************************************************************************/
RvStatus rvSipControlSendDTMF(IN RvSipCallLegHandle hCallLeg, IN RvDtmfParameters* dtmfParam)
{
    RvSipTranscHandle    hTransc;
    RvSipMsgHandle       hMsg;
    RvChar               rawBuffer[64];
    RvChar               strBuff[2];
    RvStatus rv;

    RvLogInfo(ippLogSource,(ippLogSource, ">>>  rvSipControlSendDTMF"));
    strBuff[0] = dtmfParam->digit;
    strBuff[1] = '\0';

    rv =RvSipCallLegTranscCreate(hCallLeg,NULL, &hTransc);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvSipCallLegTranscCreate failed in rvSipControlSendDTMF with error=%d",rv));
        goto return_loc;
    }

    rv = RvSipTransactionGetOutboundMsg(hTransc, &hMsg);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvSipTransactionGetOutboundMsg failed in rvSipControlSendDTMF with error=%d",rv));
        goto return_loc;
    }

    rv = RvSipMsgSetContentTypeHeader(hMsg, "application/dtmf-relay");
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvSipMsgSetContentTypeHeader failed in rvSipControlSendDTMF with error=%d",rv));
        goto return_loc;
    }

    RvSnprintf(rawBuffer,sizeof(rawBuffer), "Signal=%s\nDuration=%d\n",strBuff,dtmfParam->duration);

    rv = RvSipMsgSetBody(hMsg, rawBuffer);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvSipMsgSetBody failed in rvSipControlSendDTMF with error=%d",rv));
        goto return_loc;
    }


    rv = RvSipCallLegTranscRequest(hCallLeg,"INFO", &hTransc);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvSipCallLegTranscRequest failed in rvSipControlSendDTMF with error=%d",rv));
        goto return_loc;
    }

return_loc:
    RvLogInfo(ippLogSource,(ippLogSource, "<<<  rvSipControlSendDTMF(%d)",rv));
    return rv;
}
/***************************************************************************
 * prepareReplacesHeaderFromCallLeg
 * ------------------------------------------------------------------------
 * General: This function prepares a Replaces header from the Call-ID, from-tag and
 *          to-tag of a Call-Leg
 *
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     pCallLeg        - The call leg to make the Replaces header from.
 *          hReplacesHeader - Handle to a Constructed Replaces header.
 * Output:  hReplacesHeader - The Replaces header with hCallLeg identifiers
 ***************************************************************************/
RvStatus prepareReplacesHeaderFromCallLeg(IN       RvSipCallLegHandle         *pCallLeg,
                                          INOUT    RvSipReplacesHeaderHandle   hReplacesHeader)
{
    RvStatus rv = RV_OK;
    RvChar*  strFromTag[RV_SHORT_STR_SZ];
    RvChar*  strToTag[RV_SHORT_STR_SZ];
    RvChar*  strCallId[RV_SHORT_STR_SZ];
    RvUint  strActLen = 0;
    RvSipPartyHeaderHandle  hTo     = NULL;
    RvSipPartyHeaderHandle  hFrom   = NULL;
    RvSipCallLegDirection   eDirection;

    RvSipCallLegGetDirection(*pCallLeg,&eDirection);

    if(eDirection == RVSIP_CALL_LEG_DIRECTION_OUTGOING)
    {
        RvSipCallLegGetToHeader(*pCallLeg,&hTo);
        RvSipCallLegGetFromHeader(*pCallLeg,&hFrom);

    }
    else

    {
        /* incoming call - the to-tag value from the CallLeg goes to from-tag part of the
           replaces header and vice versa*/
        RvSipCallLegGetToHeader(*pCallLeg,&hFrom);
        RvSipCallLegGetFromHeader(*pCallLeg,&hTo);

    }

        RvSipPartyHeaderGetTag(hFrom, (RvChar*)strFromTag, sizeof(strFromTag),&strActLen);
        RvSipPartyHeaderGetTag(hTo, (RvChar*)strToTag, sizeof(strToTag),&strActLen);

    /* place the to-tag and from-tag in the replaces header  */
    rv = RvSipReplacesHeaderSetFromTag(hReplacesHeader, (RvChar*)strFromTag);

    if(rv != RV_OK)
    {
        return rv;
    }

    rv = RvSipReplacesHeaderSetToTag(hReplacesHeader,  (RvChar*)strToTag);

    if(rv != RV_OK)
    {
        return rv;
    }

    /* set the CallId in the replaces header  */
    RvSipCallLegGetCallId(*pCallLeg, sizeof(strCallId), (RvChar*)strCallId, (RvInt32*) &strActLen);
    rv = RvSipReplacesHeaderSetCallID(hReplacesHeader, (RvChar*)strCallId);

    return rv;
}
/***************************************************************************
 * prepareReplacesHeader
 * ------------------------------------------------------------------------
 * General: Construct replaces header and prepare it according to the matched call.
 *          Then, this header will be used for sending the refer message.
 * Return Value: Returns RvStatus.
 * ------------------------------------------------------------------------
 * Arguments:
 * input: hMatchedCall  - handle to the Sip matched call leg
 * output: replacesBuf  - pointer to the allocated replaces buffer which
 *                        contains the replaces header encoding.
 * Return: RvStatus        - RV_OK on successful
 *                        RV_Failure on function failure
 ***************************************************************************/
static RvStatus prepareReplacesHeader(RvSipCallLegHandle hMatchedCall, RV_CHAR **replacesBuf, int *replacesBufSize)
{
    RV_Status                   rv;
    RvSipReplacesHeaderHandle   hReplacesHeader;
    RV_CHAR                     *replacesBuffer = NULL;
    RV_UINT32                   bufSize;
    HPAGE                       hPage, tmpPage;
    RvSipMsgMgrHandle           hMsgMgr;

    /* Get page to start working with */
    rv = RPOOL_GetPage(g_appPool,0,&hPage);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipPrepareReplacesHeader::Failed in RPOOL_GetPage \n"));
        return RV_Failure;
    }
    rv= RvSipStackGetMsgMgrHandle( rvSipControlGetStackHandle(g_sipControl), &hMsgMgr);
    rv = RvSipReplacesHeaderConstruct( hMsgMgr, g_appPool, hPage, &hReplacesHeader);
    rv = prepareReplacesHeaderFromCallLeg(&hMatchedCall, hReplacesHeader);
    /* The encode function get tmp page from the pool internally */
    rv = RvSipReplacesHeaderEncode(hReplacesHeader, g_appPool, &tmpPage, &bufSize);
    if (rv != RV_OK)
    {
        /* Note that there is no need to destruct replaces header
       (though it was constructed) since this header is release when its Page is release */
        /* Free page  */
        RPOOL_FreePage(g_appPool,hPage);
        RvLogError(ippLogSource,(ippLogSource,"rvSipPrepareReplacesHeader::Message encoding failed"));
        return RV_Failure;
    }

    /*allocate a consecutive buffer*/
    rvMtfAllocatorAlloc(bufSize+1, (void**)&replacesBuffer);
    if (replacesBuffer == NULL)
    {
        RPOOL_FreePage(g_appPool,tmpPage);  /* Page of the Encode */
        RPOOL_FreePage(g_appPool,hPage);    /* Page of the construct */
        RvLogError(ippLogSource, (ippLogSource,"rvSipPrepareReplacesHeader:: Failed to allocate memory"));
        return RV_Failure;
    }
    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appPool,
        tmpPage,
        0,
        (void*)replacesBuffer,
        bufSize);
    /*terminate the buffer with null*/
    replacesBuffer[bufSize] = '\0';

    /* Free the tmp Page that was got in RvSipReplacesHeaderEncode function */
    RPOOL_FreePage(g_appPool,tmpPage);  /* Page of the Encode */
    RPOOL_FreePage(g_appPool,hPage);    /* Page of the construct */

    *replacesBuf = replacesBuffer;

    *replacesBufSize = bufSize+1;

    return RV_OK;
}




/***************************************************************************
 * rvSipControlRefer
 * ------------------------------------------------------------------------
 * General: Handle the refer message.
 *          This function sends a refer message.
 * Return Value: Returns RvBool: true in case of success, false otherwise.
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   hCall           - handle of the SIP call leg (call with B)
 *          hMatchedCall    - handle of the SIP call leg (call with C)
 *          to              - string 'to'
 *          from            - string 'from'
 * output:  None
 ***************************************************************************/
RvBool rvSipControlRefer(RvSipCallLegHandle hCall, RvSipCallLegHandle hMatchedCall, char* to, char* from)
{
    RV_CHAR     *replacesBuf;
    RV_Status   rv;
    RvSipCallLegDirection   eDirection;
    int         replacesBufSize;

    char strReferTo[RV_NAME_STR_SZ], strReferredBy[RV_NAME_STR_SZ];

    /* UNUSED since we take it from SIP call-leg*/
    RV_UNUSED_ARG(from);

    if (hMatchedCall != NULL)
    {
        /* get the direction of the call. If it is an outgoing call the refer-to
           uri is taken from the TO header and the referred-by uri is taken
           from the From header.
           If it is an incoming call it is the opposite of the above */

        RvSipCallLegGetDirection(hMatchedCall,&eDirection);

        if (eDirection == RVSIP_CALL_LEG_DIRECTION_OUTGOING)
        {
            /* the 'to' argument contains the most updated destination e.g. in case the call was
               forwarded by the original destination to another one. */
            RvSnprintf(strReferTo,sizeof(strReferTo), to);
            getHeaderSipUriFromCallLeg(hMatchedCall, strReferredBy, RV_NAME_STR_SZ, RVSIP_HEADERTYPE_FROM);
        }
        else
        {
            getHeaderSipUriFromCallLeg(hMatchedCall, strReferredBy, RV_NAME_STR_SZ, RVSIP_HEADERTYPE_TO);
            /* an incoming call my not be fully identified by the from header (no ip address),
               therefore we use the contact header for full destination identification */
            getHeaderSipUriFromCallLeg(hMatchedCall, strReferTo, RV_NAME_STR_SZ, RVSIP_HEADERTYPE_CONTACT);
        }
    }
    else
    {
            /*  hMatchedCall == NULL,  this is blind or semi attended transfer. */
            RvSnprintf(strReferTo,sizeof(strReferTo), to);

            RvSipCallLegGetDirection(hCall,&eDirection);

            /* Get Referred-by header from SIP call-leg From header if it's outgoing call, and To header if incoming call */
            if (eDirection == RVSIP_CALL_LEG_DIRECTION_OUTGOING)
            {
                getHeaderSipUriFromCallLeg(hCall, strReferredBy, RV_NAME_STR_SZ, RVSIP_HEADERTYPE_FROM);
            }
            else
            {
                getHeaderSipUriFromCallLeg(hCall, strReferredBy, RV_NAME_STR_SZ, RVSIP_HEADERTYPE_TO);
            }


    }/* end of  hMatchedCall == NULL */

    RvLogInfo(ippLogSource,(ippLogSource,"Sending REFER for call-leg %p, Referred-By: %s Refer-To:%s", hCall, strReferredBy, strReferTo));



    /* Transfer feature */
    /* hMatchedCall = NULL indicates that there is no active call with 'C',
        as in blind and semi attended transfer */
    if (hMatchedCall == NULL)
    {
        if ((rv = RvSipCallLegReferStr (hCall, strReferTo, strReferredBy,NULL)) != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"Failed to Send REFER for call-leg %p", hCall));
        }
    }
    else /* There is a matchedCall */
    {
        if((rv = prepareReplacesHeader(hMatchedCall, &replacesBuf, &replacesBufSize)) == RV_OK)
        {
            rv = RvSipCallLegReferStr(hCall, strReferTo, strReferredBy, replacesBuf);
            rvMtfAllocatorDealloc(replacesBuf, replacesBufSize);
        }
    }

    return (rv == RV_OK);
}



static RvStatus setContentType(RvSipMsgHandle hMsg)
{
    RvSipBodyHandle hBody;
    RvSipContentTypeHeaderHandle hContentType;
    RvStatus rv;

    hBody = RvSipMsgGetBodyObject(hMsg);
    RvSipContentTypeHeaderConstructInBody(hBody, &hContentType);
    if ((rv = RvSipContentTypeHeaderSetMediaType(hContentType, RVSIP_MEDIATYPE_APPLICATION, NULL)) == RV_OK)
    {
        if ((rv = RvSipContentTypeHeaderSetMediaSubType(hContentType, RVSIP_MEDIASUBTYPE_SDP, NULL)) == RV_OK)
            return RV_OK;
    }

    return RV_ERROR_UNKNOWN;
}

RvStatus rvSipControlMsgSetBody(RvSipMsgHandle hMsg, const RvSdpMsg* sdpMsg)
{
    RvSdpStatus stat=0;
    char    buf[2048];
    RvStatus rv;

    if (((rvSdpMsgEncodeToBuf((RvSdpMsg*)sdpMsg, buf, sizeof(buf), &stat)) != NULL) &&
		(stat == RV_SDPSTATUS_OK))
    {
        if ((rv = RvSipMsgSetBody(hMsg, buf)) == RV_OK)
        {
            /*This function also updates the "Content-length" field in the message*/
            if ((rv = setContentType(hMsg)) == RV_OK)
                return RV_OK;
        }
    }

    return RV_ERROR_UNKNOWN;
}

RvStatus rvSipControlGetToAddressByMessage(RvSipMsgHandle hSipMsg, char *address)
{
    RvSipPartyHeaderHandle hTo = RvSipMsgGetToHeader(hSipMsg);

    return getToHeader(hTo, address);
}

RvBool rvSipControlMsgGetReferredAddress(RvSipMsgHandle hMsg, char* address)
{
    RvSipHeaderListElemHandle   hListElem;
    RvSipAddressHandle          hAddress;
    unsigned int len;

    RvSipReferredByHeaderHandle hReferredBy = RvSipMsgGetHeaderByType(hMsg,
                                 RVSIP_HEADERTYPE_REFERRED_BY,
                                 RVSIP_FIRST_HEADER,
                                 &hListElem);

    if (hReferredBy != NULL)
    {
        hAddress = RvSipReferredByHeaderGetAddrSpec(hReferredBy);
        RvSipAddrUrlGetHost(hAddress, address, RV_SIPCTRL_ADDRESS_SIZE, &len);
        return RV_TRUE;
    }
    else
    {
        return RV_FALSE;
    }
}


/*This function sends BYE or CANCEL and terminates the call-leg object,
  so the stack will ignore any incoming events for thsi object*/
void rvSipControlTerminate(RvSipCallLegHandle hCall)
{
    rvSipControlReject(hCall, RV_SIPCTRL_STATUS_SERVICEUNAVAIL); /*Disconnect or Cancel according to the right state*/
    RvSipCallLegTerminate(hCall); /*Release this object in the stack*/
}


/***************************************************************************
 * rvSipControlRegisterClient
 * ------------------------------------------------------------------------
 * General: Register client (terminal) to Sip Server/Proxy.
 *          Handle appropriate timer of the terminal.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 *          sipTerm -     pointer to the client (Terminal) which is going to
 *                        register.
 ***************************************************************************/
RvBool rvSipControlRegisterClient( RvCCTerminalSip*  sipTerm)
{
    RvSipRegClientHandle    hRegClient  = rvCCTerminalSipGetRegClientObject(sipTerm);
    RvInt32                 nExpire     = (RvInt32)sipTerm->registerExpires;
    RvBool                  res         = rvTrue;
    RvStatus                status      = RV_OK;
    const char              *regAddr    = rvCCTerminalSipGetRegistrarAddress(sipTerm);

    if ((regAddr != NULL) && (strcmp(regAddr, "")))
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Registering Client: %s \n", sipTerm->terminalId));
        status = rvSipControlRegClientSetExpire(hRegClient, nExpire);
		rvCCTerminalSipSetAuthRetriesCount(sipTerm, 0);
        if(status!=RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlRegisterClient rvSipControlRegClientSetExpire fail error -> %d", status));
            res=rvFalse;
        }
        status = rvSipControlRegClientSend(hRegClient);
        if (status != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlRegisterClient failed to send Register message -> %p", hRegClient));
            res = rvFalse;
        }

        /* start timer to Re register*/
        status = IppTimerStart(&sipTerm->registerTimer, IPP_TIMER_RESTART_IF_STARTED, rvCCTerminalSipGetRegisterTimeout(sipTerm)/2);
        if(status!=RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlRegisterClient::IppTimerStart failed"));
            res=rvFalse;
        }
    }
	else
	/* no registrar address */
	{
		res = RV_FALSE;
	}

    return res;
}



/***************************************************************************
 * rvSipControlUnregisterClient
 * ------------------------------------------------------------------------
 * General: Unregister client (terminal) from Sip Server/Proxy.
 *          Handle appropriate timer of the terminal.
 * Return Value: RV_OK if Unregistration message was sent
 *                     or the Proxy is not configured
 * ------------------------------------------------------------------------
 * Arguments:
 *          sipTerm -     pointer to the client (Terminal) which is going to
 *                        unregister.
 ***************************************************************************/
RvBool rvSipControlUnregisterClient(RvCCTerminalSip*    sipTerm)
{
    RvSipRegClientHandle    hRegClient= rvCCTerminalSipGetRegClientObject(sipTerm);
    RvBool res = rvTrue;
    const char              *regAddr   = rvCCTerminalSipGetRegistrarAddress(sipTerm);

    if ((regAddr != NULL) && (strcmp(regAddr, "")))
    {
        RvLogInfo(ippLogSource,(ippLogSource,"Unregistering Client: %s \n", sipTerm->terminalId));
        /* let's convert Registration Client Object into Unregistration one */
        rvSipControlRegClientSetExpire(hRegClient, (RvInt32)0);
        if (rvSipControlRegClientSend(hRegClient) != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"SIPCTRL:: Failed to send Unregister message -> %p", hRegClient));
            res = rvFalse;
        }
    }

    return res;
}

void rvSipControlSetRegistrarAddress(RvSipControl* x, char* registrarAddress)
{
    strncpy(x->registrarAddress, registrarAddress, sizeof(x->registrarAddress)-1);
    x->registrarAddress[sizeof(x->registrarAddress)-1] = '\0';
}

/***************************************************************************
 * rvSipControlSetContact
 * ------------------------------------------------------------------------
 * General: copy contact string to RvSipControl object.
 *
 * Return Value: none
 *
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x          -  pointer to Sip control object
 *          contact    -  contact string
 *
 ***************************************************************************/
void rvSipControlSetContact(RvSipControl* x, char* contact)
{
    strncpy(x->contact, contact, sizeof(x->contact)-1);
    x->contact[sizeof(x->contact)-1] = '\0';
}

/***************************************************************************
 * rvSipControlIsMediaBody
 * ------------------------------------------------------------------------
 * General:  check if a message body is application/sdp
 * Return Value: RV_TRUE - body is media. RV_FALSE body is other type
 * ------------------------------------------------------------------------
 * Arguments:
 * input  hMsg
 ***************************************************************************/
RvBool rvSipControlIsMediaBody(IN RvSipMsgHandle hMsg)
{
    RvSipContentTypeHeaderHandle    hContentType = NULL;
	RvSipBodyHandle                 hBody = NULL;

    hBody = RvSipMsgGetBodyObject(hMsg);

	if (hBody == NULL)
	{
		return RV_FALSE;
	}

    hContentType = RvSipBodyGetContentType(hBody);
    if (NULL == hContentType)
    {
        return RV_FALSE;
    }

    if ( (RVSIP_MEDIATYPE_APPLICATION != RvSipContentTypeHeaderGetMediaType(hContentType)) ||
         (RVSIP_MEDIASUBTYPE_SDP != RvSipContentTypeHeaderGetMediaSubType(hContentType)) )
    {
        /*zxs changed */
        if((RVSIP_MEDIATYPE_MULTIPART == RvSipContentTypeHeaderGetMediaType(hContentType) )&&
            (RVSIP_MEDIASUBTYPE_MIXED == RvSipContentTypeHeaderGetMediaSubType(hContentType)))
        {
            RvSipBodyPartHandle hBodyPart;
            RvUint32 length;
            RvChar *strBody;
            RvStatus rv;

            RvLogInfo(ippLogSource,(ippLogSource,"######rvSipControlIsMediaBody(multipart, mixed) "));
 
            /*Gets the body string from the body object.*/
            length = RvSipBodyGetBodyStrLength(hBody);
            strBody = malloc((length)*sizeof(RvChar));
            rv = RvSipBodyGetBodyStr(hBody, strBody, length, &length);
            if (RV_OK != rv)
            {
                free(strBody);
                goto no_sdp;
            }
            /*Parse the body string.*/
            rv = RvSipBodyMultipartParse(hBody, strBody, length);
            if (RV_OK != rv)
            {
            
                free(strBody);
                goto no_sdp;
            }
            free(strBody);
            /*Views the list of body parts.*/
            rv = RvSipBodyGetBodyPart(hBody, RVSIP_FIRST_ELEMENT, NULL, &hBodyPart);
            if (RV_OK != rv)
            {
                goto no_sdp;
            }
            while (NULL != hBodyPart)
            {   
                BodyPart* pBodyPart = (BodyPart* )hBodyPart;
                hContentType = RvSipBodyGetContentType((RvSipBodyHandle)pBodyPart->pBody);
                if((RVSIP_MEDIATYPE_APPLICATION == RvSipContentTypeHeaderGetMediaType(hContentType)) &&
                    (RVSIP_MEDIASUBTYPE_SDP == RvSipContentTypeHeaderGetMediaSubType(hContentType)) )
                    return RV_TRUE;
                
                /*Gets the next body part in the list.*/
                rv = RvSipBodyGetBodyPart(hBody, RVSIP_NEXT_ELEMENT, hBodyPart,&hBodyPart);
                if (RV_OK != rv)
                {
                    goto no_sdp;
                }
            }
            
            no_sdp:
                RvLogInfo(ippLogSource,(ippLogSource,"######rvSipControlIsMediaBody(no sdp) "));
                return RV_FALSE;

        }
        else     
        return RV_FALSE;
    }
    return RV_TRUE;
}

RvBool rvSipControlIsAddressEmpty(IN RvChar* address)
{
    return (
        (address == NULL)  ||
        (strcmp(address, "") == 0) ||
        (strcmp(address,"0.0.0.0") == 0) ||
        (strcmp(address,"000.000.000.000") == 0)
    );
}


/***************************************************************************
 * rvSipControlGetCallLegNonce
 * ------------------------------------------------------------------------
 * General: get the nonce field from the authentication header
 *
 *
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   authHeader  - Handle to an authentication header
 *          nonce       - nonce buffer
 *
 ***************************************************************************/
RvStatus rvSipControlGetNonceFromAuthHeader(IN RvSipAuthenticationHeaderHandle authHeader,OUT char* nonce)
{
    RvStatus                        rv          = RV_OK;
    RvUint                          actualLen   = 0;
    RvUint                          strLen      = 0;


    if (nonce == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlGetNonceFromAuthHeader:: nonce=NULL "));
        return RV_ERROR_BADPARAM;
    }

    strLen = RvSipAuthenticationHeaderGetStringLength(authHeader,RVSIP_AUTHENTICATION_NONCE);
    rv = RvSipAuthenticationHeaderGetNonce(authHeader,nonce,strLen,&actualLen);

    return rv;
} /* rvSipControlGetNonceFromAuthHeader */


RvStatus rvSipControlSetTransportType(RvSipAddressHandle        hAddress,
                                        RvSipTransport          transportType)
{
	RvSipAddressType addrType = RvSipAddrGetAddrType(hAddress);

    if ((addrType != RVSIP_ADDRTYPE_TEL) &&      /* transport type shouldn't be added to tel uri */
		(transportType != RVSIP_TRANSPORT_UNDEFINED) &&
        (transportType != RVSIP_TRANSPORT_UDP))
    {
        return RvSipAddrUrlSetTransport(hAddress, transportType, 0);
    }

    return RV_OK;
}

#ifdef RV_CFLAG_TLS
/***************************************************************************
 * rvSipControlGetRegistrarTlsPort
 * ------------------------------------------------------------------------
 * General: Returns the number of the port which the outbound Proxy uses for a
 *			TLS connection.
 *
 *
 * Return Value: RvUint16
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    - pointer to RvSipControl object
 *
 ***************************************************************************/
RvUint16 rvSipControlGetRegistrarTlsPort(IN RvSipControl* x)
{
	return (RvUint16)(x->registrarTlsPort==0 ? RVSIPCTRL_DEFAULT_PORT + 1 : x->registrarTlsPort);
}
#endif /* RV_CFLAG_TLS */

#ifdef RV_SIP_IMS_ON
/***************************************************************************
 * rvSipControlGetIpSecPortC
 * ------------------------------------------------------------------------
 * General: Returns the number of the port as client port for IPSec
 *			connection
 *
 *
 * Return Value: RvUint16
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    - pointer to RvSipControl object
 *
 ***************************************************************************/
RvUint16 rvSipControlGetIpSecPortC(IN RvSipControl* x)
{
	return (RvUint16)(x->imsControl.ipsecPortC==0 ? RVSIPCTRL_DEFAULT_PORT + 3 : x->imsControl.ipsecPortC);
}

/***************************************************************************
 * rvSipControlGetIpSecPortS
 * ------------------------------------------------------------------------
 * General: Returns the number of the port as server port for IPSec
 *			connection
 *
 *
 * Return Value: RvUint16
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    - pointer to RvSipControl object
 *
 ***************************************************************************/
RvUint16 rvSipControlGetIpSecPortS(IN RvSipControl* x)
{
	return (RvUint16)(x->imsControl.ipsecPortS==0 ? RVSIPCTRL_DEFAULT_PORT + 5 : x->imsControl.ipsecPortS);
}

#endif




















