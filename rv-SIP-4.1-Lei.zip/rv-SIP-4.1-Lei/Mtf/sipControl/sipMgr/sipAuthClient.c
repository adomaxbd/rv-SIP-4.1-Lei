/*********************************************************************************
 *                              <sipAuthClient.c>
 *   This file gives a complete example of how to:
 *   Initiate the RADVISION SIP stack.
 *   Register application callbacks.
 *   Implement application callback.
 *   Initiate an outgoing call.
 *   Accept an incoming call.
 *   Authenticate the INVITE request.
 *   Disconnect the call.
 *   You can run this application as is.
 *   In this example the stack call itself (two call-legs are created) under the
 *   same stack. In order to call remote machine you should change the TO address
 *   defined bellow.
 *   Notice that the application exits on errors.
 *    Author                         Date
 *    ------                        ------
 *    Sarit Mekler + Oren Libis      Mar 2001
 *
 *	  Revisions
 *	  ---------
 *	  Yochi Moran					 October 2002
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#define LOGSRC	LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "rvccterminalsip.h"
#include "rvccconnsip.h"
#include "RvSipCallLegTypes.h"
#include "RvSipAuthenticator.h"
#include "md5c.h"
#include "rvansi.h"
#include "sipphone.h"
#include "SubsObject.h"

#ifdef RV_MTF_SIMPLE_ON
/* For SIMPLE client co-existence only */
#include "RvSimpleCltCommonTypes.h"
#include "RvSimpleCltPuaEvents.h"
#include "mtfBaseInt.h"
#endif  /* RV_MTF_SIMPLE_ON */

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/* Define username and password for the authentication process */
#define USERNAME	"username"
#define PASSWORD	"password"

extern RvSipControl* g_sipControl;

/*-----------------------------------------------------------------------*/
/*                      PRIVATE		FUNCTIONS		                     */
/*-----------------------------------------------------------------------*/

#ifdef RV_MTF_SIMPLE_ON

/******************************************************************************
 * GetPuaFromAuthenticator
 * ----------------------------------------------------------------------------
 * General: Retrieves the PUA handle from the Authenticator object
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator  - Handle to the Authenticator object
 * Output:  phPua           - Pointer to the PUA
 ***************************************************************************/
static RvStatus RVCALLCONV GetPuaFromAuthenticator(
                                   IN    RvSipAuthenticatorHandle     hAuthenticator,
                                   OUT   RvSimpleCltPuaHandle        *phPua)
{
	RvSipStackHandle	hSipStack;
	RvMtfHandle			hMtf;
	RvMtfBaseMgr*		mtfMgr;
	RvStatus			rv;

	/* Get the SIP stack handle */
	rv = RvSipAuthenticatorGetStackInstance(hAuthenticator, (void**)&hSipStack);
	if (RV_OK != rv)
	{
		return rv;
	}

	/* Get application handle from the stack, which is handle to MTF */
	rv = RvSipStackGetAppHandle(hSipStack, (RvSipAppStackHandle*)&hMtf);

	if (RV_OK != rv)
	{
		return rv;
	}

	mtfMgr = (RvMtfBaseMgr*)hMtf;

	/* MTF handle holds a pointer to the SIMPLE client */
	*phPua = mtfMgr->hSimplePua;

	if (*phPua == NULL)
	{
		return RV_ERROR_NOT_FOUND;
	}

	return RV_OK;
}

/******************************************************************************
 * isSimpleClientObject
 * ----------------------------------------------------------------------------
 * General: This function checks whether the Authenticator object is a SIMPLE object.
 *
 * Return Value: True if object is SIMPLE object, False if not.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator  - Handle to the Authenticator object.
 *			hObject			- handle to the stack object associated with the Authenticator object.
 *			peObjectType    - Object type
 *
 * Output:  eSimpleObjType - the SIMPLE object type.
 ***************************************************************************/
static RvBool isSimpleClientObject(
							IN    RvSipAuthenticatorHandle       hAuthenticator,
							IN    void*                          hObject,
							IN    void*                          peObjectType,
							OUT   RvSimpleCltCommonObjectType*   eSimpleObjType)
{

	RvSipCommonStackObjectType   eStackObj = *(RvSipCommonStackObjectType*)peObjectType;
	RvSimpleCltPuaHandle		 hPua;
	RvStatus					 rv;

	*eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;

	/* Retrieve the PUA handle from the authenticator */
	rv = GetPuaFromAuthenticator(hAuthenticator, &hPua);
	if (RV_OK != rv)
	{
		RvLogError(ippLogSource,(ippLogSource,"isSimpleClientObject - failed to get PUA from Authentication header 0x%p",
				                      hAuthenticator));
		return RV_FALSE;
	}

	/* Check if the SIP Stack object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, hObject, eStackObj,
										eSimpleObjType);
	if (*eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return RV_FALSE;
	}

	return RV_TRUE;
}

#endif /* RV_MTF_SIMPLE_ON */
/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/


/***************************************************************************
 * AppAuthenticationMD5Ev
 * ------------------------------------------------------------------------
 * General:  Notifies that there is a need to use the MD5 algorithm.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	pRpoolMD5Input  - Rpool pointer to the MD5 input
 *          length          - the length of the string inside the page
 * Output: 	pRpoolMD5Output - Rpool pointer to the MD5 output
 ***************************************************************************/
void RVCALLCONV AppAuthenticationMD5Ev(IN  RPOOL_Ptr                     *pRpoolMD5Input,
                                              IN  RV_UINT32                     length,
                                              OUT RPOOL_Ptr                     *pRpoolMD5Output)
{
    RV_CHAR strDigest[1024];
    RV_CHAR strResponse[33];
    RV_BYTE digest[20];
    MD5_CTX mdc;

    /* The string for the md5 is on a page. first we copy it to
	   a consecutive buffer.*/
    RPOOL_CopyToExternal(pRpoolMD5Input->hPool,
                         pRpoolMD5Input->hPage,
                         pRpoolMD5Input->offset,
                         (void*)strDigest,
                         length);

    /* implementation of the MD5 algorithm - we give the string to the MD5*/
	MD5Init(&mdc);
	MD5Update(&mdc, (RV_BYTE *)strDigest,(unsigned int)strlen(strDigest));
	MD5Final(digest, &mdc);
    MD5toString(digest, strResponse);

	/*after we have a result we must copy it back to the page*/
    RPOOL_AppendFromExternalToPage(pRpoolMD5Output->hPool,
                                   pRpoolMD5Output->hPage,
                                   (void*)strResponse,
                                   (RvInt)strlen(strResponse) + 1,
                                   &(pRpoolMD5Output->offset));

}


/***************************************************************************
 * AppAuthenticationSharedSecretEv
 * ------------------------------------------------------------------------
 * General:  set the username and password.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	hRequestUri      - handle to the request uri
 *          pRpoolRealm      - the realm string in RPool_Ptr format
 * Output: 	pRpoolUserName   - the username string in RPool_ptr format
 *          pRpoolPassword   - the password string in RPool_ptr format
 ***************************************************************************/
void RVCALLCONV AppAuthenticationSharedSecretEv(
                                   IN  RvSipAddressHandle            hRequestUri,
                                   IN  RPOOL_Ptr                     *pRpoolRealm,
                                   OUT RPOOL_Ptr                     *pRpoolUserName,
                                   OUT RPOOL_Ptr                     *pRpoolPassword)
{
	RV_UNUSED_ARG(hRequestUri);
	RV_UNUSED_ARG(pRpoolRealm);

	/*copy the username + '\0' to the given page*/
    RPOOL_AppendFromExternalToPage(pRpoolUserName->hPool,
                                   pRpoolUserName->hPage,
                                   (void*)USERNAME,
                                   (RvInt)strlen(USERNAME) + 1,
                                   &(pRpoolUserName->offset));

	/*copy the password + '\0' to the given page*/
    RPOOL_AppendFromExternalToPage(pRpoolPassword->hPool,
                                   pRpoolPassword->hPage,
                                   (void*)PASSWORD,
                                   (RvInt)strlen(PASSWORD) + 1,
                                   &(pRpoolPassword->offset));
}

/***************************************************************************
* AppAuthenticatorGetSharedSecretEv
* ------------------------------------------------------------------------
* General:  Notifies that there is a need for the username and password.
*           This callback function is for client side authentication.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input: 	hAuthenticator    - Handle to the authenticator object.
 *          hAppAuthenticator - Handle to the application authenticator.
*          hObject           - Handle to the Object, that is served
*                              by the Authenticator (e.g. CallLeg, RegClient)
*          peObjectType      - pointer to the variable, that stores the
*                              type of the hObject.
*                              Use following code to get the type:
*                              RvSipCommonStackObjectType eObjType = *peObjectType;
*          pRpoolRealm       - the realm string in RPool_ptr format
* Output: 	pRpoolUserName    - the username string in RPool_ptr format
 *                              (this is an OUT parameter for client, and IN
 *                              parameter for server).
*          pRpoolPassword    - the password string in RPool_ptr format
***************************************************************************/
void RVCALLCONV AppAuthenticatorGetSharedSecretEv(
												  IN  RvSipAuthenticatorHandle       hAuthenticator,
												  IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
												  IN  void*                          hObject,
												  IN  void*                          peObjectType,
												  IN  RPOOL_Ptr                     *pRpoolRealm,
												  OUT RPOOL_Ptr                     *pRpoolUserName,
												  OUT RPOOL_Ptr                     *pRpoolPassword)
{
	RvCCTerminal*              xTerm    = NULL;
	RvCCTerminalSip*           term     = NULL;
	char*                      username = NULL;
	char*                      password = NULL;
	RvSipCommonStackObjectType *eObjType =  peObjectType;

#ifdef RV_MTF_SIMPLE_ON

	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSipCommonStackObjectType   eStackObj = *(RvSipCommonStackObjectType*)peObjectType;
	RvSimpleCltPuaHandle   hPua;
	RvStatus               rv;

	/* Retrieve the PUA handle from the authenticator */
	rv = GetPuaFromAuthenticator(hAuthenticator, &hPua);
	if (RV_OK == rv)
	{
		/* Check if the SIP Stack object is related to a SIMPLE PUA object */
		RvSimpleCltPuaIsRelatedObjEvHandler(hPua, hObject, eStackObj,&eSimpleObjType);

		if (eSimpleObjType != RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
		{
		/* Invoke the event in the PUA */
			RvSimpleCltPuaAuthGetSharedSecretEvHandler(hPua, hAuthenticator, eSimpleObjType, hObject, peObjectType,
													   pRpoolRealm, pRpoolUserName, pRpoolPassword);
			return;
		}
	}
#endif /* RV_MTF_SIMPLE_ON */

/* The event is not intended for the SIMPLE application, continue with this proc */
	RV_UNUSED_ARG(hAuthenticator);
	RV_UNUSED_ARG(hAppAuthenticator);
	RV_UNUSED_ARG(pRpoolRealm);

	/* If the requesting object is Reg Client or CallLeg get the user name and password 
	   from the terminal object.
	   In other cases (e.g. Subscribe for MWI) use the default username and password. */

	if (*eObjType == RVSIP_COMMON_STACK_OBJECT_TYPE_REG_CLIENT)
	{
		RvSipAppRegClientHandle         hAppRegClient;

		/* Get the terminal from the hAppRegClient */
		RvSipRegClientGetAppHandle ((RvSipRegClientHandle)hObject, &hAppRegClient);
		xTerm   = (RvCCTerminal*)hAppRegClient;
	}
	else
	if (*eObjType == RVSIP_COMMON_STACK_OBJECT_TYPE_CALL_LEG)
	{
		RvSipAppCallLegHandle         hAppCallLeg;
		/* Get the terminal from the sip connection which is stored in the hAppCallLeg */
		RvSipCallLegGetAppHandle ((RvSipCallLegHandle)hObject, &hAppCallLeg);
		xTerm   = rvCCConnSipGetTerminal((RvCCConnection*)hAppCallLeg);
	}
#ifdef  USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2012/01/05 */
	else
	if (*eObjType == RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION)
	{
		username = SubsHandleGetUsername(hObject);
		password = SubsHandleGetPassword(hObject);
	}	
#endif
	if (xTerm != NULL)
	{		
		term     = rvCCTerminalSipGetImpl(xTerm);
		username = rvCCTerminalSipGetUsername(term);
		password = rvCCTerminalSipGetPassword(term);
	}

	/*If username & password of this termination are empty, use the general ones.*/
	if (rvSipControlIsNameEmpty(username))
		username = rvSipControlGetUsername(g_sipControl);

	if (rvSipControlIsNameEmpty(password))
		password = rvSipControlGetPassword(g_sipControl);

	/*copy the username + '\0' to the given page*/
	RPOOL_AppendFromExternalToPage(pRpoolUserName->hPool,
		pRpoolUserName->hPage,
		(void*)username,
		(RvInt)strlen(username) + 1,
		&(pRpoolUserName->offset));

	/*copy the password + '\0' to the given page*/
	RPOOL_AppendFromExternalToPage(pRpoolPassword->hPool,
		pRpoolPassword->hPage,
		(void*)password,
		(RvInt)strlen(password) + 1,
		&(pRpoolPassword->offset));
}

#ifdef RV_MTF_SIMPLE_ON

/***************************************************************************
 * AppAuthenticatorMD5ExEv
 * ------------------------------------------------------------------------
 * General:  Notifies that there is a need to use the MD5 algorithm.
 *           The MD5 event is a global event that is not related to a callback.
 *           Also, the handling of this event is the same for all applications,
 *           therefore we use it for all object types including SIMPLE objects.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator    - Handle to the authenticator object.
 *          hAppAuthenticator - Handle to the application authenticator handle.
 *          pRpoolMD5Input	  - Rpool pointer to the MD5 input
 *          length			  - length of the string inside the page
 * Output:  strMd5Output      - The output of the hash algorithm
 ***************************************************************************/
void RVCALLCONV AppAuthenticatorMD5ExEv(
                                   IN  RvSipAuthenticatorHandle       hAuthenticator,
                                   IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                   IN  RPOOL_Ptr                     *pRpoolMD5Input,
                                   IN  RvUint32                       length,
                                   OUT RPOOL_Ptr                     *pRpoolMD5Output)
{
	RV_CHAR strDigest[1024];
    RV_CHAR strResponse[33];
    RV_BYTE digest[20];
    MD5_CTX mdc;

	RV_UNUSED_ARG(hAuthenticator);
	RV_UNUSED_ARG(hAppAuthenticator);

    /* The string for the md5 is on a page. first we copy it to
	   a consecutive buffer.*/
    RPOOL_CopyToExternal(pRpoolMD5Input->hPool,
                         pRpoolMD5Input->hPage,
                         pRpoolMD5Input->offset,
                         (void*)strDigest,
                         length);

    /* implementation of the MD5 algorithm - we give the string to the MD5*/
	MD5Init(&mdc);
	MD5Update(&mdc, (RV_BYTE *)strDigest,strlen(strDigest));
	MD5Final(digest, &mdc);
    MD5toString(digest, strResponse);

	/*after we have a result we must copy it back to the page*/
    RPOOL_AppendFromExternalToPage(pRpoolMD5Output->hPool,
                                   pRpoolMD5Output->hPage,
                                   (void*)strResponse,
                                   strlen(strResponse) + 1,
                                   &(pRpoolMD5Output->offset));


}


/***************************************************************************
 * AppAuthenticatorMD5EntityBodyEv
 * ------------------------------------------------------------------------
 * General: Checks if the given SIP stack object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator    - handle to the Authenticator object
 *          hAppAuthenticator - Handle to the application authenticator.
 *          hObject           - Handle to the Object, that is served
 *                              by the Authenticator (e.g. CallLeg, RegClient)
 *          peObjectType      - Pointer to the variable, that stores the
 *                              type of the hObject.
 *                              Use following code to get the type:
 *                              RvSipCommonStackObjectType eObjType = *peObjectType;
 *          hMsg              - Handle to the message that it is now beeing sent
 *                              and that will include the user credentials.
 * Output:  pRpoolMD5Output   - The MD5 of the message body in RPOOL_Ptr format.
 *          pLength           - length of the string after MD5 result
 *                              concatenation.
 ***************************************************************************/
void RVCALLCONV AppAuthenticatorMD5EntityBodyEv(
                       IN     RvSipAuthenticatorHandle      hAuthenticator,
                       IN     RvSipAppAuthenticatorHandle   hAppAuthenticator,
                       IN     void*                         hObject,
                       IN     void*                         peObjectType,
                       IN     RvSipMsgHandle                hMsg,
                       OUT    RPOOL_Ptr                     *pRpoolMD5Output,
                       OUT    RvUint32                      *pLength)
{
	RvSimpleCltCommonObjectType   eSimpleObjType;

	RV_UNUSED_ARG(hAppAuthenticator);

	/* If this object is SIMPLE object, route it to the SIMPLE client toolkit since MTF shouldn't handle it. */
	if (isSimpleClientObject(hAuthenticator, hObject, peObjectType, &eSimpleObjType) == RV_TRUE)
	{
		RvSimpleCltPuaHandle   hPua;
		RvStatus               rv;

		/* Retrieve the PUA handle from the authenticator */
		rv = GetPuaFromAuthenticator(hAuthenticator, &hPua);
		if (RV_OK != rv)
		{
			return;
		}

		RvLogDebug(ippLogSource,(ippLogSource,"AppAuthenticatorMD5EntityBodyEv - Authentication object is related to SIMPLE client = 0x%p",
			hAuthenticator));

		/* Invoke the event in the PUA */
		RvSimpleCltPuaAuthMD5EntityBodyEvHandler(hPua, hAuthenticator, eSimpleObjType,
			hObject, peObjectType, hMsg, pRpoolMD5Output, pLength);

	}
}

/******************************************************************************
 * AppAuthenticatorUnsupportedChallengeEv
 * ----------------------------------------------------------------------------
 * General: Checks if the given SIP stack object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator        - Handle to the Authenticator object
 *          hAppAuthenticator     - Application handle stored in Authenticator.
 *          hObject               - Handle to the Object, that is served
 *                                  by the Authenticator(e.g.CallLeg,RegClient)
 *          peObjectType          - Pointer to the variable that stores
 *                                  the type of the hObject.
 *                                  Use following code to get the type:
 *                                  RvSipCommonStackObjectType eObjType = *peObjectType;
 *          hAuthenticationHeader - Handle to the Authentication header,
 *                                  containing unsupported challenge.
 *          hMsg                  - Handle to the message where the Application
 *                                  should set the credentials, if it wants.
 * Output:  none.
 ***************************************************************************/
void RVCALLCONV AppAuthenticatorUnsupportedChallengeEv(
                    IN RvSipAuthenticatorHandle         hAuthenticator,
                    IN RvSipAppAuthenticatorHandle      hAppAuthenticator,
                    IN void*                            hObject,
                    IN void*                            peObjectType,
                    IN RvSipAuthenticationHeaderHandle  hAuthenticationHeader,
                    IN RvSipMsgHandle                   hMsg)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSipCommonStackObjectType   eStackObj = *(RvSipCommonStackObjectType*)peObjectType;
	RvSimpleCltPuaHandle		 hPua;
	RvStatus					 rv;

	RV_UNUSED_ARG(hAppAuthenticator);

	/* Retrieve the PUA handle from the authenticator */
	rv = GetPuaFromAuthenticator(hAuthenticator, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the SIP Stack object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, hObject, eStackObj,
									    &eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaAuthUnsupportedChallengeEvHandler(hPua, hAuthenticator, eSimpleObjType,
												    hObject, peObjectType,
												    hAuthenticationHeader, hMsg);
}

/******************************************************************************
 * AppAuthenticatorNonceCountUsageEv
 * ----------------------------------------------------------------------------
 * General: Checks if the given SIP stack object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator        - Handle to the Authenticator object
 *          hAppAuthenticator     - Application handle stored in Authenticator.
 *          hObject               - Handle to the Object, that is served
 *                                  by the Authenticator(e.g.CallLeg,RegClient)
 *          peObjectType          - Pointer to the variable that stores
 *                                  the type of the hObject.
 *                                  Use following code to get the type:
 *                                  RvSipCommonStackObjectType eObjType = *peObjectType;
 *          hAuthenticationHeader - Handle to the Authentication header,
 *                                  containing challenge, credentials for which
 *                                  are being prepared.
 *          pNonceCount           - pointer to the nonceCount value, managed by
 *                                  the Stack per Challenge.
 * Output:  pNonceCount           - pointer to the nonceCount value, set by
 *                                  the Application in order to be used by
 *                                  the Stack for Credentials calculation.
 ***************************************************************************/
void RVCALLCONV AppAuthenticatorNonceCountUsageEv(
                   IN    RvSipAuthenticatorHandle        hAuthenticator,
                   IN    RvSipAppAuthenticatorHandle     hAppAuthenticator,
                   IN    void*                           hObject,
                   IN    void*                           peObjectType,
                   IN    RvSipAuthenticationHeaderHandle hAuthenticationHeader,
                   INOUT RvInt32*                        pNonceCount)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSipCommonStackObjectType   eStackObj = *(RvSipCommonStackObjectType*)peObjectType;
	RvSimpleCltPuaHandle		 hPua;
	RvStatus					 rv;

	RV_UNUSED_ARG(hAppAuthenticator);

	/* Retrieve the PUA handle from the authenticator */
	rv = GetPuaFromAuthenticator(hAuthenticator, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the SIP Stack object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, hObject, eStackObj,
									    &eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaAuthNonceCountUsageEvHandler(hPua, hAuthenticator, eSimpleObjType,
										       hObject, peObjectType,
										       hAuthenticationHeader, pNonceCount);

}

/******************************************************************************
 * AppAuthenticatorAuthorizationReadyEv
 * ----------------------------------------------------------------------------
 * General: Checks if the given SIP stack object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator        - Handle to the Authenticator object
 *          hAppAuthenticator     - Application handle stored in Authenticator.
 *          hObject               - Handle to the Object, that is served
 *                                  by the Authenticator(e.g.CallLeg,RegClient)
 *          peObjectType          - Pointer to the variable that stores
 *                                  the type of the hObject.
 *                                  Use following code to get the type:
 *                                  RvSipCommonStackObjectType eObjType = *peObjectType;
 *          RvSipAuthObjHandle    - Handle to the auth-object, related to this
 *                                  new authorization header.
 *          pAuthObjContext       - Context of application of the related auth-object.
 *          hAuthorizationHeader  - The already filled authorization header.
 * Output:  none.
 ***************************************************************************/
void RVCALLCONV AppAuthenticatorAuthorizationReadyEv(
                   IN    RvSipAuthenticatorHandle        hAuthenticator,
                   IN    RvSipAppAuthenticatorHandle     hAppAuthenticator,
                   IN    void*                           hObject,
                   IN    void*                           peObjectType,
                   IN    RvSipAuthObjHandle              hAuthObj,
                   IN    void*                           pAuthObjContext,
                   IN    RvSipAuthorizationHeaderHandle  hAuthorizationHeader)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSipCommonStackObjectType   eStackObj = *(RvSipCommonStackObjectType*)peObjectType;
	RvSimpleCltPuaHandle		 hPua;
	RvStatus					 rv;

	RV_UNUSED_ARG(hAppAuthenticator);
	RV_UNUSED_ARG(pAuthObjContext);

	/* Retrieve the PUA handle from the authenticator */
	rv = GetPuaFromAuthenticator(hAuthenticator, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the SIP Stack object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, hObject, eStackObj,
									    &eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaAuthAuthorizationReadyEvHandler(hPua, hAuthenticator, eSimpleObjType,
										          hObject, peObjectType,
										          hAuthObj, hAuthorizationHeader);

}

#endif /*RV_MTF_SIMPLE_ON */

