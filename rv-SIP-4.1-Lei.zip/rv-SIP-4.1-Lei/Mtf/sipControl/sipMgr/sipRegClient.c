/*********************************************************************************
 *                              <sipRegClient.c>
 *   This file includes:
 *      1. API to register a client
 *      2. Implementations of callback functions that handle Registration events.
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "rvccapi.h"
#include "sipRegClient.h"
#include "RvSipPartyHeader.h"
#include "RvSipExpiresHeader.h"
#include "RvSipContactHeader.h"
#include "RvSipOtherHeader.h"
#include "RvSipAddress.h"
#include "RvSipAuthenticationHeader.h"
#include "RvSipAuthorizationHeader.h"
#include "RvSipRouteHopHeader.h"
#include "rvccprovidersip.h"
#include "sipMgr.h"
#include "sipphone.h"
#include "sipControlInt.h"
#include "ippmisc.h"
#include "rvccterminalmdm.h"
#include "rvMtfPhone.h"
#ifdef RV_SIP_IMS_ON
#include "rvAkaAuth.h"
#include "mtfImsSecAgree.h"
#include "mtfImsReg.h"
#endif

#ifdef RV_MTF_SIMPLE_ON
#include "RvSimpleCltCommonTypes.h"
#include "RvSimpleCltPuaTypes.h"
#include "RvSipSubscription.h"
#include "RvSipPubClient.h"
#include "RvSimpleCltPuaEvents.h"
#include "mtfBaseInt.h"
#endif /* RV_MTF_SIMPLE_ON */

#define RVSIPCTRL_REG_EXPIRES_MAX   0xFFFFFFFF  /*Seconds*/

extern RvSipControl* g_sipControl;
extern HRPOOL        g_appPool;

/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/
static RvStatus RVCALLCONV handleRegStateRegistered(
                                          IN  RvSipRegClientHandle          hRegClient,
                                          IN  RvCCTerminal*                 xTerm);

static RvStatus RVCALLCONV handleRegStateFailed(
                                          IN  RvSipRegClientHandle          hRegClient,
                                          IN  RvCCTerminal*                 xTerm);

static RvBool handleRegStateUnauthenticated(
                                          IN  RvSipRegClientHandle            hRegClient,
                                          IN  RvSipAppRegClientHandle         hAppRegClient,
										  IN  RvSipAuthenticationHeaderHandle authHeader);

static void storeNewRegistrar(RvSipControl* sipMgr, RvSipRegClientHandle   hRegClient);

static RvStatus extractExpiresData(RvSipExpiresHeaderHandle hExpiresHeader, unsigned int *psecs );

RvBool needToAuthenticate(IN  RvSipAppRegClientHandle         hAppRegClient,
						  IN  RvSipRegClientHandle            hRegClient,
						  IN  RvSipAuthenticationHeaderHandle authHeader);

static void handleRegClientSendFailure(RvSipRegClientHandle     hRegClient,
                                        RvCCTerminal*           term);
static RvStatus regClientRemoveAllAuthObjFromList(RvSipRegClientHandle hRegClient);
static RvStatus regClientRemoveOldAuthObjFromList(RvSipRegClientHandle hRegClient);
static void persistInRegistering(RvCCTerminalSip*    sipTerm);
static void storeRegStateAndReason(RvCCTerminalMdm*                mdmt, 
							  RvSipRegClientState             eState,
							  RvSipRegClientStateChangeReason eReason);

/************************************************************************/
/************ C A L L B A C K       I M P L E M E N T A T I O N S********/
/************************************************************************/


/***************************************************************************
 * RvSipRegClientStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a register-client state change.
 *          Prints the new state.
 *          If the new state is Failed terminate the register-client using the
 *          RvSipRegClientTerminate() function.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          eState -        The new register-client state
 *          eReason -       The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppRegClientStateChangedEvHandler(
                                   IN  RvSipRegClientHandle            hRegClient,
                                   IN  RvSipAppRegClientHandle         hAppRegClient,
                                   IN  RvSipRegClientState             eState,
                                   IN  RvSipRegClientStateChangeReason eReason)
{
    RvCCTerminal*       xTerm;
    RvCCTerminalSip*    term;
    RvCCTerminal*       mdmTerm = NULL;
	RvCCTerminalMdm*    mdmt    = NULL;
    RvStatus            rv;
    RvSipControl*       sipMgr;
	RvBool              finalState = RV_TRUE;
	

    if(!hAppRegClient) /*there is no relation between hRegClient and our application, see call to RvSipRegClientSetAppHandle() in rvCCTerminalSipDestruct()*/
        return;

    xTerm   = (RvCCTerminal*)hAppRegClient;
    term    = rvCCTerminalSipGetImpl(xTerm);
    sipMgr  = rvCCSipPhoneGetSipMgr();

    RvLogEnter(ippLogSource,(ippLogSource,"Register-Client %p - State changed to %s",
           hRegClient,getRegClientStateName(eState)));

	if (term != NULL)
	{
		mdmTerm = rvCCTerminalSipGetMdmTerminal(term);

		if (mdmTerm != NULL)
		{
		    /*zhangcg: added for heartbeat from zhuzhihai's modification*/
			if ( RVSIP_REG_CLIENT_STATE_REGISTERED == eState )
			{
				/* start heartbeat timer */
				if(term->dwHeartbeatSwitch == 1 && term->dwHeartbeatCycle > 0)
				{
				    rv = IppTimerStart(&term->tHeartbeatTimer, IPP_TIMER_RESTART_IF_STARTED, (term->dwHeartbeatCycle)*1000);
				    if( rv != RV_OK )
				    {
				        RvLogError(ippLogSource,(ippLogSource,"AppRegClientStateChangedEvHandler::IppTimerStart rv = %d",rv));
				    }
			    }
			}	
			
			if (RvIppSipExtPreRegClientStateChangedCB((RvIppSipControlHandle)sipMgr, hRegClient,
				(RvIppTerminalHandle)mdmTerm, eState, eReason) == RV_FALSE)
			{
				return;
			}
			mdmt = rvCCTerminalMdmGetImpl(mdmTerm);
		}
	}

    switch(eState)
    {
    /*----------------------------------------------
      do not terminate the register-client when it changes
      state to Failed. Termination will done later on
      on Terminated stage
      ---------------------------------------------*/
	case RVSIP_REG_CLIENT_STATE_REGISTERING:
		finalState = RV_FALSE;
		break;

    case RVSIP_REG_CLIENT_STATE_FAILED:
        handleRegStateFailed(hRegClient, xTerm);
		/* handleRegStateFailed() may terminate the Reg client object. The 
		   current state is not final */
		finalState = RV_FALSE;
        /* store state and reason now although this is not a final state.
		   The final state in this case will be TERMINATED but the true 
		   state and reason are lost by time it is generated */
		storeRegStateAndReason(mdmt, eState, eReason);
		break;

	case RVSIP_REG_CLIENT_STATE_TERMINATED:
      
		/* This state is triggered by proc handleRegStateFailed().  */
		finalState = RV_TRUE;

        break;
    /*------------------------------------------------
      Notify that the registration succeeded
      ------------------------------------------------*/
	/* Note: This case must be followed by case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED */

    case RVSIP_REG_CLIENT_STATE_REGISTERED:

		/* The REGISTERED state is true also when first registration succeeded and the next one
		   is unauthorized. Therefore we need to verify that we are not handling unauthenticated
		   reason as a success reason. The next case statement handles unauthenticated state.
		   For this reason there is no break in the end of this case statement if unauthenticaed state
		   is in process */

		if (eReason !=  RVSIP_REG_CLIENT_REASON_RESPONSE_UNAUTHENTICATED_RECVD)
		{
			if (term)
			{
				if (term->networkRegisterType == RV_TERM_NETWORK_REG_TYPE_REGISTERING)
				{
					rvCCTerminalSipSetRegState(term, RV_TERM_NETWORK_REG_STATE_REGISTERED);
					RvLogInfo(ippLogSource, (ippLogSource,
						"Client Registration Succeeded, %p", hRegClient));
					handleRegStateRegistered(hRegClient, xTerm);
				}
			}

			break;
		}
		/*!!!  else - DON'T BREAK !!! */
		/* If the reason is 'unauthenticated received' we need to follow the next case */

    /*------------------------------------------------
      Send another Registration request with authentication
      ------------------------------------------------*/
    /*Send Authentication in 1 of 2 cases:
          1. Stale flag is True, meaning, username and password are correct, but nonce
             has changed, therefore need to send new Credentials.
          2. Stale flag if False, but needToAuthenticate flag is True, meaning,
             this is the first Unauthenticate reply we received, we need to send
             another Registration request with username and password.
             if needToAuthenticate flag is False, it means we already sent username
             and password, and got Unauthenticated, no need to send it over and over.
          3. because not all proxy support stale we are now checking nonce field.
             we store the nonce from recv message 401/407 and next time we receive
             401/407 we check if its the same nonce from previous, if yes we know
             that there is a mismatch in user or password and we will not authenticate again.*/

	/* Note - this case must come after case RVSIP_REG_CLIENT_STATE_REGISTERED */
    case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED:
		{
			RvSipAuthenticationHeaderHandle authHeader;
			RvSipHeaderListElemHandle       hListElem;
			RvSipMsgHandle                  hMsg        = NULL;
#ifdef RV_SIP_IMS_ON
			RvBool                          isAKAAlgorithm = RV_FALSE;
			RvSipSecurityHeaderHandle		secAgreeHeader;
#endif

			if ((rv = RvSipRegClientGetReceivedMsg(hRegClient, &hMsg)) != RV_OK)
			{
				RvLogError(ippLogSource,(ippLogSource,"AppRegClientStateChangedEvHandler: fail to get RecvMsg Handle, RegClientHandel = %p",hRegClient));
			}
			else
			{
				authHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_AUTHENTICATION,
			                                     RVSIP_FIRST_HEADER, &hListElem);
				if(authHeader==NULL)
				{
					RvLogError(ippLogSource,(ippLogSource,"AppRegClientStateChangedEvHandler: No auth header in msg, RegClientHandel = %p",hRegClient));					
				}
				else
				{

#ifdef RV_SIP_IMS_ON

		/* Check what is the authentication algorithm - MD5 or AKA-MD5. According to the algorithm
		   the appropriate authorization header will be built. */
		if (!g_sipControl->imsControl.disableAkaAuthentication)
		{
			isAKAAlgorithm = rvAkaAuthIsAkaAlgorithmInAuthHeader(authHeader);
		}
			if (term->imsTerminalSip.SecAgreeInitiated  == RV_TRUE)
			{
				/* handle security agreement header, if such exists */
				secAgreeHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_SECURITY,
					RVSIP_FIRST_HEADER, &hListElem);

				/* handle MD5 */
				if((secAgreeHeader!=NULL) && (isAKAAlgorithm == RV_FALSE))
				{
					/* choose the security for MD5 authentication. */
					mtfImsRegMd5AuthHandleRegClientUnauthState(hRegClient, term);
				}
			}

			/* handle AKA-MD5 */
		if (isAKAAlgorithm)
		{
			RvLogInfo(ippLogSource, (ippLogSource,
                    "AppRegClientStateChangedEvHandler: handling AKA unauthenticated state in Reg Client 0x%p", hRegClient));
			if (needToAuthenticate(hAppRegClient, hRegClient, authHeader) == rvTrue)
			{
				rv =  rvAkaAuthHandleRegClientUnauthState(hRegClient, term);
				if (rv != RV_OK)
				{
					/* Registration failed. If persistent registration feature is on - start a timer
					for another  register attempt */
					persistInRegistering(term);
				}
				finalState = (rv != RV_OK);
			}
		}
    	else
		{

#endif
		/* MD5 Authentication - default algorithm */
		RvLogInfo(ippLogSource, (ippLogSource,
                    "AppRegClientStateChangedEvHandler: handling MD5 unauthenticated state in Reg Client 0x%p", hRegClient));
		/* if handleRegStateUnauthenticated failed it means that another Register request has not been sent. No need to 
		   wait for another state change */
		if (handleRegStateUnauthenticated(hRegClient,hAppRegClient, authHeader) == RV_TRUE)
		{
			finalState = RV_FALSE;
		}
#ifdef RV_SIP_IMS_ON
		}
#endif
		}

		}
        break;
		}

    case RVSIP_REG_CLIENT_STATE_REDIRECTED:
        storeNewRegistrar(g_sipControl, hRegClient);

        if ((rv = RvSipRegClientRegister(hRegClient)) == RV_OK)
        {
            RvLogInfo(ippLogSource, (ippLogSource,
                "Redirected: Sending Registration for Client, %p", hRegClient));
			finalState = RV_FALSE;
        }
        else {
            RvLogError(ippLogSource, (ippLogSource,
                "Client Registration Failed, %p", hRegClient));
			/* Registration failed. If persistent registration feature is on - start a timer
			for another  register attempt */
			finalState = RV_TRUE;
			persistInRegistering(term);
        }
        break;

    case RVSIP_REG_CLIENT_STATE_MSG_SEND_FAILURE:
        handleRegClientSendFailure(hRegClient, xTerm);
        break;

    default:
        break;
    }

	if (finalState == RV_TRUE)
	{
		if (eState != RVSIP_REG_CLIENT_STATE_TERMINATED)
		{			
			/* store state and reason. If the state is TERMINATED the state 
			   and reason have already been stored in a previous state. */
			storeRegStateAndReason(mdmt, eState, eReason);
		}
		/* this is a final response. Check if the register request was sent as a part of 
		   final unregister */
		if (term->networkRegisterType == RV_TERM_NETWORK_REG_TYPE_UNREGISTERING)
		{	
			rvCCTerminalSipSetRegState(term, RV_TERM_NETWORK_REG_STATE_UNREGISTERED);
			rvCCSipPhoneFinishTermUnregistrationProcess(xTerm);
		}
		else
		{
			if (mdmt->protocolRegisterStateReported[RV_MTF_PROTOCOL_SIP] == RV_TRUE)
			{
				/* Registration data has been changed. Report the change to the user application */
				rvMtfRegisterTermReportStatus( mdmTerm, RV_FALSE);
			}
		}

	}
}

/***************************************************************************
 * AppRegClientMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Calls user callback upon reception Registration response message
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *          hRegClient -  The application handle for this register-client.
 *          hMsg -        Handle to the received message.
 ***************************************************************************/
RvStatus RVCALLCONV AppRegClientMsgReceivedEvHandler(
                                    IN  RvSipRegClientHandle          hRegClient,
                                    IN  RvSipAppRegClientHandle       hAppRegClient,
                                    IN  RvSipMsgHandle                hMsg)
{

	return RvIppSipExtRegClientMsgReceivedCB(hRegClient, hAppRegClient, hMsg);
}


/***************************************************************************
 * RvSipRegClientMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Calls user callback to notify user that Registration message is 
 *          about to be sent.
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          hMsg -          Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppRegClientMsgToSendEvHandler(
                                    IN  RvSipRegClientHandle          hRegClient,
                                    IN  RvSipAppRegClientHandle       hAppRegClient,
                                    IN  RvSipMsgHandle                hMsg)
{

	RvStatus 		res;
	RvSipMethodType	msgType;

	rvSipMgrSetUserAgentHeader(hMsg);

	/* notify user that Registration message is about to be sent */
	res = RvIppSipExtRegClientMsgToSendCB(hRegClient, hAppRegClient, hMsg);

    msgType = RvSipMsgGetRequestMethod(hMsg);
    if ((msgType == RVSIP_METHOD_REGISTER) )
    {
 /*       RvSipOtherHeaderHandle otherHeader;


        RvSipOtherHeaderConstructInMsg(hMsg,RV_FALSE, &otherHeader);
        RvSipOtherHeaderParse(otherHeader,"User-Agent: Radvision MTF");

*/
#ifdef RV_SIP_IMS_ON
		mtfImsRegClientMsgToSend(hRegClient, hAppRegClient, hMsg);

#endif  /* RV_SIP_IMS_ON */

    }

    return res;
}

/************************************************************************/
/****************** R E G   C L I E N T     A P I S *********************/
/************************************************************************/

/***************************************************************************
 * buildRegClientObject
 * ------------------------------------------------------------------------
 * General: Builds the Registration Object.
 *          Before calling the RvSipRegClientRegister() function the
 *          application should follow the below steps:
 *          1. Prepare strings syntax for building the object.
 *          2. take from the register-client two new handles to party headers
 *             using RvSipRegClientGetNewPartyHeaderHandle().
 *          3. take from the register-client a new handle to Expires headers
 *             using RvSipRegClientGetNewExpiresHeaderHandle().
 *          4. take from the register-client two new handles to Contact headers
 *             using RvSipRegClientGetNewContactHeaderHandle().
 *          5. initialize the To, From, Expires and Contact headers using the
 *             message API. In this example we use RvSipPartyHeaderParse() to
 *             initialize the party headers from a string. We use
 *             RvSipExpiresHeaderParse() to initialize the Expires header from
 *             a string, and use the RvSipContactHeaderParse() to initialize
 *             the Contact headers from a string.
 *          6. set the To, From, Expires and Contact headers in the register-
 *             client.
 *          7. Create an address object, initialize it with the registrar's
 *             address, and set it to the register-client using
 *             RvSipRegClientSetRegistrar().
 *
 ***************************************************************************/
static RvStatus buildRegClientObject(
    IN RvSipRegClientHandle*    hRegClient,
    IN RvChar*                  localAddress,
    IN const RvChar*            contact,
    IN RvUint                   expires,
    IN const RvChar*            scheme,
    IN RvUint16                 port,
	IN RvCCTerminalSip*         sipTerm )
{
    char                     contactStr[RV_SHORT_STR_SZ];
    char                     toStr[RV_SHORT_STR_SZ];
    char                     fromStr[RV_SHORT_STR_SZ];
    char                     expiresStr[RV_SHORT_STR_SZ];
    char                     registrarStr[RV_SHORT_STR_SZ];
    RvSipPartyHeaderHandle   hFrom;     /*handle to the From header*/
    RvSipExpiresHeaderHandle hExpires;  /*handle to the Expires header*/
    RvSipContactHeaderHandle hContact;  /*handle to a Contact header*/
    RvSipAddressHandle       hRegistrar;/*handle to the registrar address*/
	RvSipTransportOutboundProxyCfg  outboundCfg;
    RvStatus                 rv;
	const char              *regAddr    = rvCCTerminalSipGetRegistrarAddress(sipTerm);
	RvUint16                 regPort    = rvCCTerminalSipGetRegistrarPort(sipTerm);
	const char              *OutBoundProxyAddr    = rvCCTerminalSipGetOutboundProxyAddress(sipTerm);
	RvSipTransport           termTransport = rvCCTerminalSipGetTransportType(sipTerm);

//add by zhuhaibo 20110317 for set register domainName
    char userDomain[128];
    RvCCProvider* p  = NULL;
    RvCCProviderSip* provider = NULL;
    RvSipControl *x = NULL;

    memset(userDomain, 0, sizeof(userDomain));

    p  = sipTerm->provider;
    if (p != NULL)
    {
        provider = p->provider;
    }
    if (provider != NULL)
    {
        x = &provider->sipMgr;
    }
    if (x != NULL)
    {
        strncpy(userDomain, x->userDomain, sizeof(userDomain));
    }
//add end

    /*---------------------------------------------------
      Prepare the message fields to be set in regClientObj
    -----------------------------------------------------*/

    /*Contact - real local address, set "*" in case of unregistration*/

    if (g_sipControl->stackPort != RVSIPCTRL_NO_PORT)
        RvSnprintf(contactStr, sizeof(contactStr), "Contact:<%s:%s@%s:%d", scheme, contact, localAddress, port);
    else
        RvSnprintf(contactStr, sizeof(contactStr), "Contact:<%s:%s@%s", scheme, contact, localAddress);

    switch (termTransport)
    {
        case RVSIP_TRANSPORT_TCP:
            strcat(contactStr, ";transport=TCP>");
            break;
        case RVSIP_TRANSPORT_UDP:
        /*  strcat(contactStr, ";transport=UDP>");
            No break, some proxies don't like the "transport=UDP"*/
        case RVSIP_TRANSPORT_UNDEFINED:
		/*	No break */
		default:
			strcat(contactStr, ">"); /* No transport type will be added*/
            break;
    }


    /*Alias of registree*/
    /* the host port was omitted from the To header since it is irrelevant in this case.  */
//add by zhuhaibo 20110317 for set register domainName
    //RvSnprintf(toStr, sizeof(toStr),"To:%s:%s@%s", scheme, contact, regAddr);
    if (userDomain[0] != 0)
    {
        RvSnprintf(toStr, sizeof(toStr),"To:%s:%s@%s", scheme, contact, userDomain);
    }
    else
    {
        RvSnprintf(toStr, sizeof(toStr),"To:%s:%s@%s", scheme, contact, regAddr);
    }
//add end
    rv = rvSipControlRegClientSetTo(*hRegClient,toStr);
    if(rv!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"buildRegClientObject:rvSipControlRegClientSetTo fail error = %d",rv));
        return rv;
    }

    /*Alias of the party who registers - should be identical to the To header*/
//add by zhuhaibo 20110317 for set register domainName
    //RvSnprintf(fromStr, sizeof(fromStr), "From:%s:%s@%s", scheme, contact, regAddr);
    if (userDomain[0] != 0)
    {
        RvSnprintf(fromStr, sizeof(fromStr), "From:%s:%s@%s", scheme, contact, userDomain);
    }
    else
    {
        RvSnprintf(fromStr, sizeof(fromStr), "From:%s:%s@%s", scheme, contact, regAddr);
    }
//add end

    /*validation time of registration (sec)*/
    RvSnprintf(expiresStr, sizeof(expiresStr), "Expires:%u", expires);

    /*Registrar address*/
    if (regPort != RVSIPCTRL_NO_PORT)
    RvSnprintf(registrarStr, sizeof(registrarStr), "%s:%s:%d", scheme, regAddr,
                regPort);
    else
        RvSnprintf(registrarStr, sizeof(registrarStr), "%s:%s", scheme, regAddr);

	/* set the outbound proxy details */
	if ((OutBoundProxyAddr != NULL) && (strcmp(OutBoundProxyAddr, "")))
	{
		memset(&outboundCfg, 0, sizeof(outboundCfg));
		/* check if the outbound proxy is identified by IP address or by host name */
		if (IppUtilIsIpAddress((char*)OutBoundProxyAddr))
		{
			outboundCfg.strIpAddress = (RvChar*)OutBoundProxyAddr;			
		}
		else
		{
			outboundCfg.strHostName = (RvChar*)OutBoundProxyAddr;
		}

		/* Set transport type and ip address according to configuration. We do it even if address is domain name
		   based on RFC 3263, sections 4.1 and 4.2. */
		outboundCfg.port = (RvInt32)rvCCTerminalSipGetOutboundProxyPort(sipTerm);

		if (strcmp(scheme,"sips")== 0)
		{
			outboundCfg.eTransport = RVSIP_TRANSPORT_TLS;
		}
		else
		{
			outboundCfg.eTransport = termTransport;
		}

		RvSipRegClientSetOutboundDetails( *hRegClient, &outboundCfg, sizeof(outboundCfg));
	}

    /*---------------------------------------------------
      use a different call-id each register-client object
    -----------------------------------------------------*/
    rv = RvSipRegClientDetachFromMgr(*hRegClient);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to detach register-client,hRegClient(%p),contact(%s),ret(%s)",
            *hRegClient, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    /*------------------------------------------------------------
      get 2 handles for party headers: for the register-client
      To and From Headers
    -------------------------------------------------------------*/
    rv = RvSipRegClientGetNewPartyHeaderHandle(*hRegClient, &hFrom);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to get from header handled from register-client,hRegClient(%p),hFrom(%p)contact(%s),ret(%s)",
            *hRegClient, hFrom, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    /*------------------------------------------------------------
      get a handle for Expires header for the register-client
      Expires Header
    -------------------------------------------------------------*/
    rv = RvSipRegClientGetNewExpiresHeaderHandle(*hRegClient, &hExpires);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to get Expires header handled from register-client,hRegClient(%p),hExpires(%p),contact(%s),ret(%s)",
            *hRegClient, hExpires, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }
    /*------------------------------------------------------------
      get 2 handles for Contact headers: for the register-client
      Contact Headers
    -------------------------------------------------------------*/
    rv = RvSipRegClientGetNewContactHeaderHandle(*hRegClient,&hContact);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to get Contact header handled from register-client,hRegClient(%p),hContact(%p),contact(%s),ret(%s)",
            *hRegClient, hContact, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }
    /*------------------------------------------------------------
      Initialize the From, To, Expires and Contact headers using
      parse.
    -------------------------------------------------------------*/
    rv = RvSipPartyHeaderParse(hFrom,RV_FALSE, fromStr);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to initialize from header,hRegClient(%p),hFrom(%p),from(%s),contact(%s),ret(%s)",
            *hRegClient, hFrom, fromStr, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }


    rv = RvSipContactHeaderParse(hContact, contactStr);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to initialize Contact header,hRegClient(%p),hContact(%p),contact(%s),ret(%s)",
            *hRegClient, hContact, contactStr, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    rv = RvSipExpiresHeaderParse(hExpires, expiresStr);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to initialize Expires header,hRegClient(%p),hExpires(%p),expires(%s),contact(%s),ret(%s)",
            *hRegClient, hExpires, expiresStr, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    /*------------------------------------------------------------
      Set the To, From, Expires and Contact headers in the
      register-client
    -------------------------------------------------------------*/
    rv = RvSipRegClientSetFromHeader(*hRegClient, hFrom);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to set from header in register-client,hRegClient(%p),hFrom(%p),contact(%s),ret(%s)",
            *hRegClient, hFrom, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    rv = RvSipRegClientSetContactHeader(*hRegClient, hContact);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to set Contact header in register-client,hRegClient(%p),hContact(%p),contact(%s),ret(%s)",
            *hRegClient, hContact, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }
    rv = RvSipRegClientSetExpiresHeader(*hRegClient, hExpires);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to set Expires header in register-client,hRegClient(%p),hExpires(%p),contact(%s),ret(%s)",
            *hRegClient, hExpires, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }
    /*------------------------------------------------------------
      Construct an address object for the registrar address.
      Initialize the registrar address using parse. Set the
      registrar address to the register-client
    -------------------------------------------------------------*/
    rv = RvSipRegClientGetNewAddressHandle(*hRegClient, RVSIP_ADDRTYPE_URL,&hRegistrar);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to get address object from register-client,hRegClient(%p),hRegistrar(%p),contact(%s),ret(%s)",
            *hRegClient, hRegistrar, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }
    rv = RvSipAddrParse(hRegistrar, registrarStr);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to initialize registrar address,hRegClient(%p),hRegistrar(%p),registrar(%s),contact(%s),ret(%s)",
            *hRegClient, hRegistrar, registrarStr, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    rv = rvSipControlSetTransportType(hRegistrar, termTransport);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to set Transport type,hRegClient(%p),hRegistrar(%p),transportType(%d),contact(%s),ret(%s)",
            *hRegClient, hRegistrar, termTransport, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    rv = RvSipRegClientSetRegistrar(*hRegClient, hRegistrar);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to set registrar address in register-client,hRegClient(%p),hRegistrar(%p),contact(%s),ret(%s)",
            *hRegClient, hRegistrar, contact, rvSipControlGetErrorCodeName(rv)));
        return rv;
    }
#ifdef RV_SIP_IMS_ON

	 /*---------------------------------------------------------------------------------
	                              AKA authentication
	                              ==================
	  Send an initial authorization header with client's private identity
	  without real credential information. The server will use the identification
	  information to create Authorization Vector (AV)
	  ----------------------------------------------------------------------------------*/
	if (!g_sipControl->imsControl.disableAkaAuthentication)
	{
		rv = rvAkaAuthRegClientBuildInitialId(hRegClient, sipTerm);
		if(rv != RV_OK)
		{
			RvLogError(ippLogSource, (ippLogSource,
				"Failed to set initial authorization in register-client,hRegClient(%p),hRegistrar(%p),contact(%s),ret(%s)",
				*hRegClient, hRegistrar, contact, rvSipControlGetErrorCodeName(rv)));
			return rv;
		}
		/* clear the nonce so that on first 401/407 (unauthorized) reply there will be another registartion
		   attempt */
		 rvCCTerminalSipSetNonce(sipTerm,"");
	}
#else
	RV_UNUSED_ARG(sipTerm);
#endif

	if (RvIppSipExtRegClientCreatedCB(*hRegClient) == RV_FALSE)
	{
		RvLogError(ippLogSource, (ippLogSource,
			    "buildRegClientObject:: RvIppSipExtRegClientCreatedCB failed for reg client %p", hRegClient));
	}

    RvLogInfo(ippLogSource, (ippLogSource,
        "Client Registration Object was built successfully for: %s with the following parameters:\n\t%s\n\t%s\n\t%s\n\t%s\n\n",
           registrarStr, toStr, fromStr, contactStr, expiresStr));

    return RV_OK;
}

/***************************************************************************
 * rvSipControlRegClientCreateObject
 * ------------------------------------------------------------------------
 * General: Create Registration Client Object associated with Terminal
 * Return Value: rvTrue  - if the object was successfully created
 *               rvFalse - if the object was NOT created
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   p -    pointer to X(not implementation) Provider object
 *          xTerm - pointer to X terminal.
 * Output:  regClientObj - address of created object
 ***************************************************************************/
RvBool rvSipControlRegClientCreateObject(
    IN  RvCCProvider*           p,
    IN  RvCCTerminal*           xTerm,
    IN  const RvChar*           scheme,
    IN  RvUint16                port,
                                         OUT RvSipRegClientHandle   *regClientObj)
{
    RvCCProviderSip*    provider        = rvCCProviderSipGetImpl(p);
    RvSipControl*       sipMgr          = rvCCProviderSipGetSipMgr(p);
    RvCCTerminalSip*    sipTerm         = rvCCTerminalSipGetImpl(xTerm);
    RvUint32            expires         = sipTerm->clientRegisterExpires;
    char*               localAddress    = rvCCProviderSipGetLocalAddress(provider);
    RvStatus            status          = RV_OK;
    RvSipRegClientMgrHandle     hRegClientMgr;

    RvSipStackGetRegClientMgrHandle(sipMgr->stackHndl, &hRegClientMgr);

    rvSipControlSetContact(sipMgr,sipTerm->terminalId);

    if ((status = RvSipRegClientMgrCreateRegClient(hRegClientMgr,
                                                  (RvSipAppRegClientHandle)xTerm,
                                                   regClientObj)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"SIPCTRL::Failed to create new register-client, hRegClient(%p), contact(%s),ret(%s)",
                        *regClientObj, sipMgr->contact, rvSipControlGetErrorCodeName(status)));
        return rvFalse;
    }

    /* Build register-client object */
    if ((status = buildRegClientObject(regClientObj, localAddress,
                                                sipMgr->contact, expires,scheme, port, sipTerm)) != RV_OK)
    {
        RvSipRegClientTerminate(*regClientObj);
        RvLogError(ippLogSource,(ippLogSource,"SIPCTRL:: Failed to build register-client object -> %p", regClientObj));
        return rvFalse;
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource,"build register-client object -> %p", regClientObj));
    }

    return rvTrue;
}

/***************************************************************************
 * rvSipControlRegClientSend
 * ------------------------------------------------------------------------
 * General: Send Regiser Client Object (Registration/Unregistration message)
 *          to Sip Server/Proxy
 * Return Value: RV_OK if message was sent or no need to sent it
 *               RV_ERROR - the message can not be sent
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient  -  The Handle of Register Client Object
 *
 ***************************************************************************/
RvStatus rvSipControlRegClientSend(RvSipRegClientHandle  hRegClient)
{
    RvSipRegClientState state;
    RvStatus rv=RV_OK;

    if ((rv = RvSipRegClientGetCurrentState (hRegClient, &state)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"sipRegisterClient::Failed to get current state ,hRegClient(%p),ret(%s)",hRegClient,rvSipControlGetErrorCodeName(rv)));
        return rv;
    }

    /*No point in sending registration while we're in process of registering
      for example...*/
    if ((state != RVSIP_REG_CLIENT_STATE_IDLE) &&
        (state != RVSIP_REG_CLIENT_STATE_REGISTERED) &&
        (state != RVSIP_REG_CLIENT_STATE_REDIRECTED) &&
		(state != RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED) &&
		/* registration failed - retrying */
		(state != RVSIP_REG_CLIENT_STATE_FAILED))
	{
        return RV_OK;
	}

    if(state == RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED)
    {
        char    msgInfo[]            = "Register with Authentication for Client";
        rv = RvSipRegClientAuthenticate(hRegClient);
        if(rv==RV_OK)
        {
                RvLogInfo(ippLogSource,(ippLogSource,"Sending %s %p", msgInfo, hRegClient));
        }
        else
        {
            RvLogError(ippLogSource,(ippLogSource,"Failed to Send %s %p error = %d", msgInfo, hRegClient,rv));
        }
    }
    else
        rv = RvSipRegClientRegister(hRegClient);


    return rv;
}

/************************************************************************/
/********************* U T I L I T Y   F U N C T I O N S ****************/
/************************************************************************/

/***************************************************************************
 * getRegClientStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
const RV_CHAR*  getRegClientStateName (
                                        IN  RvSipRegClientState  eState)
{
    switch (eState)
    {
    case RVSIP_REG_CLIENT_STATE_IDLE:
        return "Idle";
    case RVSIP_REG_CLIENT_STATE_TERMINATED:
        return "Terminated";
    case RVSIP_REG_CLIENT_STATE_REGISTERING:
        return "Registering";
    case RVSIP_REG_CLIENT_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_REG_CLIENT_STATE_REGISTERED:
        return "Registered";
    case RVSIP_REG_CLIENT_STATE_FAILED:
        return "Failed";
    case RVSIP_REG_CLIENT_STATE_MSG_SEND_FAILURE:
        return "Message Sending Failed";
    default:
        return "Undefined";
    }
}

static RvMtfRegistrationState sipRegStateToMtfRegState(RvSipRegClientState  eState)
{
	switch (eState)
	{
	case RVSIP_REG_CLIENT_STATE_UNDEFINED:
	    return RV_MTF_REG_STATE_UNDEFINED;
	case RVSIP_REG_CLIENT_STATE_IDLE:
		return RV_MTF_REG_STATE_NOT_REGISTERED;
	case RVSIP_REG_CLIENT_STATE_REGISTERING:
		return RV_MTF_REG_STATE_REGISTERING;
	case RVSIP_REG_CLIENT_STATE_REDIRECTED:
		return RV_MTF_REG_STATE_REDIRECTED;
	case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED:
		return RV_MTF_REG_STATE_UNAUTHENTICATED;
	case RVSIP_REG_CLIENT_STATE_REGISTERED:
		return RV_MTF_REG_STATE_REGISTERED;
	case RVSIP_REG_CLIENT_STATE_MSG_SEND_FAILURE:
		return RV_MTF_REG_STATE_MSG_SEND_FAILURE;
	case RVSIP_REG_CLIENT_STATE_FAILED:
		return RV_MTF_REG_STATE_FAILED;	
	default:
		return RV_MTF_REG_STATE_UNDEFINED;
	}
}

static RvMtfRegistrationStateReason sipRegStateReasonToMtfRegStateReason(RvSipRegClientStateChangeReason eReason)
{
	switch (eReason)
	{
	case RVSIP_REG_CLIENT_REASON_UNDEFINED:
		return RV_MTF_REG_STATE_REASON_UNDEFINED;
	case RVSIP_REG_CLIENT_REASON_USER_REQUEST:
		return RV_MTF_REG_STATE_REASON_USER_REQUEST;
	case RVSIP_REG_CLIENT_REASON_RESPONSE_SUCCESSFUL_RECVD:
		return RV_MTF_REG_STATE_REASON_RESPONSE_SUCCESSFUL_RECVD;
	case RVSIP_REG_CLIENT_REASON_RESPONSE_REDIRECTION_RECVD:
		return RV_MTF_REG_STATE_REASON_RESPONSE_REDIRECTION_RECVD;
	case RVSIP_REG_CLIENT_REASON_RESPONSE_UNAUTHENTICATED_RECVD:
		return RV_MTF_REG_STATE_REASON_RESPONSE_UNAUTHENTICATED_RECVD;
	case RVSIP_REG_CLIENT_REASON_RESPONSE_REQUEST_FAILURE_RECVD:
		return RV_MTF_REG_STATE_REASON_RESPONSE_REQUEST_FAILURE_RECVD;
	case RVSIP_REG_CLIENT_REASON_RESPONSE_SERVER_FAILURE_RECVD:
		return RV_MTF_REG_STATE_REASON_RESPONSE_SERVER_FAILURE_RECVD;
	case RVSIP_REG_CLIENT_REASON_RESPONSE_GLOBAL_FAILURE_RECVD:
		return RV_MTF_REG_STATE_REASON_RESPONSE_GLOBAL_FAILURE_RECVD;
	case RVSIP_REG_CLIENT_REASON_LOCAL_FAILURE:
		return RV_MTF_REG_STATE_REASON_LOCAL_FAILURE;
	case RVSIP_REG_CLIENT_REASON_TRANSACTION_TIMEOUT:
		return RV_MTF_REG_STATE_REASON_TRANSACTION_TIMEOUT;
	case RVSIP_REG_CLIENT_REASON_NORMAL_TERMINATION:
		return RV_MTF_REG_STATE_REASON_NORMAL_TERMINATION;
	case RVSIP_REG_CLIENT_REASON_GIVE_UP_DNS:
		return RV_MTF_REG_STATE_REASON_GIVE_UP_DNS;
	case RVSIP_REG_CLIENT_REASON_NETWORK_ERROR:
		return RV_MTF_REG_STATE_REASON_NETWORK_ERROR;
	case RVSIP_REG_CLIENT_REASON_503_RECEIVED:
		return RV_MTF_REG_STATE_REASON_503_RECEIVED;
	case RVSIP_REG_CLIENT_REASON_CONTINUE_DNS:
		return RV_MTF_REG_STATE_REASON_CONTINUE_DNS;
	default:
		return RV_MTF_REG_STATE_REASON_UNDEFINED;
	}
}

static void storeRegStateAndReason(RvCCTerminalMdm*                mdmt, 
							  RvSipRegClientState             eState,
							  RvSipRegClientStateChangeReason eReason)
{
	RvMtfRegistrationState       mtfRegState;
	RvMtfRegistrationStateReason mtfRegStateReason;

	mtfRegState = sipRegStateToMtfRegState(eState);
	mtfRegStateReason = sipRegStateReasonToMtfRegStateReason(eReason);

	if ((mdmt->registrationStatus.protocolRegisterStateData[RV_MTF_PROTOCOL_SIP].registrationState != mtfRegState) ||
		(mdmt->registrationStatus.protocolRegisterStateData[RV_MTF_PROTOCOL_SIP].registrationStateReason != mtfRegStateReason))
	{
		/* Mark that something has changed in the register status data */
		mdmt->protocolRegisterStateReported[RV_MTF_PROTOCOL_SIP] = RV_TRUE;
		mdmt->registrationStatus.protocolRegisterStateData[RV_MTF_PROTOCOL_SIP].registrationState = mtfRegState;
		mdmt->registrationStatus.protocolRegisterStateData[RV_MTF_PROTOCOL_SIP].registrationStateReason = mtfRegStateReason;
	}
}

/***************************************************************************
* persistInRegistering
* ------------------------------------------------------------------------
* General: If the persistent registration feature is on, registration requests
*          are sent persistently until registration succeeds.
*          This proc overrides the registration timer which was started
*          according to the RegistrationExpire configuration parameter.
*          
* ------------------------------------------------------------------------
* Arguments:
* Input:   
*          
***************************************************************************/
static void persistInRegistering(RvCCTerminalSip*    sipTerm)
{
	RvCCTerminal*           mdmt = rvCCTerminalSipGetMdmTerminal(sipTerm);
	RvCCTerminalMdm*        mdmTerm = rvCCTerminalMdmGetImpl(mdmt); 
	RvCCProvider*			p = rvCCTerminalMdmGetProvider(mdmTerm);
	RvCCProviderMdm*        provider = rvCCProviderMdmGetImpl(p);

	if ((provider->persistentRegisterEnabled == RV_TRUE) && (provider->persistentRegisterRetryInterval > 0))
	{
		RvStatus status;

		/* start timer to Re register*/
		status = IppTimerStart(&sipTerm->registerTimer , IPP_TIMER_RESTART_IF_STARTED, provider->persistentRegisterRetryInterval * 1000  );
		if(status!=RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource,"persistInRegistering::IppTimerStart failed"));
		}
	}

}

/***************************************************************************
 * storeNewRegistrar
 * ------------------------------------------------------------------------
 * General: Retrieves new Registrar address, and stores it in IPP TK
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   sipMgr      - Pointer to sipControl object
 *          hRegClient  - Handle to RegClient object
 ***************************************************************************/
static void storeNewRegistrar(RvSipControl* sipMgr, RvSipRegClientHandle   hRegClient)
{
    RvSipAddressHandle      newAddress;
    char                    newRegistrar[RV_SIPCTRL_ADDRESS_SIZE];
    RV_UINT                 len;
    RvUint16                port;
    char                    toStr[RV_SHORT_STR_SZ];
    RvStatus                status = RV_OK;
    char userScheme[RV_SHORT_STR_SZ]= {"sip:"};

#ifdef RV_CFLAG_TLS
    /* use the sips scheme only if TLS was activated */
    if (rvSipControlIsTlsEnabled(sipMgr))
        RvSnprintf(userScheme, 5, "%s:", "sips");
#endif

    status  = RvSipRegClientGetRegistrar (hRegClient, &newAddress);
    status  = RvSipAddrUrlGetHost(newAddress, newRegistrar, RV_SIPCTRL_ADDRESS_SIZE, &len);
    port    = (RvUint16)RvSipAddrUrlGetPortNum(newAddress);

    RvSnprintf(toStr, sizeof(toStr),"To:%s%s@%s:%d", userScheme, sipMgr->contact, newRegistrar,
        port);

    status = rvSipControlRegClientSetTo(hRegClient,toStr);

    rvSipControlSetRegistrarAddress(sipMgr, newRegistrar);
    rvSipControlSetRegistrarPort(sipMgr, port);
}




/***************************************************************************
* copyOneServiceRouteHeader
* ------------------------------------------------------------------------
* General: copies only ONE service-route header handle at a time into the terminal
*          routeList record. The data is stored as ROUTE header type that will be
*          applied to outgoing INVITE messages when/if generated.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:
*          hSrcServiceRouteHeaderHandle - The handle to the service-route header in the received message.
*          IndexOfSRouteHeaderInMessage - The num of the current service-route header in the.
*                                         service-route list in the message.
*          routeList                    - list of route header data stopred in the terminal object
*
***************************************************************************/
static RvStatus copyOneServiceRouteHeader(
													  IN  RvSipRouteHopHeaderHandle hSrcServiceRouteHeaderHandle,
													  IN  RvInt                     IndexOfSRouteHeaderInMessage,
													  IN  RouteListDataType*        routeList)
{
    RvStatus                  rv                    = RV_OK;
    RvSipRouteHopHeaderHandle hDestRouteHeaderHandle = NULL;
	RvSipMsgMgrHandle         hMsgMgr;

    if(routeList->serviceRouteListPage == NULL) /*first call*/
	{
		rv = RPOOL_GetPage(g_appPool,0,&(routeList->serviceRouteListPage));
		if(rv != RV_OK)
		{
			RvLogError(ippLogSource, (ippLogSource,"copyOneServiceRouteHeader():: RPOOL_GetPage() Failed "));
		}
	}
	/* construct one service-route header on the application page in order to copy the
	service-route header list from the ,received message*/
	rv= RvSipStackGetMsgMgrHandle( rvSipControlGetStackHandle(g_sipControl), &hMsgMgr);
    rv = RvSipRouteHopHeaderConstruct(hMsgMgr,
		g_appPool,
		routeList->serviceRouteListPage,
		&hDestRouteHeaderHandle);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,"copyOneServiceRouteHeader():: failed to construct RouteHopHeader"));
    }

    /*copy the original service-route header to the application page*/
    rv = RvSipRouteHopHeaderCopy(hDestRouteHeaderHandle,hSrcServiceRouteHeaderHandle);
    if (rv != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,"copyOneServiceRouteHeader():: failed to copy RouteHopHeader"));
    }

    /*change the list from SERVICE_ROUTE type to ROUTE type*/
    rv = RvSipRouteHopHeaderSetHeaderType(hDestRouteHeaderHandle,RVSIP_ROUTE_HOP_ROUTE_HEADER);

    routeList->routeHopHeaderList[IndexOfSRouteHeaderInMessage] = hDestRouteHeaderHandle;
    routeList->numOfRouteHopHeadersInList++;

    return rv;
}

/***************************************************************************
 * handleServiceRouteHeader
 * ------------------------------------------------------------------------
 * General: This proc is retreiving data from Service-Route headers that
 *          may be part of the REGISTER OK reply message. One REG OK message may
 *          contain several service route addresses grouped in one  header
 *          or several headers containing one or more addresses in each.
 *          The route addresses are stored per terminal in routeList record
 *          that is part of the RvCCTerminal struct.
 *
 *
 *
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -        Handle to the outgoing message.
 *          term -        pointer to RvCCTerminal object
  *
 ***************************************************************************/

static void handleServiceRouteHeader(RvSipMsgHandle hMsg, RvCCTerminalSip* term)
{
	RvSipRouteHopHeaderHandle   hRouteHopHeader  = NULL;
	RvSipHeaderListElemHandle   headerListElem   = NULL;
	RvSipRouteHopHeaderType     routeHopType;
    RvInt                       indexOfSRouteHeaderInList = 0;
	RouteListDataType           *routeList;
	RvStatus                    rv               = RV_OK;


	routeList = rvCCTerminalSipGetRouteListData(term);
	/*delete all the global route list handles when a new message arrives from registrar*/
    rvCCTerminalSipResetRouteHopHeaderList(term);

    /*retrieve all the service-route headers from the message.NULL is returned
    if there is no list*/
    hRouteHopHeader = (RvSipRouteHopHeaderHandle)RvSipMsgGetHeaderByType(
		hMsg,
		RVSIP_HEADERTYPE_ROUTE_HOP,
		RVSIP_FIRST_HEADER,
		&headerListElem);

    /*save the service-route header list in term->routeList->routeHopHeaderList*/
    while((hRouteHopHeader != NULL) &&
		(indexOfSRouteHeaderInList < MAX_NUM_OF_ROUTE_HEADER_LIST))
    {

        routeHopType = RvSipRouteHopHeaderGetHeaderType(hRouteHopHeader);
        /*if the route hop is a record route, add its address spec to the
        route address list*/
        if(routeHopType == RVSIP_ROUTE_HOP_SERVICE_ROUTE_HEADER)
        {
			rv = copyOneServiceRouteHeader(hRouteHopHeader,indexOfSRouteHeaderInList, routeList);
			if(rv != RV_OK)
			{
				RvLogError(ippLogSource, (ippLogSource,"handleServiceRouteHeader():: failed  to copy ServiceRouteHeader"));
			}
			indexOfSRouteHeaderInList ++;
		}

		hRouteHopHeader = (RvSipRouteHopHeaderHandle)RvSipMsgGetHeaderByType(
			hMsg,
			RVSIP_HEADERTYPE_ROUTE_HOP,
			RVSIP_NEXT_HEADER,
			&headerListElem);

    }

}


/***************************************************************************
 * handleRegStateRegistered
 * ------------------------------------------------------------------------
 * General: This function is called when OK reply was received for Register,
 *          and does the following:
 *          1. Retrieves the Expires value from the reply -
 *             first check Expires field in first Contact header, if not found,
 *             look for Expires header. According to RFC 3261, section 8.3:
 *              "The "expires" parameter of a Contact header field value indicates how
 *              long the URI is valid. The value of the parameter is a number indicating
 *              seconds. If this parameter is not provided, the value of the Expires
 *              header field determines how long the URI is valid. "
 *          2. Updates internal Expire timer of IPP TK according to new value (if needed)
 *
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *          xTerm      -  pointer to RvCCTerminal object - clients X terminal.
  *         hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV handleRegStateRegistered(
                                          IN  RvSipRegClientHandle   hRegClient,
                                          IN  RvCCTerminal*          xTerm)
{
    RvSipMsgHandle            hMsg;
    RvSipHeaderListElemHandle hListElem;


    /*data of received OK (REGISTER)*/
    RvSipContactHeaderHandle    hContactHeader  = NULL;
    RvSipExpiresHeaderHandle    hExpiresHeader  = NULL;
    RvSipAddressHandle          hAddress        = NULL;
    RvUint32                    nRegisterExpires;

    /*data of sent REGISTER*/
    RvSipContactHeaderHandle    *phClientContactHeader;
    RvSipAddressHandle          hClientAddress;
    RvUint32                    nClientRegisterExpires;

    RvStatus                        rc;
    RvCCTerminalSip*    term =  rvCCTerminalSipGetImpl(xTerm); /*recipient terminal*/

    if(!term)
        return RV_ERROR_UNKNOWN;
    /*
    *   retrieve the previous expires value.
    */
    nClientRegisterExpires = rvCCTerminalSipGetRegisterExpires(term);

    /*
     *  Extract Contact header that was sent in REGISTER
     * We know that IPP uses one and only one such a header
     */
    phClientContactHeader = RvSipRegClientGetFirstContactHeader(hRegClient);
    if (phClientContactHeader)
    {
        hClientAddress = RvSipContactHeaderGetAddrSpec(*phClientContactHeader);
    }
    else
    {
        RvLogError(ippLogSource, (ippLogSource,
            "Failed to retrieve Contact header for Register-Client %p", hRegClient));
        goto return_err;
    }

    /*
    * try to extract expires data from 'Expires' parameter of 'Contact' header first.
    * else from 'Expires' header
    */
    rc = RvSipRegClientGetReceivedMsg(hRegClient, &hMsg);

    /*
     * search message for Contact header that fits the Contact header sent by this client object
     * take in attention that there may be many contact headers
     */
    for (hContactHeader = RvSipMsgGetHeaderByType(hMsg,RVSIP_HEADERTYPE_CONTACT, RVSIP_FIRST_HEADER, &hListElem);
            (hContactHeader !=NULL);
            hContactHeader = RvSipMsgGetHeaderByType(hMsg,RVSIP_HEADERTYPE_CONTACT, RVSIP_NEXT_HEADER, &hListElem) )
    {
        hAddress = RvSipContactHeaderGetAddrSpec(hContactHeader);
        /*
         *  compare with address that was sent
         */
        if (hAddress && hClientAddress && RvSipAddrIsEqual(hAddress, hClientAddress))
            hExpiresHeader = RvSipContactHeaderGetExpires(hContactHeader);
    }

    /*
     *  if Appropriate Contact header doesn't contain "expires" parameter we try extract one from "expires:" header.
     */
    if (hExpiresHeader ==NULL)
        hExpiresHeader = RvSipMsgGetHeaderByType(hMsg,RVSIP_HEADERTYPE_EXPIRES, RVSIP_FIRST_HEADER, &hListElem);

    /*
     *  extract "expires" data
     */
    if (hExpiresHeader !=NULL)
    {
        if (extractExpiresData(hExpiresHeader, &nRegisterExpires) != RV_OK)
            goto return_err;
        /*If Expires exceeds the maximum correct one*/
        if (nRegisterExpires > RVSIPCTRL_REG_EXPIRES_MAX)
            nRegisterExpires = RVSIPCTRL_REG_EXPIRES_MAX;

        if (nClientRegisterExpires != nRegisterExpires)
        {
            IppTimer*   timer = rvCCTerminalSipGetRegisterTimer(term);

            /*update Expires value in term object*/
            rvCCTerminalSipSetRegisterExpires(term, nRegisterExpires);

            /* Do NOT update hRegClient object BUT reset timer */
            if(!timer)
                return RV_ERROR_UNKNOWN;
            if(RV_OK != IppTimerStart(timer, IPP_TIMER_RESTART_IF_STARTED, rvCCTerminalSipGetRegisterTimeout(term)/2))
                return RV_ERROR_UNKNOWN;
        }
    }
	handleServiceRouteHeader(hMsg, term);
#ifdef RV_SIP_IMS_ON
	mtfImsRegisterHandleRegStateRegistered(hMsg);
#endif  /* RV_SIP_IMS_ON */

    return RV_OK;

return_err:
    RvLogError(ippLogSource, (ippLogSource,
        "handleRegStateRegistered() failed for TerminalSip %s", rvCCTerminalSipGetTermId(term)));
    return RV_ERROR_UNKNOWN;

}


/***************************************************************************
 * handleRegStateFailed
 * ------------------------------------------------------------------------
 * General: Extract Expires value from OK response upon REGISTER.
 *          Handle appropriate timer of the terminal.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *          xTerm      -  pointer to RvCCTerminal object - clients X terminal.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/

static RvStatus RVCALLCONV handleRegStateFailed(
                                          IN  RvSipRegClientHandle   hRegClient,
                                          IN  RvCCTerminal*          xTerm)
{
    RvSipMsgHandle                  hMsg;
    RvSipHeaderListElemHandle       hListElem;
    int                             statusCode=0;
    RvStatus                        rc;
    RvCCTerminalSip*    term =  rvCCTerminalSipGetImpl(xTerm); /*recipient terminal*/
    char userScheme[RV_SHORT_STR_SZ]= {"sip"};

#ifdef RV_CFLAG_TLS
    RvSipControl*           sipMgr = rvCCSipPhoneGetSipMgr();
    /* use the sips scheme only if TLS was activated */
    if (rvSipControlIsTlsEnabled(sipMgr))
	{
        RvSprintf(userScheme, "%s", "sips"); /* no doubt about TLS_SCHEME length */
	}
#endif

    /*if appropriate terminal doesn't exist*/
    if(!term)
    {
        RvLogError(ippLogSource,(ippLogSource," handleRegStateFailed() term==NULL"));
        return RV_ERROR_UNKNOWN;
    }

    /* let's get a status of failure before!!! the Reg Client object is not killed */
    rc = RvSipRegClientGetReceivedMsg(hRegClient, &hMsg);
    if (rc != RV_OK)
        goto return_err;

    statusCode = RvSipMsgGetStatusCode(hMsg);

    /* analyze failure problem */
    if (statusCode)
    switch (statusCode)
    {
        case 423 /*Interval Too Brief*/:
        {
            /*data of received Response (REGISTER)*/
            RvSipOtherHeaderHandle      hExpiresHeader =NULL;
            RvUint32                    nRegisterExpires;
            /*
            * try to extract expires data from 'Min-Expires' header.
            */
            hExpiresHeader = RvSipMsgGetHeaderByName(hMsg,"Min-Expires",    RVSIP_FIRST_HEADER, &hListElem);

            if (hExpiresHeader !=NULL)
            {
                RV_CHAR szValue[RV_SHORT_STR_SZ];
                RV_UINT len = sizeof(szValue);

                if (RvSipOtherHeaderGetValue(hExpiresHeader, szValue, len, &len) != RV_OK)
                    goto return_err;
                else
                    nRegisterExpires = atoi(szValue);

                if (rvCCTerminalSipGetRegisterExpires(term) < nRegisterExpires)
                {
                    /*update Expires value in term object*/
                    rvCCTerminalSipSetRegisterExpires(term, nRegisterExpires);
                    /* set the field for the register message that will be sent */
                    rvCCTerminalSipSetClientRegisterExpires(term, nRegisterExpires);

                    /*Set new expire value into the new RegClient object*/
                    rvSipControlRegClientSetExpire(term->regClientObject, nRegisterExpires);

                    rvSipControlRegClientSend(term->regClientObject);
                }

            }
            break;
        }
        default:

			if (rvCCTerminalSipGetToolkitRegisterState(term) != RV_TERM_TOOLKIT_REG_STATE_UNREGISTERING)
			{	
				/* In cases where another Register request is not sent immediately after
				failure the RegClient is terminated and re-created, unless this is final unregistration
				before MTF reset or shutdown. In final unregistration the register object
				is terminated as part of the terminal destruct process.
				This is not a SIP Stack requirement, this is an old MTF behavior.*/
				RvSipRegClientTerminate(hRegClient);

				/* Create a new RegClient object */
				rvSipControlRegClientCreateObject(rvCCBasePhoneGetNetProvider(),
												  xTerm, userScheme, g_sipControl->stackPort,
												  &term->regClientObject);
				/* Set the nonce in the terminal object to NULL so that when */
				/* another registration starts it won't be affected by past  */
				/* failures.                                                 */
				rvCCTerminalSipSetNonce(term,NULL);
				/*delete all the stored route list handles */
				rvCCTerminalSipResetRouteHopHeaderList(term);
				
				/* Registration failed. If persistent registration feature is on - start a timer
				   for another  register  attempt */
				persistInRegistering(term);
			}
			
            RvLogWarning(ippLogSource,(ippLogSource," handleRegStateFailed() msg=%d name=%s",statusCode, rvCCTerminalSipGetTermId(term)));
    }

    return RV_OK;

return_err:
    RvLogError(ippLogSource,(ippLogSource," handleRegStateFailed() failed for TerminalSip %s", rvCCTerminalSipGetTermId(term)));
    return RV_ERROR_UNKNOWN;
}

/***************************************************************************
 * handleRegStateUnauthenticated
 * ------------------------------------------------------------------------
 * General: handel unathenticate message from proxy.
 *
 * Return Value: RV_TRUE if need to authenticate, RV_FALSE otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *
  *         hAppRegClient   - The application handle for this register-client
 ***************************************************************************/
static RvBool handleRegStateUnauthenticated(
                                          IN  RvSipRegClientHandle            hRegClient,
                                          IN  RvSipAppRegClientHandle         hAppRegClient,
										  IN  RvSipAuthenticationHeaderHandle authHeader)
{
    RvCCTerminal*       xTerm   = NULL;
    RvCCTerminalSip*    term    = NULL;
    RvStatus            rv      = RV_OK;
	RvBool              res     = RV_TRUE;
    RvSipAuthenticatorHandle    authMgr;

    xTerm   = (RvCCTerminal*)hAppRegClient;
    term    = rvCCTerminalSipGetImpl(xTerm);

    /* remove stale check because not all proxies support this param */
    /*if ((rvSipControlIsStaleTrue((void*)hRegClient,RegHandle) == rvTrue) )*/
    {
        char                        msgInfo[]            = "Register with Authentication for Client";

        RvSipStackGetAuthenticatorHandle(g_sipControl->stackHndl, &authMgr);
        RvSipAuthenticatorSetAppHandle(authMgr, (RvSipAppAuthenticatorHandle)term);
		res = needToAuthenticate(hAppRegClient, hRegClient, authHeader);
        if (res == rvTrue)
        {
            if ((rv=RvSipRegClientAuthenticate(hRegClient)) == RV_OK)
            {
                RvLogInfo(ippLogSource,(ippLogSource,"Sending %s %p", msgInfo, hRegClient));
            }
            else
            {
                RvLogError(ippLogSource,(ippLogSource,"Failed to Send %s %p error = %d", msgInfo, hRegClient,rv));
				res = RV_FALSE;
            }
        }
		if (res == RV_FALSE)
		{
			/* Registration failed. If persistent registration feature is on - start a timer
			for another  register attempt */
			persistInRegistering(term);
		}
    }
	return res;
}


/***************************************************************************
 * handleRegClientSendFailure
 * ------------------------------------------------------------------------
 * General: This function handles a failure of sending message- it indicates
 *          the stack to send the message to next address on the list.
 *
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg        - a handle to SIP call-leg
 *          c               - pointer to SIP connection
 *
 * Output:  None
 *
 ***************************************************************************/
 static void handleRegClientSendFailure(RvSipRegClientHandle    hRegClient,
                                        RvCCTerminal*           term)
 {
#ifndef RV_DNS_ENHANCED_FEATURES_SUPPORT
  
	handleRegStateFailed(hRegClient, term);

#else

     RvStatus rv;

/****/
    /* If the list is empty RvSipRegClientDNSContinue() will return failure. You can also check the list by your self as follows:
    RvSipTransportDNSListHandle     phDnsList;
    rv = RvSipRegClientDNSGetList(hRegClient, &phDnsList);
    rv = RvSipTransportGetNumberOfDNSListEntries(hTransportMgr,  hDnsList,&srvElements,&hostNameElements,&ipAddrElements);
    if (RV_OK != rv)
        return RV_FALSE;

    if ((srvElements == 0) && (hostNameElements == 0) && (ipAddrElements == 0))
        return RV_FALSE;
*/

     /* Trying to proceed to the other addresses in the DNS list. calling RvSipRegClientDNSContinue()
       will ACK on the 503*/
    rv = RvSipRegClientDNSContinue(hRegClient);
    if(rv != RV_OK)
    {
        handleRegStateFailed(hRegClient, term);
        RvLogDebug(ippLogSource,(ippLogSource, "No more addresses on DNS list, term=0x%p", term));
        return;
    }

    /* calling this function will re send the request but this time on TCP */
    rv = RvSipRegClientDNSReSendRequest(hRegClient);
    if(rv != RV_OK)
    {
        handleRegStateFailed(hRegClient, term);
        RvLogError(ippLogSource,(ippLogSource,"Failed to re send the request on a call"));
    }
#endif /*RV_DNS_ENHANCED_FEATURES_SUPPORT*/
 }

/**********************************
 *  extract "expires" data        *
 *********************************/
static RvStatus extractExpiresData(RvSipExpiresHeaderHandle hExpiresHeader, unsigned int *psecs )
{
    RvSipExpiresFormat          format;

    if (hExpiresHeader !=NULL)
    {
        format = RvSipExpiresHeaderGetFormat(hExpiresHeader);

        switch (format)
        {
        case RVSIP_EXPIRES_FORMAT_DELTA_SECONDS:
            if (RvSipExpiresHeaderGetDeltaSeconds(hExpiresHeader, psecs) == RV_OK)
                goto return_ok;
            else
                goto return_err;
            /*Date format is not supported yet*/
        case RVSIP_EXPIRES_FORMAT_DATE:
        /*  rvTimeConvertTm
            RvSipDateHeaderHandle hDate = RvSipExpiresHeaderGetDateHandle(hExpiresHeader);*/
                goto return_err;
        default:
                goto return_err;
        }
    }
    else
    {
                goto return_err;
    }

return_ok:
    return RV_OK;

return_err:
    RvLogError(ippLogSource, (ippLogSource,
        "Failed to retrieve \"expires\" from hExpiresHeader %p", hExpiresHeader));
    return RV_ERROR_UNKNOWN;
}


/***************************************************************************
 * rvSipControlRegClientSetExpire
 * ------------------------------------------------------------------------
 * General: Set Expires value from Register Client Object to 0!!!
 *          This will convert Registration object into Unregistration.
 * Return Value: RV_OK on success
 *               RV_ERROR - on failure.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *
 ***************************************************************************/
RvStatus rvSipControlRegClientSetExpire(RvSipRegClientHandle    hRegClient, RvInt32 nExpire)
{
    RvSipExpiresHeaderHandle    hExpiresHeader;

    if (RvSipRegClientGetExpiresHeader(hRegClient, &hExpiresHeader) == RV_OK)
        return RvSipExpiresHeaderSetDeltaSeconds(hExpiresHeader, nExpire);
    else
        return RV_ERROR_UNKNOWN;
}

/***************************************************************************
 * rvSipControlRegClientSetTo
 * ------------------------------------------------------------------------
 * General: Set To value in Register Client Object
 *
 * Return Value: RV_OK on success
 *               RV_ERROR - on failure.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *
 *          toStr      -  the new to string
 *
 ***************************************************************************/
RvStatus rvSipControlRegClientSetTo(IN RvSipRegClientHandle hRegClient,
                                    IN char*                toStr)
{
    RvSipPartyHeaderHandle   hTo;       /*handle to the To header*/
    RvStatus                 status =RV_OK;
    status = RvSipRegClientGetNewPartyHeaderHandle(hRegClient, &hTo);
    if(status!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlRegClientSetTo:RvSipRegClientGetNewPartyHeaderHandle fail error =%d",status));
        return status;
    }
    status = RvSipPartyHeaderParse(hTo,RV_TRUE, toStr);
    if(status!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlRegClientSetTo:RvSipPartyHeaderParse  %s fail error =%d",toStr,status));
        return status;
    }
    status = RvSipRegClientSetToHeader(hRegClient, hTo);
    if(status!=RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvSipControlRegClientSetTo:RvSipRegClientSetToHeader fail error =%d",status));
        return status;
    }
    return status;
}


/***************************************************************************
 * rvSipControlIsSameNonce
 * ------------------------------------------------------------------------
 * General: compare the nonce field in credentials of receive msg
 *          and our regClientObject
 *
 * Return Value: True - identical, False - otherwise.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   receivedNonce   - nonce from message recv
 *          previousNonCe   - nonce from
 *
 ***************************************************************************/
RvBool rvSipControlIsSameNonce(IN char* receivedNonce,const char* previousNonCe)
{
    if ((receivedNonce==NULL) ||
        (previousNonCe==NULL))
    {
        RvLogWarning(ippLogSource,(ippLogSource,"rvSipControlIsSameNonce bad parameter"));
        return rvFalse;
    }
    if(strcmp(receivedNonce,previousNonCe)==0)
        return rvTrue;
    else
    {
        /* nonce field has been change */
        return rvFalse;
    }
}

/***************************************************************************
 * needToAuthenticate
 * ------------------------------------------------------------------------
 * General: decide if we need to authenticate to regClient
 *
 *
 * Return Value: True - need to authenticate, False - not authenticate.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient      - The sip stack register-client handle
 *          hAppRegClient   - The application handle for this register-client
 *          authHeader      - handle to the authentication handle
 *
 ***************************************************************************/
RvBool needToAuthenticate(IN  RvSipAppRegClientHandle          hAppRegClient,
						  IN  RvSipRegClientHandle             hRegClient,
						  IN  RvSipAuthenticationHeaderHandle  authHeader)
{
    RvBool              isNeedToAuthenticate    = rvTrue;
    RvStatus            status                  = RV_OK;
    char                nonce[RV_NAME_STR_SZ]   = "";
    RvCCTerminal*       xTerm                   = NULL;
    RvCCTerminalSip*    term                    = NULL;
	RvUint32            authRetries             = 0;
	RvUint32            maxAuthRetries          = 0;

    xTerm   = (RvCCTerminal*)hAppRegClient;
    term    = rvCCTerminalSipGetImpl(xTerm);

    /* get nonce from recv message */
    status = rvSipControlGetNonceFromAuthHeader(authHeader, nonce);
    if(status != RV_OK)
    {
        RvLogWarning(ippLogSource,(ippLogSource,"needToAuthenticate: Failed to get nonce, error %d", status));
        goto err_exit;
    }
    else
    {
		isNeedToAuthenticate = !(rvSipControlIsSameNonce(nonce,rvCCTerminalSipGetNonce(term)));
    }
    if (isNeedToAuthenticate==rvTrue)
    {
		/* check if there is a limitation for the number of times an authentication attempts can be made */
         if ((maxAuthRetries = rvSipControlGetMaxAuthenticateRetries(g_sipControl)) > 0)
		 {
			 authRetries = rvCCTerminalSipGetAuthRetriesCount(term);
			 if (authRetries < maxAuthRetries)
			 {
				 rvCCTerminalSipSetAuthRetriesCount(term, authRetries + 1);
			 }
			 else
			 {
				 /* no more authentication trials are allowed */
				 RvLogError(ippLogSource,(ippLogSource,"needToAuthenticate: Registration failed: can't send another register msg, num of retries (%d) was exceeded",maxAuthRetries));
				 goto err_exit;
			 }
		 }
        rvCCTerminalSipSetNonce(term,nonce);

		/* If the user has configured the removeOldAuthHeader parameter, do so */
		if (g_sipControl->removeOldAuthHeaders)
		{
			regClientRemoveOldAuthObjFromList(hRegClient);
		}
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource,"needToAuthenticate: Registration failed: mismatch user or password"));
		goto err_exit;
    }

    return rvTrue;

err_exit:
	/* The registration attempt has failed, clear all the authorization headers in the Reg Client object */
	regClientRemoveAllAuthObjFromList(hRegClient);
	return rvFalse;

}

/***************************************************************************
 * regClientRemoveAllAuthObjFromList
 * ------------------------------------------------------------------------
 * General:  Remove all auth-obj from the reg client list.
 *
 * Return Value: RV_OK - if successful. error code o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * input   : hRegClient - Handle to the regClient, holding the auth-obj list.
 ***************************************************************************/
static RvStatus regClientRemoveAllAuthObjFromList(RvSipRegClientHandle hRegClient)
{
    RvSipAuthObjHandle hAuthobj = NULL;

    RvSipRegClientAuthObjGet(hRegClient, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj) ;
    while (hAuthobj != NULL)
    {
        RvSipRegClientAuthObjRemove(hRegClient, hAuthobj);
		RvLogDebug(ippLogSource,(ippLogSource,"regClientRemoveAllAuthObjFromList:: Removing auth header 0x%p from Reg Client 0x%p",
				                      hAuthobj, hRegClient));
		/* look for the first elemet again since we removed the previous first element */
        RvSipRegClientAuthObjGet(hRegClient, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj) ;
    }
    return RV_OK;
}

/***************************************************************************
* regClientRemoveOldAuthObjFromList
* ------------------------------------------------------------------------
* General:  Remove the old auth-obj from the regClient list.
*           There are two types of auth headers: proxy-authenticate and
*           www-authenticate.
*           The last Auth object of each type in the list is the latest, all the
*           other objects are removed.
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
* input   : hRegClient - Handle to the regClient, holding the auth-obj list.
***************************************************************************/
static RvStatus regClientRemoveOldAuthObjFromList(RvSipRegClientHandle hRegClient)
{
    RvSipAuthObjHandle hNextAuthobj    = NULL;
	RvSipAuthObjHandle hCurrentAuthobj = NULL;
	RvSipAuthObjHandle hProxyAuthobj   = NULL;
	RvSipAuthObjHandle hWwwAuthobj     = NULL;
	RvSipAuthenticationHeaderType eAuthHeaderType=RVSIP_AUTH_UNDEFINED_AUTHENTICATION_HEADER;
	RvSipAuthenticationHeaderHandle hAuthHeader=NULL;
	RvBool	isValid = RV_FALSE;

    RvSipRegClientAuthObjGet(hRegClient, RVSIP_FIRST_ELEMENT, NULL, &hCurrentAuthobj) ;
	RvSipAuthObjGetAuthenticationHeader(hCurrentAuthobj,&hAuthHeader,&isValid);
	eAuthHeaderType = RvSipAuthenticationHeaderGetHeaderType(hAuthHeader);
	if (eAuthHeaderType == RVSIP_AUTH_WWW_AUTHENTICATION_HEADER)
	{
		hWwwAuthobj = hCurrentAuthobj;
	}
	else
	if (eAuthHeaderType == RVSIP_AUTH_PROXY_AUTHENTICATION_HEADER)
	{
		hProxyAuthobj = hCurrentAuthobj;
	}

	/* Loop over all auth objets */
    while (hCurrentAuthobj != NULL)
    {
		RvSipAuthObjHandle hRemoveAuthobj    = NULL;

		RvSipRegClientAuthObjGet(hRegClient, RVSIP_NEXT_ELEMENT, hCurrentAuthobj, &hNextAuthobj) ;

		if (hNextAuthobj != NULL)
		{
			RvSipAuthObjGetAuthenticationHeader(hNextAuthobj,&hAuthHeader,&isValid);
			eAuthHeaderType = RvSipAuthenticationHeaderGetHeaderType(hAuthHeader);

			if (eAuthHeaderType == RVSIP_AUTH_WWW_AUTHENTICATION_HEADER)
			{
			/* found a www-authenticate header. If we have already found
				a previous one remove it and save a pointer to the new one */

				if (hWwwAuthobj != NULL)
				{
					hRemoveAuthobj =  hWwwAuthobj;
				}
				hWwwAuthobj = hNextAuthobj;
			}
			else
				if (eAuthHeaderType == RVSIP_AUTH_PROXY_AUTHENTICATION_HEADER)
				{
				/* found a proxy-authenticate header. If we have already found
					a previous one remove it and save a pointer to the new one */
					if (hProxyAuthobj != NULL)
					{
						hRemoveAuthobj =  hProxyAuthobj;
					}
					hProxyAuthobj = hNextAuthobj;
				}
				else
				{
					/* shouldn't happen but just in case */
					hRemoveAuthobj = hCurrentAuthobj;
				}
				if (hRemoveAuthobj!= NULL)
				{
					/* this is not the last object of its type in the list, remove it */
					RvSipRegClientAuthObjRemove(hRegClient, hCurrentAuthobj);
					RvLogDebug(ippLogSource,(ippLogSource,"regClientRemoveOldAuthObjFromList:: Removing auth header 0x%p from Reg Client 0x%p",
						hCurrentAuthobj, hRegClient));
				}
		}

		hCurrentAuthobj = hNextAuthobj;
    }
    return RV_OK;
}


/******************************************************************************************************************/
/*		F O R		S I M P L E		C O - E X I S T E N C E				O N L Y                                   */
/******************************************************************************************************************/

#ifdef RV_MTF_SIMPLE_ON

/******************************************************************************
 * GetPuaFromSubs
 * ----------------------------------------------------------------------------
 * General: Retrieves the PUA handle from the Subs object
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs   - Handle to the Subs object
 * Output:  phPua   - Pointer to the PUA
 ***************************************************************************/
static RvStatus RVCALLCONV GetPuaFromSubs(
                               IN    RvSipSubsHandle        hSubs,
                               OUT   RvSimpleCltPuaHandle  *phPua)
{
	RvMtfHandle			hMtf;
	RvMtfBaseMgr*		mtfMgr;
	RvSipStackHandle	hSipStack;
	RvStatus			rv;

	/* The SIP stack holds an application object that can be retrieved from the
	   stack at any point. The SIMPLE application requires the PUA handle in
	   all callbacks.
	   At this point, since the event dispatcher is used, we can assume that the
	   PUA is the only application above the SIP stack, therefore, we can assume
	   that it is registered to the stack as its application handle.
	   If the application wishes to expand its work above the stack, it must implement
	   the event dispatcher. It would be able to attach its own application handle to
	   the SIP stack, but it will have to hold the PUA handle there, and to retrieve
	   it here in order to supply it to the PUA authentication callbacks. */
	rv = RvSipSubsGetStackInstance(hSubs, (void**)&hSipStack);
	if (RV_OK != rv)
	{
		return rv;
	}

//	rv = RvSipStackGetAppHandle(hSipStack, (RvSipAppStackHandle*)phPua);
	rv = RvSipStackGetAppHandle(hSipStack, (RvSipAppStackHandle*)&hMtf);

	mtfMgr = (RvMtfBaseMgr*)hMtf;

	*phPua = mtfMgr->hSimplePua;

	if (RV_OK != rv)
	{
		return rv;
	}

	if (*phPua == NULL)
	{
		return RV_ERROR_NOT_FOUND;
	}

	return RV_OK;
}

/******************************************************************************
 * GetPuaFromPubClient
 * ----------------------------------------------------------------------------
 * General: Retrieves the PUA handle from the Pub-Client object
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hPubClient   - Handle to the Pub-Client object
 * Output:  phPua        - Pointer to the PUA
 ***************************************************************************/
static RvStatus RVCALLCONV GetPuaFromPubClient(
                               IN    RvSipPubClientHandle   hPubClient,
                               OUT   RvSimpleCltPuaHandle  *phPua)
{
	RvMtfHandle			hMtf;
	RvMtfBaseMgr*		mtfMgr;
	RvSipStackHandle	hSipStack;
	RvStatus			rv;

	/* The SIP stack holds an application object that can be retrieved from the
	   stack at any point. The SIMPLE application requires the PUA handle in
	   all callbacks.
	   At this point, since the event dispatcher is used, we can assume that the
	   PUA is the only application above the SIP stack, therefore, we can assume
	   that it is registered to the stack as its application handle.
	   If the application wishes to expand its work above the stack, it must implement
	   the event dispatcher. It would be able to attach its own application handle to
	   the SIP stack, but it will have to hold the PUA handle there, and to retrieve
	   it here in order to supply it to the PUA authentication callbacks. */
	rv = RvSipPubClientGetStackInstance(hPubClient, (void**)&hSipStack);
	if (RV_OK != rv)
	{
		return rv;
	}

//	rv = RvSipStackGetAppHandle(hSipStack, (RvSipAppStackHandle*)phPua);
	rv = RvSipStackGetAppHandle(hSipStack, (RvSipAppStackHandle*)&hMtf);

	mtfMgr = (RvMtfBaseMgr*)hMtf;

	*phPua = mtfMgr->hSimplePua;

	if (RV_OK != rv)
	{
		return rv;
	}

	if (*phPua == NULL)
	{
		return RV_ERROR_NOT_FOUND;
	}

	return RV_OK;
}

/***************************************************************************
 * AppSubsStateChangedEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Subs State Changed callback of the SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *          Note: If the Subs is an incoming Subs, then it will not be handled by
 *          the SIMPLE PUA which is a client application. Therefore the Event
 *          Dispatcher will respond with 501 to this subscription.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs    - The sip stack subscription handle
 *            hAppSubs - The application handle for this subscription.
 *            eState   - The new subscription state.
 *            eReason  - The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppSubsStateChangedEv(
                                   IN  RvSipSubsHandle            hSubs,
                                   IN  RvSipAppSubsHandle         hAppSubs,
                                   IN  RvSipSubsState             eState,
                                   IN  RvSipSubsStateChangeReason eReason)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;


	/* Call a user callback first */
	rv = RvMtfSubsStateChangedCB(hSubs, hAppSubs, eState, eReason);

	if (rv != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsStateChangedEv: Subs %p -> returning due to user callback failure, status = %d", hSubs, rv));
        return;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		if(eState == RVSIP_SUBS_STATE_SUBS_RCVD)
        {
			/* This is a special case where the SIMPLE client application receives a SUBSCRIBE
			   request. Since the SIMPLE application implements the StateChangedEv of the subscription
			   layer, the received SUBSCRIBE invokes the creation of a new Subs object and the SIP
			   Stack awaits for the application to respond to that SUBSCRIBE. Since the SIMPLE is
			   a client application, it decalres that this SUBSCRIBE does not belong to her. Therefore,
			   the event dispatcher responds to that SUBSCRIBE. */
            RvStatus   rv;
			rv = RvSipSubsRespondReject(hSubs, 501, NULL);
            if(rv != RV_OK)
            {
				/* If responding failed we terminate the subscription */
                RvSipSubsTerminate(hSubs);
            }
        }
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaSubsStateChangedEvHandler(hPua, eSimpleObjType, hSubs,
											hAppSubs, eState, eReason);
}


/***************************************************************************
 * AppSubsSubscriptionExpiredEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Subscription Expiration callback of the SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs    - The sip stack subscription handle
 *            hAppSubs - The application handle for this subscription.
 ***************************************************************************/
void RVCALLCONV AppSubsSubscriptionExpiredEv(
                                   IN  RvSipSubsHandle            hSubs,
                                   IN  RvSipAppSubsHandle         hAppSubs)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Call a user callback first */
	rv = RvMtfSubsSubscriptionExpiredCB(hSubs, hAppSubs);

	if (rv != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsSubscriptionExpiredEv: Subs %p -> returning due to user callback failure, status = %d", hSubs, rv));
        return;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaSubsSubscriptionExpiredEvHandler(hPua, eSimpleObjType, hSubs, hAppSubs);
}

/***************************************************************************
 * AppSubsExpirationAlertEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Expiration Alert callback of the SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs    - The sip stack subscription handle
 *            hAppSubs - The application handle for this subscription.
 ***************************************************************************/
void RVCALLCONV AppSubsExpirationAlertEv(
                                   IN  RvSipSubsHandle            hSubs,
                                   IN  RvSipAppSubsHandle         hAppSubs)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Call a user callback first */
	rv = RvMtfSubsExpirationAlertCB(hSubs, hAppSubs);

	if (rv != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsExpirationAlertEv: Subs %p -> returning due to user callback failure, status = %d", hSubs, rv));
        return;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaSubsExpirationAlertEvHandler(hPua, eSimpleObjType, hSubs, hAppSubs);
}

/***************************************************************************
 * AppSubsNotifyEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Subs Notify callback of the SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs         - The sip stack subscription handle
 *          hAppSubs      - The application handle for this subscription.
 *          hNotification - The new created notification object handle.
 *          hAppNotification - The application handle for this notification. (relevant
 *                          only for a notifier subscription, which set the hAppNotification
 *                          in RvSipSubsCreateNotify().
 *          eNotifyStatus - Status of the notification object.
 *          eNotifyReason - Reason to the indicated status.
 *          hNotifyMsg    - The received msg (notify request or response).
 ***************************************************************************/
void RVCALLCONV AppSubsNotifyEv(
                                   IN  RvSipSubsHandle			hSubs,
                                   IN  RvSipAppSubsHandle		hAppSubs,
                                   IN  RvSipNotifyHandle		hNotification,
                                   IN  RvSipAppNotifyHandle		hAppNotification,
                                   IN  RvSipSubsNotifyStatus	eNotifyStatus,
                                   IN  RvSipSubsNotifyReason	eNotifyReason,
                                   IN  RvSipMsgHandle			hNotifyMsg)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;


	/* Call a user callback first */
	rv = RvMtfSubsNotifyCB(hSubs, hAppSubs, hNotification, hAppNotification, eNotifyStatus, eNotifyReason, hNotifyMsg);

	if (rv != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsNotifyEv: Subs %p -> returning due to user callback failure, status = %d", hSubs, rv));
        return;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaSubsNotifyEvHandler(hPua, eSimpleObjType, hSubs, hAppSubs, hNotification, hAppNotification,
									  eNotifyStatus, eNotifyReason, hNotifyMsg);
}

/******************************************************************************
 * AppSubsCreatedDueToForkingEv
 * ----------------------------------------------------------------------------
 * General: Implementation to the Subs Created Due to Forking callback of the
 *          SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: RV_OK (the returned status is ignored in the current stack version)
 * ----------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs       - The handle to the created forked Subscription.
 *          pExpires    - A pointer to the expiration value of the subscription
 *                        This value should be set in seconds. If the value was
 *                        not determined, it will be set to -1.
 *                        The value cannot be determined if it was not set in
 *                        the original Subscription. In this case,
 *                        the application should supply the value to limit
 *                        the life cycle of the forked subscription.
 *                        The RvSipSubsUpdateSubscriptionTimer() function can
 *                        be also used for this purpose. On expiration,
 *                        the expiration callback will be called for the forked
 *                        subscription.
 * Output:  pExpires    - A pointer to the memory where the application can set
 *                        the expiration value.
 *          phAppSubs   - The handle that the application sets
 *                        for the subscription.
 *          pRejectStatus-If Application decides to terminate this Subscription
 *                        it should set the pointer to point to positive
 *                        integer, representing Error Code. In this case Stack
 *                        will respond to the NOTIFY with error code and
 *                        will free Subscription object and
 *                        all the Subscription related resources.
 *****************************************************************************/
RvStatus RVCALLCONV AppSubsCreatedDueToForkingEv(
                                  IN        RvSipSubsHandle    hSubs,
                                  INOUT     RvInt32            *pExpires,
                                  OUT       RvSipAppSubsHandle *phAppSubs,
                                  OUT       RvUint16           *pRejectStatus)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Call a user callback first */
	rv = RvMtfSubsCreatedDueToForkingCB(hSubs, pExpires, phAppSubs, pRejectStatus);

	if (rv != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"RvMtfSubsCreatedDueToForkingEv: Subs %p -> returning due to user callback failure, status = %d", hSubs, rv));
        return rv;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return rv;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return RV_OK;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaSubsCreatedDueToForkingEvHandler(hPua, eSimpleObjType, hSubs, pExpires, phAppSubs, pRejectStatus);

	return RV_OK;
}

/***************************************************************************
 * AppSubsMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Msg To Send callback of the SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: RvStatus. Returning RV_ERROR_XXX will cease the sending of
 *                         the message.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs -      The sip stack subscription handle
 *            hAppSubs -   The application handle for this subscription.
 *            hNotify -    The notify object handle (relevant only for notify message)
 *            hAppNotify - The application notify object handle (relevant only for notify message)
 *            hMsg -       Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgToSendEv(
                                    IN    RvSipSubsHandle      hSubs,
                                    IN    RvSipAppSubsHandle   hAppSubs,
                                    IN    RvSipNotifyHandle    hNotify,
                                    IN    RvSipAppNotifyHandle hAppNotify,
                                    IN    RvSipMsgHandle       hMsg)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Call a user callback first */
	rv = RvMtfSubsMsgToSendCB(hSubs, hAppSubs, hNotify, hAppNotify, hMsg);

	if (rv != RV_OK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsMsgToSendEv: Subs %p -> returning due to user callback failure, status = %d", hSubs, rv));
        return rv;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return rv;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return RV_OK;
	}

	/* Invoke the event in the PUA */
	return RvSimpleCltPuaSubsMsgToSendEvHandler(hPua, eSimpleObjType, hSubs, hAppSubs, hNotify, hAppNotify, hMsg);
}


/***************************************************************************
 * AppSubsMsgReceivedEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Msg Received callback of the SIP Stack Subs.
 *          Checks if the given Subs object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Return Value: RvStatus. Returning RV_ERROR_XXX will cease the handling of
 *                         the received message.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs -      The sip stack subscription handle
 *            hAppSubs -   The application handle for this subscription.
 *            hNotify -    The notify object handle (relevant only for notify message)
 *            hAppNotify - The application notify object handle (relevant only for notify message)
 *            hMsg -       Handle to the incoming message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgReceivedEv(
                                    IN  RvSipSubsHandle      hSubs,
                                    IN  RvSipAppSubsHandle   hAppSubs,
                                    IN  RvSipNotifyHandle    hNotify,
                                    IN  RvSipAppNotifyHandle hAppNotify,
                                    IN  RvSipMsgHandle       hMsg)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;
	RvMtfMsgProcessType          procType;


	 /* Inform user application about the incoming message, check if application
        prefers this message to be processed or ignored */
    procType = RvMtfSubsMsgReceivedCB( hSubs, hAppSubs, hNotify, hAppNotify, hMsg);

    if (procType == RV_MTF_IGNORE_BY_STACK)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsMsgReceivedEv (subs %x) -> Ignored by SIP stack and by MTF (User Request)", hSubs));
        return RV_ERROR_UNKNOWN;
    }

    else if (procType == RV_MTF_IGNORE_BY_MTF)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"AppSubsMsgReceivedEv (subs %x) -> Ignored by MTF, will be processed by SIP stack (User Request)", hSubs));
        return RV_OK;
    }

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromSubs(hSubs, &hPua);
	if (RV_OK != rv)
	{
		return rv;
	}

	/* Check if the Subs object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hSubs,
										RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return RV_OK;
	}

	/* Invoke the event in the PUA */
	return RvSimpleCltPuaSubsMsgReceivedEvHandler(hPua, eSimpleObjType, hSubs, hAppSubs, hNotify, hAppNotify, hMsg);
}


/*-----------------------------------------------------------------------*/
/*                         PUB-CLIENT CALLBACKS						     */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppPubClientStateChangedEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Pub-Client State Changed callback of the SIP Stack Subs.
 *          Checks if the given Pub-Client object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Arguments:
 * Input:   hPubClient - The SIP stack publish-client handle.
 *          hAppPubClient - The application handle for this publish-client.
 *          eNewState - The new state of the publish-client object.
 *          eReason - The reason for the change in state.
 * Output: None
 * Return Value: void
 ***************************************************************************/
void RVCALLCONV AppPubClientStateChangedEv(
                            IN  RvSipPubClientHandle            hPubClient,
                            IN  RvSipAppPubClientHandle         hAppPubClient,
                            IN  RvSipPubClientState             eNewState,
                            IN  RvSipPubClientStateChangeReason eReason)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromPubClient(hPubClient, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the Pub-Client object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hPubClient,
										RVSIP_COMMON_STACK_OBJECT_TYPE_PUB_CLIENT,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaPubClientStateChangedEvHandler(hPua, eSimpleObjType, hPubClient, hAppPubClient,
												 eNewState, eReason);
}

/***************************************************************************
 * AppPubClientExpiredEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Pub-Client Expired callback of the SIP Stack Subs.
 *          Checks if the given Pub-Client object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Arguments:
 * Input:   hPubClient - The SIP stack publish-client handle.
 *          hAppPubClient - The application handle for this publish-client.
 * Output: None
 * Return Value: void
 ***************************************************************************/
void RVCALLCONV AppPubClientExpiredEv(
                            IN  RvSipPubClientHandle            hPubClient,
                            IN  RvSipAppPubClientHandle         hAppPubClient)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromPubClient(hPubClient, &hPua);
	if (RV_OK != rv)
	{
		return;
	}

	/* Check if the Pub-Client object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hPubClient,
										RVSIP_COMMON_STACK_OBJECT_TYPE_PUB_CLIENT,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return;
	}

	/* Invoke the event in the PUA */
	RvSimpleCltPuaPubClientObjExpiredEvHandler(hPua, eSimpleObjType, hPubClient, hAppPubClient);
}


/***************************************************************************
 * AppPubClientMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Pub-Client Msg To Send callback of the SIP Stack Subs.
 *          Checks if the given Pub-Client object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Arguments:
 * Input:     hPubClient    - The sip stack publish-client handle
 *            hAppPubClient - The application handle for this publish-client.
 *            hMsg          - Handle to the outgoing message.
 * Output: None.
 * Return Value: RvStatus. Returning RV_ERROR_XXX will cease the sending of
 *                         the message.
 ***************************************************************************/
RvStatus RVCALLCONV AppPubClientMsgToSendEv(
                                   IN  RvSipPubClientHandle    hPubClient,
                                   IN  RvSipAppPubClientHandle hAppPubClient,
                                   IN  RvSipMsgHandle          hMsg)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromPubClient(hPubClient, &hPua);
	if (RV_OK != rv)
	{
		return rv;
	}

	/* Check if the Pub-Client object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hPubClient,
										RVSIP_COMMON_STACK_OBJECT_TYPE_PUB_CLIENT,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return RV_OK;
	}

	/* Invoke the event in the PUA */
	return RvSimpleCltPuaPubClientMsgToSendEvHandler(hPua, eSimpleObjType, hPubClient, hAppPubClient, hMsg);
}

/***************************************************************************
 * AppPubClientMsgReceivedEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Pub-Client Msg Received callback of the SIP Stack Subs.
 *          Checks if the given Pub-Client object is related to the SIMPLE PUA application.
 *          If it is, invokes the relevant event handler in the SIMPLE PUA.
 *
 * Arguments:
 * Input:     hPubClient    - The sip stack publish-client handle
 *            hAppPubClient - The application handle for this publish-client.
 *            hMsg          - Handle to the incoming message.
 * Output: None
 * Return Value: RvStatus. Returning RV_ERROR_XXX will cease the handling of
 *                         the received message.
 ***************************************************************************/
RvStatus RVCALLCONV AppPubClientMsgReceivedEv(
                                    IN  RvSipPubClientHandle    hPubClient,
                                    IN  RvSipAppPubClientHandle hAppPubClient,
                                    IN  RvSipMsgHandle          hMsg)
{
	RvSimpleCltCommonObjectType  eSimpleObjType = RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED;
	RvSimpleCltPuaHandle         hPua;
	RvStatus                     rv;

	/* Retrieve the PUA handle from the Subs object */
	rv = GetPuaFromPubClient(hPubClient, &hPua);
	if (RV_OK != rv)
	{
		return rv;
	}

	/* Check if the Pub-Client object is related to a SIMPLE PUA object */
	RvSimpleCltPuaIsRelatedObjEvHandler(hPua, (void*)hPubClient,
										RVSIP_COMMON_STACK_OBJECT_TYPE_PUB_CLIENT,
										&eSimpleObjType);
	if (eSimpleObjType == RVSIMPLECLT_COMMON_OBJECT_TYPE_UNDEFINED)
	{
		/* The event is not intended for the SIMPLE application */
		return RV_OK;
	}

	/* Invoke the event in the PUA */
	return RvSimpleCltPuaPubClientMsgReceivedEvHandler(hPua, eSimpleObjType, hPubClient, hAppPubClient, hMsg);
}


/***************************************************************************
 * AppTransactionOpenCallLegEv
 * ------------------------------------------------------------------------
 * General: Implementation to the Transaction Open Call-Leg callback of
 *          the SIP Stack Transaction.
 *          When a request that is suitable for opening a dialog is received
 *          (INVITE/ REFER/SUBSCRIBE-with no To tag), the Transaction layer
 *          asks the application whether to open a call-leg for this transaction.
 *          This function is used for rejecting incoming INVITEs by the
 *          SIP stack since the SIMPLE Client can handle only incoming
 *          SUBSCRIBE messages.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTranscMgr  - The handle of the new server transaction.
 *          pAppMgr     - The application context. You supply this context
 *                        when setting the event handles.
 *          hTransc     - The handle of the new server transaction.
 * OUT:     bOpenCalled - RV_TRUE if the application wishes that the stack
 *                        will handle the transaction in a call-leg context.
 *                        RV_FALSE otherwise.
 ***************************************************************************/
RvStatus RVCALLCONV AppTransactionOpenCallLegEv(
                             IN  RvSipTranscMgrHandle    hTranscMgr,
                             IN  void                   *pAppMgr,
                             IN  RvSipTranscHandle       hTransc,
                             OUT RvBool                 *bOpenCalled)
{
    RvChar strMethod[128] = "\0";

    RvSipTransactionGetMethodStr(hTransc,128,strMethod);

    if (strcmp(strMethod,"SUBSCRIBE") == 0)
    {
        *bOpenCalled = RV_TRUE;
    }
    else
    {
        *bOpenCalled = RV_FALSE;
    }

    RV_UNUSED_ARG(hTranscMgr);
    RV_UNUSED_ARG(pAppMgr);

    return RV_OK;
}

#endif /* RV_MTF_SIMPLE_ON */

