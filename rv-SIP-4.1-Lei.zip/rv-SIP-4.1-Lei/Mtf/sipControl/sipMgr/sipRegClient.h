#ifndef SIP_REG_CLIENT_H
#define SIP_REG_CLIENT_H

#include "rvccterminalsip.h"
#include "rvccapi.h"
#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSipRegClientTypes.h"
#include "RvSipRegClient.h"


RvBool rvSipControlRegClientCreateObject(
    IN  RvCCProvider*           p,
    IN  RvCCTerminal*           xTerm,
    IN  const RvChar*           scheme,
    IN  RvUint16                port,
										 OUT RvSipRegClientHandle	*regClientObj);


RvStatus rvSipControlRegClientSend(RvSipRegClientHandle		hRegClient);


RvStatus rvSipControlRegClientSetExpire(RvSipRegClientHandle	hRegClient, RvInt32 nExpire);

/***************************************************************************
 * rvSipControlRegClientSetTo
 * ------------------------------------------------------------------------
 * General: Set To value in Register Client Object
 *          
 * Return Value: RV_OK on success
 *				 RV_ERROR - on failure.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	hRegClient -  The sip stack register-client handle
 *
 *			toStr	   -  the new to string
 *
 ***************************************************************************/
RvStatus rvSipControlRegClientSetTo(IN RvSipRegClientHandle	hRegClient,
									IN char*				toStr);

/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/

void RVCALLCONV AppRegClientStateChangedEvHandler(
                           IN  RvSipRegClientHandle            hRegClient,
                           IN  RvSipAppRegClientHandle         hAppRegClient,
                           IN  RvSipRegClientState             eState,
                           IN  RvSipRegClientStateChangeReason eReason);

RvStatus RVCALLCONV AppRegClientMsgReceivedEvHandler(
	                       IN  RvSipRegClientHandle          hRegClient,
                           IN  RvSipAppRegClientHandle       hAppRegClient,
                           IN  RvSipMsgHandle                hMsg);

RvStatus RVCALLCONV AppRegClientMsgToSendEvHandler(
	                       IN  RvSipRegClientHandle          hRegClient,
                           IN  RvSipAppRegClientHandle       hAppRegClient,
                           IN  RvSipMsgHandle                hMsg);

const RV_CHAR*  getRegClientStateName (IN  RvSipRegClientState  eState);

RvBool rvSipControlIsSameNonce(IN char* receivedNonce,const char* previousNonCe);

/******************************************************************************************************************/
/*		F O R		S I M P L E		C O - E X I S T E N C E				O N L Y                                   */
/******************************************************************************************************************/



/***************************************************************************
 * AppSubsStateChangedEv
 ***************************************************************************/
void RVCALLCONV AppSubsStateChangedEv(
                                   IN  RvSipSubsHandle            hSubs,
                                   IN  RvSipAppSubsHandle         hAppSubs,
                                   IN  RvSipSubsState             eState,
                                   IN  RvSipSubsStateChangeReason eReason);

/***************************************************************************
 * AppSubsSubscriptionExpiredEv
 ***************************************************************************/
void RVCALLCONV AppSubsSubscriptionExpiredEv(
                                   IN  RvSipSubsHandle            hSubs,
                                   IN  RvSipAppSubsHandle         hAppSubs);

/***************************************************************************
 * AppSubsExpirationAlertEv
 ***************************************************************************/
void RVCALLCONV AppSubsExpirationAlertEv(
                                   IN  RvSipSubsHandle            hSubs,
                                   IN  RvSipAppSubsHandle         hAppSubs);

/***************************************************************************
 * AppSubsNotifyEv
 ***************************************************************************/
void RVCALLCONV AppSubsNotifyEv(
                                   IN  RvSipSubsHandle			hSubs,
                                   IN  RvSipAppSubsHandle		hAppSubs,
                                   IN  RvSipNotifyHandle		hNotification,
                                   IN  RvSipAppNotifyHandle		hAppNotification,
                                   IN  RvSipSubsNotifyStatus	eNotifyStatus,
                                   IN  RvSipSubsNotifyReason	eNotifyReason,
                                   IN  RvSipMsgHandle			hNotifyMsg);

/******************************************************************************
 * AppSubsCreatedDueToForkingEv
 *****************************************************************************/
RvStatus RVCALLCONV AppSubsCreatedDueToForkingEv(
                                  IN        RvSipSubsHandle    hSubs,
                                  INOUT     RvInt32            *pExpires,
                                  OUT       RvSipAppSubsHandle *phAppSubs,
                                  OUT       RvUint16           *pRejectStatus);

/***************************************************************************
 * AppSubsMsgToSendEv
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgToSendEv(
                                    IN    RvSipSubsHandle      hSubs,
                                    IN    RvSipAppSubsHandle   hAppSubs,
                                    IN    RvSipNotifyHandle    hNotify,
                                    IN    RvSipAppNotifyHandle hAppNotify,
                                    IN    RvSipMsgHandle       hMsg);

/***************************************************************************
 * AppSubsMsgReceivedEv
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgReceivedEv(
                                    IN  RvSipSubsHandle      hSubs,
                                    IN  RvSipAppSubsHandle   hAppSubs,
                                    IN  RvSipNotifyHandle    hNotify,
                                    IN  RvSipAppNotifyHandle hAppNotify,
                                    IN  RvSipMsgHandle       hMsg);

/*-----------------------------------------------------------------------*/
/*                         PUB-CLIENT CALLBACKS						     */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppPubClientStateChangedEv
 ***************************************************************************/
void RVCALLCONV AppPubClientStateChangedEv(
                            IN  RvSipPubClientHandle            hPubClient,
                            IN  RvSipAppPubClientHandle         hAppPubClient,
                            IN  RvSipPubClientState             eNewState,
                            IN  RvSipPubClientStateChangeReason eReason);

/***************************************************************************
 * AppPubClientExpiredEv
 ***************************************************************************/
void RVCALLCONV AppPubClientExpiredEv(
                            IN  RvSipPubClientHandle            hPubClient,
                            IN  RvSipAppPubClientHandle         hAppPubClient);

/***************************************************************************
 * AppPubClientMsgToSendEv
 ***************************************************************************/
RvStatus RVCALLCONV AppPubClientMsgToSendEv(
                                   IN  RvSipPubClientHandle    hPubClient,
                                   IN  RvSipAppPubClientHandle hAppPubClient,
                                   IN  RvSipMsgHandle          hMsg);

/***************************************************************************
 * AppPubClientMsgReceivedEv
 ***************************************************************************/
RvStatus RVCALLCONV AppPubClientMsgReceivedEv(
                                    IN  RvSipPubClientHandle    hPubClient,
                                    IN  RvSipAppPubClientHandle hAppPubClient,
                                    IN  RvSipMsgHandle          hMsg);

/***************************************************************************
 * AppTransactionOpenCallLegEv
 ***************************************************************************/
RvStatus RVCALLCONV AppTransactionOpenCallLegEv(
                             IN  RvSipTranscMgrHandle    hTranscMgr,
                             IN  void                   *pAppMgr,
                             IN  RvSipTranscHandle       hTransc,
                             OUT RvBool                 *bOpenCalled);


#endif /*SIP_REG_CLIENT_H*/
