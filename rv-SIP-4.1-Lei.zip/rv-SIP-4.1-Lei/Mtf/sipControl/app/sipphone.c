/******************************************************************************
Filename   : sipPhone.c
Description: Sip Phone Application
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "sipphone.h"
#include "sipControlInt.h"
#include "rvccterminalmdm.h"
#include "rvccprovidermdm.h"
#include "rvccconnmdm.h"
#include "rvccprovidersip.h"
#include "rvccterminalsip.h"
#include "rvccconnsip.h"
#include "rvcctext.h"
#include "rvmdmtermevent.h"
#include "rvstring.h"
#include "rvccCfwMgr.h"
#include "ippmisc.h"
#include "ippevexchange.h"

static RvBool sipPhoneRegisterAllTermsToNetwork(void);
static void rvCCSipPhoneDestruct(RvCCIPPhone* ipPhone);

/**********************************************************************************
                        G E T T E R S / S E T T E R S
**********************************************************************************/
/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
RvSipControl* rvCCSipPhoneGetSipMgr(void)
{
    RvCCProvider* provider = rvCCBasePhoneGetNetProvider();
    return rvCCProviderSipGetSipMgr(provider);
}


/**********************************************************************************
                        P R I V A T E       F U N C T I O N S
**********************************************************************************/

/***************************************************************************
 * findDestinationAddress
 * ------------------------------------------------------------------------
 * General: This function search for destination address according to the
 *          input address.
 * Return Value: Returns RvBool.
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   c           - connection
 *          address     - address
 *          destAddress - Pointer of dest address
 *          destAddressLen - Length of dest address.
 * output:  destAddress - destination address
 * Return: RvBool       - RvTrue is address was found, RvFalse, otherwise
 ***************************************************************************/
static RvBool findDestinationAddress(RvCCConnection *c, const char *address, char *destAddress, RvUint destAddressLen)
{
    RvCCTerminal    *t      = rvCCConnectionGetTerminal(c);
    RvCCTerminalMdm *term   = rvCCTerminalMdmGetImpl(t);
    RvMdmTerm       *mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
    RvChar          foundDestAddress[RV_IPP_ADDRESS_SIZE] = {0}; /* Initialize with NULL termination */
    RvChar          userScheme[RV_SHORT_STR_SZ]= {0};
	RvChar          tmpDestAddress[RV_IPP_ADDRESS_SIZE] = {0};	

	if (((strchr(address, '@') != NULL) || (strchr(address, '.') != NULL) || (strchr(address, ':') != NULL)))
    {
        /*if destination address is URI, just make call to this address*/
        strncpy(foundDestAddress, address, sizeof(foundDestAddress)-1);
        foundDestAddress[sizeof(foundDestAddress)-1] = '\0';
    }
    else if (rvMdmTermMapDialStringToAddress_(mdmTerm, address, foundDestAddress) == RV_FALSE)
	{
    /*If destination address is not URI, it must be phone number. In this
		case if Registrar is configured, send digits as username to Registrar*/
		RvChar *proxyAddress = rvSipControlGetRegistrarAddress(rvCCSipPhoneGetSipMgr());
		if (rvSipControlIsAddressEmpty(proxyAddress) == RV_FALSE)
		{
			RvSipControl* mgr = rvCCSipPhoneGetSipMgr();
			RvSnprintf(foundDestAddress,sizeof(foundDestAddress), "%s@%s:%d",address, proxyAddress,
				rvSipControlGetRegistrarPort(mgr));
		}
		else
		{
        /* Destination address is phone number and no Registrar is configured,
			can't make a call */
			return RV_FALSE;
		}
	}

    rvIppGetUserScheme(foundDestAddress, userScheme);
    /* Note: Meanwhile, there is no scheme validation. i.e, the user put another scheme... */
    /* Check if there is a scheme in the found address and if it not a proxy address  */
    if (userScheme[0] == '\0')
    {
		RvSnprintf(tmpDestAddress, sizeof(tmpDestAddress), "sip:%s", foundDestAddress);
		
        strncpy(foundDestAddress, tmpDestAddress, sizeof(foundDestAddress)-1);
        foundDestAddress[sizeof(foundDestAddress)-1] = '\0';
    }

    if (rvCCTerminalGetState(t) == RV_CCTERMINAL_CFW_ACTIVATING_STATE)
    {
        /* Update cfw address and state */
        rvCCCfwUpdateCfwAddress(t, foundDestAddress, (RvUint)strlen(foundDestAddress));
    }
    else
    {
        rvCCConnectionSetThirdPartyAddress(c, foundDestAddress);
    }

    RvSnprintf (destAddress, destAddressLen, "%s", foundDestAddress);
    return rvTrue;
}

/***************************************************************************
 * checkIfPortNumbersMatch
 * ------------------------------------------------------------------------
 * General: This function checks whether two port numbers match.
 *			Ports of 0 and 5060 are considered equivalent.
 *          
 * Return Value: True if it matches
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   firstPort	- first port number.
 *          secondPort  - second port number.
 *
 * output:  None
 * Return:  True if ports match.
 ***************************************************************************/
static RvBool checkIfPortNumbersMatch(RvUint16      firstPort,
									  RvUint16      secondPort)
{
    if ((firstPort == secondPort) || 
		((firstPort == 0) && (secondPort == RVSIPCTRL_DEFAULT_PORT)) || 
		((firstPort == RVSIPCTRL_DEFAULT_PORT) && (secondPort == 0)))
	{
        return rvTrue;
	}

	else
	{
		return rvFalse;
	}

}

/***************************************************************************
 * isLocalAddressMatch
 * ------------------------------------------------------------------------
 * General: This function checks whether local address + port matches the
 *          received address + port.
 * Return Value: True if it matches
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   sipControl  - pointer to sipControl
 *          address     - ip address
 *          port        - port number
 *
 * output:  None
 * Return: True if both address + port matches the local ones
 ***************************************************************************/
static RvBool isLocalAddressMatch(RvSipControl* sipControl,
                                  RvCCTerminal* t,
                                  char*         address,
                                  RvUint16      port)
{
	char comparedLocalAddress[RV_IPP_ADDRESS_SIZE]; /* address to be compared to given address */

    /* compare the addresses, and return rvFalse if they're different */

	strcpy(comparedLocalAddress,rvCCTerminalMdmGetLocalAddress(t));

#if (RV_NET_TYPE & RV_NET_IPV6)
    if (IppUtilIsIpV4(comparedLocalAddress) == RV_FALSE)
    {
		/* remove scope id from IPV6 address */
        IppUtilRemoveScopeIdFromIpv6String(comparedLocalAddress);
    }
#endif /* RV_NET_IPV6 */

	/* compare addresses and exit if they're not equal */
	if (strcmp(address, comparedLocalAddress) != 0)
	{
		return rvFalse;	
	}

	/* local and dialed addresses are identical, now compare ports */

#ifdef RV_CFLAG_TLS
    if (rvSipControlIsTlsEnabled(sipControl) == rvTrue)
    {
		/* compare TLS ports */
		if (checkIfPortNumbersMatch(rvIppTlsGetPort(), port) == RV_TRUE)
		{
			return rvTrue;
		}
    }
#endif

	/* compare TCP ports */
	if (checkIfPortNumbersMatch(sipControl->stackTcpPort, port) == RV_TRUE)
	{
		return rvTrue;
	}

	/* compare UDP ports */
	if (checkIfPortNumbersMatch(sipControl->stackUdpPort, port) == RV_TRUE)
	{
		return rvTrue;
	}

    return rvFalse;
}

/***************************************************************************
 * rvCCSipPhoneIsRegistrarAddressMatch
 * ------------------------------------------------------------------------
 * General: This function checks whether Registrar address + port matches the
 *          received address + port.
 * Return Value: True if it matches
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   sipControl  - pointer to sipControl
 *          address     - ip address
 *          port        - port number
 *
 * output:  None
 * Return: True if both address + port matches the registrar's address + port
 ***************************************************************************/
static RvBool rvCCSipPhoneIsRegistrarAddressMatch(RvSipControl* sipControl, char* address, RvUint16 port)
{
    if (port == 0)
        port = 5060;

    if ((!strcmp(address, rvSipControlGetRegistrarAddress(sipControl))) &&
        (rvSipControlGetRegistrarPort(sipControl) == port))
        return rvTrue;

    return rvFalse;
}


/***************************************************************************
 * rvCCSipPhoneIsCallingMyself
 * ------------------------------------------------------------------------
 * General: This function checks whether user called himself.
 *          User called himself if username equals termination id, and if
 *          address either equals local address or registrar address.
 *
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   c           - connection
 *          address     - address
 *          destAddress - destination address to fill.
 * output:  reason      - event cause
 * Return Value: Returns True if this is a self call.
 ***************************************************************************/
static RvBool rvCCSipPhoneIsCallingMyself(RvCCConnection* c, char* destAddress)
{
    RvSipControl* sipControl = rvCCSipPhoneGetSipMgr();
    RvCCTerminal* t = rvCCConnMdmGetTerminal(c);
    char username[RV_NAME_STR_SZ];
    char ipAddress[RV_IPP_ADDRESS_SIZE];
    RvUint16 port;

    rvSipMgrGetUserNameFromUrl(destAddress, username);
    rvSipMgrGetHostFromUrl(destAddress, ipAddress, sizeof(ipAddress));
    port = rvSipMgrGetPortFromUrl(destAddress);

    /* Return True, if both conditions are true:
       1. (username == term id)
       2. (address == local address) or (address == registrar address)*/
    if ((!strcmp(rvCCTerminalGetId(t), username)) &&
        ((isLocalAddressMatch(sipControl, t, ipAddress, port)) ||
         (rvCCSipPhoneIsRegistrarAddressMatch(sipControl, ipAddress, port))))
    {
            return rvTrue;
    }

    return rvFalse;

}

/***************************************************************************
 * createNewSipConnection
 * ------------------------------------------------------------------------
 * General: This function create new sip connection
 * Return Value: Returns new connection.
 * ------------------------------------------------------------------------
 * Arguments:
 * input:   c           - connection
 *          address     - address
 *          destAddress - destination address to fill.
 * output:  reason      - event cause
 * Return: new created connection
 ***************************************************************************/
RvCCConnection* createNewSipConnection(RvCCConnection* c, const char* address,
                                              RvCCEventCause* reason)
{
    RvCCProvider* p = rvCCBasePhoneGetNetProvider();
    RvCCCall* call = rvCCConnectionGetCall(c);
    RvCCTerminal* t = rvCCConnectionGetTerminal(c);
    const RvChar* termId = rvCCTerminalGetId(t);
    RvCCTerminal* ts = rvCCProviderSipFindTerminalById(p, termId);
    RvCCConnection* newConn=NULL;
    char localAddress[RV_SIPCTRL_ADDRESS_SIZE];
    char destAddress[RV_IPP_ADDRESS_SIZE];

    if (call != NULL)
    {
        rvCCCallLock(c->call);
    }

    memset(destAddress, 0, sizeof(destAddress));
    if (findDestinationAddress(c, address, destAddress, sizeof(destAddress)) == rvFalse)
    {
        *reason = RV_CCCAUSE_NOT_FOUND; /* Destination not found */
        if (call != NULL)
        {
            rvCCCallUnlock(c->call);
        }
        return NULL;
    }

    /* Check whether the call is addressed to me, no point in letting it through */
    if (rvCCSipPhoneIsCallingMyself(c, destAddress) == rvTrue)
    {
        *reason = RV_CCCAUSE_BUSY;
        if (call != NULL)
        {
            rvCCCallUnlock(c->call);
        }
        return NULL;
    }

    if ((newConn = rvCCProviderSipCreateConnection(p, ts)) != NULL)
    {
        RvCCProviderSip* provider = rvCCProviderSipGetImpl(p);

        if (call != NULL)
        {
            rvCCCallAddParty(call, newConn);
        }

        /*Set destination address*/
        rvCCConnSipSetRemoteAddress(newConn, destAddress);
        /*Set source address - for now set the default one*/
        if ((termId != NULL) && (strcmp(termId, "")))
        {
            RvSnprintf(localAddress,RV_SIPCTRL_ADDRESS_SIZE, "%s@%s", termId, provider->localAddress);
            rvCCConnSipSetLocalAddress(newConn, localAddress);
        }
        else
        {
            rvCCConnSipSetLocalAddress(newConn, provider->localAddress);
    }
    }
    if (call != NULL)
    {
        rvCCCallUnlock(c->call);
    }
    return newConn;
}




#if 0
/******************************************************************************
*  createNewMdmConnection
*  ---------------------------------
*  General : This proc is invoked when a call in received by the MTF.
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static RvCCConnection* createNewMdmConnection(RvCCConnection* c, const char* address,
                                              RvCCEventCause* reason)
{
    RvCCProvider*   p           = rvCCBasePhoneGetMdmProvider();
    RvCCCall*       call        = rvCCConnectionGetCall(c);
    RvCCConnection* newConn     = NULL;

    RvCCTerminal*   t_ = rvCCConnSipGetTerminal(c);
	RvCCTerminalSip* term;
	char*           termId = NULL;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- createNewMdmConnection(conn:%p, addr:%s, reason:%s )",c, address, rvCCTextCause(*reason)));


	/* Get the terminal id from the RvCCterminal. This is the Call's actual terminal id as was
	   mapped by the user application. The mapping was done by callback rvMdmTermMgrMapAddressToTermination_
	   when the connection was initialized  */
	if (t_ != NULL)
	{
		term = rvCCTerminalSipGetImpl(t_) ;
		termId = rvCCTerminalSipGetTermId(term);
	}

    if (c->call != NULL)
        rvCCCallLock(c->call);

    if (termId != NULL)
    {
        RvCCTerminal* t = rvCCProviderFindTerminalByTermId(p, termId);
        RvLogDebug(ippLogSource,(ippLogSource,"createNewMdmConnection::rvCCProviderFindTerminalByTermId(p:%p, termId:%s)",p, termId));
        if (t != NULL)
        {
            if ((newConn = rvCCProviderMdmCreateConnection(p, t)) != NULL)
                rvCCCallAddParty(call, newConn);
            else
				/* In this case no more free lines are available */
                *reason = RV_CCCAUSE_BUSY;
        }
        else
			/* In this case the termination can not be found */
            *reason = RV_CCCAUSE_NOT_FOUND;
    }
    else
        *reason = RV_CCCAUSE_NOT_FOUND;

    if (c->call != NULL)
    {
        rvCCCallUnlock(c->call); 
    }

    RvLogDebug(ippLogSource,(ippLogSource,"--> createNewMdmConnection newConn:%p", newConn));
    return newConn;
}




/******************************************************************************
*  sipTermGetRegistrationState
*  ---------------------------------
*  General : specifies a sip terminal registration state
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipt              sip call control Terminal (NOT implementation)
*
*  Output:         none.
******************************************************************************/
static RvNetworkRegisterState sipTermGetRegistrationState(RvCCTerminal *sipt)
{
    if (sipt != NULL)
    {
        RvCCTerminalSip* sipTerm = rvCCTerminalSipGetImpl(sipt);
        return sipTerm->networkRegisterState;
    }

    return ((RvNetworkRegisterState)RV_ERROR_UNKNOWN);
}
#endif   /* end #if 0 */


/**********************************************************************************
                C A L L B A C K S    I M P L E M E N T A T I O N S
**********************************************************************************/


/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************
static void getDialedDigit(RvCCConnection* x, char* digit)
{
    RvCCTerminalMdm* term = rvCCConnMdmGetTerminalImpl(x);
    RvMdmEvent* event;
    const RvMdmParameterList *args;
    const RvMdmParameterValue* value;
    const char* id;

    event = rvCCTerminalMdmGetLastEvent(term);
    args = rvMdmEventGetParameterList(event);
    value = rvMdmParameterListGet2(args, "keyid");

    id = rvMdmParameterValueGetValue(value);

    digit[0] = id[1];
    digit[1] = '\0';
}
*/

/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static void* getSipPhoneFromXMgr(RvMdmXTermMgr * x)
{
    RvCCProvider* p = (RvCCProvider*)x;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvMdmTermMgr* mgr = provider->mdmTermMgr;
    return mgr->xApp;
}

/******************************************************************************
* rvCCSipPhoneFinishTermUnregistrationProcess
*  ---------------------------------
*  General : finish un-registration process for UI or Analog termination.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipt   - termination that is going to accomplish un-registration
*  Output:         none.
******************************************************************************/
void rvCCSipPhoneFinishTermUnregistrationProcess(RvCCTerminal*  sipt)
{
    RvCCTerminalSip* sipTerm = rvCCTerminalSipGetImpl(sipt);
    RvCCTerminal*    mdmt = (RvCCTerminal *)sipTerm->mdmXTerm;
    RvCCTerminalMdm* mdmTerm = NULL;
    RvCCProvider*    mdmProvider = NULL;
    RvCCProvider*    sipProvider= rvCCBasePhoneGetNetProvider();
    RvCCTerminalType type = RV_CCTERMINALTYPE_UNKNOWN;
    IppTimer*   registerTimer = rvCCTerminalSipGetRegisterTimer(sipTerm);

	if (mdmt != NULL)
	{
		mdmTerm = rvCCTerminalMdmGetImpl(mdmt);
		mdmProvider = mdmTerm->provider;
		type       = rvCCTerminalMdmGetType(mdmTerm);
	}
    IppTimerStop(registerTimer);

    if (rvCCTerminalSipGetToolkitRegisterState(sipTerm) == RV_TERM_TOOLKIT_REG_STATE_UNREGISTERING)
    {
        /* The last things to do when the request to unregister was coming from the toolkit and not from the network
           is to unregister from providers and deallocate      */
        rvSipProviderUnregisterTerm(sipProvider, sipt, type);
		rvMtfUnregisterPhysTermDone(mdmt);
    }
    else
    {
        /* Inform the application that Terminal was unregistered from network (or "timed out") */
		if (mdmt != NULL)
		{
			rvMdmTermUnregisterTermFromNetworkDone_(&mdmTerm->mdmTerm);
		}
        rvCCTerminalSipSetToolkitRegisterState(sipTerm, RV_TERM_TOOLKIT_REG_STATE_NONE);
    }
    return;
}


/******************************************************************************
*  sipPhoneRegisterTermToNetwork
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static RvBool sipPhoneRegisterTermToNetwork(RvMdmTerm* mdmTerm,
                                     const char* termId,
                                     RvCCTerminalType type)
{
    RV_UNUSED_ARG(mdmTerm);

    if ((type == RV_CCTERMINALTYPE_UI) || (type == RV_CCTERMINALTYPE_ANALOG))
    {
        RvCCProvider*           p;
        RvCCTerminal*           xTerm;
        RvCCTerminalSip*        term;
        RvSipControl*           sipControl;
		RvBool                  res = RV_TRUE;

        p = rvCCBasePhoneGetNetProvider();
        if(!p)
            goto err_exit;
        xTerm = rvCCProviderSipFindTerminalById(p, termId);
        if(!xTerm)
            goto err_exit;
        term = rvCCTerminalSipGetImpl(xTerm);
        if(!term)
            goto err_exit;

        sipControl = rvCCSipPhoneGetSipMgr();

        /* Link MDM Terminal to SIP terminal.  */
        term->mdmXTerm = mdmTerm->xTerm;

        res = rvSipControlRegisterClient(term); /* the function logs an error */
		if (res == RV_TRUE)
		{
			rvCCTerminalSipSetRegType(term, RV_TERM_NETWORK_REG_TYPE_REGISTERING);
		}
    }

    return RV_TRUE;
err_exit:
    RvLogError(ippLogSource,(ippLogSource,"sipPhoneRegisterTermToNetwork() failed. termId = %s,type = %d", termId, type));
    return RV_FALSE;
}

/******************************************************************************
*  sipPhoneUnregisterTermFromNetwork
*  ---------------------------------
*  General : Unregister UI or ANALOG terminal from network
*
*  Return Value:   rvFalse - if SIP Phone did non started
*                  rvTrue  - all other cases.
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipPhone  - pointer to SIP Phone object
*                  mdmXt      - mdm X terminal (not implementation)
*                  sipXt      - sip X terminal (not implementation)
*  Output:         none.
******************************************************************************/
static RvBool sipPhoneUnregisterTermFromNetwork(RvCCTerminal* mdmXt,RvCCTerminal* sipXt)
{
    RvCCTerminalMdm* mdmTerm = rvCCTerminalMdmGetImpl(mdmXt);
    RvBool res=rvTrue;

    if ((rvCCTerminalMdmGetType(mdmTerm) == RV_CCTERMINALTYPE_UI) ||
        (rvCCTerminalMdmGetType(mdmTerm) == RV_CCTERMINALTYPE_ANALOG))
    {
        RvCCTerminalSip* sipTerm = rvCCTerminalSipGetImpl(sipXt);

        /* send Unregistration ONLY if the terminal is Registered */
        if (sipTerm->networkRegisterState == RV_TERM_NETWORK_REG_STATE_REGISTERED)
        {
            rvCCTerminalSipSetRegType(sipTerm, RV_TERM_NETWORK_REG_TYPE_UNREGISTERING);
            res = rvSipControlUnregisterClient(sipTerm);	
			if (res == RV_TRUE)
			{
				/* Start a timer to complete unregistration in case the server does not respond fast enough */
				 RvCCTerminalSip* sipTerm = rvCCTerminalSipGetImpl(sipXt);
				 IppTimerStart(&sipTerm->registerTimer, IPP_TIMER_RESTART_IF_STARTED, rvCCTerminalSipGetUnregisterTimeout(sipTerm));
			}
        }
    }

    return res;
}

/******************************************************************************
*  registerTermToNetwork
*  ----------------------------
*  General :        This function registers a termination to Proxy.
*                   It is called when the user is calling rvMdmTermMgrRegisterTermToNetwork_().
*
*  Return Value:    RvTrue  - if terminal was registered successfully.
*                   RvFalse - if termination failed to register.
*  ----------------------------------------------------------------------------
*  Arguments:       xTerm               pointer to sipPhone
*                   mdmTerm             pointer to mdmTerm
*  Output:          none.
******************************************************************************/
static RvBool registerTermToNetwork(RvMdmXTermMgr * xTerm, RvMdmTerm* mdmTerm)
{
    RvBool result = rvFalse;
    RvCCIPPhone* ipPhone = (RvCCIPPhone *)getSipPhoneFromXMgr(xTerm);

    if (ipPhone)
    {
        RvCCTerminal* t = (RvCCTerminal*)mdmTerm->xTerm;
        RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
        RvCCTerminalType type = rvCCTerminalMdmGetType(term);
        const char* id = rvCCTerminalMdmGetId(term);
        result = sipPhoneRegisterTermToNetwork(mdmTerm, id, type);
    }

    return result;
}

/******************************************************************************
*  registerAllTermsToNetwork
*  ----------------------------
*  General :        This function registers all terminations to Proxy.
*                   It is called when registration time, defined by RegistrationExpire
*                   parameter, or by the user using rvMdmTermMgrRegisterAllTermsToNetwork_().
*
*  Return Value:    RvTrue  - if all terminals registered successfully.
*                   RvFalse - if at least one termination failed to register.
*  ----------------------------------------------------------------------------
*  Arguments:       xTerm              pointer to sipPhone
*  Output:          none.
******************************************************************************/
static RvBool registerAllTermsToNetwork(RvMdmXTermMgr * xTerm)
{
    RvBool result=rvFalse;  /* init as failure */
    RvCCIPPhone* ipPhone = (RvCCIPPhone *)getSipPhoneFromXMgr(xTerm);

    if (ipPhone)
    {
        result = sipPhoneRegisterAllTermsToNetwork();
    }

    return result;
}

/******************************************************************************
*  sipPhoneRegisterAllTermsToNetwork
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static RvBool sipPhoneRegisterAllTermsToNetwork(void)
{
    RvCCProvider*       p                   = rvCCBasePhoneGetMdmProvider();
    RvCCProviderMdm*    provider            = rvCCProviderMdmGetImpl(p);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter = NULL;
    RvBool              result              = rvTrue;

    for (iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        const char* termId = *rvMapIterGetKey(RvCharPtr,RvCCTerminalPtr)(iter);
        RvCCTerminal** pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        RvCCTerminal* t = *pt;
        RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
        RvMdmTerm* mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
        RvCCTerminalType type = rvCCTerminalMdmGetType(term);
        const char* id = rvCCTerminalMdmGetId(term);

        if ((result = sipPhoneRegisterTermToNetwork(mdmTerm, id, type)) == rvFalse)
        {
            result = rvFalse;
			RvLogError(ippLogSource,(ippLogSource,"Client Registration failed for: %s", termId));
        }
    }

    return result;
}

/******************************************************************************
*  unregisterTermFromNetwork
*  ----------------------------
*  General :        This function unregisters a termination to Proxy.
*                   It is called when the user is calling rvMdmTermMgrUnregisterTermFromNetwork_().
*
*  Return Value:    RvTrue  - if terminal was unregistered successfully.
*                   RvFalse - if termination failed to unregister.
*  ----------------------------------------------------------------------------
*  Arguments:       xTerm               pointer to sipPhone
*                   mdmTerm             pointer to mdmTerm
*  Output:          none.
******************************************************************************/
static RvBool unregisterTermFromNetwork(RvMdmXTermMgr * x,RvMdmTerm *term)
{
    RvBool          result      = rvFalse;
    RvCCProvider*    sipProvider= rvCCBasePhoneGetNetProvider();
    RvCCProvider*   mdmProvider = rvCCBasePhoneGetMdmProvider();

    /* Check if it is possible to perform un-registration.
    I.e, check if the termination is alive */
    /* Find out if specific terminal exists in the mdm provider terminal list */
    if (rvCCProviderMdmFindIfTerminalExist(mdmProvider, term) == rvFalse)
    {
        /* Impossible to perform unregister. The termination is not alive */
        result = rvFalse;
    }
    else
    {
        RvCCTerminal*    mdmt       = (RvCCTerminal*)(term->xTerm);
        const RvChar*    termId     = rvCCTerminalGetId(mdmt);
        RvCCTerminal*    sipt       = rvCCProviderSipFindTerminalById(sipProvider, termId);
        RvCCTerminalSip* sipTerm=NULL;
        IppTimer*        timer=NULL;
        RvCCIPPhone*     ipPhone = (RvCCIPPhone *)getSipPhoneFromXMgr(x);

        if (sipt)
        {
            sipTerm = rvCCTerminalSipGetImpl(sipt);
            timer = &sipTerm->registerTimer;

            /* Link mdmXTerm to sipTerm. It will be used when
            * UI and Analog terminals accomplish un-registration
            * (rvCCSipPhoneFinishTermUnregistrationProcess).
            */
            sipTerm->mdmXTerm = term->xTerm;

            if (ipPhone)
            {
                result = sipPhoneUnregisterTermFromNetwork(mdmt, sipt);
            }

            /* the un-registration process will be completed later: after OK from proxy or Timeout */

            IppTimerStart(timer, IPP_TIMER_RESTART_IF_STARTED, rvCCTerminalSipGetUnregisterTimeout(sipTerm));
        }
    }
    return(result);
}



/******************************************************************************
*  sipPhoneRegisterPhysTerm
*  ---------------------------------
*  General : Do registration with sip registrar for every physical terminal
*            that registers
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static RvMdmTerm* sipPhoneRegisterPhysTerm(
    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties)
{
    RvMdmTerm* mdmTerm;

    mdmTerm = rvMdmProviderRegisterPhysTerm(x, c, id, termProperties);
    if (mdmTerm != NULL)
    {
        RvCCIPPhone*     ipPhone = (RvCCIPPhone *)getSipPhoneFromXMgr(x);
        RvCCProvider* sipProvider = rvCCBasePhoneGetNetProvider();
		RvCCProviderSip* sipProviderImpl = rvCCProviderSipGetImpl(sipProvider);
        RvCCTerminalType type = rvCCProviderMdmFindTerminalType(c, id);
        RvCCTerminal* t = rvSipProviderRegisterTerm(sipProvider, id, type, termProperties);
        RvCCTerminalSip* term=NULL;
        IppTimer* timer=NULL;

        /* Get and start registration timer only for UI and analog terminations
           (t will be NULL for audio terminations*/
        if (t == NULL)
            return mdmTerm;

        term = rvCCTerminalSipGetImpl(t);
        timer = rvCCTerminalSipGetRegisterTimer(term);

        /* Link MDM Terminal to SIP terminal.  */
        term->mdmXTerm = mdmTerm->xTerm;

        if ((ipPhone != NULL) && (sipProviderImpl->autoRegister == RV_TRUE))
        {
            /* Register termination to Proxy */
            sipPhoneRegisterTermToNetwork(mdmTerm, id, type);
        }
        else if (timer->callback != NULL)
        {
            /*  check that we have a timer callback function to start */
            IppTimerStart(timer, IPP_TIMER_RETURN_IF_STARTED, 0);
        }
    }

    return mdmTerm;
}

void sipPhoneRegisterPhysTermAsyncStep(
    IN RvMdmTerm*					mdmTerm,
    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties,
    IN void*                        userData)
{
    RV_UNUSED_ARG(userData);
	if (mdmTerm != NULL)
    {
        RvCCIPPhone*     ipPhone = (RvCCIPPhone *)getSipPhoneFromXMgr(x);
        RvCCProvider* sipProvider = rvCCBasePhoneGetNetProvider();
		RvCCProviderSip* sipProviderImpl = rvCCProviderSipGetImpl(sipProvider);
        RvCCTerminalType type = rvCCProviderMdmFindTerminalType(c, id);
        RvCCTerminal* t = rvSipProviderRegisterTerm(sipProvider, id, type, termProperties);
        RvCCTerminalSip* term=NULL;

        /* Get and start registration timer only for UI and analog terminations
           (t will be NULL for audio terminations*/
        if (t == NULL)
            return;

        term = rvCCTerminalSipGetImpl(t);

        /* Link MDM Terminal to SIP terminal.  */
        term->mdmXTerm = mdmTerm->xTerm;

        /* Register termination to Proxy*/
        if ((ipPhone != NULL) && (sipProviderImpl->autoRegister == RV_TRUE))
        {
            sipPhoneRegisterTermToNetwork(mdmTerm, id, type);
        }
        /* Start registration timer only for UI and analog terminations
           (t will be NULL for audio terminations*/
        else if (t != NULL)
        {
            RvCCTerminalSip* term = rvCCTerminalSipGetImpl(t);
            IppTimer* timer = rvCCTerminalSipGetRegisterTimer(term);
            if (timer->callback)
                IppTimerStart(timer, IPP_TIMER_RETURN_IF_STARTED, 0);
        }
    }
}

static RvMdmTerm* sipPhoneRegisterPhysTermAsync(

    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties,
    IN void*                        userData)
{
    RvMdmTerm* mdmTerm;

    mdmTerm = rvMdmProviderRegisterPhysTermAsync(x, c, id, termProperties, userData);
	sipPhoneRegisterPhysTermAsyncStep(mdmTerm,x,c,id,termProperties,userData);
    return mdmTerm;

}
/******************************************************************************
*  sipPhoneUnregisterPhysTerm
*  ---------------------------------
*  General : unregister physical termination
*
*  Return Value:   rvTrue
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x     -  MDM terminal manager, actually MDM provider
*                  xTerm -  MDM terminal. (contains information about MDM terminal manager)
*  Output:         none.
******************************************************************************/
RvBool sipPhoneUnregisterPhysTerm(IN RvMdmXTermMgr* x, IN RvMdmXTerm* xTerm)
{
    RvCCTerminal*    mdmt       = (RvCCTerminal*)xTerm;
    RvCCTerminalMdm* mdmTerm    = rvCCTerminalMdmGetImpl(mdmt);
    RvCCProvider*    sipProvider= rvCCBasePhoneGetNetProvider();
	RvCCProvider*	 mdmProvider = rvCCTerminalMdmGetProvider(mdmTerm);
	RvCCProviderMdm* providerMdm = rvCCProviderMdmGetImpl(mdmProvider);
    const RvChar*    termId;
    RvCCTerminalType type;
    RvCCTerminal*    sipt;
    RvCCTerminalSip* sipTerm=NULL;
    IppTimer*        timer=NULL;
	RvBool           res = RV_TRUE;

    termId      = rvCCTerminalGetId(mdmt);
    type        = rvCCTerminalMdmGetType(mdmTerm);

	/* Handle UI and ANALOG terminals unregistration differently than
	   the other terminals. don't call rvMdmTermUnregisterTermDone_() and 
       rvMdmProviderUnregisterTerm(), it will be done later by proc 
	   rvMtfUnregisterPhysTermDone() */
	if ((type == RV_CCTERMINALTYPE_UI) ||
		(type == RV_CCTERMINALTYPE_ANALOG))
		
    {
		sipt    = rvCCProviderSipFindTerminalById(sipProvider, termId);
		if (!sipt)
		{
			return res;
		}
		sipTerm = rvCCTerminalSipGetImpl(sipt);
		if ((!sipTerm) || (!providerMdm) || (!mdmTerm))
		{
			return res;
		}

		/* Initialize the toolkitRegisterState to notify that the origin of the request
		is the toolkit and not the network */
		rvCCTerminalSipSetToolkitRegisterState(sipTerm, RV_TERM_TOOLKIT_REG_STATE_UNREGISTERING);

		res = sipPhoneUnregisterTermFromNetwork(mdmt, sipt);

		/* If register request was not sent, finish the unregister process now.
		   If persistent registration is enabled the unregistration is completed immediately.
		   Otherwise - let the unregistration from the network complete.
		   Proc rvCCSipPhoneFinishTermUnregistrationProcess() will be called later on when 
		   unregistration ends */
		   
		if ((res == RV_FALSE) || 
			(providerMdm->persistentRegisterEnabled == RV_TRUE) ||
			(sipTerm->networkRegisterState != RV_TERM_NETWORK_REG_STATE_REGISTERED))
		{				
			timer = &sipTerm->registerTimer;
			/* stop the timer if we have it. We don't need it any more  */
			if (timer)
				IppTimerStop(timer);
			/* stop the register complete timer if it is still running */
			IppTimerStop(&mdmTerm->registerCompleteTimer);

			/* Link mdmXTerm to sipTerm. It will be used when
			 * UI and Analog terminals accomplish Deregistration
			 * (rvCCSipPhoneFinishTermUnregistrationProcess).
			 */
			sipTerm->mdmXTerm = xTerm;
			rvSipProviderUnregisterTerm(sipProvider, sipt, type);
			rvMtfUnregisterPhysTermDone(mdmt);
		}
    }
	else
    {
        if (type != RV_CCTERMINALTYPE_EPHEMERAL)
        {
            /* Inform the application that Terminal was unregistered from network */
            rvMdmTermUnregisterTermDone_(&mdmTerm->mdmTerm);
        }     

        rvMdmProviderUnregisterTerm(x, xTerm);
    }

    return res;
}

/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static void sipPhoneSetMediaCaps(void* mgr_,RvMdmTermClass * rtpClass)
{
	/* Get the media from the rtp class */
    RvMdmMediaDescriptor* media = rvMdmTermClassGetMediaCapabilites_(rtpClass);
    RvMdmStreamDescriptor* caps = (RvMdmStreamDescriptor*)rvMdmMediaDescriptorGetStream(media, 0);
    RV_UNUSED_ARG(mgr_);

    /* Set the media in the provider */
    rvCCProviderSipSetMediaCaps(rvCCBasePhoneGetNetProvider(),caps);
}


/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static void sipPhoneStop(IN RvMdmXTermMgr* x)
{
	
    RvCCProvider*       p = rvCCBasePhoneGetNetProvider();
	RvCCProviderSip*    provider= rvCCProviderSipGetImpl(p);
	RvStatus            status;

	RV_UNUSED_ARG(x);

	/* Destruct the watchdog timer */
	/* It is done here and not in rvCCProviderSipDestruct() because by the time that proc
	   is invoked the timer process is already stopped */
	if(provider->watchdogTimeout > 0)
    {
        status = IppTimerDestruct(&provider->watchdogTimer);
        if(status!=RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipDestruct::IppTimerDestruct watchdogTimer(%x), error = %d",provider->watchdogTimer,status));
        }
    }
	ProtocolThreadStop();
}


/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static void sipPhoneMgrDestruct(RvMdmTermMgr *  mgr) 
{
    rvCCSipPhoneDestruct(mgr->xApp);
	rvMtfAllocatorDealloc(mgr->xApp, sizeof(RvCCIPPhone));

    /*rvCCBasePhoneConstruct should be called first when user initiates the toolkit,
      and rvCCBasePhoneDestruct should be called last*/
    rvCCBasePhoneDestruct(rvCCBasePhoneGetBasePhone());
}


/******************************************************************************
*
*  ---------------------------------
*  General :
*
*                   .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          xxxxx              yyyyyyy
*
*  Output:         none.
******************************************************************************/
static void rvCCSipPhoneDestruct(RvCCIPPhone* x)
{
	RV_UNUSED_ARG(x);
    rvCCProviderMdmDestruct(rvCCBasePhoneGetMdmProvider());
    rvCCProviderSipDestruct(rvCCBasePhoneGetNetProvider());
}


void rvCCSipPhoneGetCallback(
    OUT RvMdmXTermMgrClbks*       xTermMgrClbks)
{
    xTermMgrClbks->registerPhysTermF = sipPhoneRegisterPhysTerm;
    xTermMgrClbks->registerPhysTermAsyncF = sipPhoneRegisterPhysTermAsync;
    xTermMgrClbks->unregisterTermF = sipPhoneUnregisterPhysTerm;

    xTermMgrClbks->mediaCapsUpdatedF = sipPhoneSetMediaCaps;
    xTermMgrClbks->registerAllTermsToNetworkF = registerAllTermsToNetwork;
    xTermMgrClbks->registerTermToNetworkF = registerTermToNetwork;
    xTermMgrClbks->unregisterTermFromNetworkF = unregisterTermFromNetwork;

    xTermMgrClbks->startF = NULL;
    xTermMgrClbks->stopF  = sipPhoneStop;
    xTermMgrClbks->destructF = sipPhoneMgrDestruct;
}


/******************************************************************************
*  rvCCSipPhoneSetFromAddress
*  ----------------------------
*  General :      Set "from" Address - the address of EP,
*                 from where the message was sent.
*  Return Value:   none
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          legHandle - app call handle (actually call control connection)
*                  from      - IP address string to set
*  Output:         none.
******************************************************************************/
void rvCCSipPhoneSetFromAddress(RvSipAppCallLegHandle legHandle, char *from)
{
   RvCCConnection *c = (RvCCConnection *)legHandle;
   RvCCConnSip* conn = rvCCConnSipGetIns(c);

   /* TODO: We might rather want to return an error here if we're out of bounds...*/
   strncpy(conn->fromAddress, from, sizeof(conn->fromAddress)-1);
   conn->fromAddress[sizeof(conn->fromAddress)-1] = '\0';
}
void rvCCIPPhoneAddSIP(
    IN RvMdmTermMgr*        termMgr,
    IN RvMtfSipPhoneCfg*	cfg,
	IN RvSipStackHandle     stackHandle)
{
	/*Signal that we will use SIP*/
	rvCCBasePhoneUse();

    /*Create Sip Provider*/
    /*-------------------*/
    rvCCProviderSipConstruct(rvCCBasePhoneGetNetProvider(), rvCCBasePhoneGetCallMgr(), stackHandle, cfg, ((RvCCIPPhone*)termMgr->xApp)->a);

    /*Register SIP Connection callbacks*/
    rvCCProviderSipRegisterAddressAnalyzeCB(rvCCBasePhoneGetNetProvider(), addressAnalyzeCB);
    rvCCProviderSipRegisterInProcessCB(rvCCBasePhoneGetNetProvider(), inProcessCB);
}

RvBool isSipAddress(const char* address)
{
	char* schemes[]={"sip:","sips:"};
	RvUint32 i;

	for (i=0;i<sizeof(schemes)/sizeof(schemes[0]);i++)
	if (!strncmp(address,schemes[i], strlen(schemes[i])))
		return RV_TRUE;
	return RV_FALSE;
}

void mapSipAddress(const char* address, char* destAddress)
{
	RV_UNUSED_ARGS(address);
	RV_UNUSED_ARGS(destAddress);
}

 RvBool getDestinationAddress(const char *address, char *destAddress, RvUint destAddressLen)
{

    RvChar          foundDestAddress[RV_IPP_ADDRESS_SIZE] = {0}; /* Initialize with NULL termination */
    RvChar          userScheme[RV_SHORT_STR_SZ]= {0};
	RvChar          tmpDestAddress[RV_IPP_ADDRESS_SIZE] = {0};	
	if (((strchr(address, '@') != NULL) || (strchr(address, '.') != NULL) || (strchr(address, ':') != NULL)))
    {
        /*if destination address is URI, just make call to this address*/
        strncpy(foundDestAddress, address, sizeof(foundDestAddress)-1);
        foundDestAddress[sizeof(foundDestAddress)-1] = '\0';
    }
    else
	{
    /*If destination address is not URI, it must be phone number. In this
		case if Registrar is configured, send digits as username to Registrar*/
		RvChar *proxyAddress = rvSipControlGetRegistrarAddress(rvCCSipPhoneGetSipMgr());
		if (rvSipControlIsAddressEmpty(proxyAddress) == RV_FALSE)
		{
			RvSipControl* mgr = rvCCSipPhoneGetSipMgr();
			RvSnprintf(foundDestAddress,sizeof(foundDestAddress), "%s@%s:%d",address, proxyAddress,
				rvSipControlGetRegistrarPort(mgr));
		}
		else
		{
        /* Destination address is phone number and no Registrar is configured,
			can't make a call */
			return RV_FALSE;
		}
	}

    rvIppGetUserScheme(foundDestAddress, userScheme);
    /* Note: Meanwhile, there is no scheme validation. i.e, the user put another scheme... */
    /* Check if there is a scheme in the found address and if it not a proxy address  */
    if (userScheme[0] == '\0')
    {
		RvSnprintf(tmpDestAddress, sizeof(tmpDestAddress), "sip:%s", foundDestAddress);
		
        strncpy(foundDestAddress, tmpDestAddress, sizeof(foundDestAddress)-1);
        foundDestAddress[sizeof(foundDestAddress)-1] = '\0';
    }


    RvSnprintf (destAddress, destAddressLen, "%s", foundDestAddress);
    return rvTrue;
}

