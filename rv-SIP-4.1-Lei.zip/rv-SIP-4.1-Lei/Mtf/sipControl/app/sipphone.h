/******************************************************************************
Filename:    sipphone.h
Description: Sip Phone Application Header
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef SIPPHONE_H
#define SIPPHONE_H

#include "rvalloc.h"
#include "rvmap.h"
#include "rvstring.h"

#include "rvcccall.h"
#include "rvccapi.h"
#include "sipMgr.h"
#include "basephone.h"

#define PROTOCOL 0

RvCCProvider* rvCCSipPhoneGetSipProvider(void);
RvSipControl* rvCCSipPhoneGetSipMgr(void);

void rvCCSipPhoneSetFromAddress(RvSipAppCallLegHandle legHandle, char *longFrom);
void rvCCSipPhoneFinishTermUnregistrationProcess(RvCCTerminal*  t);

#endif /*SIPPHONE_H*/
