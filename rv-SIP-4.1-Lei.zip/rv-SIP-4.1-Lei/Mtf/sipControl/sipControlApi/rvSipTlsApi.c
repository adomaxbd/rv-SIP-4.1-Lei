/******************************************************************************
Filename   : rvSipTlsApi.c
Description: Sip TLS Control Extension APIs
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC	LOGSRC_SIPCONTROL

#include "rvtypes.h"

#ifdef RV_CFLAG_TLS
#include "rvSipTlsApi.h"


extern RvIppSipTlsExtClbks        sipTlsExtClbks;

/******************************************************************************
*  rvIppSipTlsInitConfig
*  --------------------------------
*  General :        Set default TLS values into Sip phone configuration structure
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          cfg       Pointer to Sip phone configuration structure
*  Output:         none.
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipTlsInitConfig(IN RvMtfSipPhoneCfg* cfg)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppSipTlsInitConfig(cfg=%p)", cfg));

    /* Initialize default TLS parameters */
    memset(&cfg->transportTlsCfg, 0, sizeof(cfg->transportTlsCfg));

    /* the client engine only verifies certificates so it only needs to load TLS
    methods and the depth of the certificate chain it will allow to certify */

    cfg->transportTlsCfg.stackTlsPort = 5061;
    cfg->transportTlsCfg.stackTlsAddress = cfg->localAddress;
    cfg->transportTlsCfg.stackNumOfTlsAddresses = 1;

    cfg->transportTlsCfg.certDepth  = 5;
    cfg->transportTlsCfg.privateKeyType = RVSIP_TRANSPORT_PRIVATE_KEY_TYPE_RSA_KEY;
    cfg->transportTlsCfg.tlsMethod  = RVSIP_TRANSPORT_TLS_METHOD_TLS_V1;
    cfg->transportTlsCfg.tlsPostConnectAssertFlag = RV_TRUE;
	cfg->transportTlsCfg.registrarTlsPort = 5061;

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipTlsInitConfig()"));
}

/******************************************************************************
*  rvIppSipTlsRegisterExtClbks
*  --------------------------------
*  General :        Registers SIP TLS user callbacks
*                   Should be called before rvIppSipStackInitialize()
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          clbks              Structure includes pointers to user implementations
*
*  Output:         none.
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipTlsRegisterExtClbks(IN RvIppSipTlsExtClbks* clbks)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppSipTlsRegisterExtClbks(clbks=%p)", clbks));
    if (clbks != NULL)
        memcpy(&sipTlsExtClbks, clbks, sizeof(RvIppSipTlsExtClbks));
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipTlsRegisterExtClbks()"));
}

#endif /* RV_CFLAG_TLS */
