/******************************************************************************
Filename   : rvmdmpkg.c
Description: Package,event and signal information for Media Device Manager
******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:1.9.01$
$Author: D.Elbert$
******************************************************************************/
#define LOGSRC	LOGSRC_MDM
#include "ipp_inc_std.h"
#include "rvmdmpkg.h"
#include "rvmdm.h"
#include "rvstr.h"

rvDefineMap(RvIString, RvMdmSignalInfo)


/***********************************************************************************/
/*		Methods for package registration                                           */
/***********************************************************************************/
/* Get digitmap package info or NULL */
RvMdmDigitMapData* rvMdmTermMgrGetDigitMapPkgInfo_(RvMdmTermMgr * mgr,const char * pkg)
{
	RvPtrListIter i;
	RvMdmDigitMapData * data;

	for(i=rvPtrListBegin(&mgr->digitMapData);i!=rvPtrListEnd(&mgr->digitMapData);i=rvPtrListIterNext(i))
    {
		data = (RvMdmDigitMapData *)rvPtrListIterData(i);
		if(!rvStrIcmp(pkg,rvMdmPackageItemGetPackage(&data->pkgItem)))
			return data;
	}
	return NULL;
}

void rvMdmTermMgrSetDigitMapPkgInfo_(RvMdmTermMgr * mgr,RvMdmDigitMapData * dmData)
{
	RvMdmDigitMapData * newDigitMap = NULL;
	rvMtfAllocatorAlloc( sizeof(RvMdmDigitMapData), (void**)&newDigitMap);
	rvMdmDigitMapDataCopyConstruct(newDigitMap,dmData,mgr->a);
	rvPtrListPushBack(&mgr->digitMapData,newDigitMap);
}

/*------------------------------------------------------------------------------*/
/* RvMdmEventData methods                                                       */
/*------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------*/
/* RvMdmSignalData methods                                                      */
/*------------------------------------------------------------------------------*/
void rvMdmSignalDataConstructA(RvMdmSignalData* x,const char* id,RvMdmSignalType type,RvAlloc* a)
{
	rvStringConstruct(&x->id,id,a);
	rvMdmParameterListConstructA(&x->args,a);
	x->type = type;
	x->timeout = 0;
}

/*$
{function:
	{name: rvMdmSignalDataDestruct}
	{class: RvMdmSignalData}
	{include: rvmdm.h}
	{description:
		{p: Destruct a SignalData object.}
	}
	{proto: void rvMdmSignalDataDestruct(RvMdmSignalData* x);}
	{params:
		{param: {n:x} {d:The object.}}
	}
}
$*/
void rvMdmSignalDataDestruct(RvMdmSignalData* x){
	rvStringDestruct(&x->id);
	rvMdmParameterListDestruct(&x->args);
}
/*$
{function:
	{name: rvMdmSignalDataSetTimeout}
	{class: RvMdmSignalData}
	{include: rvmdm.h}
	{description:
		{p: Set signal timeout value (for signals of type RV_MDMSIGNAL_TIMEOUT).}
	}
	{proto: void rvMdmSignalDataSetTimeout(RvMdmSignalData* x,RvMilliseconds timeout)}
	{params:
		{param: {n:x} {d:The signal data object.}}
		{param: {n:timeout} {d:The timeout value in miliseconds.}}
	}
}
$*/
void rvMdmSignalDataSetTimeout(RvMdmSignalData* x,RvMilliseconds timeout)
{
	x->timeout = (RvUint32)timeout;
}

/*------------------------------------------------------------------------------*/
/* RvMdmDigitMapData methods                                                    */
/*------------------------------------------------------------------------------*/

/*$
{function:
	{name: rvMdmDigitMapDataConstruct}
	{class: RvMdmDigitMapData}
	{include: rvmdm.h}
	{description:
		{p: Constructs an RvMdmDigitMapData object, which defines package specific handling of digitmap events.}
	}
	{proto: void rvMdmDigitMapDataConstruct(RvMdmDigitMapData* dmData,
											const char* completionEventName,
											RvMdmDigitMapBuildCompletionEvCB completeEvF,
											RvMdmDigitMapTranslateEventCB    translateF,
											void* userData);}
	{params:
		{param: {n:dmData} {d:The object.}}
		{param: {n:completionEventName} {d:The name of the digitmap completion event for the package.}}
		{param: {n:completeEvF} {d:This callback will be called by the Media Device Manager when it generates
								   a digitMap completion event.}}
		{param: {n:translateF} {d:This callback translates (maps) the events of the package to valid digitmap
								  symbols (0-9, A-F). }}
		{param: {n:userData} {d:Will be a parameter to completeEvF.}}
	}
	{notes:
		{note:
			Only for packages which support digitmap events (MEGACO: dd).
		}
	}
}
$*/
void rvMdmDigitMapDataConstruct(RvMdmDigitMapData* dmData,
								const char* completionEventName,
								RvMdmDigitMapBuildCompletionEvCB completeEvF,
								RvMdmDigitMapTranslateEventCB  translateF,
								void * userData) 
{
	rvMdmPackageItemConstructA(&dmData->pkgItem,"",completionEventName,prvDefaultAlloc);
	dmData->evCompleteF = completeEvF;
	dmData->translateF = translateF;
	dmData->userData = userData;
	dmData->alloc = prvDefaultAlloc;
}

/*$
{function:
	{name: rvMdmDigitMapDataDestruct}
	{class: RvMdmDigitMapData}
	{include: rvmdm.h}
	{description:
		{p: Destructs an RvMdmDigitMapData object.}
	}
	{proto: void rvMdmDigitMapDataDestruct(RvMdmDigitMapData* dmData);}
	{params:
		{param: {n:dmData} {d:The object.}}
	}
}
$*/
void rvMdmDigitMapDataDestruct(RvMdmDigitMapData* dmData)
{
	rvMdmPackageItemDestruct(&dmData->pkgItem);
}

void rvMdmDigitMapDataCopyConstruct(RvMdmDigitMapData* d,RvMdmDigitMapData* s,RvAlloc* a)
{
	rvMdmPackageItemConstructCopy(&d->pkgItem,&s->pkgItem,a);
	d->evCompleteF = s->evCompleteF;
	d->translateF = s->translateF;
	d->userData = s->userData;
	d->alloc = a;
}

/*------------------------------------------------------------------------------*/
/* RvMdmPackage methods				                                            */
/*------------------------------------------------------------------------------*/
static void registerSignalInfo(RvMdmPackage *pkg,RvMdmSignalData* signal);

/*------------------------------------------------------------------------------*/
/*$
{function:
	{name: rvMdmPackageRegisterSignal}
	{class: RvMdmPackage}
	{include: rvmdm.h}
	{description:
		{p: Register a signal defined in the package.}
	}
	{proto: void rvMdmPackageRegisterSignal(RvMdmPackage* x,RvMdmSignalData* signal);}
	{params:
		{param: {n:x} {d:The package object.}}
		{param: {n:signal} {d:The signal data.}}
	}
}
$*/
void rvMdmPackageRegisterSignal(RvMdmPackage* x,RvMdmSignalData* signal)
{
	RvMdmSignalEx megSig;
	RvMdmPackageItem name;
	RvMdmParameterList* params;

	/* register the signal info in the map*/
	registerSignalInfo(x,signal);

	/* Build a signal */
	rvMdmPackageItemConstructA(&name,rvStringGetData(&x->name),
								  rvStringGetData(&signal->id),x->alloc);
	rvMdmSignalExConstructA(&megSig,&name,x->alloc);
	rvMdmSignalExSetType(&megSig,signal->type);
	rvMdmSignalExSetDuration(&megSig,signal->timeout/10);

	params = (RvMdmParameterList*)rvMdmSignalExGetParameterList(&megSig);
	rvMdmParameterListCopy(params,&signal->args);

	/* Add to the signal descriptor */
	rvMdmSignalsDescriptorAddSignal(&x->signals,&megSig);

	/* Delete local objects */
	rvMdmPackageItemDestruct(&name);
	rvMdmSignalExDestruct(&megSig);
}

/*------------------------------------------------------------------------------*/
/*$
{function:
	{name: rvMdmPackageRegisterEvent}
	{class: RvMdmPackage}
	{include: rvmdm.h}
	{description:
		{p: Register an event defined in the package.}
	}
	{proto: void rvMdmPackageRegisterEvent(RvMdmPackage* x,RvMdmEventData* event);}
	{params:
		{param: {n:x} {d:The package object.}}
		{param: {n:event} {d:The event data.}}
	}
}
$*/
void rvMdmPackageRegisterEvent(RvMdmPackage* x,const char* eventId)
{
	RvMdmRequestedEvent megEvent;
	RvMdmPackageItem name;

	/* Build a megaco signal */
	rvMdmPackageItemConstructA(&name,
        rvStringGetData(&x->name), eventId ,x->alloc);
	rvMdmRequestedEventConstructA(&megEvent,&name,x->alloc);

	/* Add to the signal descriptor */
	rvMdmEventsDescriptorAddEvent(&x->events,&megEvent);

	/* Delete local objects */
	rvMdmPackageItemDestruct(&name);
	rvMdmRequestedEventDestruct(&megEvent);
}



/*$
{function:
	{name: rvMdmPackageRegisterDigitMapData}
	{class: RvMdmPackage}
	{include: rvmdm.h}
	{description:
		{p: Register the object describing the package specific handling of digitmap events,
			including the mapping of package events to digitmap symbols and the production of the
		    digitmap completion event.}

		{p: Use only for packages implementing digitmaps events.
		    The RADVISION toolkit implements the DTMF package so this function has to
			be called only when the user defines other packages implementing digitmap
			events.}
	}
	{proto: void rvMdmPackageRegisterDigitMapData(RvMdmPackage* x,RvMdmDigitMapData* data);}
	{params:
		{param: {n:x} {d:The package object.}}
		{param: {n:data} {d:The package specific digitmap data.}}
	}
}
$*/
void rvMdmPackageRegisterDigitMapData(RvMdmPackage* x,RvMdmDigitMapData* data)
{
	rvStringAssign(&data->pkgItem.package,x->name);
	rvMdmTermMgrSetDigitMapPkgInfo_(x->mgr,data);
}

/* Protected methods */
void rvMdmPackageConstruct_(RvMdmPackage* x,const char* name,RvMdmTermMgr* mgr,RvAlloc* a)
{
	x->mgr = mgr;
	rvStringConstruct(&x->name,name,a);
	rvMdmSignalsDescriptorConstructA(&x->signals,a);
	rvMdmEventsDescriptorConstructA(&x->events,0,a);
	rvMapConstruct(RvIString,RvMdmSignalInfo)(&x->signalInfo, a);
	x->alloc = a;
	x->refs = 0;
}
void rvMdmPackageDestruct_(RvMdmPackage* x)
{
	rvStringDestruct(&x->name);
	rvMdmSignalsDescriptorDestruct(&x->signals);
	rvMdmEventsDescriptorDestruct(&x->events);
	rvMapDestruct(&x->signalInfo);
}


static void rvMdmPackagePtrConstructCopy(RvMdmPackagePtr *d, const RvMdmPackagePtr *s, RvAlloc *a)
{
	RV_UNUSED_ARG(a);
	*d = *s;
	(*d)->refs++;
}

static void rvMdmPackagePtrDestruct(RvMdmPackagePtr *x)
{
	if(--(*x)->refs == 0)
	{
		rvMdmPackageDestruct_(*x);
		rvMtfAllocatorDealloc(*x, sizeof(RvMdmPackage));
	}
}

#define RvMdmPackagePtrConstructCopy rvMdmPackagePtrConstructCopy
#define RvMdmPackagePtrDestruct      rvMdmPackagePtrDestruct
rvDefineMap(RvIString,RvMdmPackagePtr)



static void registerSignalInfo(RvMdmPackage *pkg,RvMdmSignalData* signal)
{
    /* We can safely assume that signals that we get here are lowercase */
	RvMdmSignalInfo signalInfo;

	signalInfo.type = signal->type;
	signalInfo.duration = signal->timeout;
	rvMapSetValue(RvIString, RvMdmSignalInfo)(&pkg->signalInfo, &signal->id, &signalInfo);
}


/*--------------------------------------------------------------------------*/
/* Used by the application in the EventParametersCB                         */
/* for the off-hook, on-hook cases                                          */
/*--------------------------------------------------------------------------*/

void rvMdmPackageBuildGenericPkg(RvMdmPackage* pkg)
{
	RvMdmParameterValue param;

	rvMdmPackageRegisterEvent(pkg, "Generalcause");
	rvMdmPackageRegisterEvent(pkg, "sc");

	rvMdmParameterValueConstruct(&param, "NR");
	rvMdmParameterValueOr(&param, "UR");
	rvMdmParameterValueOr(&param, "FT");
	rvMdmParameterValueOr(&param, "FP");
	rvMdmParameterValueOr(&param, "IW");
	rvMdmParameterValueOr(&param, "UN");

	rvMdmParameterValueConstruct(&param, "");

	rvMdmParameterValueConstruct(&param, "TO");
	rvMdmParameterValueOr(&param, "EV");
	rvMdmParameterValueOr(&param, "SD");
	rvMdmParameterValueOr(&param, "NC");

}

