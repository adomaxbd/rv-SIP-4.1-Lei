/******************************************************************************
Filename   : rvMdm.c
Description: Methods for Media Device Manager
******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:11.15.00$
$Author: D.Elbert$
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

#define LOGSRC  LOGSRC_MDM
#include "ipp_inc_std.h"
#include "rvmdm.h"
#include "rvmdmmediastream.h" 
#include "rvmdmtermsignal.h"
#include "rvmdmtermevent.h"
#include "rvccterminalmdm.h"
#include "rvstr.h"


#define nprn(_s) ( (_s != NULL) ? (_s) : "(null)" )

static RvMdmPackage* rvMdmTermMgrCreatePackage(RvMdmTermMgr* mgr,const char* name);



/*------------------------------------------------------------------------------*/
/* RvMdmMediaStreamDescr methods                                                      */
/*------------------------------------------------------------------------------*/
/*$
{function:
    {name: rvMdmMediaStreamDescrGetMode}
    {class: RvMdmMediaStreamDescr}
    {include: rvmdm.h}
    {description:
        {p: Gets the mode of the media stream (towards the outside of the context).}
    }
    {proto: RvMdmStreamMode rvMdmMediaStreamDescrGetMode(RvMdmMediaStreamDescr* x);}
    {params:
        {param: {n:x} {d:The media descriptor object.}}
    }
    {returns:
        The media stream mode.
    }
}
$*/
RvMdmStreamMode rvMdmMediaStreamDescrGetMode(RvMdmMediaStreamDescr* x)
{
    return x->mode;
}

/*$
{function:
    {name: rvMdmMediaStreamDescrGetLocalDescr}
    {class: RvMdmMediaStreamDescr}
    {include: rvmdm.h}
    {description:
        {p: Gets the local media descriptor for a media stream.}
    }
    {proto: RvSdpMsgList * rvMdmMediaStreamDescrGetLocalDescr(RvMdmMediaStreamDescr* x);}
    {params:
        {param: {n:x} {d:The media descriptor object.}}
    }
    {returns:
        The local media descriptor (NULL if absent).
    }
}
$*/
RvSdpMsgList * rvMdmMediaStreamDescrGetLocalDescr(RvMdmMediaStreamDescr* x)
{
    return x->localDescr;
}

/*$
{function:
    {name: rvMdmMediaStreamDescrGetRemoteDescr}
    {class: RvMdmMediaStreamDescr}
    {include: rvmdm.h}
    {description:
        {p: Gets the remote media descriptor for a media stream.}
    }
    {proto: RvSdpMsgList * rvMdmMediaStreamDescrGetRemoteDescr(RvMdmMediaStreamDescr* x);}
    {params:
        {param: {n:x} {d:The media descriptor object.}}
    }
    {returns:
        The remote media descriptor (NULL if absent).
    }
}
$*/
RvSdpMsgList * rvMdmMediaStreamDescrGetRemoteDescr(RvMdmMediaStreamDescr* x)
{
    return x->remoteDescr;
}

/*$
{function:
    {name: rvMdmMediaStreamDescrReportLocalDescr}
    {class: RvMdmMediaStreamDescr}
    {include: rvmdm.h}
    {description:
        {p: Called to indicate that the local media descriptor has been modified.
            The application will usually call this function after changing the
            local media descriptor by selecting a value from overspecified
            values or setting a value that was underspecified (e.g. the local UDP port).}
    }
    {proto: void rvMdmMediaStreamDescrReportLocalDescr(RvMdmMediaStreamDescr* x);}
    {params:
        {param: {n:x} {d:The media descriptor object.}}
    }
}
$*/
void rvMdmMediaStreamDescrReportLocalDescr(RvMdmMediaStreamDescr* x)
{
    x->reportFlag = (RvMdmMediaStreamDescrReport)((int)x->reportFlag | (int)RV_MDMMEDIASTREAM_REPORTLOCAL);
}

/*$
{function:
    {name: rvMdmMediaStreamDescrReportRemoteDescr}
    {class: RvMdmMediaStreamDescr}
    {include: rvmdm.h}
    {description:
        {p: Called to indicate that the remote media descriptor has been modified.
            The application will usually call this function after changing the
            remote media descriptor by selecting a value from overspecified
            values or setting a value that was underspecified. }
    }
    {proto: void rvMdmMediaStreamDescrReportRemoteDescr(RvMdmMediaStreamDescr* x);}
    {params:
        {param: {n:x} {d:The media descriptor object.}}
    }
}
$*/
void rvMdmMediaStreamDescrReportRemoteDescr(RvMdmMediaStreamDescr* x)
{
    x->reportFlag = (RvMdmMediaStreamDescrReport)((int)x->reportFlag | (int)RV_MDMMEDIASTREAM_REPORTREMOTE);
}

/*$
{protected_function:
    {name: rvMdmMediaStreamDescrConstruct_}
    {class: RvMdmMediaStreamDescr}
    {include: rvmdm.h}
    {description:
        {p: Constructs the media descriptor.}
    }
    {proto: rvMdmMediaStreamDescr* rvMdmMediaStreamDescrConstruct_(RvMdmMediaStreamDescr* x,
                                           RvMdmStreamMode mode,
                                           RvSdpMsgList * localDescr,
                                           RvSdpMsgList * remoteDescr);}
    {params:
        {param: {n:x} {d:The media descriptor object.}}
    }
    {returns:
        A pointer to the object.
    }
}
$*/
RvMdmMediaStreamDescr* rvMdmMediaStreamDescrConstruct_(RvMdmMediaStreamDescr* x,
                                           RvMdmStreamMode mode,
                                           RvSdpMsgList * localDescr,
                                           RvSdpMsgList * remoteDescr)
{
    x->mode = mode;
    x->remoteDescr = remoteDescr;
    x->localDescr = localDescr;
    x->reportFlag = (RvMdmMediaStreamDescrReport)0;
    return x;
}


/*------------------------------------------------------------------------------*/
/*  RvMdmSignal methods                                                         */
/*------------------------------------------------------------------------------*/

/*$
{protected_function:
    {name: rvMdmSignalConstruct_}
    {class: RvMdmSignal}
    {include: rvmdm.h}
    {description:
        {p: Constructs a signal.}
    }
    {proto: void rvMdmSignalConstruct_(RvMdmSignal * signal,
                          const char* id,const char* pkg,
                          const RvMdmParameterList* args,
                          RvMdmMediaStream* mediaStream);}
    {params:
        {param: {n:signal} {d:The signal object.}}
        {param: {n:id} {d:The signal id.}}
        {param: {n:pkg} {d:The pkg id.}}
        {param: {n:media} {d:The media stream where the should be applied. 0 is none.}}
        {param: {n:args} {d:The signal arguments.}}
    }

}
$*/
void rvMdmSignalConstruct_(RvMdmSignal * signal,
                          const char* id,const char* pkg,
                          const RvMdmParameterList* args)
{
    signal->id = id;
    signal->pkg = pkg;
    signal->params = args;
}


/*$
{function:
    {name: rvMdmSignalGetId}
    {class: RvMdmSignal}
    {include: rvmdm.h}
    {description:
        {p: Gets the signal id.}
    }
    {proto: const char* rvMdmSignalGetId(const RvMdmSignal * signal);}
    {params:
        {param: {n:signal} {d:The signal object.}}
    }
    {returns: The signal id.}
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmSignalGetId(IN const RvMdmSignal * signal)
{
    const RvChar* id;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmSignalGetId(signal=%p)", signal));

    id = signal->id;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmSignalGetId()=%s", nprn(id)));

    return id;
}

/*$
{function:
    {name: rvMdmSignalGetPkg}
    {class: RvMdmSignal}
    {include: rvmdm.h}
    {description:
        {p: Gets the package to which the signal belongs.}
    }
    {proto: const char* rvMdmSignalGetPkg(const RvMdmSignal * signal);}
    {params:
        {param: {n:signal} {d:The signal object.}}
    }
    {returns: The signal package.}
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmSignalGetPkg(const RvMdmSignal * signal)
{
    const RvChar* pkg;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmSignalGetPkg(signal=%p)", signal));

    pkg = signal->pkg;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmSignalGetPkg()=%s", nprn(pkg)));

    return pkg;
}

/*$
{function:
    {name: rvMdmSignalGetArguments}
    {class: RvMdmSignal}
    {include: rvmdm.h}
    {description:
        {p: Gets the signal arguments.}
    }
    {proto: const RvMdmParameterList* rvMdmSignalGetArguments(const RvMdmSignal *signal);}
    {params:
        {param: {n:signal} {d:The signal object.}}
    }
    {returns: The arguments to the signal. Returns an empty list if there are no arguments.}
}
$*/
RVAPI const RvMdmParameterList* RVCALLCONV rvMdmSignalGetArguments(IN const RvMdmSignal *signal)
{
    const RvMdmParameterList* params;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmSignalGetArguments(signal=%p)", signal));

    params = signal->params;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmSignalGetArguments()=%p", params));

    return params;
}

/*------------------------------------------------------------------------------*/
/* RvMdmTermClass methods                                                       */
/*------------------------------------------------------------------------------*/
/*$
{function:
    {name: rvMdmTermClassRegisterStartSignalCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback function to use to start a signal in a termination of this class.
            This signal will usually not stop by itself but only when the callback registered
            with rvMdmTermClassRegisterStopSignalCB() is called. }
    }
    {proto: void rvMdmTermClassRegisterStartSignalCB(RvMdmTermClass* c,RvMdmTermStartSignalCB startSignalF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:startSignalF} {d:The callback function.}}
    }
}
$*/
/* Signal callbacks registration */
RVAPI void RVCALLCONV rvMdmTermClassRegisterStartSignalCB(
    IN RvMdmTermClass*          c,
    IN RvMdmTermStartSignalCB   startSignalF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterStartSignalCB(c=%p,f=%p)", c, startSignalF));

    c->startSignalF = startSignalF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterStartSignalCB()"));
}

/*$
{function:
    {name: rvMdmTermClassRegisterStopSignalCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to use to stop a signal in a termination of this class.}
    }
    {proto: void rvMdmTermClassRegisterStopSignalCB (RvMdmTermClass* c, RvMdmTermStopSignalCB stopSignalF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:stopSignalF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassRegisterStopSignalCB(
    IN RvMdmTermClass*          c,
    IN RvMdmTermStopSignalCB    stopSignalF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterStopSignalCB(c=%p,f=%p)", c, stopSignalF));

    c->stopSignalF = stopSignalF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterStopSignalCB()"));
}

/*$
{function:
    {name: rvMdmTermClassRegisterPlaySignalCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to use to play a signal in a termination of this class.}
        {p: This signal is played to completion
            by the application and not stopped by the termination manager.}

    }
    {proto: void rvMdmTermClassRegisterPlaySignalCB (RvMdmTermClass* c, RvMdmTermPlaySignalCB playSignalF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:playSignalF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassRegisterPlaySignalCB(
    IN RvMdmTermClass*          c,
    IN RvMdmTermPlaySignalCB    playSignalF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterPlaySignalCB(c=%p,f=%p)", c, playSignalF));

    c->playSignalF = playSignalF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterPlaySignalCB()"));
}

/*$
{function:
    {name: rvMdmTermClassRegisterCreateMediaCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to call when creating a media stream in a termination of this class.}
    }
    {proto: void rvMdmTermClassRegisterCreateMediaCB(RvMdmTermClass* c,RvMdmTermCreateMediaCB createMediaF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:createMediaF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassRegisterCreateMediaCB(
    IN RvMdmTermClass*          c,
    IN RvMdmTermCreateMediaCB   createMediaF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterCreateMediaCB(c=%p,f=%p)", c, createMediaF));

    c->createMediaF = createMediaF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterCreateMediaCB()"));
}

/*$
{function:
    {name: rvMdmTermClassRegisterDestroyMediaCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to call when deleting a media stream in a termination of this class.}
    }
    {proto: void rvMdmTermClassRegisterDestroyMediaCB(RvMdmTermClass* c,RvMdmTermDestroyMediaCB destroyMediaF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:destroyMediaF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassRegisterDestroyMediaCB(
    IN RvMdmTermClass*          c,
    IN RvMdmTermDestroyMediaCB  destroyMediaF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterDestroyMediaCB(c=%p,f=%p)", c, destroyMediaF));

    c->destroyMediaF = destroyMediaF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterDestroyMediaCB()"));
}

/*$
{function:
    {name: rvMdmTermClassRegisterModifyMediaCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to call when modifying an existing media stream in a termination of this class.}
    }
    {proto: void rvMdmTermClassRegisterModifyMediaCB(RvMdmTermClass* c,RvMdmTermModifyMediaCB modifyMediaF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:modifyMediaF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassRegisterModifyMediaCB(
    IN RvMdmTermClass*          c,
    IN RvMdmTermModifyMediaCB   modifyMediaF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterModifyMediaCB(c=%p,f=%p)", c, modifyMediaF));

    c->modifyMediaF = modifyMediaF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterModifyMediaCB()"));
}


RVAPI void RVCALLCONV rvMdmTermClassRegisterRegisterPhysTermCompletedCB(
    IN RvMdmTermClass*                      c,
    IN RvMdmTermRegisterPhysTermCompletedCB registerPhysTermCompletedF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterRegisterPhysTermCompletedCB(c=%p,f=%p)", c, registerPhysTermCompletedF));

    c->registerPhysTermCompletedF = registerPhysTermCompletedF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterRegisterPhysTermCompletedCB()"));
}


RVAPI void RVCALLCONV rvMdmTermClassRegisterUnregisterTermCompletedCB(
    IN RvMdmTermClass*                      c,
    IN RvMdmTermUnregisterTermCompletedCB   unregisterTermCompletedF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterUnregisterTermCompletedCB(c=%p,f=%p)", c, unregisterTermCompletedF));

    c->unregisterTermCompletedF = unregisterTermCompletedF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterUnregisterTermCompletedCB()"));
}


RVAPI void RVCALLCONV rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB(
    IN RvMdmTermClass*                                  c,
    IN RvMdmTermUnregisterTermFromNetworkCompletedCB    unregisterTermFromNetworkCompletedF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB(c=%p,f=%p)", c, unregisterTermFromNetworkCompletedF));

    c->unregisterTermFromNetworkCompletedF = unregisterTermFromNetworkCompletedF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB()"));
}


/*$
{function:
    {name: RvMdmTermRegisterModifyMediaCompletedCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to call when registering a physical termination is done, if called asynchronous.}
    }
    {proto: void RvMdmTermRegisterModifyMediaCompletedCB(RvMdmTermClass* c,RvMdmTermModifyMediaCompletedCB mediaModifiedCompletedF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:modifyMediaCompletedF} {d:The callback function.}}
    }
}
$*/

RVAPI void rvMdmTermClassRegisterModifyMediaCompletedCB(RvMdmTermClass* c, RvMdmTermModifyMediaCompletedCB modifyMediaCompletedF)
{
    c->modifyMediaCompletedF = modifyMediaCompletedF;
}
/*$
{function:
    {name: rvMdmTermMgrRegisterConnectCB}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to call when connecting a media in a termination to a media in another termination.}
    }
    {proto: void rvMdmTermMgrRegisterConnectCB(RvMdmTermMgr* mgr,RvMdmTermMgrConnectCB connectF);}
    {params:
        {param: {n:mgr} {d:A pointer to termination class object.}}
        {param: {n:connectF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrRegisterConnectCB(
    IN RvMdmTermMgr*            m,
    IN RvMdmTermMgrConnectCB    connectF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterConnectCB(m=%p,connectF=%p)", m, connectF));

    m->connectF = connectF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterConnectCB()"));
}

/*$
{function:
    {name: rvMdmTermMgrRegisterDisconnectCB}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Set the callback to call when disconnecting a media in a termination of this class from a media in another termination.}
    }
    {proto: void rvMdmTermMgrRegisterDisconnectCB(RvMdmTermClass* c,RvMdmTermMgrDisconnectCB disconnectF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:disconnectF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrRegisterDisconnectCB(
    IN RvMdmTermMgr*                m,
    IN RvMdmTermMgrDisconnectCB     disconnectF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterDisconnectCB(m=%p,disconnectF=%p)", m, disconnectF));

    m->disconnectF = disconnectF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterDisconnectCB()"));
}


/*$
{function:
    {name: rvMdmTermMgrForEachPhysicalTerm}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Calls func for each registred physical termination, until func returns rvTrue or there are no
            more terminations.}
    }
    {proto: RvBool rvMdmTermMgrForEachPhysicalTerm(RvMdmTermMgr* mgr,RvMdmProcessEachTermCB func,void* data);}
    {params:
        {param: {n:mgr} {d:The termination manager.}}
        {param: {n:func} {d:The function to call.}}
        {param: {n:data} {d:user data to pass to the function.}}
    }
    {returns:
        The value returned by the last call to func.
    }
}
$*/
RVAPI RvBool RVCALLCONV rvMdmTermMgrForEachPhysicalTerm(
    IN RvMdmTermMgr*            mgr,
    IN RvMdmProcessEachTermCB   func,
    IN void*                    data)
{
    RvBool result;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrForEachPhysicalTerm(mgr=%p,func=%p,data=%p)", mgr, func, data));

    result = mgr->xTermMgrClbks->forEachPhysTermF(mgr->xTermMgr, func, data);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrForEachPhysicalTerm()=%d", result));

    return result;
}

/*$
{function:
    {name: rvMdmTermMgrMediaCapabilitiesUpdated}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: This function should be called after all media capabilities were loaded.}
    }
    {proto: RvBool rvMdmTermMgrMediaCapabilitiesUpdated(IN RvMdmTermMgr*    mgr, IN RvMdmTermClass*  rtpClass);}
    {params:
        {param: {n:mgr} {d:The termination manager.}}
        {param: {n:rtpClass} {d:A pointer to RTP class.}}
    }
    {returns:
        None.
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrMediaCapabilitiesUpdated(
    IN RvMdmTermMgr*    mgr,
    IN RvMdmTermClass*  rtpClass)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrMediaCapabilitiesUpdated(mgr=%p,rtpClass=%p)", mgr, rtpClass));

    mgr->xTermMgrClbks->mediaCapsUpdatedF(mgr, rtpClass);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrMediaCapabilitiesUpdated()"));
}

/*$
{function:
    {name: rvMdmTermClassAddMediaCapabilities}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Add media capabilities to a termination class.}
        {p: Call this function once for every type of stream with different
            capabilities that the class support  (once for terminations supporting
            one stream,two for terminations supporting two types of streams
            (i.e. audio and video), etc.}
    }
    {proto: void rvMdmTermClassAddMediaCapabilities(RvMdmTermClass *c,
                                        const RvSdpMsgList * localDescr,
                                        const RvSdpMsgList * remoteDescr,
                                        const RvMdmParameterList* localProperties);
    }
    {params:
        {param: {n:c} {d:A pointer to the termination class.}}
        {param: {n:localDescr} {d:A list of supported media values for the local media.}}
        {param: {n:remoteDescr} {d:A list of supported media values for the remote media.}}
        {param: {n:localProperties} {d:A list of supported local control properties for
                                       this stream.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassAddMediaCapabilities(
    IN RvMdmTermClass*              c,
    IN const RvSdpMsgList*          localDescr,
    IN const RvSdpMsgList*          remoteDescr,
    IN const RvMdmParameterList*    localProperties)
{
    RvSize_t i, num;

    /* Add one media stream and copy the descriptors */
    RvMdmStreamDescriptor stream;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassAddMediaCapabilities(c=%p,local=%p,remote=%p,properties=%p)", c, localDescr, remoteDescr, localProperties));

/*
 *  As streamId param  of below ctor we pass number of streams in c->mediaCaps (ec. in stream vector)
 * At the end of function we add this stream to c->mediaCaps. As result
 * passed streamId param is equal to an index of this stream in stream vector of c->mediaCaps.
 * This link is never used: Later, when we get stream from c, we always use index=0
 */
    rvMdmStreamDescriptorConstructA(&stream,
                                       (RvMdmStreamId)rvMdmMediaDescriptorGetNumStreams(&c->mediaCaps),
                                       c->a);

    num = rvSdpMsgListGetSize(localDescr);
    for (i = 0; i < num; i++)
        rvMdmStreamDescriptorAddLocalDescriptor(&stream,
                                                   rvSdpMsgListGetElement((RvSdpMsgList*)localDescr, i));

    num = rvSdpMsgListGetSize(remoteDescr);
    for (i = 0; i < num; i++)
        rvMdmStreamDescriptorAddRemoteDescriptor(&stream,
                                                    rvSdpMsgListGetElement((RvSdpMsgList*)remoteDescr, i));

    if (localProperties != NULL)
        rvMdmParameterListCopy(&stream.parameters, localProperties);

    rvMdmMediaDescriptorAddStream(&c->mediaCaps, &stream);
    rvMdmStreamDescriptorDestruct(&stream);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassAddMediaCapabilities()"));
}

/******************************************************************************
 * rvMdmTermClassClearMediaCapabilities
 * ----------------------------------------------------------------------------
 * General:
 *  Clears all current media capabilities from a Termination class.
 *
 * Arguments:
 * Input:  c        - A pointer to the Termination class.
 * Output: None.
 *
 * Return Value: None.
 *****************************************************************************/
RVAPI void RVCALLCONV rvMdmTermClassClearMediaCapabilities(IN RvMdmTermClass* c)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassClearMediaCapabilities(c=%p)", c));

    rvMdmMediaDescriptorDestruct(&c->mediaCaps);
    rvMdmMediaDescriptorConstructA(&c->mediaCaps, c->a);

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassClearMediaCapabilities()"));
}


/*$
{function:
    {name: rvMdmTermClassAddSupportedPkg}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Use to set the list of packages supported by a termination.
            Must be called for every package that a termination of this class
            supports.}
    }
    {proto: void rvMdmTermClassAddSupportedPkg(RvMdmCapabilities *c,const char* name,unsigned int version);}
    {params:
        {param: {n:c} {d:A pointer to the termination class.}}
        {param: {n:name} {d:The name of a supported package (previously registered with the TermMgr).}}
        {param: {n:version} {d:The package id.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassAddSupportedPkg(
    IN RvMdmTermClass*  c,
    IN const RvChar*    name,
    IN RvUint           version)
{
    RV_UNUSED_ARG(version);

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassAddSupportedPkg(c=%p,name=%s)", c, name));

    rvMdmPackagesDescriptorAddPackage(&c->pkgsCaps, name);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassAddSupportedPkg()"));
}



/*$
{function:
    {name: rvMdmTermClassRegisterMatchDialStringCB}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Optional - Register a callback to check a matching of a dial string to a digitmap.}

    }
    {proto: void rvMdmTermClassRegisterMatchDialStringCB(RvMdmTermClass* c, RvMdmTermMatchDialStringCB matchDialStringF);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:matchDialStringF} {d:The callback function.}}
    }
}
$*/
RVAPI void rvMdmTermClassRegisterMatchDialStringCB(
    IN RvMdmTermClass*              c,
    IN RvMdmTermMatchDialStringCB   matchDialStringF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterMatchDialStringCB(c=%p,func=%p)", c, matchDialStringF));

    c->matchDialStringF = matchDialStringF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterMatchDialStringCB()"));
}

/*$
{function:
    {name: rvMdmTermClassRegisterMapDialStringToAddressCB}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Register a callback that maps a dial string to an address.
            Registration of this callback function is not optional.
        }
    }
    {proto: void rvMdmTermClassRegisterMapDialStringToAddressCB(RvMdmTermClass* c, rvMdmTermMapDialStringToAddressCB mapDialStringToAddressF);
    }
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:mapDialStringToAddressF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermClassRegisterMapDialStringToAddressCB(
    IN RvMdmTermClass*                      c,
    IN RvMdmTermMapDialStringToAddressCB    mapDialStringToAddressF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterMapDialStringToAddressCB(c=%p,func=%p)", c, mapDialStringToAddressF));

    c->mapDialStringToAddressF = mapDialStringToAddressF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermClassRegisterMapDialStringToAddressCB()"));
}


/*Private Functions:*/
/*$
{protected_function:
    {name: rvMdmTermClassConstructA_}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Constructor.}
    }
    {proto: void rvMdmTermClassConstructA_(RvMdmTermClass * c,RvAlloc * a);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
        {param: {n:a} {d:Allocator.}}
    }
}
$*/
void rvMdmTermClassConstructA_(RvMdmTermClass * c, RvAlloc * a)
{
    memset(c, 0, sizeof(*c));
    rvMdmMediaDescriptorConstructA(&c->mediaCaps, a);
    rvMdmPackagesDescriptorConstructA(&c->pkgsCaps, a);
    c->a = a;
}

/*$
{protected_function:
    {name: rvMdmTermClassDestruct_}
    {class: RvMdmTermClass}
    {include: rvmdm.h}
    {description:
        {p: Destructor.}
    }
    {proto: void rvMdmTermClassDestruct_(RvMdmTermClass * c);}
    {params:
        {param: {n:c} {d:A pointer to termination class object.}}
    }
}
$*/
void rvMdmTermClassDestruct_(RvMdmTermClass * c)
{
    rvMdmMediaDescriptorDestruct(&c->mediaCaps);
    rvMdmPackagesDescriptorDestruct(&c->pkgsCaps);
}

RvMdmMediaDescriptor* rvMdmTermClassGetMediaCapabilites_(RvMdmTermClass * c)
{
    return &c->mediaCaps;
}

/*------------------------------------------------------------------------------*/
/* RvMdmTerm methods                                                            */
/*------------------------------------------------------------------------------*/
/*$
{function:
    {name: rvMdmTermProcessEvent}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Report an event detected in the termination.}
    }
    {proto: void rvMdmTermProcessEvent(RvMdmTerm* term,const char* pkg,const char* id,RvMdmMediaStream* media,RvMdmParameterList* args);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
        {param: {n:pkg} {d:The package id.}}
        {param: {n:id} {d:The event id.}}
        {param: {n:media} {d:The user id of the media stream where the event was detected,
                           or 0 if the event is not related to any media.}}
        {param: {n:args} {d:The event parameters or NULL.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermProcessEvent(
    IN RvMdmTerm*           term,
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmMediaStream*    media,
    IN RvMdmParameterList*  args)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermProcessEvent(term=%p,pkg=%s,id=%s,media=%p,args=%p)", term, pkg, id, media, args));

    rvMdmTermQueueObsEvent(term, pkg, id, media, args);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermProcessEvent()"));
}


/*------------------------------------------------------------------------------*/
/* RvMdmTerm methods						                                    */
/*------------------------------------------------------------------------------*/

RVAPI RvStatus RVCALLCONV rvMdmTermSetPhoneNumber(
    IN RvMdmTerm*       term,
    IN const RvChar*    number)
{
    RvStatus status;

    RvLogEnter(ippLogSource,(ippLogSource,"rvMdmTermSetPhoneNumber(term=%p,number=%s)", term, number));

    status = terminalMdmSetPhoneNumber(term, number);

    RvLogLeave(ippLogSource,(ippLogSource,"rvMdmTermSetPhoneNumber()=%d", status));

    return status;
}

/*$
{function:
    {name: rvMdmTermModifyMedia}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: .}
    }
    {proto: void rvMdmTermModifyMedia(RvMdmTerm* term, RvSdpMsg* sdpMsg); }
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
        {param: {n:sdpMsg} {d:A pointer to SDP message that includes new media parameters.}}
    }
}
$*/
RvBool rvMdmTermModifyMedia(RvMdmTerm* term, RvSdpMsg* sdpMsg)
{
    return terminalMdmModifyMedia(term, sdpMsg, "modify");
}

/*@*****************************************************************************
* rvMdmTermModifyMediaByUpdate 
* -----------------------------------------------------------------------------
* General:
*         Triggers sending an UPDATE request with the given SDP.
*
* Arguments:
*
* Input:  term             - Pointer to the MDM terminal object.
*         sdpMsg           - Pointer to the SDP to be attached to the UPDATE request.
*
* Return Value: Upon success RV_TRUE is returned.
 ****************************************************************************@*/
RVAPI RvBool rvMdmTermModifyMediaByUpdate(IN RvMdmTerm* term,
										  IN RvSdpMsg*  sdpMsg)
{
    return terminalMdmModifyMedia(term, sdpMsg, "update");
}

/*$
{function:
    {name: rvMdmTermGetUserData}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Returns the user data associated with the termination.}
    }
    {proto: void * rvMdmTermGetUserData(RvMdmTerm* term);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
    }
    {returns:
        The termination user data or NULL if not set.
    }
}
$*/
RVAPI void* RVCALLCONV rvMdmTermGetUserData(IN RvMdmTerm* term)
{
    return term->userData;
}

/*$
{function:
    {name: rvMdmTermSetUserData}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Sets user data associated with the termination.}
    }
    {proto: void rvMdmTermSetUserData(RvMdmTerm* term,void* data);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
        {param: {n:data} {d:The user data.}}
    }
    {notes:
        {note:
            Use this function to associate application data and memory with
            the termination. In this way the application may avoid the need to
            have his own database of terminations.
        }
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermSetUserData(
    IN RvMdmTerm*   term,
    IN void*        data)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermSetUserData(term=%p,data=%p)", term, data));

    term->userData = data;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermSetUserData()"));
}

/*$
{function:
    {name: rvMdmTermGetClass}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Gets the termination class}
    }
    {proto: RvMdmTermClass * rvMdmTermGetClass(RvMdmTerm* term);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
    }
    {returns:
        The termination class or NULL if not set.
    }
    {notes:
        {note:

        }
    }
}
$*/
RvMdmTermClass* rvMdmTermGetClass(RvMdmTerm* term)
{
    return term->termClass;
}
/*$
{function:
    {name: rvMdmTermGetType}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Gets the termination type.}
    }
    {proto: RvMdmTermType rvMdmTermGetType(RvMdmTerm* term);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
    }
    {returns:
        The termination type (ephemeral,physical,undefined).
    }
}
$*/
RVAPI RvMdmTermType RVCALLCONV rvMdmTermGetType(IN RvMdmTerm* term)
{
    RvMdmTermType type;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermGetType(term=%p)", term));

    type = terminalMdmGetTermType(term->xTerm);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermGetType()=%d", type));

    return type;
}

/*$
{protected_function:
    {name: rvMdmTermCreateMediaStream_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Create a media stream on a termination.}
    }
    {proto: RvMdmMediaStream* rvMdmTermCreateMediaStream_(RvMdmTerm* term,,RvMdmMediaStream* media,
                                                     RvMdmMediaStreamDescr* streamDescr,
                                                     RvMdmError* mediaError);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:media} {d:Media object.}}
        {param: {n:streamDescr} {d:Properties of the media.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return the user identifier of the new media, or 0 if it fails.
        The selected values must be set in streamDescr.
    }
}
$*/
RvBool rvMdmTermCreateMediaStream_(RvMdmTerm* term,RvMdmMediaStream* media,RvMdmMediaStreamDescr* streamDescr,RvMdmError* mdmError)
{
    if (term->termClass->createMediaF != NULL)
        return term->termClass->createMediaF(term, media, streamDescr, mdmError);
    else
        return RV_FALSE;
}

/*$
{protected_function:
    {name: rvMdmTermModifyMediaStream_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Modify the characteristics of a media on a termination.}
    }
    {proto: RvBool rvMdmTermModifyMediaStream_(RvMdmTerm* term,RvMdmMediaStream* media,
                                               RvMdmMediaStreamDescr* streamDescr,
                                               RvMdmError* mediaError);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:mediaStream} {d:user identifier of the media.}}
        {param: {n:streamDescr} {d:Properties of the media.}}
        {param: {n:mediaError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return rvFalse of it fails.
        The selected values must be set in streamDescr.
    }
}
$*/
RvBool rvMdmTermModifyMediaStream_(RvMdmTerm* term,RvMdmMediaStream* media,RvMdmMediaStreamDescr* streamDescr,RvMdmError* mediaError)
{
    if (term->termClass->modifyMediaF != NULL)
        return term->termClass->modifyMediaF(term, media, streamDescr, mediaError);
    else
        return RV_FALSE;
}

/*$
{protected_function:
    {name: rvMdmTermDestroyMediaStream_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Close a media stream on a termination and release resources.}
    }
    {proto: RvBool rvMdmTermDestroyMediaStream_(RvMdmTerm* term,
                                                 RvMdmMediaStream* mediaStream,OUT RvMdmError* mdmError);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:mediaStream} {d:user identifier of the media.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        rvFalse if fails.
    }
}
$*/
RvBool rvMdmTermDestroyMediaStream_(RvMdmTerm* term,RvMdmMediaStream* mediaStream,OUT RvMdmError* mdmError)
{
    if (term->termClass->destroyMediaF != NULL)
        return term->termClass->destroyMediaF(term,mediaStream,mdmError);
    else
        return RV_FALSE;
}

/*$
{protected_function:
    {name: rvMdmTermRegisterPhysTermDone_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Inform the application that register a physical termination operation has been completed.}
    }
    {proto: void rvMdmTermRegisterPhysTermDone_(RvMdmTerm* term, OUT RvMdmError* mdmError);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
}
$*/
void rvMdmTermRegisterPhysTermDone_(IN RvMdmTerm* term)
{
    if (term->termClass->registerPhysTermCompletedF != NULL)
    {
        RvMdmError unused;

        RvLogEnter(ippLogSource, (ippLogSource, "RvMdmTermRegisterPhysTermCompletedCB(term=%p)", term));

        term->termClass->registerPhysTermCompletedF(term, &unused);

        RvLogLeave(ippLogSource, (ippLogSource, "RvMdmTermRegisterPhysTermCompletedCB()"));
    }
}

/*$
{protected_function:
    {name: rvMdmTermUnregisterTermDone_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Inform the application that unregister termination operation has been completed.}
    }
    {proto: void rvMdmTermUnregisterTermDone_(RvMdmTerm* term, OUT RvMdmError* mdmError);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
}
$*/
void rvMdmTermUnregisterTermDone_(RvMdmTerm* term)
{
    if (term->termClass->unregisterTermCompletedF != NULL)
    {
        RvMdmError unused;

        RvLogEnter(ippLogSource, (ippLogSource, "RvMdmTermUnregisterTermCompletedCB(term=%p)", term));

        term->termClass->unregisterTermCompletedF(term, &unused);

        RvLogLeave(ippLogSource, (ippLogSource, "RvMdmTermUnregisterTermCompletedCB()"));
    }
}

/*$
{protected_function:
    {name: rvMdmTermUnregisterTermFromNetworkDone_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Inform the application that unregister termination operation from network has been completed.}
    }
    {proto: void rvMdmTermUnregisterTermFromNetworkDone_(RvMdmTerm* term, OUT RvMdmError* mdmError);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
}
$*/
void rvMdmTermUnregisterTermFromNetworkDone_(IN RvMdmTerm* term)
{
    RvMdmError unused;

    RvLogEnter(ippLogSource, (ippLogSource, "RvMdmTermUnregisterTermFromNetworkCompletedCB(term=%p)", term));

    term->termClass->unregisterTermFromNetworkCompletedF(term, &unused);

    RvLogLeave(ippLogSource, (ippLogSource, "RvMdmTermUnregisterTermFromNetworkCompletedCB()"));
}

/*$
{protected_function:
    {name: rvMdmTermModifyMediaDone_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Inform the application that register a physical termination operation has been completed.}
    }
    {proto: void rvMdmTermModifyMediaDone_(RvMdmTerm* term, RvBool status, RvMdmMediaStream* media, RvMdmMediaStreamDescr* streamDescr, RvMdmTermReasonModifyMedia reason);}
    {params:
        {param: {n:term} {d:Termination.}}
        {param: {n:status} {d:Status of the process.}}
        {param: {n:media} {d:new media parameters}}
        {param: {n:streamDescr} {d:media parameters returned by the user}}
        {param: {n:reason} {d:indicates the reason for the status}}
    }
}
$*/

void rvMdmTermModifyMediaDone_(RvMdmTerm* term,
                               RvBool status,
                               RvMdmMediaStream* media,
                               RvMdmMediaStreamDescr* streamDescr,
                               RvMdmTermReasonModifyMedia reason)
{
    if (term->termClass->modifyMediaCompletedF != NULL)
        term->termClass->modifyMediaCompletedF(term, status, media, streamDescr, reason);
}


/*$
{function:
    {name: rvMdmTermGetId}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Gets the termination id.}
    }
    {proto: const char* rvMdmTermGetId(RvMdmTerm* term);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
    }
    {returns:
        The termination id.
    }
    {notes:
        {note:
            For a temporary termination inside the SelectTermination callback
            (type RV_MDMTERMTYPE_UNKNOWN) this will return a partial id or an empty string.
        }
    }
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmTermGetId(IN RvMdmTerm* term)
{
    const RvChar* idStr;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermGetId(term=%p)", term));

    idStr = rvCCTerminalMdmGetTermId((RvCCTerminal *)term->xTerm);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermGetId()=%s", nprn(idStr)));

    return idStr;
}

/*$
{protected_function:
    {name: rvMdmTermConstruct_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Constructs an abstract termination.}
    }
    {proto: void rvMdmTermConstruct_(RvMdmTerm* term,RvMdmTermClass* termClass,
                                     RvMdmXTerm* xTerm);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
        {param: {n:termClass} {d:A pointer to termination class.}}
        {param: {n:xTermClbks} {d:A pointer to a table of callbacks set by the concrete manager.}}
        {param: {n:xTerm} {d:A pointer to the concrete termination.}}
    }
    {notes:
        {note:
            Call from the function that register with the concrete termination manager.
        }
    }
}
$*/
void rvMdmTermConstruct_(
    IN RvMdmTerm*       term,
    IN RvMdmTermClass*  termClass,
    IN RvMdmXTerm*      xTerm)
{
    term->termClass = termClass;
    term->xTerm = xTerm;
    term->userData = NULL;
}

/*$
{protected_function:
    {name: rvMdmTermDestruct_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Destruct the object.}
    }
    {proto: void rvMdmTermDestruct_(RvMdmTerm* term);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
    }

}
$*/
void rvMdmTermDestruct_(RvMdmTerm* term)
{
    RV_UNUSED_ARG(term);
}

/*$
{protected_function:
    {name: rvMdmTermGetXTerm_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Return the concrete termination associated with the abtract termination.}
    }
    {proto: RvMdmXTerm * rvMdmTermGetXTerm_(RvMdmTerm* term);}
    {params:
        {param: {n:term} {d:A pointer to termination object.}}
    }
    {returns:
        Returns the concrete termination.
    }
}
$*/
RvMdmXTerm * rvMdmTermGetXTerm_(RvMdmTerm* term)
{
    return term->xTerm;
}

/*$
{protected_function:
    {name: rvMdmTermStartSignal_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Start a signal in a termination.}
    }
    {proto: RvBool rvMdmTermStartSignal_(RvMdmTerm* term,RvMdmSignal * s,OUT RvMdmError* mdmError)}
    {params:
        {param: {n:term} {d:The termination.}}
        {param: {n:s} {d:The signal.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return "rvFalse" if it fails. In this case mdmError can be set. If is not set, a default error value will be assigned.
    }
}
$*/
RvBool rvMdmTermStartSignal_(RvMdmTerm* term, RvMdmSignal * s,OUT RvMdmError* mdmError)
{
    if (term->termClass->startSignalF != NULL)
        return term->termClass->startSignalF(term, s, mdmError);
    else
        return RV_FALSE;
}

/*$
{protected_function:
    {name: rvMdmTermStopSignal_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Stop a signal in a termination.}
    }
    {proto: RvBool rvMdmTermStopSignal_(RvMdmTerm* term,RvMdmSignal * s,OUT RvMdmError* mdmError);}
    {params:
        {param: {n:term} {d:The termination.}}
        {param: {n:s} {d:The signal.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return "rvFalse" if it fails. In this case mdmError can be set. If is not set, a default error value will be assigned.
    }
}
$*/
RvBool rvMdmTermStopSignal_(RvMdmTerm* term,RvMdmSignal * s,OUT RvMdmError* mdmError)
{
    if (term->termClass->stopSignalF != NULL)
        return term->termClass->stopSignalF(term, s, mdmError);
    else
        return RV_FALSE;
}

/*$
{protected_function:
    {name: rvMdmTermPlaySignal_}
    {class: RvMdmTerm}
    {include: rvmdm.h}
    {description:
        {p: Start a signal in a termination.}
    }
    {proto: RvBool rvMdmTermPlaySignal_(RvMdmTerm* term,RvMdmSignal * s,RvBool reportCompletion,OUT RvMdmError* mdmError)}
    {params:
        {param: {n:term} {d:The termination.}}
        {param: {n:s} {d:The signal.}}
        {param: {n:reportCompletion}
            {d:If rvTrue, the application must call rvMdmTermSignalCompleted when the signal ends.
               Can be set only for signal of type RV_MEGACOSIGNAL_BRIEF. }}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return "rvFalse" if it fails. In this case mdmError can be set. If is not set, a default error value will be assigned.
    }
}
$*/
RvBool rvMdmTermPlaySignal_(RvMdmTerm* term,RvMdmSignal * s,RvBool reportCompletion,OUT RvMdmError* mdmError)
{
    if (term->termClass->playSignalF != NULL)
        return term->termClass->playSignalF(term,s,reportCompletion,mdmError);
    else
        return RV_FALSE;
}

RvBool rvMdmTermClassIsPkgSupported_(RvMdmTermClass* termClass,const char* pkg)
{
    size_t i;
    RvMdmPackagesDescriptor* pkgs = &termClass->pkgsCaps;

    i = rvMdmPackagesDescriptorGetNumPackages(pkgs);
    for (i=0;i<rvMdmPackagesDescriptorGetNumPackages(pkgs);i++)
    {
        if (!rvStrIcmp(rvMdmPackagesDescriptorGetPackageName(pkgs,i),pkg))
            return RV_TRUE;
    }
    return RV_FALSE;
}

RvBool rvMdmTermIsPkgSupported_(RvMdmTerm* term,const char* pkg)
{
    return rvMdmTermClassIsPkgSupported_(term->termClass,pkg);
}

RvMdmPackagesDescriptor* rvMdmTermGetPackages_(RvMdmTerm* term)
{
    return &term->termClass->pkgsCaps;
}

RvMdmMediaDescriptor* rvMdmTermGetMediaCapabilites_(RvMdmTerm* term)
{
    return &term->termClass->mediaCaps;
}

RvMdmDigitMapMatchType rvMdmTermMatchDialString_(RvMdmTerm* x, const char *dialString, unsigned int *timerDuration)
{
    if (x->termClass->matchDialStringF != NULL)
        return x->termClass->matchDialStringF(x, dialString, timerDuration);
    else
        return terminalMdmMatchDigitMap(x->xTerm, dialString, timerDuration);
}

RvBool rvMdmTermMapDialStringToAddress_(RvMdmTerm* x, const char* dialString, char* address)
{
    return x->termClass->mapDialStringToAddressF(x, dialString, address);
}

/*------------------------------------------------------------------------------*/
/* RvMdmTermMgr methods                                                         */
/*------------------------------------------------------------------------------*/

/*
{function:
    {name: rvMdmRegisterSignal}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Register signal.}
    }
    {proto: static void rvMdmRegisterSignal(RvMdmPackage* pkg,const char* id,int timeout);}
    {params:
        {param: {n:pkg} {d:A pointer to package class object.}}
        {param: {n:id} {d:A pointer to event name string.}}
        {param: {n:timeout} {d:The signal timeout.}}
    }
}
*/
static void rvMdmRegisterSignal(RvMdmPackage* pkg,const char* id,int timeout)
{
    RvMdmSignalData signal;
    RvMdmSignalType type = RV_MDMSIGNAL_ONOFF;

    if (timeout > 0)
        type = RV_MDMSIGNAL_TIMEOUT;
    else if (timeout < 0)
        type = RV_MDMSIGNAL_BRIEF;

    /* Register the events*/
    rvMdmSignalDataConstructA(&signal, id, type, prvDefaultAlloc);
    if (timeout > 0)
        rvMdmSignalDataSetTimeout(&signal, (RvMilliseconds)timeout);
    rvMdmPackageRegisterSignal(pkg, &signal);
    rvMdmSignalDataDestruct(&signal);
}

/*
{function:
    {name: rvMdmRegisterPackages}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Register default packages.}
    }
    {proto: static void rvMdmRegisterPackages(RvMdmTermMgr* mgr);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager class object.}}
    }
}
*/
static void rvMdmRegisterPackages(RvMdmTermMgr* mgr)
{
    RvMdmPackage* pkg;
    const RvChar *digitChars[] = {
        "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9",
        "da", "db", "dc", "dd", "ds", "do", "ce", NULL
    };
    const RvChar **pStr;

    /* Register package al */
    /*---------------------*/
    pkg = rvMdmTermMgrCreatePackage(mgr,"al");

    rvMdmPackageRegisterEvent(pkg,"of");
    rvMdmPackageRegisterEvent(pkg,"on");
    rvMdmPackageRegisterEvent(pkg,"fl");

    rvMdmRegisterSignal(pkg,"ri",180000);

    /* Register package dd */
    /*---------------------*/
    pkg = rvMdmTermMgrCreatePackage(mgr,"dd");
    for (pStr = digitChars; *pStr; pStr++)
        rvMdmPackageRegisterEvent(pkg, *pStr);

    /* Register package dd-end */
    /*---------------------*/
    pkg = rvMdmTermMgrCreatePackage(mgr,"dd-end");
    for (pStr = digitChars; *pStr; pStr++)
        rvMdmPackageRegisterEvent(pkg, *pStr);

    /* Register package dg */
    /*---------------------*/
    pkg = rvMdmTermMgrCreatePackage(mgr,"dg");
    rvMdmRegisterSignal(pkg,"d0",-1);
    rvMdmRegisterSignal(pkg,"d1",-1);
    rvMdmRegisterSignal(pkg,"d2",-1);
    rvMdmRegisterSignal(pkg,"d3",-1);
    rvMdmRegisterSignal(pkg,"d4",-1);
    rvMdmRegisterSignal(pkg,"d5",-1);
    rvMdmRegisterSignal(pkg,"d6",-1);
    rvMdmRegisterSignal(pkg,"d7",-1);
    rvMdmRegisterSignal(pkg,"d8",-1);
    rvMdmRegisterSignal(pkg,"d9",-1);
    rvMdmRegisterSignal(pkg,"da",-1);
    rvMdmRegisterSignal(pkg,"db",-1);
    rvMdmRegisterSignal(pkg,"dc",-1);
    rvMdmRegisterSignal(pkg,"dd",-1);
    rvMdmRegisterSignal(pkg,"ds",-1);
    rvMdmRegisterSignal(pkg,"do",-1);

    /* Register package cg */
    /*---------------------*/
    pkg = rvMdmTermMgrCreatePackage(mgr,"cg");
    rvMdmRegisterSignal(pkg,"bt",30000);
    rvMdmRegisterSignal(pkg,"wt",180000);
    rvMdmRegisterSignal(pkg,"rt",180000);
    rvMdmRegisterSignal(pkg,"dt",16000);
    rvMdmRegisterSignal(pkg,"ct",30000);
    rvMdmRegisterSignal(pkg,"sit",180000);
    rvMdmRegisterSignal(pkg,"pt",180000);
    rvMdmRegisterSignal(pkg,"cw",300+85+250);
    rvMdmRegisterSignal(pkg,"cr",180000);

    /* Register package cd */
    /*---------------------*/
    pkg = rvMdmTermMgrCreatePackage(mgr,"cd");

    rvMdmPackageRegisterEvent(pkg,"dt");
    rvMdmPackageRegisterEvent(pkg,"rt");
    rvMdmPackageRegisterEvent(pkg,"bt");
    rvMdmPackageRegisterEvent(pkg,"ct");
    rvMdmPackageRegisterEvent(pkg,"sit");
    rvMdmPackageRegisterEvent(pkg,"wt");
    rvMdmPackageRegisterEvent(pkg,"pt");
    rvMdmPackageRegisterEvent(pkg,"cw");
    rvMdmPackageRegisterEvent(pkg,"cr");

}

/*$
{protected_function:
    {name: rvMdmTermMgrConstruct_}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Common constructor for the termination manager.}
    }
    {proto: void rvMdmTermMgrConstruct_(RvMdmTermMgr* mgr,RvAlloc * a);}
    {params:
        {param: {n:term} {d:A pointer to termination manager object.}}
        {param: {n:a} {d:Allocator.}}
    }

}
$*/
void rvMdmTermMgrConstruct_(RvMdmTermMgr* mgr,RvAlloc * a)
{
    mgr->a = a;
    rvMapConstruct(RvIString,RvMdmPackagePtr)(&mgr->packageData,a);
    rvPtrListConstruct(&mgr->termClassList,mgr->a);
    rvPtrListConstruct(&mgr->digitMapData,a);
    mgr->connectF = NULL;
    mgr->disconnectF = NULL;
    mgr->userData = NULL;
    mgr->xTermMgr = NULL;
    mgr->xApp = NULL;

    rvMdmRegisterPackages(mgr);
}

/*$
{function:
    {name: rvMdmTermMgrDestruct}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Destructs the termination manager and release all the memory.}
    }
    {proto: void rvMdmTermMgrDestruct(RvMdmTermMgr* mgr);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
    }

}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrDestruct(IN RvMdmTermMgr* mgr)
{
    RvPtrListIter i;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrDestruct(mgr=%p)", mgr));

    /* Destruct all the term class objects */
    for(i=rvPtrListBegin(&mgr->termClassList);i!=rvPtrListEnd(&mgr->termClassList);i=rvPtrListIterNext(i))
    {
        RvMdmTermClass * termClass = rvPtrListIterData(i);
        rvMdmTermClassDestruct_(termClass);
        rvMtfAllocatorDealloc(termClass, sizeof(RvMdmTermClass));
    }
    rvPtrListDestruct(&mgr->termClassList);

    if (mgr->xTermMgrClbks != NULL)
        mgr->xTermMgrClbks->destructF(mgr);

    rvMapDestruct(&mgr->packageData);

    /* Free the list members */
    for(i=rvPtrListBegin(&mgr->digitMapData);i!=rvPtrListEnd(&mgr->digitMapData);i=rvPtrListIterNext(i))
    {
        RvMdmDigitMapData* data = rvPtrListIterData(i);
        rvMdmDigitMapDataDestruct(data);
        rvMtfAllocatorDealloc(data, sizeof(RvMdmDigitMapData));
    }
    rvPtrListDestruct(&mgr->digitMapData);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrDestruct()"));
}

/*$
{function:
    {name: rvMdmTermMgrStart}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:After calling this function the termination manager will start processing
           commands and events, and the MG will signal that is going up.}
    }
    {proto: void rvMdmTermMgrStart(RvMdmTermMgr* mgr,RvMdmServiceChange * sc);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:sc} {d:The service change parameters to NULL.}}
        {param: {n:delay} {d:The delay in milliseconds to wait before starting the MDM.}}
    }
    {notes:
        {note:
            Usually called after registering the physical endpoints.
        }
        {note:
            If sc is NULL default values will be used.
        }
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrStart(
    IN RvMdmTermMgr*        mgr,
    IN RvMdmServiceChange*  sc,
    IN RvInt32              delay)
{
	RV_UNUSED_ARG(mgr);
    RV_UNUSED_ARG(delay);
    RV_UNUSED_ARG(sc);

	/* There is nothing to do at MTF start. This proc is left here for reference only */
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrStart(mgr=%p)", mgr));


    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrStart()"));
}


/*$
{function:
    {name: rvMdmTermMgrStop}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Calling this function will cause the MG to signal that is going down.}
    }
    {proto: void rvMdmTermMgrStop(RvMdmTermMgr* mgr,RvMdmServiceChange * sc);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:sc} {d:The service change parameters o NULL.}}
    }
    {notes:
        {note:
            If sc is NULL default values will be used.
        }
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrStop(
    IN RvMdmTermMgr*        mgr,
    IN RvMdmServiceChange*  sc)
{
    RV_UNUSED_ARG(sc);

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrStop(mgr=%p)", mgr));

    mgr->xTermMgrClbks->stopF(mgr->xTermMgr);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrStop()"));
}


/*$
{function:
    {name: rvMdmTermMgrCreateTermClass}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Allocates and construct a new termination class in the Termination Manager.}
    }
    {proto: RvMdmTermClass * rvMdmTermMgrCreateTermClass(RvMdmTermMgr* mgr);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
    }
    {returns:
        The new termination class or NULL if it fails.
    }
    {notes:
        {note:
            Use the RvMdmTermClass to set the properties for the new class.
        }
    }
}
$*/
RVAPI RvMdmTermClass* RVCALLCONV rvMdmTermMgrCreateTermClass(IN RvMdmTermMgr* mgr)
{
    RvMdmTermClass * termClass = NULL;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrCreateTermClass(mgr=%p)", mgr));

    /* Allocate a new termination class,initialize and save on list */
    rvMtfAllocatorAlloc(sizeof(RvMdmTermClass), (void**)&termClass);
    rvMdmTermClassConstructA_(termClass,mgr->a);
    /* All the classes support the generic package */
    rvMdmTermClassAddSupportedPkg(termClass,"g",1);
    rvPtrListPushBack(&mgr->termClassList,termClass);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrCreateTermClass()=%p", termClass));

    return termClass;
}

/*$
{function:
    {name: rvMdmTermMgrRegisterPhysicalTermination}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Register a physical termination of an existing class with the termination manager.}
    }
    {proto: RvMdmTerm*  rvMdmTermMgrRegisterPhysicalTermination(RvMdmTermMgr* mgr,
                                             RvMdmTermClass * c,const char* id,
                                             RvMdmTermDefaultProperties* termProperties,
                                             RvMdmServiceChange * sc);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:c} {d:A pointer to a previously created and initialized termination class.}}
        {param: {n:id} {d:The termination id.}}
        {param: {n:termProperties} {d:Default properties of the termination or NULL.}}
        {param: {n:sc} {d:The service change parameters o NULL.}}
    }
    {returns:
        A pointer to the new termination or NULL if it fails.
    }
    {notes:
        {note:
            If the function is called after calling rvMdmTermMgrStart,
            it will signal that the new termination is coming up.
        }
        {note:
            If sc is NULL default values will be used.
        }
    }
}
$*/
RVAPI RvMdmTerm* RVCALLCONV rvMdmTermMgrRegisterPhysicalTermination(
    IN RvMdmTermMgr*                        mgr,
    IN RvMdmTermClass*                      c,
    IN const RvChar*                        id,
    IN struct RvMdmTermDefaultProperties_*  termProperties,
    IN RvMdmServiceChange*                  sc)
{
    RvMdmTerm* obj;

    RV_UNUSED_ARG(sc);

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterPhysicalTermination(mgr=%p,c=%p,id=%s,prop=%p)", mgr, c, id, termProperties));

    obj = mgr->xTermMgrClbks->registerPhysTermF(mgr->xTermMgr, c, id, termProperties);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterPhysicalTermination()=%p", obj));

    return obj;
}

RVAPI RvMdmTerm* RVCALLCONV rvMdmTermMgrRegisterPhysicalTerminationAsync(
    IN RvMdmTermMgr*                        mgr,
    IN RvMdmTermClass*                      c,
    IN const RvChar*                        id,
    IN struct RvMdmTermDefaultProperties_*  termProperties,
    IN void*                                userData)
{
    RvMdmTerm* obj;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterPhysicalTerminationAsync(mgr=%p,c=%p,id=%s,prop=%p,userData=%p)", mgr, c, id, termProperties, userData));

    obj = mgr->xTermMgrClbks->registerPhysTermAsyncF(mgr->xTermMgr, c, id, termProperties, userData);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterPhysicalTerminationAsync()=%p", obj));

    return obj;
}

/*$
{function:
    {name: rvMdmTermMgrRegisterEphemeralTermination}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Register an ephemeral termination of an existing class with the termination manager.}
    }
    {proto: RvMdmTerm*  rvMdmTermMgrRegisterEphemeralTermination(RvMdmTermMgr* mgr,
                                                     RvMdmTermClass * c,RvMdmTermDefaultProperties* termProperties);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:c} {d:A pointer to a previously created and initialized termination class.}}
        {param: {n:termProperties} {d:Default properties of the termination or NULL.}}
    }
    {returns:
        A pointer to the new termination or NULL if it fails.
    }
    {notes:
        {note:
            This function will not signal that the new termination is coming up.
        }
    }
}
$*/
RVAPI RvMdmTerm* RVCALLCONV rvMdmTermMgrRegisterEphemeralTermination(
    IN RvMdmTermMgr*                        mgr,
    IN RvMdmTermClass*                      c,
    IN const RvChar*                        id,
    IN struct RvMdmTermDefaultProperties_*  termProperties)
{
    RvMdmTerm*  obj;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterEphemeralTermination(mgr=%p,c=%p,id=%s,prop=%p)", mgr, c, id, termProperties));

    obj = mgr->xTermMgrClbks->registerEphTermF(mgr->xTermMgr,c,id,termProperties);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterEphemeralTermination()=%p", obj));

    return obj;
}

/*$
{function:
    {name: rvMdmTermMgrUnregisterTermination}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Unregister a termination. An unregistred termination will not receive or send
           messages.
        }
    }
    {proto: RvBool rvMdmTermMgrUnregisterTermination(RvMdmTermMgr* mgr,RvMdmTerm* term,RvMdmServiceChange * sc);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:term} {d:A pointer to a termination.}}
        {param: {n:sc} {d:The service change parameters o NULL.}}
    }
    {returns:
        RvFalse if it fails.
    }
    {notes:
        {note:
            If the function is called after calling rvMdmTermMgrStart,
            and the termination is of type Physical,
            it will signal that the termination is going down
        }
        {note:
            If sc is NULL default values will be used.
        }
    }
}
$*/
RVAPI RvBool RVCALLCONV rvMdmTermMgrUnregisterTermination(
    IN RvMdmTermMgr*        mgr,
    IN RvMdmTerm*           term,
    IN RvMdmServiceChange*  sc)
{
    RvBool result;

    RV_UNUSED_ARG(sc);

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrUnregisterTermination(mgr=%p,term=%p)", mgr, term));

    result = mgr->xTermMgrClbks->unregisterTermF(mgr->xTermMgr, term->xTerm);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrUnregisterTermination()=%d", result));

    return result;
}


RVAPI RvBool RVCALLCONV rvMdmTermMgrUnregisterTerminationAsync(
    IN RvMdmTermMgr*        mgr,
    IN RvMdmTerm*           mdmTerm,
    IN RvMdmServiceChange*  sc)
{
    RvBool result;

    RV_UNUSED_ARG(sc);

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrUnregisterTerminationAsync(mgr=%p,term=%p)", mgr, mdmTerm));

    result = mgr->xTermMgrClbks->unregisterTermAsyncF(mgr->xTermMgr, mdmTerm->xTerm);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrUnregisterTerminationAsync()=%d", result));

    return result;
}


/*$
{function:
    {name: rvMdmTermMgrFindTermination}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Find a termination by id.
        }
    }
    {proto: RvMdmTerm* rvMdmTermMgrFindTermination(RvMdmTermMgr* mgr,const char* id);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:id} {d:The termination id.}}
    }
    {returns:
        A pointer to the termination or NULL if not found.
    }
}
$*/
RVAPI RvMdmTerm* RVCALLCONV rvMdmTermMgrFindTermination(
    IN RvMdmTermMgr*    mgr,
    IN const RvChar*    id)
{
    RvMdmTerm* t;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrFindTermination(mgr=%p,id=%s)", mgr, id));

    t = mgr->xTermMgrClbks->findTermF(mgr->xTermMgr,id);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrFindTermination()=%p", t));

    return t;
}

/*$
{function:
    {name: rvMdmTermMgrGetIdleTermination}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Returns an idle termination, matching a partially specified id.
        }
    }
    {proto: RvMdmTerm* rvMdmTermMgrGetIdleTermination(RvMdmTermMgr* mgr,const char* id);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:id} {d:The partial id, use an empty string to get any idle termination.
                           Use '\$' to match a specific pattern.}}
    }
    {returns:
        A pointer to the termination or NULL if not found.
    }
}
$*/
RVAPI RvMdmTerm* RVCALLCONV rvMdmTermMgrGetIdleTermination(
    IN RvMdmTermMgr*    mgr,
    IN const RvChar*    id)
{
    RvMdmTerm* t;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrGetIdleTermination(mgr=%p,id=%s)", mgr, id));

    t = mgr->xTermMgrClbks->getIdleTermF(mgr->xTermMgr,id);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrGetIdleTermination()=%p", t));

    return t;
}


/*$
{function:
    {name: rvMdmTermMgrRegisterSelectTermCB}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Set the callback to be called to select a termination.
        }
    }
    {proto: void rvMdmTermMgrRegisterSelectTermCB(RvMdmTermMgr* mgr,RvMdmTermMgrSelectTerminationCB selectF);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:selectF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrRegisterSelectTermCB(
    IN RvMdmTermMgr*                    mgr,
    IN RvMdmTermMgrSelectTerminationCB  selectF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterSelectTermCB(mgr=%p,f=%p)", mgr, selectF));

    mgr->selectF = selectF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterSelectTermCB()"));
}

/*$
{function:
    {name: rvMdmTermMgrRegisterDeleteEphTermCB}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Set the callback to be called to release an ephemeral
           termination.
        }
    }
    {proto: void rvMdmTermMgrRegisterDeleteEphTermCB(RvMdmTermMgr* mgr,RvMdmTermMgrDeleteEphTermCB deleteEphF);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:deleteEphF} {d:The callback function.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrRegisterDeleteEphTermCB(
    IN RvMdmTermMgr*                mgr,
    IN RvMdmTermMgrDeleteEphTermCB  deleteEphF)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterDeleteEphTermCB(mgr=%p,f=%p)", mgr, deleteEphF));

    mgr->deleteEphF = deleteEphF;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrRegisterDeleteEphTermCB()"));
}


/*$
{function:
    {name: rvMdmTermMgrCreatePackage}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Register a package.
        }
    }
    {proto: RvMdmPackage* rvMdmTermMgrCreatePackage(RvMdmTermMgr* mgr,const char* name);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:name} {d:The new package name.}}
    }
    {returns:
        The new package,use to register events,signals, properties and statistics.
    }
}
$*/
static RvMdmPackage* rvMdmTermMgrCreatePackage(RvMdmTermMgr* mgr,const char* name)
{
    RvString pkgStr;
    RvMdmPackage *pkgInfo = NULL;
    const RvMdmPackagePtr *pkgInfoPtr;

    rvStringConstruct(&pkgStr, name,mgr->a);
    rvStringMakeLowercase(&pkgStr);

    pkgInfoPtr = rvMapGetValue(RvIString,RvMdmPackagePtr)(&mgr->packageData, &pkgStr);
    if (pkgInfoPtr != NULL)
        pkgInfo = *pkgInfoPtr;
    else
    {
        rvMtfAllocatorAlloc(sizeof(RvMdmPackage), (void**)&pkgInfo);
        rvMdmPackageConstruct_(pkgInfo,name,mgr,mgr->a);
        rvMapSetValue(RvIString,RvMdmPackagePtr)(&mgr->packageData, &pkgStr, &pkgInfo);
    }
    rvStringDestruct(&pkgStr);

    return pkgInfo;
}

/*$
{function:
    {name: rvMdmTermMgrGetPackage}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Get a handler to and existing package, use to overwrite or add values.
        }
    }
    {proto: RvMdmPackage* rvMdmTermMgrGetPackage(RvMdmTermMgr* mgr,const char* name);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:name} {d:The package name.}}
    }
    {returns:
        The package handler or null if not previously registered.
    }
}
$*/
RVAPI RvMdmPackage* RVCALLCONV rvMdmTermMgrGetPackage(
    IN RvMdmTermMgr*    mgr,
    IN const RvChar*    name)
{
    RvString pkgStr;
    RvMdmPackage *pkgInfo = NULL;
    const RvMdmPackagePtr *pkgInfoPtr;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrGetPackage(mgr=%p,name=%s)", mgr, name));

    rvStringConstruct(&pkgStr, name,mgr->a);
    rvStringMakeLowercase(&pkgStr);

    pkgInfoPtr = rvMapGetValue(RvIString,RvMdmPackagePtr)(&mgr->packageData, &pkgStr);
    if (pkgInfoPtr != NULL)
        pkgInfo = *pkgInfoPtr;

    rvStringDestruct(&pkgStr);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrGetPackage()=%p", pkgInfo));

    return pkgInfo;
}

/*$
{function:
    {name: rvMdmTermMgrRegisterMapAddressToTermCB}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Register a callback that maps an address to a termination.
            Registration of this callback function is not optional.
        }
    }
    {proto: void rvMdmTermMgrRegisterMapAddressToTermCB(RvMdmTermMgr* mgr, rvMdmTermMgrMapAddressToTermCB mapAddressToTermF);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:mapAddressToTermF} {d:The callback function.}}
    }
}
$*/
RVAPI void rvMdmTermMgrRegisterMapAddressToTermCB(RvMdmTermMgr* mgr, RvMdmTermMgrMapAddressToTermCB mapAddressToTermF)
{
    mgr->mapAddressToTermF = mapAddressToTermF;
}

/*$
{protected_function:
    {name: rvMdmTermMgrRegisterXTermMgrClbks_}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p:Register the callbacks to the concrete termination manager.
        }
    }
    {proto: void rvMdmTermMgrRegisterXTermMgrClbks_(RvMdmTermMgr* mgr,RvMdmXTermClbks * t);
    }
    {params:
        {param: {n:mgr} {d:A pointer to termination manager object.}}
        {param: {n:t} {d:A pointer to the table of callbacks.}}
    }
}
$*/
void rvMdmTermMgrRegisterXTermMgrClbks_(RvMdmTermMgr* mgr,RvMdmXTermMgrClbks * t)
{
    mgr->xTermMgrClbks = t;
}

RvMdmTerm* rvMdmTermMgrSelectTermination_(RvMdmTermMgr* mgr,RvMdmTerm* tempTerm)
{
    return mgr->selectF(mgr, tempTerm);
}

RvMdmPackage* rvMdmTermMgrGetPkgInfo_(RvMdmTermMgr *termMgr,const RvString *pkgStr)
{
    RvMdmPackage *pkgInfo;
    const RvMdmPackagePtr *pkgInfoPtr;

    pkgInfoPtr = rvMapGetValue(RvIString, RvMdmPackagePtr)(&termMgr->packageData, pkgStr);
    if(pkgInfoPtr != NULL)
        pkgInfo = *pkgInfoPtr;
    else {
        pkgInfo = NULL;
    }
    return pkgInfo;
}

const RvMdmSignalInfo* rvMdmTermMgrGetSignalInfo_(RvMdmTermMgr* x,const RvString* pkgStr,const RvString* sigStr)
{
    const RvMdmSignalInfo* signalInfo = NULL;
    RvMdmPackage* pkgInfo = rvMdmTermMgrGetPkgInfo_(x,pkgStr);

    if(pkgInfo != NULL)
    {
        signalInfo = rvMapGetValue(RvIString, RvMdmSignalInfo)(&pkgInfo->signalInfo, sigStr);
    }
    return signalInfo;
}

void rvMdmTermMgrDeleteEphTerm_(RvMdmTermMgr* mgr,RvMdmTerm* ephTerm)
{
    mgr->deleteEphF(mgr,ephTerm);
}


/*$
{protected_function:
    {name: rvMdmTermMgrConnectMediaStreams_}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Connect a media stream in a termination to a media stream in another termination.}
    }
    {proto: rvMdmTermMgrConnectMediaStreams_(RvMdmTermMgr* mgr,RvMdmTerm* source,RvMdmMediaStream* m1,RvMdmTerm* target,
                                     RvMdmMediaStream* m2,RvMdmStreamDirection direction,RvMdmError * error);}
    {params:
        {param: {n:mgr} {d:Termination manager.}}
        {param: {n:source} {d:First termination.}}
        {param: {n:m1} {d:Media stream in first termination.}}
        {param: {n:target} {d:Second termination.}}
        {param: {n:m2} {d:Media stream in second termination.}}
        {param: {n:direction} {d:Direction of the media flow.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return "rvFalse" if it fails. In this case mdmError can be set. If is not set, a default error value will be assigned.
    }
}
$*/
RvBool rvMdmTermMgrConnectMediaStreams_(RvMdmTermMgr* mgr,RvMdmTerm* source,RvMdmMediaStream* m1,RvMdmTerm* target,
                                     RvMdmMediaStream* m2,RvMdmStreamDirection direction,RvMdmError * error)
{
    if (mgr->connectF != NULL)
        return mgr->connectF(mgr,source,m1,target,m2,direction,error);
    else
        return RV_FALSE;
}


/*$
{protected_function:
    {name: rvMdmTermMgrDisconnectMediaStreams_}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Disconnect a media stream in a termination from a media stream in another termination.
        }
    }
    {proto: RvBool rvMdmTermMgrDisconnectMediaStreams_(RvMdmTermMgr* mgr,RvMdmTerm* source,RvMdmMediaStream* m1,
                                                    RvMdmTerm* target,RvMdmMediaStream* m2,RvMdmError * error);}
    {params:
        {param: {n:mgr} {d:Termination manager.}}
        {param: {n:source} {d:First termination.}}
        {param: {n:m1} {d:Media stream in first termination.}}
        {param: {n:target} {d:Second termination.}}
        {param: {n:m2} {d:Media stream in second termination.}}
        {param: {n:mdmError} {d:(Optional) Use to set error information.}}
    }
    {returns:
        Return "rvFalse" if it fails. In this case mdmError can be set. If is not set, a default error value will be assigned.
    }
}
$*/
RvBool rvMdmTermMgrDisconnectMediaStreams_(RvMdmTermMgr* mgr,RvMdmTerm* source,RvMdmMediaStream* m1,
                                        RvMdmTerm* target,RvMdmMediaStream* m2,RvMdmError * error)
{
    if (mgr->disconnectF != NULL)
        return mgr->disconnectF(mgr,source,m1,target,m2,error);
    else
        return RV_FALSE;
}

/*$
{function:
    {name: rvMdmTermMgrRegisterAllTermsToNetwork}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Sends a Registration request to network for all terminations who
            registered to MDM.}
    }
    {proto: void * rvMdmTermMgrRegisterAllTermsToNetwork(RvMdmTermMgr* mgr);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager.}}
    }
    {returns:
        rvTrue if message was sent successfully, rvFalse, if not.
    }
}
$*/
RVAPI RvBool RVCALLCONV rvMdmTermMgrRegisterAllTermsToNetwork(IN RvMdmTermMgr* mgr)
{
    RvBool res;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermMgrRegisterAllTermsToNetwork(mgr=%p)", mgr));

    res = mgr->xTermMgrClbks->registerAllTermsToNetworkF(mgr->xTermMgr);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermMgrRegisterAllTermsToNetwork()=%d", res));

    return res;
}

/*$
{function:
    {name: rvMdmTermMgrRegisterTermToNetwork_}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Sends a Registration request to network for this termination only.}
    }
    {proto: void * rvMdmTermMgrRegisterTermToNetwork_(RvMdmTermMgr* mgr, RvMdmTerm* term);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager.}}
        {param: {n:term} {d:A pointer to the termination.}}
    }
    {returns:
        rvTrue if message was sent successfully, rvFalse, if not.
    }
}
$*/
RVAPI RvBool RVCALLCONV rvMdmTermMgrRegisterTermToNetwork(
    IN RvMdmTermMgr*    mgr,
    IN RvMdmTerm*       term)
{
    RvBool res;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermMgrRegisterTermToNetwork(mgr=%p,term=%p)", mgr, term));

    res = mgr->xTermMgrClbks->registerTermToNetworkF(mgr->xTermMgr, term);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermMgrRegisterTermToNetwork()=%d", res));

    return res;
}

/*$
{function:
    {name: rvMdmTermMgrUnregisterTermFromNetwork_}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Sends an unregistration request to network for this termination only.}
    }
    {proto: void * rvMdmTermMgrUnregisterTermFromNetwork_(RvMdmTermMgr* mgr, RvMdmTerm* term);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager.}}
        {param: {n:term} {d:A pointer to the termination.}}
    }
    {returns:
        rvTrue if message was sent successfully, rvFalse, if not.
    }
}
$*/
RVAPI RvBool RVCALLCONV rvMdmTermMgrUnregisterTermFromNetwork(
    IN RvMdmTermMgr*    mgr,
    IN RvMdmTerm*       term)
{
    RvBool res;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermMgrUnregisterTermFromNetwork(mgr=%p,term=%p)", mgr, term));

    res = mgr->xTermMgrClbks->unregisterTermFromNetworkF(mgr->xTermMgr, term);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermMgrUnregisterTermFromNetwork()=%d", res));

    return res;
}


/*$
{function:
    {name: rvMdmTermMgrGetUserData}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Returns the user data associated with the termination manager.}
    }
    {proto: void * rvMdmTermMgrGetUserData(RvMdmTermMgr* mgr);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager.}}
    }
    {returns:
        The termination manager user data or NULL if not set.
    }
}
$*/
RVAPI void* RVCALLCONV rvMdmTermMgrGetUserData(IN RvMdmTermMgr* mgr)
{
    void* data;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrGetUserData(mgr=%p)", mgr));

    data = mgr->userData;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrGetUserData()=%p", data));

    return data;
}

/*$
{function:
    {name: rvMdmTermMgrSetUserData}
    {class: RvMdmTermMgr}
    {include: rvmdm.h}
    {description:
        {p: Sets user data associated with the termination.}
    }
    {proto: void rvMdmTermMgrSetUserData(RvMdmTermMgr* mgr,void* data);}
    {params:
        {param: {n:mgr} {d:A pointer to termination manager.}}
        {param: {n:data} {d:The user data.}}
    }
    {notes:
        {note:
            Use this function to associate application data and memory with
            the termination manager.
        }
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermMgrSetUserData(IN RvMdmTermMgr* mgr, IN void* data)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermMgrSetUserData(mgr=%p,data=%p)", mgr, data));

    mgr->userData = data;

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermMgrSetUserData()"));
}


char* rvMdmTermMgrMapAddressToTermination_(RvMdmTermMgr* mgr, const char* address)
{
    return mgr->mapAddressToTermF(mgr, address);
}

/*---------------------------------------------------------------------------------*/
/* Default properties                                                              */
/*---------------------------------------------------------------------------------*/
void rvMdmTermDefaultPropertiesConstructA(RvMdmTermDefaultProperties* x, RvAlloc* alloc)
{
    RvMdmDigitMap map;

    memset(x, 0, sizeof(*x));

    rvMdmDigitMapConstructA(&map, alloc);
    rvMdmDigitMapDescriptorConstructA(&x->digitMap, "", &map,alloc);
    rvMdmDigitMapDestruct(&map);

    rvMdmTermPhoneNumbersConstruct(&(x->phoneNumbers));

    rvMdmTermPresentationInfoConstruct(&(x->presentationInfo));
	x->transportType = -1; /* Undefined transport type */
}

/*$
{function:
    {name: rvMdmTermDefaultPropertiesConstruct}
    {class: RvMdmTermDefaultProperties}
    {include: rvmdm.h}
    {description:
        {p:Constructs the object.}
    }
    {proto: void rvMdmTermDefaultPropertiesConstruct(RvMdmTermDefaultProperties* x);}
    {params:
        {param: {n:x} {d:The default properties object.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesConstruct(
    IN RvMdmTermDefaultProperties*  x)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesConstruct(x=%p)", x));

    rvMdmTermDefaultPropertiesConstructA(x,prvDefaultAlloc);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesConstruct()"));
}

/*$
{function:
    {name: rvMdmTermDefaultPropertiesDestruct}
    {class: RvMdmTermDefaultProperties}
    {include: rvmdm.h}
    {description:
        {p:Constructs the object.}
    }
    {proto: void rvMdmTermDefaultPropertiesDestruct(RvMdmTermDefaultProperties* x);}
    {params:
        {param: {n:x} {d:The default properties object.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesDestruct(
    IN RvMdmTermDefaultProperties*  x)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesDestruct(x=%p)", x));

    rvMdmDigitMapDescriptorDestruct(&x->digitMap);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesDestruct()"));
}


/*$
{function:
    {name: rvMdmTermDefaultPropertiesSetDigitMap}
    {class: RvMdmTermDefaultProperties}
    {include: rvmdm.h}
    {description:
        {p:Set the default list of digit map patterns.}
    }
    {proto: void rvMdmTermDefaultPropertiesSetDigitMap(RvMdmTermDefaultProperties* x,RvMdmDigitMap* digitMap,const char* name);}
    {params:
        {param: {n:x} {d:The default properties object.}}
        {param: {n:digitMap} {d:The digitmap patterns.}}
        {param: {n:name}     {d:The digitmap name.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetDigitMap(
    IN RvMdmTermDefaultProperties*  x,
    IN RvMdmDigitMap*               digitMap,
    IN const RvChar*                name)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetDigitMap(x=%p, digitMap=%p, name=%s)", x, digitMap, name));

    rvMdmDigitMapDescriptorDestruct(&x->digitMap);
    rvMdmDigitMapDescriptorConstruct(&x->digitMap, name, digitMap);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetDigitMap()"));
}


RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetUsername(
    IN RvMdmTermDefaultProperties*  x,
    IN const RvChar*                username)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetUsername(x=%p, username=%s)", x, username));

    strncpy(x->username, username, sizeof(x->username)-1);
    x->username[sizeof(x->username)-1] = '\0';

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetUsername()"));
}


RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetPassword(
    IN RvMdmTermDefaultProperties*  x,
    IN const RvChar*                password)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetPassword(x=%p, password=%s)", x, password));

    strncpy(x->password, password, sizeof(x->password)-1);
    x->password[sizeof(x->password)-1] = '\0';

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetPassword()"));
}

RVAPI RvBool RVCALLCONV rvMdmTermPropertiesSetPresentationInfo(
    IN RvMdmTermDefaultProperties*  x,
    IN RvMdmTermPresentationInfo*   presentationInfo)
{
    RvBool result = RV_FALSE;

    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermPropertiesSetPresentationInfo(x=%p, info=%p)", x, presentationInfo));

    if ((x != NULL) && (presentationInfo != NULL))
    {
        result = RV_TRUE;
        rvMdmTermPresentationInfoCopy(&(x->presentationInfo), presentationInfo);
    }

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermPropertiesSetPresentationInfo()"));

    return result;
}


RVAPI void RVCALLCONV rvMdmTermPropertiesSetPhoneNumbers(
    IN RvMdmTermDefaultProperties*  x,
    IN RvMdmTermPhoneNumbers*       phoneNumbers)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermPropertiesSetPhoneNumbers(x=%p, numbers=%p)", x, phoneNumbers));

    if ((x != NULL) && (phoneNumbers != NULL))
        rvMdmTermPhoneNumbersCopy(&x->phoneNumbers, phoneNumbers);

    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermPropertiesSetPhoneNumbers()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetRegistrarAddress(
															IN RvMdmTermDefaultProperties*  x,
															IN const RvChar*                registrarAddress)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegistrarAddress(x=%p, registrarAddress=%s)", x, registrarAddress));
	
    strncpy(x->registrarAddress, registrarAddress, sizeof(x->registrarAddress)-1);
    x->registrarAddress[sizeof(x->registrarAddress)-1] = '\0';
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegistrarAddress()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetRegistrarPort(
																	IN RvMdmTermDefaultProperties*  x,
																	IN RvUint16                     registrarPort)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegistrarPort(x=%p, registrarPort=%d)", x, registrarPort));
	    
    x->registrarPort = registrarPort;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegistrarPort()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetOutboundProxyAddress(
																	IN RvMdmTermDefaultProperties*  x,
																	IN const RvChar*                outboundProxyAddress)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetOutboundProxyAddress(x=%p, outboundProxyAddress=%s)", x, outboundProxyAddress));
	
    strncpy(x->outboundProxyAddress, outboundProxyAddress, sizeof(x->outboundProxyAddress)-1);
    x->outboundProxyAddress[sizeof(x->outboundProxyAddress)-1] = '\0';
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetOutboundProxyAddress()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetOutboundProxyPort(
														 IN RvMdmTermDefaultProperties*  x,
														 IN RvUint16                     outboundProxyPort)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetOutboundProxyPort(x=%p, outboundProxyPort=%d)", x, outboundProxyPort));
	    
    x->outboundProxyPort = outboundProxyPort;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetOutboundProxyPort()"));
}
#ifdef RV_CFLAG_TLS
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetRegistrarTlsPort(
																	IN RvMdmTermDefaultProperties*  x,
																	IN RvUint16                     registrarTlsPort)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegistrarTlsPort(x=%p, registrarTlsPort=%d)", x, registrarTlsPort));
	
    x->registrarTlsPort = registrarTlsPort;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegistrarTlsPort()"));
}
#endif
#ifdef RV_SIP_IMS_ON
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetPAccessNetworkInfo(
																		IN RvMdmTermDefaultProperties*  x,
																		IN RvChar*                      pAccessNetworkInfo)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetPAccessNetworkInfo(x=%p, pAccessNetworkInfo=%s)", x, pAccessNetworkInfo));
	
    strcpy(x->PAccessNetworkInfo, pAccessNetworkInfo);
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetPAccessNetworkInfo()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetIpSecPortC(
																	IN RvMdmTermDefaultProperties*  x,
																	IN RvUint32                     ipsecPortC)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetipSecPortC(x=%p, ipsecPortC=%d)", x, ipsecPortC));
	
    x->ipsecPortC= ipsecPortC;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetIpSecPortC()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetIpSecPortS(
															  IN RvMdmTermDefaultProperties*  x,
															  IN RvUint32                     ipsecPortS)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetipSecPortS(x=%p, ipsecPortS=%d)", x, ipsecPortS));
	
    x->ipsecPortS = ipsecPortS;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetIpSecPortS()"));
}

#endif

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetRegisterExpires(
														   IN RvMdmTermDefaultProperties*  x,
														   IN RvUint32                     registerExpires)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegisterExpires(x=%p, registerExpires=%d)", x, registerExpires));
	    
    x->registerExpires = registerExpires;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetRegisterExpires()"));
}

RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetTransportType(
														  IN RvMdmTermDefaultProperties*	x,
														  IN RvInt							transportType)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetTransportTcp(x=%p, transportTcp=%d)", x, transportType));
	
	x->transportType = transportType;  
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetTransportTcp()"));
}

//Leibt
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetCFW(
														  IN RvMdmTermDefaultProperties*	x,
														  IN RvInt							cfwType, IN RvChar* address,IN RvUint cfnrTimeout)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetCFW(x=%p, cfw type=%d)", x, cfwType));
	
	x->cfwType= cfwType;
	if(address != NULL)
		strncpy(x->cfwAddress,address,sizeof(x->cfwAddress)-1);
	x->cfnrTimeout = cfnrTimeout ;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetCFW()"));
}

/* zhuzhh, 2011/05/27, disable cwt for line, modify, start */
RVAPI void RVCALLCONV rvMdmTermDefaultPropertiesSetDisableCallWaiting(
														   IN RvMdmTermDefaultProperties*  x,
														   IN RvBool                       disableCallWaiting)
{
    RvLogEnter(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetDisableCallWaiting(x=%p, disableCallWaiting=%d)", x, disableCallWaiting));
	    
    x->disableCallWaiting = disableCallWaiting;
	
    RvLogLeave(ippLogSource, (ippLogSource, "rvMdmTermDefaultPropertiesSetDisableCallWaiting()"));
}
/* zhuzhh, 2011/05/27, disable cwt for line, modify, end */

/*==============================================================
            I P P H O N E   P A C K A G E S
===============================================================*/
/*Generate an event completion for digitmaps for the kp package */
void  rvMdmKpDigitMapBuildEvComplete(RvMdmParameterList *parameters,
                                        const char * digitString,
                                        RvMdmDigitMapMatchType matchType,
                                        void* userData)
{
    RvAlloc * alloc = (RvAlloc*)userData;

    /* If the digitString is empty, don't encode the parameter.
       In the package, encoding an empty string is required,
       but the syntax doesn't support it */
    if (digitString[0])
    {
        RvString quotedDigits;
        RvMdmParameterValue value;

        /* Build the parameter value (digit string) */
        rvStringConstruct(&quotedDigits,"\"",alloc);
        rvStringConcatenate(&quotedDigits,digitString);
        rvStringConcatenate(&quotedDigits,"\"");
        rvMdmParameterValueConstructA(&value,rvStringGetData(&quotedDigits),alloc);

        /* Add to digit string parameter list */
        rvMdmParameterListSet2(parameters,"ds",&value);

        rvMdmParameterValueDestruct(&value);
        rvStringDestruct(&quotedDigits);
    }

    /* Add Termination method */
    if (matchType != RV_MDMDIGITMAP_NOMATCH)
    {
        RvMdmParameterValue value;
        const RvChar* paramValue[] = {"PM", "FM", "UM"};

        rvMdmParameterValueConstructA(&value, paramValue[(int)matchType-1], alloc);

        /* Add termination method to parameter list */
        rvMdmParameterListSet2(parameters, "Meth", &value);

        /* Destruct local objects */
        rvMdmParameterValueDestruct(&value);
    }
}

/* Maps events to characters, ignores all keydown events, and check only keyup.
    Returns RV_MDMEVENT_NOTFOUND if failed to translate,
    or RV_MDMEVENT_IGNORE if the event should be ignored. */
unsigned char rvMdmKpDigitMapTranslateKeypadEv(const RvChar* eventName, const RvMdmParameterList* args)
{
/*
+------+--------------+
| DTMF | Event Symbol |
+------+--------------+
| d0   | "0"          |
| d1   | "1"          |
| d2   | "2"          |
| d3   | "3"          |
| d4   | "4"          |
| d5   | "5"          |
| d6   | "6"          |
| d7   | "7"          |
| d8   | "8"          |
| d9   | "9"          |
| dA   | "A" or "a"   |
| dB   | "B" or "b"   |
| dC   | "C" or "c"   |
| dD   | "D" or "d"   |
| ds   | "E" or "e"   |
| do   | "F" or "f"   |
+------+--------------+
*/
    if (eventName[0] == 'k')
    {
        if (!strcmp(eventName, "kd"))
        {
            const RvChar* key;
            const RvMdmParameterValue* value = rvMdmParameterListGet2(args, "keyid");
            key = rvMdmParameterValueGetValue(value);

            if (key[1]>='0' && key[1]<='9')
                return (unsigned char)key[1];
            if (key[1]>='a' && key[1]<='d')
                return (unsigned char)key[1];
            if (key[1]=='s')
                return (unsigned char)'e';
            if (key[1]=='o')
                return (unsigned char)'f';
        }
        else if (!strcmp(eventName, "ku"))
            return RV_MDMEVENT_IGNORE;
    }

    return RV_MDMEVENT_NOTFOUND;
}

/* Preregister the packages used for the ip phone user interface */
RVAPI void rvMdmTermMgrRegisterIPPhoneUiPackages(RvMdmTermMgr* mgr)
{
    RvMdmPackage* pkg;
    RvMdmParameterValue value;
    RvMdmDigitMapData dmData;

    rvMdmParameterValueConstruct(&value, "");

    pkg = rvMdmTermMgrCreatePackage(mgr, "dis");
    rvMdmRegisterSignal(pkg,"di", -1);
    rvMdmRegisterSignal(pkg,"cld", -1);

    pkg = rvMdmTermMgrCreatePackage(mgr, "key");
    rvMdmPackageRegisterEvent(pkg,"kd");
    rvMdmPackageRegisterEvent(pkg,"ku");

    pkg = rvMdmTermMgrCreatePackage(mgr, "kp");
    rvMdmPackageRegisterEvent(pkg,"kd");
    rvMdmPackageRegisterEvent(pkg,"ku");
    rvMdmPackageRegisterEvent(pkg,"ce");

    /* For this package also register digitmap data */
    rvMdmDigitMapDataConstruct(&dmData,"ce",
                               rvMdmKpDigitMapBuildEvComplete,
                               rvMdmKpDigitMapTranslateKeypadEv,
                               mgr->a);
    rvMdmPackageRegisterDigitMapData(pkg,&dmData);
    rvMdmDigitMapDataDestruct(&dmData);


    pkg = rvMdmTermMgrCreatePackage(mgr, "labelkey");
    rvMdmPackageRegisterEvent(pkg,"kd");
    rvMdmPackageRegisterEvent(pkg,"ku");

    pkg = rvMdmTermMgrCreatePackage(mgr, "kf");
    rvMdmPackageRegisterEvent(pkg,"kd");
    rvMdmPackageRegisterEvent(pkg,"ku");

    pkg = rvMdmTermMgrCreatePackage(mgr, "ind");
    rvMdmRegisterSignal(pkg,"is", -1);

    pkg = rvMdmTermMgrCreatePackage(mgr, "ks");
    rvMdmPackageRegisterEvent(pkg,"kd");
    rvMdmPackageRegisterEvent(pkg,"ku");
    rvMdmRegisterSignal(pkg,"sd", -1);

    /*Radvision Internal package*/
    pkg = rvMdmTermMgrCreatePackage(mgr, "rvcc");
    rvMdmPackageRegisterEvent(pkg,"ga"); /*Gateway active event*/
    rvMdmRegisterSignal(pkg,"la", -1); /* Line active signal */
    rvMdmRegisterSignal(pkg,"li", -1); /* Line inactive signal */
    rvMdmRegisterSignal(pkg,"callerid",-1);
    rvMdmPackageRegisterEvent(pkg,"reject"); /*Reject event*/

    rvMdmParameterValueDestruct(&value);
}

/***********************************************************/
/** Description: Register user package and event.       ***/
/**              If package already exists, it won't     ***/
/**              create it.                              ***/
/***********************************************************/
RVAPI void rvMdmTermMgrRegisterUserSignal(RvMdmTermMgr* mgr, const char* pkg, const char* signal)
{
    RvMdmPackage* pkgItem = NULL;

    RvLogInfo(ippLogSource, (ippLogSource,
        "rvMdmTermMgrRegisterUserSignal::mgr=%p, pkg=%s, signal=%s",
        mgr, (pkg!=NULL)?pkg:"None", (signal!=NULL)?signal:"None"));

    if ((mgr == NULL) || (pkg == NULL) || (signal == NULL))
    {
        RvLogWarning(ippLogSource,(ippLogSource,
            "rvMdmTermMgrRegisterUserSignal::IGNORED! NULL parameter"));
    }

    /*Create a new package in TermMgr, if already exists, will do nothing.*/
    pkgItem = rvMdmTermMgrCreatePackage(mgr, pkg);
    /*Register the signal to the new package*/
    rvMdmRegisterSignal(pkgItem, signal, -1);
}

/***********************************************************/
/** Description: Add user package to a class             ***/
/**                                                      ***/
/***********************************************************/
RVAPI void rvMdmTermMgrSetUserPackage(RvMdmTermClass* c, const char* pkg)
{
    RvLogInfo(ippLogSource,(ippLogSource,
        "rvMdmTermMgrSetUserPackage(class=%p, pkg=%s)", c, (pkg!=NULL)?pkg:"None"));

    if ((c == NULL) || (pkg == NULL))
    {
        RvLogWarning(ippLogSource, (ippLogSource,
            "rvMdmTermMgrSetUserPackage::IGNORED! NULL parameter"));
    }

    if (rvMdmTermClassIsPkgSupported_(c, pkg) == rvTrue)
    {
        /*Do nothing if package already exists*/
        RvLogInfo(ippLogSource, (ippLogSource,
            "rvMdmTermMgrSetUserPackage::class=%p, Package %s already exists", c, pkg));
    }
    else
    {
        rvMdmTermClassAddSupportedPkg(c, pkg, 1);
    }
}

/***********************************************************/
/** Description: Initialize the class representing ui    ***/
/**              terminations, by registering supported  ***/
/**              packages .                              ***/
/***********************************************************/
void rvMdmTermClassSetIPPhoneUIPackages(RvMdmTermClass* c)
{
    rvMdmTermClassAddSupportedPkg(c, "dis", 1);
    rvMdmTermClassAddSupportedPkg(c, "key", 1);
    rvMdmTermClassAddSupportedPkg(c, "kp", 1);
    rvMdmTermClassAddSupportedPkg(c, "labelkey", 1);
    rvMdmTermClassAddSupportedPkg(c, "kf", 1);
    rvMdmTermClassAddSupportedPkg(c, "ind", 1);
    rvMdmTermClassAddSupportedPkg(c, "ks", 1);

    /* Used to send state information to the application */
    rvMdmTermClassAddSupportedPkg(c, "rvcc", 0);
}

/***********************************************************/
/** Description: Set the packages supported by audio     ***/
/** transducer.                                          ***/
/***********************************************************/
void rvMdmTermClassSetAudioTransducerPackages(RvMdmTermClass* c)
{
    rvMdmTermClassAddSupportedPkg(c,"dg",0);
    rvMdmTermClassAddSupportedPkg(c,"cg",0);

    /* Media */
    rvMdmTermClassAddSupportedPkg(c,"rtp",0);
    /*rvMdmTermClassAddSupportedPkg(c,"nt",0);*/
    rvMdmTermClassAddSupportedPkg(c,"tdmc",1);
}

/***********************************************************/
/** Description: Set the packages supported by rtp       ***/
/** termination.                                         ***/
/***********************************************************/
void rvMdmTermClassSetRtpTermPackages(RvMdmTermClass* c)
{
    rvMdmTermClassAddSupportedPkg(c,"rtp",0);
    /*rvMdmTermClassAddSupportedPkg(c,"nt",0);*/
    rvMdmTermClassAddSupportedPkg(c,"tdmc",1);
}

/***********************************************************/
/** Description: Set the packages supported by analog    ***/
/** line termination.                                    ***/
/***********************************************************/
void rvMdmTermClassSetAnalogLinePackages(RvMdmTermClass* c)
{
    rvMdmTermClassAddSupportedPkg(c,"al",0);
    rvMdmTermClassAddSupportedPkg(c,"dd",0);
    rvMdmTermClassAddSupportedPkg(c,"dd-end",0);
    rvMdmTermClassAddSupportedPkg(c,"cg",0);
    rvMdmTermClassAddSupportedPkg(c,"dg",0);
    rvMdmTermClassAddSupportedPkg(c,"andisp",0); /*display*/

    /* Used to send state information to the application */
    rvMdmTermClassAddSupportedPkg(c, "rvcc", 0);

    /* rtp packets */
    rvMdmTermClassAddSupportedPkg(c,"rtp",0);
    /*rvMdmTermClassAddSupportedPkg(c,"nt",0);*/
    rvMdmTermClassAddSupportedPkg(c,"tdmc",1);
}

#ifdef __cplusplus
}
#endif


