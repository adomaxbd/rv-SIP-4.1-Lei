/******************************************************************************
Filename:    rvMtfExtControlApi.c
Description: This file includes functions of extensibility control (SIP and MDM).
*******************************************************************************
                Copyright (c) 2008 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC	LOGSRC_BASE

#include "rvMtfExtControlApi.h"
#include "mtfBaseInt.h"
#include "sipphone.h"
#include "rvccconnmdm.h"
#include "rvcctext.h"
#include "rvccconnsip.h"

/*-----------------------------------------------------------------------
                    G L O B A L		V A R I A B L E S
 ------------------------------------------------------------------------*/

extern		RvMtfSipControlClbks     sipExtClbks; /* SIP extension callbacks */
extern		RvMtfCallControlClbks	 mdmExtClbks; /* MDM extension callbacks */

/*-----------------------------------------------------------------------
                    P U B L I C		F U N C T I O N S
 ------------------------------------------------------------------------*/



/*****************************************************************************
 * rvMtfRegisterSipExtCallbacks()
 *****************************************************************************/
RVAPI void RVCALLCONV rvMtfRegisterSipExtCallbacks(
					IN RvMtfSipControlClbks* clbks)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterSipExtCallbacks(clbks=%p)", clbks));

    if (clbks != NULL)
    {
        sipExtClbks.postCallLegCreatedIncomingCB = clbks->postCallLegCreatedIncomingCB;
		sipExtClbks.postCallLegCreatedOutgoingCB = clbks->postCallLegCreatedOutgoingCB;
		sipExtClbks.postMsgReceivedCB = clbks->postMsgReceivedCB;
		sipExtClbks.postMsgToSendCB = clbks->postMsgToSendCB;
		sipExtClbks.postStateChangedCB = clbks->postStateChangedCB;
		sipExtClbks.preCallLegCreatedIncomingCB = clbks->preCallLegCreatedIncomingCB;
		sipExtClbks.preCallLegCreatedOutgoingCB  = clbks->preCallLegCreatedOutgoingCB;
		sipExtClbks.preMsgReceivedCB = clbks->preMsgReceivedCB;
		sipExtClbks.preStateChangedCB= clbks->preStateChangedCB;
		sipExtClbks.regClientStateChangedCB = clbks->regClientStateChangedCB;
		sipExtClbks.regClientCreatedCB = clbks->regClientCreatedCB;
		sipExtClbks.regExpResolutionNeededCB = clbks->regExpResolutionNeededCB;
		sipExtClbks.regClientMsgToSendCB = clbks->regClientMsgToSendCB;
		sipExtClbks.regClientMsgReceivedCB = clbks->regClientMsgReceivedCB;
		sipExtClbks.registerStackEventsCB = clbks->registerStackEventsCB;
		sipExtClbks.stackConfigCB = clbks->stackConfigCB;
	}

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterSipExtCallbacks()"));
}

/*****************************************************************************
 * rvMtfSipRegisterSubsClbks() 
 *****************************************************************************/
RVAPI void RVCALLCONV rvMtfSipRegisterSubsClbks(
					IN RvMtfSubscribeClbks* clbks)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfSipRegisterSubsClbks(clbks=%p)", clbks));
	
    if (clbks != NULL)
    {
        
		sipExtClbks.subsClbks.subsStateChangedCB          = clbks->subsStateChangedCB;
		sipExtClbks.subsClbks.subsSubscriptionExpiredCB   = clbks->subsSubscriptionExpiredCB;   
		sipExtClbks.subsClbks.subsExpirationAlertCB       = clbks->subsExpirationAlertCB;
		sipExtClbks.subsClbks.subsNotifyCB                = clbks->subsNotifyCB;
		sipExtClbks.subsClbks.subsCreatedDueToForkingCB   = clbks->subsCreatedDueToForkingCB;								   
		sipExtClbks.subsClbks.subsMsgToSendCB             = clbks->subsMsgToSendCB;									
     	sipExtClbks.subsClbks.subsMsgReceivedCB           = clbks->subsMsgReceivedCB;
	}
	
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSipRegisterSubsClbks()"));
}

/***************************************************************************
 * rvMtfRegisterMdmExtCallbacks()
 ***************************************************************************/
RVAPI void RVCALLCONV rvMtfRegisterMdmExtCallbacks(
                  IN RvMtfCallControlClbks*      clbks)
{

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterMdmExtCallbacks(clbks=%p)", clbks));

    mdmExtClbks.updateTextDisplayCB = clbks->updateTextDisplayCB;

    mdmExtClbks.postProcessEventCB = clbks->postProcessEventCB;

	mdmExtClbks.connStateChangedCB = clbks->connStateChangedCB;

	mdmExtClbks.termRegistrationStateChangedCB = clbks->termRegistrationStateChangedCB;
    mdmExtClbks.preProcessEventCB = clbks->preProcessEventCB;

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterMdmExtCallbacks()"));

}

/*****************************************************************************
 * rvMtfGetSipStackHandle() 
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfGetSipStackHandle(
				IN RvMtfHandle				hMtf,
				OUT RvSipStackHandle*		hSipStack)
{
	RvMtfBaseMgr*  mtfMgr = (RvMtfBaseMgr*) hMtf;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfGetSipStackHandle(hMtf=%p)", hMtf));

	*hSipStack = mtfMgr->sipStackHandle;

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfGetSipStackHandle(*hSipStack=%p)=%d",*hSipStack, RV_OK));

	return RV_OK;

}


/****************************************************************************
*  rvMtfTerminationGetByTermId()
*****************************************************************************/
RVAPI RV_Status RVCALLCONV rvMtfTerminationGetByTermId(
    IN RvMtfHandle				hMtf,
    IN RvChar*					termId,
	OUT RvIppTerminalHandle*	hTerm)
{
	RvCCProvider* p = rvCCBasePhoneGetMdmProvider();

	RV_UNUSED_ARG(hMtf);

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminationGetByTermId(hMtf=%p,termId=%s)", hMtf, termId));

	*hTerm = rvIppMdmProviderFindTerminalByTermId((RvIppProviderHandle)p, termId);

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationGetByTermId(*hTerm=%p)=%d", *hTerm, RV_OK));

	return RV_OK;
}



/****************************************************************************
*  rvMtfTerminationGetId()
*****************************************************************************/
RVAPI RV_Status RVCALLCONV rvMtfTerminationGetId(
		IN    RvIppTerminalHandle   hTerm,
		INOUT RvChar*               termId,
		IN    RvSize_t              termIdLen)
{
	RvBool rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminationGetId(terminalHndl=%p,termId=%p,termIdLen=%d)",
		hTerm, termId, termIdLen));

    rv = rvIppMdmTerminalGetId(hTerm, termId, termIdLen);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationGetId(termId=%s)=%d", termId, rv));

	return ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);
}

/****************************************************************************
*  rvMtfTerminationStopAllActiveSignals()
*****************************************************************************/
RVAPI void RVCALLCONV rvMtfTerminationStopAllActiveSignals(
					IN RvIppTerminalHandle		hTerm)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminationStopAllActiveSignals(terminalHndl=%p)", hTerm));
    rvIppMdmTerminalStopSignals(hTerm);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationStopAllActiveSignals()"));
}



/****************************************************************************
*  rvMtfTerminationGetLastDialString()
*****************************************************************************/
RVAPI RV_Status RVCALLCONV rvMtfTerminationGetLastDialString(
    IN		RvIppTerminalHandle		hTerm,
	IN		RvIppConnectionHandle   hConn,
    OUT		RvChar*					dialString,
    IN		RvSize_t				dialStringLen)
{
	RV_Status	res = RV_ERROR_UNKNOWN;
	RvBool		rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetDialString(hTerm=%p,dialString=%p,dialStringLen=%d",
		hTerm, dialString, dialStringLen));

    rv = rvIppMdmTerminalGetDialString(hTerm, dialString, dialStringLen);
	/* Dial string may already be reset in the terminal, therefore take it from the Connection. */
	if (rv == RV_FALSE)
	{
		RvCCConnection* c = (RvCCConnection*)hConn;
		if ((dialString != NULL) && (strcmp(dialString, "")))
		{
			RvCCConnMdm* mdmConn = rvCCConnMdmGetIns(c);
			strncpy(dialString, mdmConn->dialString, dialStringLen);
			dialString[dialStringLen-1] = '\0';
			res = RV_OK;
		}
	}
	else
	{
		res = RV_OK;
	}

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetDialString(dialString=%s)=%d", dialString, res));

	return res;
}


/****************************************************************************
*  rvMtfTerminationGetActiveConnection()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminationGetActiveConnection(
				IN RvIppTerminalHandle		hTerm,
				OUT RvIppConnectionHandle*  hConn)
{

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminationGetActiveConnection(hTerm=%p)", hTerm));
    *hConn = rvIppMdmTerminalGetActiveConnection(hTerm);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationGetActiveConnection(hConn=%p)", *hConn));

	return RV_OK;
}

/****************************************************************************
*  rvMtfTerminationGetOtherConnectionOnHold()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminationGetOtherConnectionOnHold(
				IN RvIppTerminalHandle		hTerm,
				IN RvIppConnectionHandle	hConn,
				OUT RvIppConnectionHandle*	hHeldConn)
{
	RvCCTerminal* t = (RvCCTerminal*)hTerm;
	RvCCConnection* currConn = (RvCCConnection*)hConn;
	RvInt maxConnections = rvCCTerminalGetNumberOfLines(t);
	int i;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminationGetOtherConnectionOnHold(hTerm=%p,hConn=%p)", hTerm, hConn));

	*hHeldConn = NULL;

    if (t != NULL)
    {
        for (i=0 ; i<maxConnections ; ++i)
        {
            if (rvCCConnectionIsCallOnHold(t->connections[i]) && (t->connections[i] != currConn) == RV_TRUE)
			{
				*hHeldConn = (RvIppConnectionHandle)t->connections[i];
			}
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationGetOtherConnectionOnHold(hHeldConn=%p)", *hHeldConn));

	return RV_OK;

}

/****************************************************************************
*  rvMtfTerminationGetState()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminationGetState(
				IN RvIppTerminalHandle			hTerm,
				OUT RvMtfTerminationState*		terminalState)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminationGetState(hTerm=%p)", hTerm));
    *terminalState = rvIppMdmTerminalGetState(hTerm);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationGetState(terminalState=%s)", rvMtfTextTerminalState(*terminalState)));

	return RV_OK;

}

/**********************************************************************************
                    C O N N E C T I O N     A P I s
**********************************************************************************/

/****************************************************************************
*  rvMtfConnectionGetTerminal()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetTerminal(
    IN RvIppConnectionHandle		hConn,
	OUT RvIppTerminalHandle*		hTerm)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetTerminal(hConn=%p)", hConn));
    *hTerm = rvIppMdmConnGetTerminal(hConn);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetTerminal(hTerm=%p)", *hTerm));

	return RV_OK;

}

/****************************************************************************
*  rvMtfConnectionGetLineId()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetLineId(
    IN RvIppConnectionHandle			hConn,
	OUT RvInt32*						lineId)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetLineId(hConn=%p)", hConn));
    *lineId = rvIppMdmConnGetLineId(hConn);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetLineId()=%d", lineId));

	return RV_OK;
}

/****************************************************************************
*  rvMtfConnectionGetState()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetState(
    IN RvIppConnectionHandle		hConn,
	OUT	RvMtfConnectionState*		connState)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetState(hConn=%p)", hConn));
    *connState = rvIppMdmConnGetState(hConn);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetState()=%s", rvCCTextConnState(*connState)));

    return RV_OK;
}

/****************************************************************************
*  rvMtfConnectionGetTermConnState()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetTermConnState(
		IN RvIppConnectionHandle	hConn,
		OUT RvMtfTermConnState*		state)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetTermConnState(hConn=%p)", hConn));
    *state = rvIppMdmConnGetTermState(hConn);
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetTermConnState()=%s", rvCCTextTermConnState(*state)));

	return RV_OK;
}


/****************************************************************************
*  rvMtfConnectionSetAppHandle()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionSetAppHandle(
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionSetAppHandle(hConn=%p,hConnApp=%p)", hConn, hConnApp));

    rvIppMdmConnSetUserData(hConn, (void*)hConnApp);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionSetAppHandle()=%d", RV_OK));

	return RV_OK;
}

/****************************************************************************
*  rvMtfConnectionGetAppHandle()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetAppHandle(
    IN RvIppConnectionHandle	hConn,
	IN RvMtfConnAppHandle*		hConnApp)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetAppHandle(hConn=%p)", hConn));

    *hConnApp = rvIppMdmConnGetUserData(hConn);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetAppHandle()=%p", *hConnApp));

	return RV_OK;

}

/****************************************************************************
*  rvMtfConnectionGetCallerName()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetCallerName(
    IN    RvIppConnectionHandle     hConn,
    OUT	  RvChar*                   callerName,
    IN    RvSize_t                  callerNameLen)
{
	RvBool rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetCallerName(hConn=%p,name=%p,len=%d",
		hConn, callerName, callerNameLen));

    rv = rvIppMdmConnGetCallerName(hConn, callerName, callerNameLen);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetCallerName(name=%s)=%d",
		callerName, ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN)));

	return ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);
}


/****************************************************************************
*  rvMtfConnectionGetCallerAddress()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetCallerAddress(
    IN    RvIppConnectionHandle		hConn,
    INOUT RvChar*					callerAddress,
    IN    RvSize_t					callerAddressLen)
{
	RvBool rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetCallerAddress(hConn=%p,address=%p,len=%d",
		hConn, callerAddress, callerAddressLen));

    rv = rvIppMdmConnGetCallerAddress(hConn, callerAddress, callerAddressLen);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetCallerAddress(address=%s)=%d",
		callerAddress, ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN)));

	return ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);
}


/****************************************************************************
*  rvMtfConnectionGetCallType()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetCallType(
    IN RvIppConnectionHandle    hConn,
	OUT RvMtfCallType*			callType)
{
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetCallType(hConn=%p)", hConn));

    *callType = rvIppMdmConnGetCallState(hConn);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetCallType(type=%s)=%d",
		rvCCTextCallState(*callType), RV_OK));

	return RV_OK;
}

/*****************************************************************************
* rvMtfConnGetSipCallLeg() 
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnGetSipCallLeg(
	IN RvIppConnectionHandle	hConn,
	OUT RvSipCallLegHandle*		hCallLeg)
{

	RvCCConnection* c = (RvCCConnection*)hConn;
	RvCCConnection* sipc = c->curParty;
	RvCCConnSip* sipConn;
	RvStatus	rv = RV_ERROR_UNKNOWN;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnGetSipCallLeg(hConn=%p)", hConn));

	*hCallLeg = NULL;
	if (rvMtfConnectionGetProtocolId(hConn) == RV_MTF_PROTOCOL_SIP)
	{
		sipc = c->curParty;

		if (sipc != NULL)
		{
			sipConn = rvCCConnSipGetIns(sipc);
			*hCallLeg = sipConn->callLegHndl;

			rv = RV_OK;
		}
	}
	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnGetSipCallLeg(*hCallLeg=%p)=%d",*hCallLeg, rv));

	return rv;

}

/*****************************************************************************
* rvMtfConnectionGetProtocolId() 
*****************************************************************************/
RVAPI RvInt RVCALLCONV rvMtfConnectionGetProtocolId(
	IN RvIppConnectionHandle	hConn)
{

	RvCCConnection* c = (RvCCConnection*)hConn;
	int protocol=-1;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetProtocolId(hConn=%p)", hConn));

	if (c->funcs->getProtocolIdF)
	{
		protocol = c->funcs->getProtocolIdF();
	}
	else 
	if (c->curParty)
	{
		if (c->curParty->funcs->getProtocolIdF)
		{
			protocol = c->curParty->funcs->getProtocolIdF();
		}
	}		

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetProtocolId(hConn=%p)=%d",c, protocol));

	return protocol;

}

/****************************************************************************
*  rvMtfConnectionSetLocalMedia()  
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionSetLocalMedia(
	IN RvIppConnectionHandle	hConn,
	IN RvSdpMsg*		        localSdp)
{
	RvCCConnection* c     = (RvCCConnection*)hConn;
	RvCCConnection* party = rvCCConnectionGetConnectParty(c);
	RvCCMediaState mediaState = rvCCConnectionGetMediaState(c);

	if ((c != NULL) && (localSdp != NULL))
	{
		party = rvCCConnectionGetConnectParty(c);
		mediaState = rvCCConnectionGetMediaState(c);
	}
	else
	{
		RvLogError(ippLogSource,(ippLogSource, "rvMtfConnectionSetLocalMedia() bad parameter hConn=%p, localSdp=%p)", hConn, localSdp));
		return RV_ERROR_BADPARAM;
	}

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionSetLocalMedia(hConn=%p, localSdp=%p)", hConn, localSdp));
	/* Changing the media in the middle of media operation is dangerous and may have unpredictable
	   results. It is limited to the stage of media creation. It shouldn't be done while media
	   is modified. */
	if ((mediaState == RV_CCMEDIASTATE_CREATING) ||
		(mediaState == RV_CCMEDIASTATE_CREATED))
	{
		rvCCConnectionSetLocalMedia(c, localSdp);
		/* In the party connection the local media is stored as remote media. This is true for SIP,
		  need to be verified for H323 connection */	   
		rvCCConnectionSetRemoteMedia(party, localSdp);
	}
	else
	{
		RvLogWarning(ippLogSource,(ippLogSource, 
			         "rvMtfConnectionSetLocalMedia() - media change not allowed in state = %s ", rvCCTextMediaState(mediaState)));
		return RV_ERROR_ILLEGAL_ACTION;
	}
	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionSetLocalMedia()=%d", RV_OK));

	return RV_OK;
} 
/****************************************************************************
*  rvMtfTerminationGetAppHandle()  
*****************************************************************************/
RVAPI  RvStatus RVCALLCONV rvMtfTerminationGetAppHandle(
					IN RvIppTerminalHandle			hTerm,
					OUT RvMtfTerminalAppHandle*		hAppTerm)
{
	RvLogEnter(ippLogSource,(ippLogSource, " rvMtfTerminationGetAppHandle(hTerm=%p)", hTerm));
    *hAppTerm = rvIppMdmTerminalGetUserData(hTerm);
    RvLogLeave(ippLogSource,(ippLogSource, " rvMtfTerminationGetAppHandle(hAppTerm=%p)=%d", *hAppTerm, RV_OK));

	return RV_OK;
}

/****************************************************************************
*  rvMtfTerminationSetAppHandle()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminationSetAppHandle (
                               IN RvIppTerminalHandle		hTerm,
                               IN RvMtfTerminalAppHandle    hAppTerm)
{
	RvLogEnter(ippLogSource,(ippLogSource, " rvMtfTerminationSetAppHandle (hTerm=%p)", hTerm));
    rvIppMdmTerminalSetUserData(hTerm, (void*)hAppTerm);
    RvLogLeave(ippLogSource,(ippLogSource, " rvMtfTerminationSetAppHandle()"));

	return RV_OK;
}

/******************************************************************************
* rvMtfTerminationIsUpdateAllowedByRemoteParty
*****************************************************************************/
RVAPI RvStatus rvMtfTerminationIsUpdateAllowedByRemoteParty(
						   IN RvIppTerminalHandle		hTerm,
						   IN RvIppConnectionHandle		hConn,
						   IN RvBool*					bIsUpdateAllowed)
{
	RvCCTerminal* t = (RvCCTerminal*)hTerm;
	RvCCConnection* conn;
	RvCCConnection* party;

	if (hConn != NULL)
	{
		/* Get the SIP connection  */
		party = rvCCConnectionGetConnectParty((RvCCConnection*)(hConn));
	}
	else
	{
		conn = rvCCTerminalGetActiveConnection(t);
		party = rvCCConnectionGetConnectParty(conn);
	}

	if (party != NULL)
	{
		*bIsUpdateAllowed = rvCCConnSipIsUpdateAllowedByRemoteParty(party);
		return RV_OK;
	}

	return RV_ERROR_UNKNOWN;

}

/******************************************************************************
* rvMtfTerminationIsUpdateInProcess
*****************************************************************************/
RVAPI RvStatus rvMtfTerminationIsUpdateInProcess(
						IN RvIppTerminalHandle		hTerm,
						IN RvIppConnectionHandle	hConn,
						IN RvBool*					bIsUpdateInProcess)
{
	RvCCTerminal* t = (RvCCTerminal*)hTerm;
	RvCCConnection* conn;
	RvCCConnection* party;

	if (hConn != NULL)
	{
		/* Get the SIP connection  */
		party = rvCCConnectionGetConnectParty((RvCCConnection*)(hConn));
	}
	else
	{
		conn = rvCCTerminalGetActiveConnection(t);
		party = rvCCConnectionGetConnectParty(conn);
	}

	if (party != NULL)
	{
		*bIsUpdateInProcess = (rvCCConnGetUpdateState((RvCCConnection*)(party)) != RV_CCUPDATESTATE_NONE);
		return RV_OK;
	}

	return RV_ERROR_UNKNOWN;

}

/******************************************************************************
* rvMtfTerminationGetOfferAnswerState
*****************************************************************************/
RVAPI RvStatus rvMtfTerminationGetOfferAnswerState(
						IN RvIppTerminalHandle			hTerm,
						IN RvIppConnectionHandle		hConn,
						OUT RvMtfOfferAnswerState*		stateOfferAnswer)
{
	RvCCTerminal* t = (RvCCTerminal*)hTerm;
	RvCCConnection* conn;
	RvCCConnection* party;

	if (hConn != NULL)
	{
		/* Get the SIP connection  */
		party = rvCCConnectionGetConnectParty((RvCCConnection*)(hConn));
	}
	else
	{
		conn = rvCCTerminalGetActiveConnection(t);
		party = rvCCConnectionGetConnectParty(conn);
	}

	if (party != NULL)
	{
		*stateOfferAnswer = rvCCConnSipGetOfferAnswerState((RvCCConnection*)(party));
		return RV_OK;
	}

	return RV_ERROR_UNKNOWN;
}

/******************************************************************************
* rvMtfTerminationIsUpdateFeasible
*****************************************************************************/
RVAPI RvStatus rvMtfTerminationIsUpdateFeasible(
					   IN RvIppTerminalHandle		hTerm,
					   IN RvIppConnectionHandle		hConn,
					   IN RvBool*					bIsUpdateFeasible)
{
	RvCCTerminal* t = (RvCCTerminal*)hTerm;
	RvCCConnection* conn;
	RvCCConnection* party;

	if (hConn != NULL)
	{
		/* Get the SIP connection  */
		party = rvCCConnectionGetConnectParty((RvCCConnection*)(hConn));
	}
	else
	{
		conn = rvCCTerminalGetActiveConnection(t);
		party = rvCCConnectionGetConnectParty(conn);
	}

	if (party != NULL)
	{
		*bIsUpdateFeasible = rvCCConnSipIsUpdatePermitted((RvCCConnection*)(party));
		return RV_OK;
	}

	return RV_ERROR_UNKNOWN;

}

/****************************************************************************
*  rvMtfTerminalMakeCallOnFreeConnection()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminalMakeCallOnFreeConnection(
    IN RvIppTerminalHandle		hTerm,
    IN const RvChar*				address,
    IN RvMtfConnAppHandle		hConnApp,
    OUT RvIppConnectionHandle*	hConn)
{
    RvCCTerminal* t 		= (RvCCTerminal*)hTerm;
    RvCCConnection*			freeConn = NULL;
    RvIppConnectionHandle	hActiveConn;
    RvMtfEventInfo 			eventInfo;
    RvStatus				res = RV_OK;
    int                     i;
	RvInt                   maxConnections  = rvCCTerminalGetNumberOfLines(t);

    RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCallOnFreeConnection(hTerm=%p,address=%s)", hTerm, ((address != NULL) ? address : "NULL")));


    /* Check if there isn't another call which is not on Hold */
    rvMtfTerminationGetActiveConnection(hTerm, &hActiveConn);
    //rvMtfTerminationGetOtherConnectionOnHold(hTerm, hActiveConn, &hHeldConn);
    for (i=0 ; i<maxConnections ; ++i)
    {
        if ((rvCCConnectionGetState(t->connections[i])== RV_CCCONNSTATE_CONNECTED) &&
			(rvCCConnectionGetTermState(t->connections[i])!= RV_CCTERMCONSTATE_HELD) &&
			(rvCCConnectionGetTermState(t->connections[i])!= RV_CCTERMCONSTATE_REMOTE_HELD) &&
			(rvCCConnectionGetTermState(t->connections[i])!= RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD))
        {
            RvLogError(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCallOnFreeConnection failed, there is another call active, line=%d, hTerm=%p",
                t->connections[i]->lineId, hTerm));
            res = RV_ERROR_UNKNOWN; /*TODO REAL ERROR*/
            break;
        }
    }
    if (res == RV_OK)
    {
        freeConn = rvCCTerminalFindFreeConnection(t);
        if (freeConn == NULL)
        {
            RvLogError(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCallOnFreeConnection failed, no free lines are available, hTerm=%p", hTerm));
            res = RV_ERROR_UNKNOWN; /*TODO REAL ERROR*/
        }

        if (res == RV_OK)
        {

            /* Send Line event for the free line */
            memset(&eventInfo, 0, sizeof(RvMtfEventInfo));
            eventInfo.lineId = freeConn->lineId;
            rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_LINE, &eventInfo);

            /* Store user data in the connection */
            //rvMtfConnectionSetAppHandle(*hConn, hConnApp);
            freeConn->userData = (void *)hConnApp;

            /* Send the Invite message */
            res = rvMtfTerminalMakeCall(hTerm, address);
            if (res != RV_OK)
            {
                RvLogError(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCallOnFreeConnection() - failed to establish a new call (hTerm=%p, termId=%s, address=%s)",
                    hTerm, rvCCTerminalMdmGetTermId(t), address));
                freeConn = NULL;
                res = RV_ERROR_UNKNOWN;
            }

        }
    }
    *hConn = (RvIppConnectionHandle)freeConn;
    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCallOnFreeConnection()=%d", res));

    return res;
}
/****************************************************************************
*  rvMtfTerminalDisconnectCall()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminalDisconnectCall(
    IN RvIppTerminalHandle		hTerm,
    IN RvIppConnectionHandle	hConn)
{
    RvCCTerminal* t 	= (RvCCTerminal*)hTerm;
    RvMtfEventInfo 		eventInfo;
    RvInt32 			lineId;
    RvStatus			res = RV_OK;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminalDisconnectCall(hTerm=%p,hConn=%p)", hTerm, hConn));

    /* Validation check for the connection */
    rvMtfConnectionGetLineId(hConn, &lineId);
    if (lineId > rvCCTerminalGetNumberOfLines(t))
    {
        RvLogError(ippLogSource,(ippLogSource, "rvMtfTerminalDisconnectCall() - failed to disconnect call, invalid connection (hTerm=%p, hConn=%p, lineId=%d)",
            hTerm, hConn, lineId));
        res = RV_ERROR_UNKNOWN;
    }
    else
    {
		RvCCConnection* c = (RvCCConnection*)hConn;
		RvCCConnState state = rvCCConnectionGetState(c);

        /* Send Line event for this line to disconnect it*/
        memset(&eventInfo, 0, sizeof(RvMtfEventInfo));
        eventInfo.lineId = lineId;
		/* In the following states an incoming call is in process.
		   Don't disconnect the call by RV_CCTERMEVENT_LINE in these cases because 
		   it will result in answering the call, as the line is onhook. */
		if ((state == RV_CCCONNSTATE_OFFERED) ||
			(state == RV_CCCONNSTATE_ALERTING) ||
			(state == RV_CCCONNSTATE_TRANSFER_OFFERED) ||
			(state == RV_CCCONNSTATE_TRANSFER_ALERTING))
		{
			rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_REJECT_KEY, &eventInfo);
		}
		else
		{
			RvCCTermConnState termConnState = rvCCConnectionGetTermState(c);

			if ((termConnState == RV_CCTERMCONSTATE_HELD) ||
				(termConnState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD ))
			{
				/* In case the line is held - disconnect the call. Sending LINE event will unhold the call,
				   this is not the desired action. */

				RvBool callStillAlive = RV_TRUE;

				rvCCConnMdmProcessEvent(c, RV_CCTERMEVENT_DISCONNECTING, &callStillAlive, RV_CCCAUSE_NORMAL);
			}
			else
			{
				rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_LINE, &eventInfo);
			}
		}
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminalDisconnectCall()=%d", res));

    return res;
}

/****************************************************************************
*  rvMtfTerminalGetConnectionByLineId()  
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminalGetConnectionByLineId ( 
	IN  RvIppTerminalHandle		hTerm,
	IN  RvInt32                  lineId,
	OUT RvIppConnectionHandle*   hConn)
{
	RvCCTerminal*     t = (RvCCTerminal*)hTerm;
	RvCCTerminalMdm*  mdmTerm = rvCCTerminalMdmGetImpl(t);
	RvCCConnection*   conn = NULL;
	RvStatus          rv = RV_ERROR_NOT_FOUND;
	RvCCTerminalType  termType = rvCCTerminalMdmGetType(mdmTerm);

	RvLogEnter(ippLogSource,(ippLogSource, " rvMtfTerminalGetConnectionByLineId (hTerm=%p, lineId=%d)", hTerm, lineId));

	*hConn = NULL;

	if ((termType != RV_CCTERMINALTYPE_UI) && (termType != RV_CCTERMINALTYPE_ANALOG))
	{
		/* The connection info is stored in the UI or ANALOG terminal. If hTerm is none of these, get
		the UI terminal */

        RvCCProvider*  p = rvCCBasePhoneGetMdmProvider();

		t = rvCCProviderFindTermByType(p, RV_CCTERMINALTYPE_UI);
		if (t != NULL)
		{
			mdmTerm = rvCCTerminalMdmGetImpl(t);
		}
		else
		{
			mdmTerm = NULL;
		}
	}

	if(mdmTerm == NULL)
	{
		/* Couldn't find a terminal of the right type, log an error */
		RvLogError(ippLogSource,(ippLogSource, " rvMtfTerminalGetConnectionByLineId hTerm=%p not associated with a UI or ANALOG term ",
			hTerm)); 
		rv = RV_ERROR_BADPARAM;
	}
	else
    {
		if (lineId > RV_CCTERMINAL_MAXCONNS)
		{
			RvLogError(ippLogSource,(ippLogSource, " rvMtfTerminalGetConnectionByLineId lineId=%d > max number of lines=%d",
				lineId, RV_CCTERMINAL_MAXCONNS)); 
			rv = RV_ERROR_BADPARAM;
		}
		else
		{
			int i; 

			for(i=0; i<RV_CCTERMINAL_MAXCONNS; i++)
			{
				conn = t->connections[i];
				if (rvCCConnectionGetLineId(conn) == lineId)
				{
					*hConn = (RvIppConnectionHandle)conn;
					rv = RV_OK;
					break;
				}
			}
		}
    }

		RvLogLeave(ippLogSource,(ippLogSource, " rvMtfTerminalGetConnectionByLineId(hConn=%p)", *hConn));

		return rv;
}
/******************************************************************************
*  rvMtfConnectionGetRemoteDisplayName
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetRemoteDisplayName(
	IN    RvIppConnectionHandle     hConn,
	OUT	  RvChar*                   displayName,
	IN    RvSize_t					displayNameLen)
{
	
	RvCCConnection* c = (RvCCConnection*)hConn;

	const RvChar* tmpDisplayName = NULL;
	RvBool		  rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetRemoteDisplayName(hConn=%p)", hConn));

	if (c->curParty->funcs->getRemoteDisplayNameF !=NULL)
	{
		tmpDisplayName = rvCCConnectionGetRemoteDisplayName(c->curParty);
		if (tmpDisplayName != NULL)
		{
			strncpy(displayName, tmpDisplayName,displayNameLen-1);
			displayName[displayNameLen-1] = '\0';
			rv = RV_TRUE;
		}
		else
		{
			rv = RV_FALSE;
		}
	}
	else
	{
		rv = RV_FALSE;
	}
	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetRemoteDisplayName(name=%s)=%d", 
		tmpDisplayName, ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN)));

	return ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);
}
/******************************************************************************
*  rvMtfConnectionGetRemotePhoneNumber (RvMtfConnectionsPkg)
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetRemotePhoneNumber(
	IN    RvIppConnectionHandle     hConn,
	OUT	  RvChar*                   remotePhoneNumber,
	IN    RvSize_t					remotePhoneNumberLen)
{

	RvCCConnection* c = (RvCCConnection*)hConn;

	const RvChar* tmpRemotePhoneNumber = NULL;
	RvBool		  rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetRemotePhoneNumber(hConn=%p)", hConn));

	if (c->curParty->funcs->getRemotePhoneNumberF !=NULL)
	{
		tmpRemotePhoneNumber = rvCCConnectionGetRemotePhoneNumber(c->curParty);
		if (tmpRemotePhoneNumber != NULL)
		{
			strncpy(remotePhoneNumber, tmpRemotePhoneNumber,remotePhoneNumberLen-1);
			remotePhoneNumber[remotePhoneNumberLen-1] = '\0';
			rv = RV_TRUE;
		}
		else
		{
			rv = RV_FALSE;
		}
	}
	else
	{
		rv = RV_FALSE;
	}


	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetRemotePhoneNumber(phone=%s)=%d", 
		tmpRemotePhoneNumber, ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN)));

	return ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);
}
/******************************************************************************
*  rvMtfConnectionGetRemoteUri(RvMtfConnectionsPkg)
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfConnectionGetRemoteUri(
	IN    RvIppConnectionHandle     hConn,
	OUT	  RvChar*                   remoteUri,
	IN    RvSize_t					remoteUriLen)
{

	RvCCConnection* c = (RvCCConnection*)hConn;

	const RvChar* tmpRemoteUri = NULL;
	RvBool		  rv;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfConnectionGetRemoteUri(hConn=%p)", hConn));

	if (c->curParty->funcs->getRemoteUriF!=NULL)
	{
		tmpRemoteUri = rvCCConnectionGetRemoteUri(c->curParty);
		if (tmpRemoteUri != NULL)
		{
			strncpy(remoteUri, tmpRemoteUri,remoteUriLen-1);
			remoteUri[remoteUriLen-1] = '\0';
			rv = RV_TRUE;
		}
		else
		{
			rv = RV_FALSE;
		}
	}
	else
	{
		rv = RV_FALSE;
	}


	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfConnectionGetRemoteUri(uri=%s)=%d", 
		tmpRemoteUri, ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN)));

	return ((rv == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);
}
