/******************************************************************************
Filename:    rvMtfBaseTypes.h
Description: This files include basic type definitions for MTF.
*******************************************************************************
                Copyright (c) 2008 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#ifndef RV_MTF_BASE_TYPES_H
#define RV_MTF_BASE_TYPES_H

#include "rvMtfSignalsTypes.h"
#include "rvMtfHandles.h"
#include "rvIppCfwApi.h"
#include "rvmdmobjects.h"
#include "rvCallControlApi.h"
#include "RvSipStackTypes.h"
#include "RvSipCallLegTypes.h"
#include "RvSipRegClientTypes.h"
#include "RvSipSubscriptionTypes.h"
#include "RvSipAuthenticator.h"
#include "RvSipMsgTypes.h"
#include "rvtypes.h"


/*@*****************************************************************************
 * Type: RvMtfTerminationConfig (RvMtfTerminationsPkg)
 * -----------------------------------------------------------------------------
 * Description: This structure includes the configuration parameters for a
 * termination that are set when the termination is registered to the MTF.
 *
 ****************************************************************************@*/
typedef struct  {
#ifdef RV_MTF_N_LINES
	RvInt						numberOfLines;
	    /*  Number of lines in the terminal. Indicates the number of simultaneous calls that
         	can be connected in the terminal while one of the calls is active and the others are on Hold.
         	When this parameter is set, it applies to this terminal only, and overrides the parameter set in RvIppSipPhoneCfg. */
#endif /* RV_MTF_N_LINES */
    RvChar						username[RV_NAME_STR_SZ];
		/* This parameter is used for Authentication. */

    RvChar						password[RV_NAME_STR_SZ];
		/* This parameter is used for Authentication. */

    RvChar						displayName[RV_NAME_STR_SZ];
		/* This parameter is used as the sendind username in the
	       outgoing Invite. */

	RvChar						registrarAddress[RV_NAME_STR_SZ];
		/* IP address or domain name of the Registrar. All Register messages
	       will be sent to this address. */

	RvUint16					registrarPort;
		/* Port number of the Registrar. */

	RvChar						outboundProxyAddress[RV_NAME_STR_SZ];
		/* IP address or domain name of the outbound Proxy. All outgoing
	       messages will be sent to this address. */

	RvUint16					outboundProxyPort;
		/* Port number of the outbound Proxy. */
#ifdef RV_CFLAG_TLS
	RvUint16            registrarTlsPort; 
	/* The number of the port that the registrar uses for a TLS connection. */
#endif
#ifdef RV_SIP_IMS_ON
	RvChar				PAccessNetworkInfo[RV_SHORT_STR_SZ];  
	/* P-Access-Network-Info header text, assumed to be in the correct syntax. */
	RvUint32			ipsecPortC;			  
	/* The number of the port used as the client port for the IPSec connection. */
	RvUint32			ipsecPortS;			  
	/* The number of the port used as the server port for the IPSec connection. */
#endif

	RvUint32					registerExpires;
		/* Register refresh timeout. Indicates the time period between
		   Register messages, in seconds. When this parameter is not set,
	       the value will be taken from the registrationExpire parameter
	       in RvIppSipPhoneCfg. */

	RvSipTransport				transportType;
		/* The Transport type of the outgoing messages. Valid values are
		   RVSIP_TRANSPORT_UDP, RVSIP_TRANSPORT_TCP and
		   RVSIP_TRANSPORT_UNDEFINED. If this parameter is set to
		   RVSIP_TRANSPORT_UNDEFINED, the value will be taken from the
		   transportType parameter in RvIppSipPhoneCfg.
           Default: RVSIP_TRANSPORT_UDP. */

	RvMdmDigitMap*				digitMap;
		/* Defines digitmap pattern. If this parameter is not set, MTF
		   will use its default one. */
	/* zhuzhh, 2011/05/27, disable cwt for line, modify, start */
	RvBool                      disableCallWaiting;
	/* zhuzhh, 2011/05/27, disable cwt for line, modify, end */
	//Leibt
	unsigned char 	            cfwType;               /* UNCONDITIONAL, BUSY, NO_REPLY, NONE */
	char						cfwAddress[32];
	RvUint                      cfnrTimeout ;
} RvMtfTerminationConfig;


/*@*****************************************************************************
*  RvMtfRegisterAnalogTermCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called after the application registers an
*               analog termination to the MTF by calling
                rvMtfRegisterAnalogTermination(), to indicate that the
*				registration is complete.
*
*  Arguments:
*  Input:          hTerm	- Handle to the terminal.
*				   hAppTerm	- Handle to the application data associated with
*                  the terminal.
*
*  Return Value:   None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfRegisterAnalogTermCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfRegisterIPPhoneTermsCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called after the application registers
*               IP Phone terminations to the MTF by calling
*               rvMtfRegisterIPPhoneTerminations(), to indicate that the
*               registration is complete.
*
*  Arguments:
*  Input:          hTerm	- Handle to the terminal.
*				   hAppTerm	- Handle to the application data associated with
*                  the terminal.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfRegisterIPPhoneTermsCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfRegisterVideoTermsCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :  This callback is called after the application registers video
*			  terminations to the MTF by calling
*             rvMtfRegisterVideoTerminations(), to indicate that the
*             registration is complete.
*
*  Arguments:
*  Input:          hTerm	- Handle to the terminal.
*				   hAppTerm	- Handle to the application data associated with
*                             the terminal.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfRegisterVideoTermsCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfUnregisterAnalogTermCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called after the application unregisters an
*               analog termination to the MTF by calling
*				rvMtfUnregisterAnalogTermination(), to indicate that the
*				unregistration is complete.
*
*  Arguments:
*  Input:          hTerm	- Handle to the terminal.
*				   hAppTerm	- Handle to the application data associated with
*                             the terminal.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfUnregisterAnalogTermCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfUnregisterIPPhoneTermsCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called after the application unregisters
*               IP Phone terminations from the MTF by calling
*				rvMtfUnregisterIPPhoneTerminations(), to indicate that the
*				unregistration is complete.
*
*  Arguments:
*  Input:          hMtf		- Handle to the MTF instance.
*				   hAppTerm	- Handle to the application data associated with
*                             the terminal.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfUnregisterIPPhoneTermsCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfUnregisterVideoTermsCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called after the application unregisters video
*				terminations from the MTF by calling
*               rvMtfUnregisterVideoTerminations(), to indicate that the
*				unregistration is complete.
*
*  Arguments:
*  Input:           hTerm		- Handle to the terminal.
*				    hAppTerm	- Handle to the application data associated
*                                 with the terminal.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfUnregisterVideoTermsCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfUnregisterTermFromServerCompletedEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called after the application registers a
*				termination (analog or IP Phone) to the SIP server, to indicate
*               that the registration is complete (either a reply was received
*               from the server, or a timeout occurred). The application registers
*				a termination to the SIP Registrar by calling
*				rvMtfRegisterTerminationToSipServer().
*
*  Arguments:
*  Input:          hTerm	- Handle to the terminal.
*				   hAppTerm	- Handle to the application data associated with
*                  the terminal.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfUnregisterTermFromServerCompletedEv)(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm);

/*@*****************************************************************************
*  RvMtfMapDialStringToAddressEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is called when the user presses a complete
*				phone number (dial string). It requires the application to
*               return a SIP address that will be used to send out an Invite
*				message. This callback is relevant when the user establishes
*				a call by pressing digits. It is not relevant when the user
*               provides the destination SIP address by calling
*				rvMtfTerminalMakeCall().
*
*  Arguments:
*  Input:			hTerm		- Handle to the terminal.
*				    hAppTerm	- Handle to the application data associated
*                                 with the terminal.
*					dialString	- The phone number dialed by the user.
*
*  Output:          address		- The string containing the SIP address to be
*                                 used to send out the Invite message.
*
*  Return Value:    RV_OK if successful, other if not.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMapDialStringToAddressEv)(
									IN  RvIppTerminalHandle		hTerm,
									IN  RvMtfTerminalAppHandle	hAppTerm,
									IN  RvChar*					dialString,
									OUT RvChar*					address);

/*@*****************************************************************************
*  RvMtfMapAddressToTerminationEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is optional. It is used for mapping incoming
*				calls to a termination. If this callback is not registered by
*				the application, the MTF will use its default implementation
*				and will match the username in the To header of the incoming
*				Invite to the termination ID. If the application registers
*			    this callback, it can decide dynamically which termination
*               will receive the incoming call. The returned termination
*				must be registered with the MTF before the callback is called.
*
*  Arguments:
*  Input:			hMtf		- Handle to the MTF instance.
*				    hAppMtf		- Handle to the application data associated
*                                 with the MTF instance.
*					address		- The SIP address taken from the To header
*                                 of the incoming Invite message.
*
*  Output:          termId		- The termination ID to receive the call.
*                                 This termination must be registered with
*								  the MTF before the callback is called.
*
*  Return Value:    RV_OK if successful, other if not.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMapAddressToTerminationEv)(
									IN  RvMtfHandle			hMtf,
									IN  RvMtfAppHandle		hAppMtf,
									IN  RvChar*				address,
									OUT RvChar*				termId);

/*@*****************************************************************************
*  RvMtfMatchDialStringToPatternEv (RvMtfBasePkg)
* -----------------------------------------------------------------------------
*  General :    This callback is optional. It is used for matching a phone number
*				dialed by the user to a digitmap pattern. This callback is relevant for  
*				user applications that registered their own digitmap pattern. User applications
*				that do not register their own digitmap can use the MTF's default digitmap 
*				(see the MTF Programmer Guide for more information 
*			    about the default digitmap). 
*               This callback is called every time the user presses a digit.
*				The user application should check whether the dial string dialed by the user
*				matches one of its patterns and return the matching type. If the matching
*				type is PARTIALMATCH or FULLMATCH, the user application should also set the 
*				timeout that the MTF needs to wait for the next digit. 
*
*  Arguments:
*  Input:			hTerm			- Handle to the terminal.
*					hAppTerm		- Handle to the user application data associated with
*									  the terminal.
*					dialString		- The phone number that was dialed by the user so far.
*
*  Output:          timerDuration	- The time duration to wait for the next digit, 
*									  or a timeout.
*
*  Return Value:    The digitmap matching type of the phone number. Possible values are:

*		            NOMATCH--The dial string does not match any legal pattern. 
*			        The MTF stops collecting digits and starts playing a warning tone.

*		            PARTIALMATCH--The dial string may match a legal pattern. 
*				    The MTF continues collecting digits.

*		            FULLMATCH--The dial string matches a legal pattern, but might be		
*				    ambiguous (i.e., more digits can be collected).
*					The MTF continues collecting digits.

*		            UNAMBIGUOUSMATCH--The dial string matches a legal pattern.
*				    The MTF stops collecting digits and tries to map this dial string
*				    to a destination address, by invoking the callback RvMtfMapDialStringToAddressEv().
*														   
****************************************************************************@*/
typedef RvMdmDigitMapMatchType (RVCALLCONV *RvMtfMatchDialStringToPatternEv)(
									IN  RvIppTerminalHandle		hTerm,
									IN  RvMtfTerminalAppHandle	hAppTerm,
									IN  RvChar*					dialString,
									OUT RvUint*					timerDuration);


/*@*****************************************************************************
 * Type: RvMtfMdmClbks (RvMtfBasePkg)
 * -----------------------------------------------------------------------------
 * Description: This structure includes MDM callbacks.
 ****************************************************************************@*/
typedef struct
{
    RvMtfStartSignalEv							startSignalCB;
    RvMtfStopSignalEv							stopSignalCB;
    RvMtfRegisterIPPhoneTermsCompletedEv		registerIPPhoneTermsCompletedCB;
    RvMtfUnregisterIPPhoneTermsCompletedEv		unregisterIPPhoneTermsCompletedCB;
	RvMtfRegisterVideoTermsCompletedEv			registerVideoTermsCompletedCB;
    RvMtfUnregisterVideoTermsCompletedEv		unregisterVideoTermsCompletedCB;
	RvMtfRegisterAnalogTermCompletedEv			registerAnalogTermCompletedCB;
    RvMtfUnregisterAnalogTermCompletedEv		unregisterAnalogTermCompletedCB;
    RvMtfUnregisterTermFromServerCompletedEv	unregisterTermFromServerCompletedCB;
    RvMtfMapDialStringToAddressEv				mapDialStringToAddressCB;
	RvMtfMapAddressToTerminationEv				mapAddressToTerminationCB;
	RvMtfMatchDialStringToPatternEv				matchDialStringToPatternCB;
}RvMtfMdmClbks;

/*@*****************************************************************************
* Enum: RvMtfTermRegistrationState (RvMtfBasePkg)
* -----------------------------------------------------------------------------
* Description: This enumeration reflects the results of Registration/UnRegistration
*              requested by the user application.
****************************************************************************@*/
typedef enum
{
	RV_MTF_TERM_REG_STATE_UNDEFINED,
		/* Indicates that no status was assigned. */
	RV_MTF_TERM_REG_STATE_REGISTRATION_COMPLETE,
	    /* Indicates that a request to register a terminal was handled completely. */
	RV_MTF_TERM_REG_STATE_UNREGISTRATION_COMPLETE
	   /* Indicates that a request to unregister a terminal was handled completely. */
} RvMtfTermRegistrationState;

/*@*****************************************************************************
* Enum: RvMtfRegistrationState (RvMtfBasePkg)
* -----------------------------------------------------------------------------
* Description: This enumeration reflects the registration state of a terminal.
****************************************************************************@*/
typedef enum
{
	    RV_MTF_REG_STATE_UNDEFINED,
		RV_MTF_REG_STATE_NOT_REGISTERED,
		RV_MTF_REG_STATE_REGISTERED,
		RV_MTF_REG_STATE_DISCOVERED,
		RV_MTF_REG_STATE_REGISTERING,
		RV_MTF_REG_STATE_REDIRECTED,
		RV_MTF_REG_STATE_UNAUTHENTICATED,
        RV_MTF_REG_STATE_FAILED,
		RV_MTF_REG_STATE_MSG_SEND_FAILURE
} RvMtfRegistrationState;

/*@*****************************************************************************
* Enum: RvMtfRegistrationStateReason (RvMtfBasePkg)
* -----------------------------------------------------------------------------
* Description: This enumeration reflects the reason for the registration state of
*              a terminal.
****************************************************************************@*/
typedef enum
{
	RV_MTF_REG_STATE_REASON_UNDEFINED,
	RV_MTF_REG_STATE_REASON_USER_REQUEST,
	RV_MTF_REG_STATE_REASON_RESPONSE_SUCCESSFUL_RECVD,
	RV_MTF_REG_STATE_REASON_RESPONSE_REDIRECTION_RECVD,
	RV_MTF_REG_STATE_REASON_RESPONSE_UNAUTHENTICATED_RECVD,
	RV_MTF_REG_STATE_REASON_RESPONSE_REQUEST_FAILURE_RECVD,
	RV_MTF_REG_STATE_REASON_RESPONSE_SERVER_FAILURE_RECVD,
	RV_MTF_REG_STATE_REASON_RESPONSE_GLOBAL_FAILURE_RECVD,
	RV_MTF_REG_STATE_REASON_LOCAL_FAILURE,
	RV_MTF_REG_STATE_REASON_TRANSACTION_TIMEOUT,
	RV_MTF_REG_STATE_REASON_NORMAL_TERMINATION,
	RV_MTF_REG_STATE_REASON_GIVE_UP_DNS,
	RV_MTF_REG_STATE_REASON_NETWORK_ERROR,
	RV_MTF_REG_STATE_REASON_503_RECEIVED,
	RV_MTF_REG_STATE_REASON_CONTINUE_DNS,
	RV_MTF_REG_STATE_REASON_GATEKEEPER_CONFIRM,
	RV_MTF_REG_STATE_REASON_GATEKEEPER_REJECT,
	RV_MTF_REG_STATE_REASON_REGISTRATION_CONFIRM,
	RV_MTF_REG_STATE_REASON_REGISTRATION_REJECT,
	RV_MTF_REG_STATE_REASON_UNREGISTRATION_REQUEST,
	RV_MTF_REG_STATE_REASON_UNREGISTRATION_CONFIRM,
	RV_MTF_REG_STATE_REASON_UNREGISTRATION_REJECT,
	RV_MTF_REG_STATE_REASON_NONSTANDARD_MESSAGE,
	RV_MTF_REG_STATE_REASON_RESOURCE_AVAILABILITY_CONFIRMATION,
	RV_MTF_REG_STATE_REASON_PERMANENT_ALTERNATE_GATEKEEPER_CONFIRMATION,
	RV_MTF_REG_STATE_REASON_SEARCHING_ALTERNATE_GATEKEEPER
} RvMtfRegistrationStateReason;

/*@*****************************************************************************
* Enum: RvMtfRegisterReportType (RvMtfBasePkg)
* -----------------------------------------------------------------------------
* Description: This enumeration reflects the type of report that should be sent
*              to the user application when a change occurs in the status
*              of the registration to a server:
*              RV_REGISTER_REPORT_TYPE_REG_COMPLETE - The first report that is sent
*                    when the MTF registers to the various protocol servers after 
*                    setup. This report indicates that a final response has
*                    been received for all registration attempts, or that a timeout 
*                    has occurred while waiting for results.
*              RV_REGISTER_REPORT_TYPE_REG_UPDATE - A report of this type is sent
*                    when a register state to a server was changed.
*              RV_REGISTER_REPORT_TYPE_UNREG_COMPLETE - The last report sent when 
*                    the MTF unregisters from all servers.
****************************************************************************@*/
typedef enum {
	RV_REGISTER_REPORT_TYPE_REG_COMPLETE,
	RV_REGISTER_REPORT_TYPE_REG_UPDATE,
	RV_REGISTER_REPORT_TYPE_UNREG_COMPLETE
} RvMtfRegisterReportType;

/*@*****************************************************************************
* Type: RvMtfRegisterStateData (RvMtfBasePkg)
* -----------------------------------------------------------------------------
* Description: This structure includes data about the registration to a server.
****************************************************************************@*/
typedef struct 
{
	RvMtfRegistrationState              registrationState;
	RvMtfRegistrationStateReason        registrationStateReason;
} RvMtfRegisterStateData; 

/*@*****************************************************************************
* Type: RvMtfTermRegistrationStatus (RvMtfBasePkg)
* -----------------------------------------------------------------------------
* Description: This structure includes data about the registration to servers, per 
*              protocol.
****************************************************************************@*/
typedef struct
{
	RvMtfRegisterStateData                protocolRegisterStateData[RV_MTF_PROTOCOL_NUM];  
} RvMtfTermRegistrationStatus;

#endif /*RV_MTF_BASE_TYPES_H*/
