/******************************************************************************
Filename:    rvMtfPhone.h
Description: MTF Phone Header
*******************************************************************************
                Copyright (c) 2009 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef MTFPHONE_H
#define MTFPHONE_H

#include "rvcccall.h"
#include "rvccapi.h"
#include "rvMtfBaseTypes.h"

RvMdmTermMgr* getMdmTermMgr(void);
void setMdmTermMgr(RvMdmTermMgr* mgr);
RvCCConnection*  addressAnalyzeCB(RvCCConnection* x, const char* address,
                                  RvCCEventCause inReason, RvCCEventCause* outReason);
void inProcessCB(RvCCConnection* x, RvCCEventCause reason);


typedef struct
{
	RvAlloc*	a;
//	RvBool		mapAddresses;
	RvBool      defaultProtocolType;

}RvCCIPPhone;

void rvIPPhoneConstruct(
    OUT RvMdmTermMgr*       mgr,
	IN  RvMtfSipPhoneCfg*		cfg);

RvBool rvMtfUnregisterPhysTermDone(IN RvCCTerminal* mdmt);
void rvMtfRegisterTermReportStatus( RvCCTerminal*      mdmt, 							
									RvBool            timeOut );
RvBool isH323Address(const char* address);

#endif /*MTFPHONE_H*/
