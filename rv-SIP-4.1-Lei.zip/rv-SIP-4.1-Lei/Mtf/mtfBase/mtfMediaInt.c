/******************************************************************************
Filename   : mtfMediaInt.c
Description: This file includes functions for calling media user callbacks.
******************************************************************************
                Copyright (c) 2008 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#define LOGSRC	LOGSRC_BASE
#include "ipp_inc_std.h"
#include "ippmisc.h"
#include "rvcctext.h"
#include "rvmdm.h"
#include "mtfBaseInt.h"


/*===============================================================================*/
/*========== I N T E R N A L    M E D I A   C A L L B A C K S	=================*/
/*===============================================================================*/

void rvModifyMediaCompletedIntCB(
			  void*                         connection,
              struct RvMdmTerm_*		    term,
              RvBool					    status,
			  RvMdmMediaStreamInfo *        media,
              RvMdmMediaStreamDescr*	    streamDescr,
              RvMdmTermReasonModifyMedia	reason)
{
    RvMtfBaseMgr*	    mtfMgr;
    RvIppTerminalHandle	termHndl;
    RvSdpMsgList*	    sdpList;
    RvSdpMsg*		    sdpMsg;
	RvCCConnection*     conn = (RvCCConnection*)connection;

    sdpList = rvMdmMediaStreamDescrGetLocalDescr(streamDescr);
    sdpMsg = rvSdpMsgListGetElement(sdpList, 0);

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

    if (mtfMgr == NULL)
	{
        return;
	}

    termHndl = rvIppMdmTerminalGetHandle(term);

    if (termHndl == NULL)
	{
        return;
	}

	/*  There are three options for user callback implementation:
	 *  1. Old implementation invoked by rvMdmTermModifyMediaDone_,
	 *  2. New callback by terminal invoked by mediaClbks.modifyMediaCompletedCB,
	 *  3. New callback by connection invoked by connMediaClbks.connModifyMediaCompletedCB
	 *   Only one of the three options will be invoked.
	 */
	if (term->termClass->modifyMediaCompletedF != NULL)
	{
		rvMdmTermModifyMediaDone_( term, status, media, streamDescr, reason);
	}
	else
	if (mtfMgr->mediaClbks.modifyMediaCompletedCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvModifyMediaCompletedIntCB() - before user callback modifyMediaCompletedCB, term id=%s, term=0x%p, status=%d",
			rvMdmTermGetId(term), term, reason));
		mtfMgr->mediaClbks.modifyMediaCompletedCB(termHndl, (RvMtfTerminalAppHandle)term->userData, (RvMtfDynamicModifyMediaStatus)reason, sdpMsg);
		RvLogDebug(ippLogSource,(ippLogSource, "rvModifyMediaCompletedIntCB() - after user callback modifyMediaCompletedCB, term id=%s, term=0x%p, status=%d",
			rvMdmTermGetId(term), term, reason));
	}
	else
	if (mtfMgr->connMediaClbks.connModifyMediaCompletedCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvModifyMediaCompletedIntCB() - before user callback connModifyMediaCompletedCB, term id=%s, term=0x%p, status=%d",
			rvMdmTermGetId(term), term, reason));
		mtfMgr->connMediaClbks.connModifyMediaCompletedCB(
			                                              (RvIppConnectionHandle)conn,
			                                              (RvMtfConnAppHandle)conn->userData,
		                                                  termHndl,
													      (RvMtfTerminalAppHandle)term->userData,
			                                              (RvMtfDynamicModifyMediaStatus)reason,
														   sdpMsg);
		RvLogDebug(ippLogSource,(ippLogSource, "rvModifyMediaCompletedIntCB() - after user callback connModifyMediaCompletedCB, term id=%s, term=0x%p, status=%d",
			rvMdmTermGetId(term), term, reason));
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvModifyMediaCompletedIntCB() - this callback was not registered by application, term id=%s, term=0x%p, status=%d",
			rvMdmTermGetId(term), term, reason));
	}


}

/***************************************************************************
 * rvRtpConnectIntCB
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrConnectCB
 *
 ***************************************************************************/
RvBool rvRtpConnectIntCB(
						RvCCConnection*  conn,
						RvMdmTermMgr *termMgr,
						RvMdmTerm *source,
						RvMdmMediaStreamInfo *m1,
						RvMdmTerm *target,
						RvMdmMediaStreamInfo *m2,
	                    RvMdmStreamDirection direction)
{
    RvMtfBaseMgr*	    mtfMgr;
	RvIppTerminalHandle	termHndlSource;
	RvIppTerminalHandle	termHndlTarget;
	RvMtfTerminalType	termType;
	RvStatus		    rc;
	RvBool              rv;

    mtfMgr = rvGetMtfMgrByMdmTerm(source);

	termHndlSource = rvIppMdmTerminalGetHandle(source);

    if (termHndlSource == NULL)
	{
        return RV_TRUE;
	}

	termHndlTarget = rvIppMdmTerminalGetHandle(target);

    if (termHndlTarget == NULL)
	{
        return RV_TRUE;
	}

	termType = rvIppMdmTerminalGetType(termHndlSource);

    /*  There are three options for user callback implementation:
	 *  1. Old implementation invoked by rvMdmTermMgrConnectMediaStreams_,
	 *  2. New callback by terminal invoked by mediaClbks.connectMediaCB,
	 *  3. New callback by connection invoked by connMediaClbks.connConnectMediaCB
	 *   Only one of the three options will be invoked.
	 */
	if (termMgr->connectF != NULL)
	{
		RvMdmError          mdmError;

		rv = rvMdmTermMgrConnectMediaStreams_(termMgr, source, m1, target, m2, direction, &mdmError);
	}
	else
	if (mtfMgr->mediaClbks.connectMediaCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvRtpConnectIntCB() - before user callback connectMediaCB, source term id=%s, source=0x%p, target term id=%s, target=0x%p",
					rvMdmTermGetId(source), source, rvMdmTermGetId(target), target));
		rc = mtfMgr->mediaClbks.connectMediaCB(
					(RvIppTerminalHandle)termHndlSource,
					(RvMtfTerminalAppHandle)source->userData,
					(RvIppTerminalHandle)termHndlTarget,
					(RvMtfTerminalAppHandle)target->userData,
					termType);
		RvLogDebug(ippLogSource,(ippLogSource, "rvRtpConnectIntCB() - after user callback connectMediaCB, source term id=%s, source=0x%p, target term id=%s, target=0x%p",
					rvMdmTermGetId(source), source, rvMdmTermGetId(target), target));
		rv = (rc == RV_OK);
	}
	else
	if (mtfMgr->connMediaClbks.connConnectMediaCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource,
			"rvRtpConnectIntCB() - before user callback connConnectMediaCB, conn %p, source term =%p, dest term=%p",conn, source, target));

		rc = mtfMgr->connMediaClbks.connConnectMediaCB(
			(RvIppConnectionHandle)conn,
			(RvMtfConnAppHandle)conn->userData,
			(RvIppTerminalHandle)termHndlSource,
			(RvMtfTerminalAppHandle)source->userData,
			(RvIppTerminalHandle)termHndlTarget,
			(RvMtfTerminalAppHandle)target->userData,
			termType);

		RvLogDebug(ippLogSource,(ippLogSource,
			"rvRtpConnectIntCB() - after user callback connConnectMediaCB, conn %p, source term =%p, dest term=%p, rc= %d",conn, source, target, rc));

		rv = (rc == RV_OK );
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvRtpConnectIntCB() - this callback was not registered by application, source term id=%s, source=0x%p, target term id=%s, target=0x%p",
					rvMdmTermGetId(source), source, rvMdmTermGetId(target), target));

		rv = RV_TRUE;
	}

	return (rv);
}

/***************************************************************************
 * rvRtpDisconnectIntCB
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrDisconnectCB
 *
 ***************************************************************************/
RvBool rvRtpDisconnectIntCB(
							RvCCConnection*     conn,
							RvMdmTermMgr*		termMgr,
	                        RvMdmTerm*			source,
                            RvMdmMediaStream*	m1,
                            RvMdmTerm*			target,
                            RvMdmMediaStream*	m2)
{
    RvMtfBaseMgr*	    mtfMgr;
	RvIppTerminalHandle	termHndlSource;
	RvIppTerminalHandle	termHndlTarget;
	RvMtfTerminalType	termType;
    RvStatus		    rc;
	RvBool              rv;

    mtfMgr = rvGetMtfMgrByMdmTerm(source);

	termHndlSource = rvIppMdmTerminalGetHandle(source);

    if (termHndlSource == NULL)
	{
        return RV_TRUE;
	}

	termHndlTarget = rvIppMdmTerminalGetHandle(target);

    if (termHndlTarget == NULL)
	{
        return RV_TRUE;
	}

	termType = rvIppMdmTerminalGetType(termHndlSource);

	/*  There are three options for user callback implementation:
	 *  1. Old implementation invoked by rvMdmTermMgrDisconnectMediaStreams_,
	 *  2. New callback by terminal invoked by mediaClbks.disconnectMediaCB,
	 *  3. New callback by connection invoked by connMediaClbks.connConnectMediaCB
	 *   Only one of the three options will be invoked.
	 */
	if (termMgr->disconnectF != NULL)
	{
		RvMdmError          mdmError;

		rv = rvMdmTermMgrDisconnectMediaStreams_(termMgr, source, m1, target, m2, &mdmError);
	}
    else
	if (mtfMgr->mediaClbks.disconnectMediaCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvRtpDisconnectIntCB() - before user callback disconnectMediaCB, source term id=%s, source=0x%p, target term id=%s, target=0x%p",
					rvMdmTermGetId(source), source, rvMdmTermGetId(target), target));
		rc = mtfMgr->mediaClbks.disconnectMediaCB(
					(RvIppTerminalHandle)termHndlSource,
					(RvMtfTerminalAppHandle)source->userData,
					(RvIppTerminalHandle)termHndlTarget,
					(RvMtfTerminalAppHandle)target->userData,
					termType);

		RvLogDebug(ippLogSource,(ippLogSource, "rvRtpDisconnectIntCB() - after user callback disconnectMediaCB, source term id=%s, source=0x%p, target term id=%s, target=0x%p",
					rvMdmTermGetId(source), source, rvMdmTermGetId(target), target));
		rv = (rc == RV_OK );
	}
	else
	if (mtfMgr->connMediaClbks.connDisconnectMediaCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource,
			"rvRtpConnectIntCB() - before user callback connDisconnectMediaCB, conn %p, source term =%p, dest term=%p",conn, source, target));

		rc = mtfMgr->connMediaClbks.connDisconnectMediaCB(
			(RvIppConnectionHandle)conn,
			(RvMtfConnAppHandle)conn->userData,
			(RvIppTerminalHandle)termHndlSource,
			(RvMtfTerminalAppHandle)source->userData,
			(RvIppTerminalHandle)termHndlTarget,
			(RvMtfTerminalAppHandle)target->userData,
			termType);

		RvLogDebug(ippLogSource,(ippLogSource,
			"rvRtpConnectIntCB() - after user callback connDisconnectMediaCB, conn %p, source term =%p, dest term=%p, rc= %d",conn, source, target, rc));

		rv = (rc == RV_OK );
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvRtpDisconnectIntCB() - this callback was not registered by application, source term id=%s, source=0x%p, target term id=%s, target=0x%p",
					rvMdmTermGetId(source), source, rvMdmTermGetId(target), target));

		rv = RV_TRUE;
	}

    return (rv);
}

/******************************************************************************
*  rvRtpCreateMediaIntCB
*  ----------------------------
*  General :        Media CB for TK. Used in version with MediaFrameWork
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         RV_TRUE on success.
******************************************************************************/
RvBool rvRtpCreateMediaIntCB(
			 RvCCConnection*            conn,
             struct RvMdmTerm_*         term,
             RvMdmMediaStreamDescr*     streamDescr)
{
    RvMtfBaseMgr*				mtfMgr;
	RvMdmError                  mdmError;
	RvIppTerminalHandle			termHndl;
    RvMtfMediaParams			params;
    RvStatus					rc;
	RvBool                      rv;
	RvChar                      logText[256];

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

	/* Map old parameters to new parameters */

    if (streamDescr->param.cmd == RVMDM_CMD_CREATE)
	{
        params.action = RVMTF_MEDIA_NEW;
        params.localSdp = streamDescr->param.normal.localSdp;
        params.remoteSdp = streamDescr->param.normal.remoteSdp;
        params.localCapsSdp = streamDescr->param.normal.localCapsSdp;
	}
	else
	{
		RvLogError(ippLogSource,(ippLogSource,"rvRtpCreateMediaIntCB() - unknown media action (%d) for Term: %s",
			streamDescr->param.cmd, rvMdmTermGetId(term)));
		return RV_FALSE;

	}

	termHndl = rvIppMdmTerminalGetHandle(term);

    if (termHndl == NULL)
	{
        return RV_TRUE;
	}

	/*  There are three options for user callback implementation:
	 *  1. Old implementation invoked by rvMdmTermCreateMediaStream_,
	 *  2. New callback by terminal invoked by mediaClbks.createMediaStreamCB,
	 *  3. New callback by connection invoked by connMediaClbks.connCreateMediaStreamCB
	 *   Only one of the three options will be invoked.
	 */
	if (term->termClass->createMediaF != NULL)
	{
		rv = rvMdmTermCreateMediaStream_(term, NULL, streamDescr, &mdmError);
	}
	else
	if (mtfMgr->mediaClbks.createMediaStreamCB != NULL)
	{
		sprintf(logText,
			    "rvRtpCreateMediaIntCB() - before user callback createMediaStreamCB, term id=%s, term=0x%p with local sdp:",
				 rvMdmTermGetId(term), term);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
     //	RvLogDebug(ippLogSource,(ippLogSource, "rvRtpCreateMediaIntCB() - before user callback createMediaStreamCB, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		IppPrintSdp(params.localSdp, "");
		rc = mtfMgr->mediaClbks.createMediaStreamCB(termHndl, (RvMtfTerminalAppHandle)term->userData, &params);
		sprintf(logText,"rvRtpCreateMediaIntCB() - after user callback, term id=%s, term=0x%p  rc = %d with local sdp ",
			     rvMdmTermGetId(term), term, rc);
		IppPrintSdp(params.localSdp, logText);
		// RvLogDebug(ippLogSource,(ippLogSource, "rvRtpCreateMediaIntCB() - after user callback, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
        rv = (rc == RV_OK);
	}
	else
	if (mtfMgr->connMediaClbks.connCreateMediaStreamCB != NULL)
	{
		sprintf(logText,
			    "rvRtpCreateMediaIntCB() - before user callback connCreateMediaStreamCB, conn %p, term id=%s, term=0x%p with local SDP:",conn, rvMdmTermGetId(term), term);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
//		RvLogDebug(ippLogSource,(ippLogSource,
//			"rvRtpCreateMediaIntCB() - before user callback connCreateMediaStreamCB, conn %p, term id=%s, term=0x%p with local SDP:",conn, rvMdmTermGetId(term), term));

		rc = mtfMgr->connMediaClbks.connCreateMediaStreamCB( (RvIppConnectionHandle)conn, (RvMtfConnAppHandle)conn->userData,
			                                                  termHndl, (RvMtfTerminalAppHandle)term->userData,
		                                                      &params);
		rv = (rc == RV_OK);

		sprintf(logText,
			    "rvRtpCreateMediaIntCB() - after user callback connCreateMediaStreamCB, conn %p, term id=%s, term=0x%p rc = %d, with local SDP:",
			    conn, rvMdmTermGetId(term), term, rc);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvRtpCreateMediaIntCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));

		rv = RV_TRUE;
	}

    return (rv);
}

/******************************************************************************
*  rvRtpModifyMediaIntCB
*  ----------------------------
*  General :        Media CB for TK. Used in version with MediaFrameWork
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         RV_TRUE on success.
******************************************************************************/
RvBool rvRtpModifyMediaIntCB(
				 RvCCConnection*    conn,
                 struct RvMdmTerm_* term,
                 RvMdmMediaStreamDescr* streamDescr
                 )
{
    RvMtfBaseMgr*	    mtfMgr;
	RvIppTerminalHandle	termHndl;
    RvMtfMediaParams    params;
    RvStatus		    rc;
	RvBool              rv;
	RvChar              logText[256];

    RvSdpMsgList	*sdpListLocal	= rvMdmMediaStreamDescrGetLocalDescr(streamDescr);
    RvSdpMsgList	*sdpListRemote	= rvMdmMediaStreamDescrGetRemoteDescr(streamDescr);
    RvSdpMsg		*msgLocal		= NULL;
    RvSdpMsg		*msgRemote		= NULL;

    msgLocal = rvSdpMsgListGetElement( sdpListLocal, 0);

    if (sdpListRemote != NULL)
    {
        msgRemote = rvSdpMsgListGetElement( sdpListRemote, 0);

    }

	memset(&params, 0, sizeof(params));

	switch (streamDescr->param.cmd)
    {
	case RVMDM_CMD_MUTE_ALL:
		params.action = RVMTF_MEDIA_MUTE;
		break;
	case RVMDM_CMD_UNMUTE_ALL:
		params.action = RVMTF_MEDIA_UNMUTE;
		break;
	case RVMDM_CMD_HOLD_REMOTE:
	case RVMDM_CMD_HOLD_LOCAL_TO_INACTIVE:
		params.action = RVMTF_MEDIA_HOLD_REMOTE;
		break;
	case RVMDM_CMD_UNHOLD_REMOTE:
		params.action = RVMTF_MEDIA_UNHOLD_REMOTE;
		break;

	case RVMDM_CMD_HOLD_LOCAL:
	case RVMDM_CMD_HOLD_REMOTE_TO_INACTIVE:
		params.action = RVMTF_MEDIA_HOLD_LOCAL;
		break;
	case RVMDM_CMD_UNHOLD_LOCAL:
		params.action = RVMTF_MEDIA_UNHOLD_LOCAL;
		break;

	case RVMDM_CMD_UNHOLD_INACTIVE_TO_REMOTE:
		params.action = RVMTF_MEDIA_UNHOLD_INACTIVE_TO_REMOTE;
		break;

	case RVMDM_CMD_UNHOLD_INACTIVE_TO_LOCAL:
		params.action = RVMTF_MEDIA_UNHOLD_INACTIVE_TO_LOCAL;
		break;

	case RVMDM_CMD_NORMAL:
		params.action = RVMTF_MEDIA_MODIFY_SESSION;
		break;

	case RVMDM_CMD_CREATE:
	case RVMDM_CMD_IDLE:
		params.action = RVMTF_MEDIA_NEW;
		break;
	case RVMDM_CMD_UNKNOWN:
		params.action = RVMTF_MEDIA_UNKNOWN;
		break;
	default:
		RvLogError(ippLogSource,(ippLogSource,"rvRtpModifyMediaIntCB() - unknown media action (%d) for Term: %s",
			streamDescr->param.cmd, rvMdmTermGetId(term)));
		return RV_FALSE;
    }

	/* Map old parameters to new parameters */

    switch (streamDescr->param.cmd)
    {
    case RVMDM_CMD_MUTE_ALL:
    case RVMDM_CMD_UNMUTE_ALL:
        params.remoteSdp = streamDescr->param.mute_all.remoteSdp;
        params.localSdp = msgLocal;
        params.localCapsSdp = NULL;
        break;

    case RVMDM_CMD_HOLD_REMOTE:
    case RVMDM_CMD_UNHOLD_REMOTE:
    case RVMDM_CMD_HOLD_LOCAL_TO_INACTIVE:
    case RVMDM_CMD_UNHOLD_INACTIVE_TO_LOCAL:
        params.remoteSdp = streamDescr->param.hold_remote.remoteSdp;
        params.localSdp = msgLocal;
        params.localCapsSdp = NULL;
        break;

    case RVMDM_CMD_HOLD_LOCAL:
    case RVMDM_CMD_UNHOLD_LOCAL:
    case RVMDM_CMD_HOLD_REMOTE_TO_INACTIVE:
    case RVMDM_CMD_UNHOLD_INACTIVE_TO_REMOTE:
        params.localSdp = streamDescr->param.hold_local.localSdp;
        params.remoteSdp = msgRemote;
        params.localCapsSdp = NULL;
        break;

    case RVMDM_CMD_NORMAL:
        params.action = RVMTF_MEDIA_MODIFY_SESSION;
        params.localSdp = streamDescr->param.normal.localSdp;
        params.remoteSdp = streamDescr->param.normal.remoteSdp;
        params.localCapsSdp = streamDescr->param.normal.localCapsSdp;

        break;

	case RVMDM_CMD_CREATE:
    case RVMDM_CMD_IDLE:
    case RVMDM_CMD_UNKNOWN:
        break;
    default:
		break;
    }

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

	termHndl = rvIppMdmTerminalGetHandle(term);

    if (termHndl == NULL)
	{
        return RV_TRUE;
	}

	/*  There are three options for user callback implementation:
	 *  1. Old implementation invoked by rvMdmTermModifyMediaStream_,
	 *  2. New callback by terminal invoked by mediaClbks.modifyMediaStreamCB,
	 *  3. New callback by connection invoked by connMediaClbks.connModifyMediaStreamCB
	 *   Only one of the three options will be invoked.
	 */
	if (term->termClass->modifyMediaF != NULL)
	{
		RvMdmError          mdmError;

		rv = rvMdmTermModifyMediaStream_(term, NULL, streamDescr, &mdmError);
	}
	else
	if (mtfMgr->mediaClbks.modifyMediaStreamCB != NULL)
    {
		sprintf(logText,
			"rvRtpModifyMediaIntCB() - before user callback modifyMediaStreamCB, term id=%s, term=0x%p, with local SDP", rvMdmTermGetId(term), term);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
		//RvLogDebug(ippLogSource,(ippLogSource, "rvRtpModifyMediaIntCB() - before user callback modifyMediaStreamCB, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		rc = mtfMgr->mediaClbks.modifyMediaStreamCB(termHndl, (RvMtfTerminalAppHandle)term->userData, &params);
	//	RvLogDebug(ippLogSource,(ippLogSource, "rvRtpModifyMediaIntCB() - after user callback, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		sprintf(logText,
			"rvRtpModifyMediaIntCB() - after user callback modifyMediaStreamCB, term id=%s, term=0x%p rc = %d, with local SDP", rvMdmTermGetId(term), term, rc);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
        rv = (rc == RV_OK);
	}
	else
	if (mtfMgr->connMediaClbks.connModifyMediaStreamCB != NULL)
	{
		sprintf(logText,
			"rvRtpModifyMediaIntCB() - before user callback connModifyMediaStreamCB, conn = %p, term id=%s, term=0x%p, with local SDP", conn, rvMdmTermGetId(term), term);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
		//RvLogDebug(ippLogSource,(ippLogSource, "rvRtpModifyMediaIntCB() - before user callback connModifyMediaStreamCB, conn = %p, term id=%s, term=0x%p", conn, rvMdmTermGetId(term), term));
		rc = mtfMgr->connMediaClbks.connModifyMediaStreamCB((RvIppConnectionHandle)conn, (RvMtfConnAppHandle)conn->userData,
			                                                  termHndl, (RvMtfTerminalAppHandle)term->userData, &params);
		sprintf(logText,
	         	"rvRtpModifyMediaIntCB() - after user callback connModifyMediaStreamCB, conn = %p, term id=%s, term=0x%p, with local SDP", conn, rvMdmTermGetId(term), term);
		/* print the local SDP with the log text */
		IppPrintSdp(params.localSdp, logText);
		// RvLogDebug(ippLogSource,(ippLogSource, "rvRtpModifyMediaIntCB() - after user callback, rc = %d",rc));
		rv = (rc == RV_OK);
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvRtpModifyMediaIntCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));

		rv = RV_TRUE;
	}

    return (rv);
}



/******************************************************************************
*  MtfRtpDestroyMedia
*  ----------------------------
*  General :        Media CB for TK. Used in version with MediaFrameWork
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         RV_TRUE on success.
******************************************************************************/
RvBool rvRtpDestroyMediaIntCB(
	     RvCCConnection*    conn,
         RvMdmTerm*         term,
         RvMdmMediaStream*  media)
{
    RvMtfBaseMgr*		mtfMgr;
	RvIppTerminalHandle	termHndl;
	RvStatus	     	rc;
	RvBool              rv;

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

	termHndl = rvIppMdmTerminalGetHandle(term);

    if (termHndl == NULL)
	{
        return RV_TRUE;
	}

	/*  There are three options for user callback implementation:
	 *  1. Old implementation invoked by rvMdmTermDestroyMediaStream_,
	 *  2. New callback by terminal invoked by mediaClbks.destroyMediaStreamCB,
	 *  3. New callback by connection invoked by connMediaClbks.connDestroyMediaStreamCB
	 *   Only one of the three options will be invoked.
	 */
	if (term->termClass->destroyMediaF != NULL)
	{
		RvMdmError          mdmError;

		rv = rvMdmTermDestroyMediaStream_(term, media, &mdmError);
	}
	else
	if (mtfMgr->mediaClbks.destroyMediaStreamCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvRtpDestroyMediaIntCB() - before user callback destroyMediaStreamCB, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		rc = mtfMgr->mediaClbks.destroyMediaStreamCB(termHndl, (RvMtfTerminalAppHandle)term->userData);
		RvLogDebug(ippLogSource,(ippLogSource, "rvRtpDestroyMediaIntCB() - after user callback destroyMediaStreamCB, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		rv = (rc == RV_OK);
	}
	else
	if (mtfMgr->connMediaClbks.connDestroyMediaStreamCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource,
			"rvRtpDestroyMediaIntCB() - before user callback connDestroyMediaStreamCB, conn %p, term id=%s, term=0x%p",conn, rvMdmTermGetId(term), term));

		rc = mtfMgr->connMediaClbks.connDestroyMediaStreamCB( (RvIppConnectionHandle)conn,
			(RvMtfConnAppHandle)conn->userData,
			termHndl,
			(RvMtfTerminalAppHandle)term->userData);

		rv = (rc == RV_OK);

		RvLogDebug(ippLogSource,(ippLogSource,
			"rvRtpDestroyMediaIntCB() - after user callback connDestroyMediaStreamCB, conn %p, term id=%s, term=0x%p, rc = %d",conn, rvMdmTermGetId(term), term, rc));

	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvRtpDestroyMediaIntCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));

		rv = RV_TRUE;
	}

    return (rv);
}

RvBool rvPhysCreateMediaIntCB(
          struct RvMdmTerm_* term,
          RvMdmMediaStream* media,
          RvMdmMediaStreamDescr* streamDescr,
          OUT RvMdmError* mdmError)
{
    RvMtfBaseMgr*		mtfMgr;
	RvIppTerminalHandle	termHndl;
	RvMtfTerminalType	termType;
    RvBool				rc;

    RV_UNUSED_ARG(media);
    RV_UNUSED_ARG(streamDescr);
    RV_UNUSED_ARG(mdmError);

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

	termHndl = rvIppMdmTerminalGetHandle(term);

    if (termHndl == NULL)
	{
        return RV_TRUE;
	}

	termType = rvIppMdmTerminalGetType(termHndl);

	if (mtfMgr->mediaClbks.startPhysicalDeviceCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvPhysCreateMediaIntCB() - before user callback, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		rc = mtfMgr->mediaClbks.startPhysicalDeviceCB(termHndl, (RvMtfTerminalAppHandle)term->userData, termType);
		RvLogDebug(ippLogSource,(ippLogSource, "rvPhysCreateMediaIntCB() - after user callback, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvPhysCreateMediaIntCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));

		rc = RV_OK;
	}

    return (rc == RV_OK);
}


RvBool rvPhysDestroyMediaIntCB(
           RvMdmTerm*         term,
           RvMdmMediaStream*  media,
           OUT RvMdmError*    mdmError)
{
    RvMtfBaseMgr*		mtfMgr;
	RvIppTerminalHandle	termHndl;
	RvMtfTerminalType	termType;
    RvBool				rc;

    RV_UNUSED_ARG(media);
    RV_UNUSED_ARG(mdmError);

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

	termHndl = rvIppMdmTerminalGetHandle(term);

    if (termHndl == NULL)
	{
        return RV_TRUE;
	}

	termType = rvIppMdmTerminalGetType(termHndl);

	if (mtfMgr->mediaClbks.stopPhysicalDeviceCB != NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvPhysDestroyMediaIntCB() - before user callback, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		rc = mtfMgr->mediaClbks.stopPhysicalDeviceCB(termHndl, (RvMtfTerminalAppHandle)term->userData, termType);
		RvLogDebug(ippLogSource,(ippLogSource, "rvPhysDestroyMediaIntCB() - after user callback, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvPhysDestroyMediaIntCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));

		rc = RV_OK;
	}

    return (rc == RV_OK);
}

#ifdef RV_MTF_SECOND_VIDEO
/******************************************************************************
*  rvRtpModifySpecificMediaStreamIntCB 
*  ----------------------------
*  General :    Modify Media Stream CB for TK. Used in version with MediaFrameWork
*               Currently used to open/close presentation video stream 
*
*  Return Value:   RV_TRUE on success.
*
*  ----------------------------------------------------------------------------
*  Arguments:	   	
*  Input:       conn				connection
*               streamHndl			Mtf handle to the media stream 
*               term				pointer to MDM terminal
*               mediaStreamParams   parameters of the media stream being
*									modified
*               applStreamHndl      pointer to application handle tp the
*                                   media stream
*  Output:         None
******************************************************************************/
RvBool rvRtpModifySpecificMediaStreamIntCB(
							RvCCConnection*    conn,
							RvMtfMediaStreamHandle streamHndl,
							struct RvMdmTerm_* term,
							RvMtfMediaStreamParams*  mediaStreamParams,
							RvMtfMediaStreamAppHandle* applStreamHndl)
{
	RvMtfBaseMgr*	    mtfMgr;
	RvIppTerminalHandle	termHndl;
	RvStatus		    rc;
	RvBool              rv;
	RvChar              logText[256];

	mtfMgr = rvGetMtfMgrByMdmTerm(term);
	termHndl = rvIppMdmTerminalGetHandle(term);

	if (termHndl == NULL)
	{
		return RV_TRUE;
	}

	/* print the media descriptor with the log text */
	sprintf(logText, "rvRtpModifySpecificMediaStreamIntCB() - before user callback connModifySpecificMediaStreamCB, conn=0x%p, streamHndl=0x%p, applStreamHndl=0x%p, termId=%s, term=0x%p, Stream Direction=%d", 
		conn, streamHndl, *applStreamHndl, rvMdmTermGetId(term), term, mediaStreamParams->streamDirection);
	rvCCTextPrintMediaStreamDescr(mediaStreamParams->streamDescriptor, logText, RV_LOGLEVEL_INFO);

	if (mtfMgr->connMediaClbks.connModifySpecificMediaStreamCB != NULL)
	{
		
		rc = mtfMgr->connMediaClbks.connModifySpecificMediaStreamCB((RvIppConnectionHandle)conn, (RvMtfConnAppHandle)conn->userData,
			termHndl, (RvMtfTerminalAppHandle)term->userData, streamHndl, applStreamHndl, mediaStreamParams); 

		rv = (rc == RV_OK);
		
 		if (mediaStreamParams->streamDirection == RVMTF_MEDIA_STREAM_RECEIVE)
 		{			
			sprintf(logText,
				"rvRtpModifySpecificMediaStreamIntCB() - after user callback connModifySpecificMediaStreamCB, conn = %p, streamHndl=0x%p, applStreamHndl=0x%p, term id=%s, term=0x%p, with local SDP",
				conn, streamHndl, *applStreamHndl, rvMdmTermGetId(term), term);

			/* print the the median descriptor with the log text */
			rvCCTextPrintMediaStreamDescr(mediaStreamParams->streamDescriptor, logText, RV_LOGLEVEL_INFO);
		}
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"connModifySpecificMediaStreamCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));

		return RV_TRUE;
	}
	return (rv);
}
#endif



