/******************************************************************************
Filename:    ippcodec_g7231.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "ippcodec_g7231.h"

#define LOGSRC	LOGSRC_CODEC

#define	STR_G7231_PTIME				"ptime"
#define STR_G7231_AUDIO_FRAMES		"audioFrames"
#define STR_G7231_SILENCE_SUPPORT   "SilenceSupp"
/*******************************************************************************/
#define AUDIO_FRAMES_PTIME_MULTIPLY		30
/*******************************************************************************/
/*******************************************************************************/
RVAPI RvStatus CodecData_g7231_Construct( OUT CodecData_g7231*	data,
				   IN RvSdpMediaDescr* descr,/*where the codec is located*/
				   IN int			payload
				   )
{
    const char* szValue;

	memset( data,0, sizeof(CodecData_g7231));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
	/* parse the codec parameters */
		
    szValue = ippGetAttrByName( STR_G7231_PTIME, descr);
    if(szValue)
        data->ptime = atoi(szValue);
    else
        data->ptime = 0;

    szValue = ippGetAttrByName( STR_G7231_AUDIO_FRAMES, descr);
    if(szValue)
        data->audioFrames = atoi(szValue);
    else
		data->audioFrames = data->ptime/AUDIO_FRAMES_PTIME_MULTIPLY;

    szValue = ippGetAttrByName( STR_G7231_SILENCE_SUPPORT, descr);
    if(szValue && RvStrcasecmp( szValue, "on") ==0 )
        data->bSilenceSupp = rvTrue;
    else
    	data->bSilenceSupp = rvFalse;

	return RV_OK;
}
/*******************************************************************************/
RVAPI void CodecData_g7231_Destruct( OUT CodecData_g7231*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
