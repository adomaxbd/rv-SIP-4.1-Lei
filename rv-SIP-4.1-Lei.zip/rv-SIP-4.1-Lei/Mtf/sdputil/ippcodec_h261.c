/******************************************************************************
Filename:    ippcodec_h261.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "ippcodec_h261.h"

#define LOGSRC	LOGSRC_CODEC

extern RvLogSource         g_logSrc;
/*******************************************************************************/
#define    STR_H261_QCIF_V         "QCIF"	/*qcifMPI	INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H261_CIF_V          "CIF"	/*cifMPI		INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H261_D_V            "D"
#define    STR_H261_MAXBR_V        "MAXBR"	/*maxBitRate	INTEGER (1..192400),	-- units 100 bit/s*/
#define    STR_TIAS                "TIAS"
#define	   STR_AS					"AS"
#define	   DEFAULT_MAXBR			3200
/*******************************************************************************/
#define set_order(order, index, value, order_privilege)   if(order > index){ order = index; order_privilege = value;}
/*******************************************************************************/
RVAPI RvStatus CodecData_h261_Construct( OUT CodecData_h261*	data,
								  IN RvSdpMediaDescr* descr,/*where the codec is located*/
								  IN int			payload
								  )
{
    char    value[32];
    RvUint32    order = 0xFFFF;
    RvInt       index;
	
	memset( data,0, sizeof(CodecData_h261));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
    
	/*  parse the codec parameters
     *  --------------------------
     */

	/*MUST parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H261_D_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        )  &&  RvStrcasecmp( value, "2") ==0)
        data->unrestrictedVector = rvTrue;
    else
    	data->unrestrictedVector = rvFalse;
	
	/*MUST parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H261_MAXBR_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->maxBitRate = atoi(value);
    else if /*interop MCU*/ (RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H261_MAXBR_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->maxBitRate = atoi(value);
	
    else if /* from bandwith*/(rvSdpMediaDescrGetNumOfBandwidth( descr) >0)
    {
        RvSdpBandwidth* band = rvSdpMediaDescrGetBandwidth( descr);
        if(RvStrcasecmp(STR_TIAS, band->iBWType) ==0)
            data->maxBitRate = band->iBWValue /100;
		else	if(RvStrcasecmp(STR_AS, band->iBWType) ==0)
				data->maxBitRate = band->iBWValue*10;
		else
		    data->maxBitRate = DEFAULT_MAXBR;
    }

    else
	{
		RvLogError(&g_logSrc, (&g_logSrc,"sdpToData(): %s is't found in Sdp data", STR_H261_MAXBR_V));
		data->maxBitRate = DEFAULT_MAXBR;
		goto err_exit;
	}
	
	
    /*get resolution options and their order */
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H261_QCIF_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->qcifMPI = atoi( value);
        set_order( order, (RvUint32)index, MF_RESOLUTION_QCIF, data->order_privilege);
    }
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H261_CIF_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->cifMPI = atoi( value);
        set_order( order, (RvUint32)index, MF_RESOLUTION_CIF, data->order_privilege);
    }
        
    /*default behavior according RFC 4629*/
    if(order == 0xFFFF)
    {
        data->qcifMPI =2;
        data->framerate = 30/ data->qcifMPI;
        data->order_privilege = MF_RESOLUTION_QCIF;

//        data->cifMPI =2;
//        data->framerate = 30/ data->cifMPI;
//        data->order_privilege = MF_RESOLUTION_CIF;
    }
    /*frame rate*/
    switch(data->order_privilege)
    {
		case MF_RESOLUTION_QCIF:
			data->framerate = 30/ data->qcifMPI;
			break;
		case MF_RESOLUTION_CIF:
			data->framerate = 30/ data->cifMPI;
			break;
		default:
    		RvLogError(&g_logSrc, (&g_logSrc,"sdpToData(): Resolution is't found in Sdp data. Used default: QCIF=2"));
			break;
    }
	
	/*
	*	get encoding name
	*/
	{
		RvSdpRtpMap* rtpMap = NULL;	

		if(	IppCodecFindRtpMapInMediaDescr( descr, payload, &rtpMap) && rtpMap)
		{
			data->szEncodingName = rvSdpRtpMapGetEncodingName( rtpMap);			
		}
		else
		{
			if( payload < FIRST_DYNAMIC_PAYLOAD)
			{
				data->szEncodingName = rvSdpCodecNameGetByPayLoad( payload);
			}
			else
				goto err_exit;
		}
	}
	
	return RV_OK;
err_exit:
	return RV_ERROR_UNKNOWN;
}
/******************************************************************************
*  CodecData_h261_to_mediaDsecr
*  --------------------------------
*  General :        Converts data from CodecData_h261 type structure into media
*                   descriptor
*
*
*  Return Value:   RV_OK - all the parameters converted successfully
*                  RV_ERROR_UNKNOWN - otherwise
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          data - ptr to codec data to be converted
*                  descr - media descriptor where the converted values are set
*                          The descriptor may hold values. Theses values will be
*                          overridden.
*                  payload - of the codec.
*
*  Output:         none.
******************************************************************************/
RVAPI RvStatus CodecData_h261_to_mediaDsecr( IN CodecData_h261*	data,
											INOUT RvSdpMediaDescr* descr,/*where the codec is located*/
											IN int		         payload,
											IN RV_BOOL           listOneXCif
										    )
{


   char    value[32];
   RvInt   numOfParams, i;
   RV_BOOL addNextXCIF = RV_TRUE;
 
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);


	
	/* clear all Fmtp params in descr */

	numOfParams = RvSdpCodecFmtpParamGetNum( descr, payload, ' ');
	for (i=0; i < numOfParams; i++)		
	{		
		RvSdpCodecFmtpParamRemoveByIndex(			
			descr,			
			0,			
			RV_FALSE,			
			payload,			
			' ');		
	}
		
	/* copy params from data to the media descriptor */

	/*MUST parameter*/

	if (data->unrestrictedVector)
	{
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H261_D_V,
			NULL,
			rvTrue,
			payload,
			' ',
			NULL);
	}	

	/* convert max bitrate to TIAS parameter. 
	   In some cases the bitrate was extracted from an FMTP parameter MAXBR.
	   It is converted back to TIAS as this is the H261 standard parameter */
	
	/*MUST parameter*/

	
    
    if(rvSdpMediaDescrGetNumOfBandwidth( descr) !=0)
		rvSdpMediaDescrRemoveBandwidth(descr ,0);

	if (data->maxBitRate != 0)
	{
		IppSdpUtil_itoa(data->maxBitRate, value);
		rvSdpMediaDescrAddBandwidth(descr, "TIAS", data->maxBitRate * 100);
	}


	/*  handle xCIF parameters */
	
	/* Put the preferred xCIF option. If one was not found, put one
	   of the less-preferred xCIF or all of them - depending on the value of listOneXCif.*/
	switch(data->order_privilege)
	{

	case MF_RESOLUTION_QCIF:

		if (data->qcifMPI !=0)
		{				
			IppSdpUtil_itoa(data->qcifMPI, value);
			
			RvSdpCodecFmtpParamSet(
				descr,
				"QCIF",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;
		
	case MF_RESOLUTION_CIF:
		
		if (data->cifMPI !=0)
		{		
			IppSdpUtil_itoa(data->cifMPI, value);
			
			RvSdpCodecFmtpParamSet(
				descr,
				"CIF",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;

	default:
		break;
	}

	/* Add the less preferred xCIF parameters */

	if ((data->qcifMPI) && (data->order_privilege != MF_RESOLUTION_QCIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->qcifMPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"QCIF",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
		addNextXCIF = !listOneXCif;
	}
	
	
	if ((data->cifMPI) && (data->order_privilege != MF_RESOLUTION_CIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->cifMPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"CIF",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
	}

	
	return RV_OK;

}
/*******************************************************************************/
RVAPI void CodecData_h261_Destruct( OUT CodecData_h261*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
