/******************************************************************************
Filename:    ippcodec.c
Description: Ipp wrapper for codec parsing API
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#define LOGSRC	LOGSRC_CODEC

#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include "rvaddress.h"
#include "rvsdpmsg.h"
#include "ippcodec.h"
#include "rvstrutils.h"


RvLogSource     g_logSrc;
static RvInt32  g_initialized;
/*-----------------------------------------------------------------------*/
/*                   PRIVATE FUNCTIONS	DECLARATION                      */
/*-----------------------------------------------------------------------*/


/*-----------------------------------------------------------------------*/
/*                   API FUNCTION	IMPLEMENTATIONS                      */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * IppSdpUtil_itoa
 * ------------------------------------------------------------------------
 * General: The function convert integer to string.
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: number - The integer value.
 *        str	 - The buffer that will contain the string of the integer.
 *		  
 ***************************************************************************/
RVAPI char *IppSdpUtil_itoa(int number, char *str)
{
  if (!str) return NULL;

  sprintf(str, "%d", number);
  return str;
}

/************************************************************************
 * IppCodecInitialize
 * purpose: check if the string is from a valid number
 *	This function initializes the SDP Codec module;
 *  It needs to be called exactly once before any other function from
 *  the module
 * input  : none
 * output :	none
 * return : RV_OK if success
 *
 ************************************************************************/
RVAPI RvStatus IppCodecInitialize(RvLogMgr* logMgr)
{
    RvStatus rc = RV_OK;
	
#if (RV_LOGMASK != RV_LOGLEVEL_NONE)
    if(0 == g_initialized++)
    {
		rc = RvLogSourceConstruct( logMgr, &g_logSrc, "SdpUtil", "SdpUtil");
        if(rc ==RV_OK)
        {
			RvLogMessageType logMask = (		RV_LOGLEVEL_EXCEP   |
			                                 	RV_LOGLEVEL_ERROR   |
			                                	RV_LOGLEVEL_WARNING /*|
							            		RV_LOGLEVEL_INFO	|
							             		RV_LOGLEVEL_DEBUG   |
							             		RV_LOGLEVEL_ENTER   |
							            		RV_LOGLEVEL_LEAVE     */);
			RvLogSourceSetMask( &g_logSrc, logMask);
        }
    }
    else
        rc =RV_OK;
#endif
	return rc;
}


/************************************************************************
 * IppCodecEnd
 * purpose: check if the string is from a valid number
 *	This function de-initializes the SDP Codec module;
 *  It needs to be called exactly once at the end of module use.
 * input  : none
 * output :	none
 * return : RV_OK if success
 *
 ************************************************************************/
RVAPI RvStatus IppCodecEnd(void)
{
    RvStatus rc;
    if(0 == --g_initialized)
	    rc = RvLogSourceDestruct(&g_logSrc);
    else
        rc =RV_OK;

	return rc;
}

/***************************************************************************************
 * IppCodecGetEnum
 * -------------------------------------------------------------------------------------
 * General:   Parse RvSdpMediaDescr and return codec enum this descr speaks about
 *
 * Return Value: IppCodecEnum
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			 RvSdpMediaDescr*	descr	- media parameters.
 *			 int				payload	- /if payload <0 than the 1st payload inside descr will be used /
 *
 * Output:   None
 *
**************************************************************************************/
RVAPI enMFRtpPayloadCodecType_t	IppCodecGetEnum( IN RvSdpMediaDescr* descr, IN int payload)
{
	int	i = -1;
	const char		*szSdpCodecName;
	RvSdpRtpMap*	rtpMap;

    static struct   {const char* name; enMFRtpPayloadCodecType_t codec;}   table[]=
    {	
		{"AMR",         eMFAMRPayloadCodecType},
        {"AMR-NB",      eMFAMRPayloadCodecType},

        {"PCMU",        eMFG711UPayloadCodecType},
        {"PCMA",        eMFG711APayloadCodecType},
        {"G711",        eMFG711UPayloadCodecType},
        {"G.711",       eMFG711UPayloadCodecType},
        {"G711u",       eMFG711UPayloadCodecType},
        {"G.711u",      eMFG711UPayloadCodecType},
        {"G711a",       eMFG711APayloadCodecType},
        {"G.711a",      eMFG711APayloadCodecType},
        
        {"G722"	,       eMFG722PayloadCodecType},
        {"G722-64",     eMFG722PayloadCodecType},
        {"G722-56",     eMFG722PayloadCodecType},
        {"G722-48",     eMFG722PayloadCodecType},
        
        /*	{"G7221"*/
        
        {"G7231",       eMFG723PayloadCodecType},
        {"G723",        eMFG723PayloadCodecType},
        {"G.723",       eMFG723PayloadCodecType},
        {"G723-6-3k",   eMFG723PayloadCodecType},
        {"G.723-5-3k",  eMFG723PayloadCodecType},
        {"G723-5-3k",   eMFG723PayloadCodecType},
        /*
        static const char*	names_g726[3] =
        {
        "G726-24",
        "G726-32",
        "G726-48"
        };
        */
        {"g729",		eMFG729PayloadCodecType},
        {"g.729",		eMFG729PayloadCodecType},
        {"g729a",		eMFG729PayloadCodecType},
        {"g.729a",		eMFG729PayloadCodecType},
        {"g729b",		eMFG729ABPayloadCodecType},
        {"g.729b",		eMFG729ABPayloadCodecType},
        {"g729ab",		eMFG729ABPayloadCodecType},
        {"g.729ab",		eMFG729ABPayloadCodecType},
        
        {"H261",		eMFH261PayloadCodecType},
        {"H.261",		eMFH261PayloadCodecType},
           
        {"H263",        eMFH263_2190_PayloadCodecType},

/*      {"H263",        eMFH263_2429_PayloadCodecType},
        {"H263",        eMFH263_2429_follow_on_PayloadCodecType},
        {"H263",        eMFH263_2190_short_packet_PayloadCodecType},*/
        {"H263-1998",   eMFH263_2190_PayloadCodecType},
        {"H263-2000",   eMFH263_2190_PayloadCodecType},
        
        {"",			eMFNullPayloadCodecType}
    };
/*
     static const char*	names_mp4v_es[1] =
	{
		"MP4V-ES"
	};
	static const char*	names_mp4_latm[1] =
	{
		"MP4-LATM"
	};
*/
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);

	if(	IppCodecFindRtpMapInMediaDescr( descr, payload, &rtpMap) && rtpMap)
	{
		szSdpCodecName = rvSdpRtpMapGetEncodingName( rtpMap);

	}
	else
	{
		if( payload < FIRST_DYNAMIC_PAYLOAD)
		{
			szSdpCodecName = rvSdpCodecNameGetByPayLoad( payload);
		}
		else
			goto err_exit;
	}

	if (szSdpCodecName == NULL)
	{
		/* Couldn't find a codec name for this payload */
		RvLogError(&g_logSrc,(&g_logSrc,"IppCodecGetEnum() no codec name for payload %d.", payload));
		goto err_exit;
	}
	
	while( table[++i].codec != eMFNullPayloadCodecType)
	{
		if (!RvStrcasecmp(table[i].name, szSdpCodecName))
			return table[i].codec;
	}

err_exit:
	return eMFNullPayloadCodecType;
}
/***************************************************************************************/


/********************************************************
 *
 * API: Wrappers
 *
 *******************************************************/
RVAPI const char* IppSdpMediaGetMediaIp( IN RvSdpMediaDescr*	descr)
{
	const char*	psz;
	RvSdpConnection*	sdpConn = rvSdpMediaDescrGetConnection( descr);

	if(!sdpConn)
		return NULL;
	psz = rvSdpConnectionGetAddress( sdpConn);
	if(!psz)
		return NULL;

	return psz;
}

/************************************************************************/
RVAPI RvStatus IppSdpMediaSetMediaIp( IN RvSdpMediaDescr* descr,
							IN RvSdpAddrType type, /* RV_SDPADDRTYPE_IP4 or RV_SDPADDRTYPE_IP6 */
							IN const char* szAddr)
{
	RvSdpConnection*	sdpConn = rvSdpMediaDescrGetConnectionByIndex( descr,0);
	if(!sdpConn)
        rvSdpMediaDescrRemoveConnection( descr, 0);
    rvSdpMediaDescrAddConnection(descr, RV_SDPNETTYPE_IN, type, szAddr);

	return RV_OK;
}

/************************************************************************/
RVAPI RvStatus IppSdpMediaSetRtpPort( IN RvSdpMediaDescr* descr, IN RvUint16 port)
{
	rvSdpMediaDescrSetPort( descr, port);
	return RV_OK;
}
/************************************************************************
 * IppSdpMsgGetRtpIP
 * purpose: search for IP address of given payload in RvSdpMsg
 *  the module
 * input  :
 *			msg			- SdpMsg to search in
 *			payload		- number to search
 * output :
 *			nIp			- IP as 32-bit number
 *			szIp		- IP as string
 * return : RV_TRUE  if found
 *
 ************************************************************************/
RvStatus IppSdpMediaGetRtpIP(
							IN RvSdpMsg*		msg,
							IN RvSdpMediaDescr*	descr,
							OUT RvUint32*		pIp,
							OUT char**			pszIp)
{
	RvSdpConnection*	sdpConn;
	char*				psz;

	/*
	 *	find connection in media or in whole media
	 */
	sdpConn = rvSdpMediaDescrGetConnection( descr);
	if( sdpConn == NULL )
		sdpConn = rvSdpMsgGetConnection( msg);

	if( sdpConn == NULL )
	{
		RvLogError(&g_logSrc,(&g_logSrc,"IppSdpMsgGetRtpIP() no connection."));
		goto err_exit;
	}

	psz = (char*)rvSdpConnectionGetAddress( sdpConn);

	if( pszIp)
		*pszIp = psz;

	if( pIp)
	{
		RvAddressStringToIpv4(  pIp, psz);
	}

	return RV_OK;
err_exit:
	RvLogError(&g_logSrc,(&g_logSrc,"IppSdpMsgGetRtpIP() failed."));
	return RV_ERROR_UNKNOWN;
}

/************************************************************************
 * IppSdpMediaGetRtcpPort
 * purpose: search for RTCP port of given payload in RvSdpMsg
 *  the module
 * input  :
 *			msg			- SdpMsg to search in
 *			payload		- number to search
 * output :
 *			nPort			- RTCP port
 * return : RV_TRUE  if found
 *
 ************************************************************************/
RvStatus IppSdpMediaGetRtcpPort( IN RvSdpMediaDescr* descr, OUT RvUint16* pPort)
{
	RvUint16			port =0;
	RvSdpAttribute*		attr;
	unsigned int		i;


	*pPort = 0;

	/* look for a rtcp attribute, if there is any... */
	for (i=0 ; i<rvSdpMediaDescrGetNumOfAttr( descr); ++i)
	{
		attr = rvSdpMediaDescrGetAttribute( descr, i);
        if ((attr != NULL) && !RvStrcasecmp(rvSdpAttributeGetName(attr), "rtcp"))
        {
			port = (RvUint16)atoi( rvSdpAttributeGetValue(attr));
		}
	}

	if (port == 0)
		port = (RvUint16)(1 + rvSdpMediaDescrGetPort( descr));
	if (port == 1)
	{
		RvLogError(&g_logSrc,(&g_logSrc,"IppSdpMsgGetRtcpPort(). port =0."));
		goto err_exit;
	}

	*pPort = port;
	return RV_OK;
err_exit:
	RvLogError(&g_logSrc,(&g_logSrc,"IppSdpMediaGetRtcpPort() failed. "));
	return RV_ERROR_UNKNOWN;
}

/************************************************************************
 * IppSdpMediaGetRtpPort
 * purpose: search for RTP port of given payload in RvSdpMsg
 *  the module
 * input  :
 *			msg			- SdpMsg to search in
 *			payload		- number to search
 * output :
 *			pPort			- buffer for RTP port
 * return : RV_TRUE  if found
 *
 ************************************************************************/
RVAPI RvStatus IppSdpMediaGetRtpPort(
								IN RvSdpMediaDescr*	descr,
								OUT RvUint16* pPort)
{
	RvUint16			port;

	*pPort = (RvUint16)(-1);

	port = (RvUint16)rvSdpMediaDescrGetPort( descr);
	if (port == (RvUint16)(-1))
	{
		RvLogError(&g_logSrc,(&g_logSrc,"IppSdpMsgGetRtpPort(). port =-1."));
		goto err_exit;
	}

	*pPort = port;
	return RV_OK;
err_exit:
	RvLogError(&g_logSrc,(&g_logSrc,"IppSdpMsgGetRtpPort() failed."));
	return RV_ERROR_UNKNOWN;
}

/************************************************************************
 * IppCodecFindRtpMapInMediaDescr
 * purpose: find the rtpMap of a given payload in RvSdpMediaDescr
 *
 * input  :
 *			media		- MediaDescr to search in
 *			payload		- number to search
 * output :
 *			pprtpMap	- points to rtpMap element of appropriate payload
 * return : RV_TRUE  if found or if not found rtpMap for static payload
 *                   (rtpMap line is not mandatory in static codecs)
 *
 ************************************************************************/
RvBool	IppCodecFindRtpMapInMediaDescr(
							IN RvSdpMediaDescr	*media,
							IN int payload,
							OUT RvSdpRtpMap** pprtpMap)
{
	size_t		idxPayload, idxRtpMap;
    RvBool      bFound =RV_FALSE;

	if(pprtpMap)
		*pprtpMap = NULL;

	/*Go through list of codecs*/
	for(idxPayload=0; idxPayload < rvSdpMediaDescrGetNumOfPayloads(media); ++idxPayload)
	{
		RvSdpRtpMap*	rtpMap = NULL;
		int				element;

		/* find the rtp map of this payload type */
		for(idxRtpMap=0; idxRtpMap< rvSdpMediaDescrGetNumOfRtpMap(media); ++idxRtpMap)
		{
			rtpMap = rvSdpMediaDescrGetRtpMap(media, idxRtpMap);
            if (rtpMap != NULL)
            {
			element = rvSdpRtpMapGetPayload(rtpMap);
			/*Look for the rtp map that matches this payload*/
			if (element == payload)
			{
                    bFound = RV_TRUE;
				break;
			}
            }
		}

		if(bFound)
		{
			if(pprtpMap)
				*pprtpMap = rtpMap;

            return RV_TRUE;
		}

		if(payload == rvSdpMediaDescrGetPayloadNumber(media, (int)idxPayload))
		{
			if (payload < FIRST_DYNAMIC_PAYLOAD)
			{/* static payload*/
				if(pprtpMap)
					*pprtpMap = NULL;
                return RV_TRUE;
			}
		}
	}

    return RV_FALSE;
}


/*-----------------------------------------------------------------------*/
/*                   PRIVATE FUNCTIONS	IMPLENETATION                    */
/*-----------------------------------------------------------------------*/

RvBool	IppCodecFindPayloadInMsg(
					IN RvSdpMsg *msg,
					IN int payload,
					OUT RvSdpMediaDescr** ppdescr,
					OUT RvSdpRtpMap** pprtpMap)
{
	RvSdpMediaDescr		*media;
	size_t				i;

	*ppdescr = NULL;

	for(i=0; i < rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		media = rvSdpMsgGetMediaDescr(msg, i);

		if( IppCodecFindRtpMapInMediaDescr( media, payload, pprtpMap))
		{
			*ppdescr = media;
            return RV_TRUE;
		}
	}
    return RV_FALSE;

}

/********************************************************
 *
 * API: Codec ----> SDP. Internal
 *
 *******************************************************/
void IppFmtpAttrConstruct( INOUT IppFmtpAttr* attr, IN int payLoad, IN char delimeter)
{
	attr->delimeter = delimeter;
	memset( attr, 0, sizeof(IppFmtpAttr));
	sprintf( attr->buf, "%d", payLoad);
}
/*=====================================================================*/
RvStatus IppFmtpAttrAddParamByName( INOUT IppFmtpAttr* attr,
								  IN const char* param_name,
								  IN const char* value)
{
	int		len = (int)strlen(attr->buf);

	if(!attr->bNotFirstParam)
		attr->buf[ len] = ' ';
	else
		attr->buf[ len] = attr->delimeter;

	attr->buf[ len+1] = '\0';

	sprintf( &attr->buf[ len+1], "%s=%s", param_name, value);

    attr->bNotFirstParam = RV_TRUE;
	return RV_OK;
}
/*=====================================================================*/
/***********************************************************
 Function:    getStringAttr ()

 Description: Get  value of media descr attributes if exists.

 Arguments:   media - includes sdp message, OUT ptime - packet time

 Returns:     attr value or NULL if such an attribute doesn exists.
***********************************************************/
const char* getStringAttr(RvSdpMediaDescr *media, IN const char* szAttr)
{
	RvSdpAttribute* attr;
	unsigned int i;

	/* look for a packetization attribute, if there is any... */
	for (i=0 ; i<rvSdpMediaDescrGetNumOfAttr(media); ++i)
	{
		 attr = rvSdpMediaDescrGetAttribute(media, i);
         if ((attr != NULL) && (RvStrcasecmp(rvSdpAttributeGetName(attr), szAttr) == 0))
		 {
			 return rvSdpAttributeGetValue( attr);
		 }
	}

	/*
	 *	we get here if appropriate attr is not found
	 */
	return NULL;
}
/***********************************************************
 Function:    setStringAttr ()

 Description: Set  SDP message attributes.

 Arguments:   media - includes sdp message, OUT ptime - packet time

 Returns:     None.
***********************************************************/
void setStringAttr(RvSdpMediaDescr *media, IN const char* szAttr, IN const char* szValue)
{
	RvSdpAttribute* attr;
	unsigned int i;

	/* look for a packetization attribute, if there is any... */
	for (i=0 ; i<rvSdpMediaDescrGetNumOfAttr(media); ++i)
	{
		 attr = rvSdpMediaDescrGetAttribute(media, i);
         if ((attr != NULL) && !RvStrcasecmp(rvSdpAttributeGetName(attr), szAttr))
		 {
			 rvSdpAttributeSetValue( attr, szValue);
			 return;
		 }
	}

	/*
	 *	we get here if appropriate attr is not found
	 */
	rvSdpMediaDescrAddAttr( media, szAttr, szValue);
}
/***********************************************************
 Function:    setIntAttr ()

 Description: Set  SDP message attributes.

 Arguments:   media - includes sdp message,

 Returns:     None.
***********************************************************/
void setIntAttr(RvSdpMediaDescr *media, IN const char* szAttr, IN RvUint32 nValue)
{
	char	szValue[16];

	setStringAttr(media, szAttr, IppSdpUtil_itoa( nValue, szValue));
}
/***********************************************************
 Function:    setPacketTime ()

 Description: Set packet time tin SDP message attributes.

 Arguments:   media - includes sdp message, OUT ptime - packet time

 Returns:     None.
***********************************************************/
void setPacketTime(RvSdpMediaDescr *media, IN RvUint32 ptime)
{
	setIntAttr( media, "ptime", ptime);
}
/********************************************************************************/

RVAPI int 	IppCodecGetFirstPayload( IN RvSdpMediaDescr* descr )
{
	if( rvSdpMediaDescrGetNumOfPayloads (descr) >0)
		return rvSdpMediaDescrGetPayloadNumber( descr, 0);
	else
		return -1;
}
/********************************************************************************/
RVAPI RvStatus IppSerializeSdpDescrTo( OUT char* buf, IN RvUint32 bufsize, IN RvSdpMediaDescr* descr)
{
	RvSdpMsg msg;
	RvSdpStatus	stat=0;
    char*   szEnd;

	rvSdpMsgConstruct( &msg);
	if(rvSdpMsgInsertMediaDescr( &msg, descr) != RV_SDPSTATUS_OK)
	{
		RvLogError(&g_logSrc,(&g_logSrc,"serializeSdpDescr_to() failed"));
		rvSdpMsgDestruct( &msg);
        goto err_exit;
	}

    szEnd = rvSdpMsgEncodeToBuf( &msg, buf, bufsize, &stat) ;
	
	if ((szEnd == NULL) || (stat != RV_SDPSTATUS_OK))
	{
		RvLogError(&g_logSrc, (&g_logSrc, "IppSerializeSdpDescrTo() - SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
			msg, stat));
        goto err_exit;
	}
    *szEnd ='\0';
	rvSdpMsgDestruct( &msg);
	return RV_OK;
err_exit:
	rvSdpMsgDestruct( &msg);
	return RV_ERROR_UNKNOWN;
}
/***************************************************************************************/
RVAPI RvStatus IppSerializeSdpDescrFrom( IN const char* buf, OUT RvSdpMediaDescr* pdescr)
{
    RvSdpParseStatus	stat;
    int					len = (int)strlen( buf);
    RvSdpMsg            msg;
    RvSdpMediaDescr*    pdescrTmp;

    if(rvSdpMsgConstructParse( &msg, (char*)buf, &len, &stat) !=NULL)
    {
        pdescrTmp = rvSdpMsgGetMediaDescr( &msg, 0);
        if(!pdescrTmp)
        {
        	rvSdpMsgDestruct( &msg);
            return RV_ERROR_UNKNOWN;
        }
        rvSdpMediaDescrCopy( pdescr, pdescrTmp);
    	rvSdpMsgDestruct( &msg);
        return RV_OK;
    }

    return RV_ERROR_UNKNOWN;
}
/***************************************************************************************/
const char* ippGetAttrByName(IN const char* attrName, IN RvSdpMediaDescr *descr)
{
	RvSdpAttribute* attr;
	RvSize_t	i;
    const char  *attrNameTemp;

	for (i =0 ; i < rvSdpMediaDescrGetNumOfAttr2(descr); ++i)
	{
		attr = rvSdpMediaDescrGetAttribute2(descr, i);
        attrNameTemp = rvSdpAttributeGetName(attr);
		if (!RvStrcasecmp( attrNameTemp, attrName))
		{
            return rvSdpAttributeGetValue(attr);
		}
	}

    return NULL;
}
/***************************************************************************************/
