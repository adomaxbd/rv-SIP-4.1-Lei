/******************************************************************************
Filename:    rvMtfImsApi.h
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_MTF_IMS_API_H
#define RV_MTF_IMS_API_H

#ifdef RV_SIP_IMS_ON

#include "rvMtfHandles.h"
#include "rvMtfImsTypes.h"

#if defined(__cplusplus)
extern "C" {
#endif

/*@*****************************************************************************
 * rvMtfRegisterImsCallbacks (RvMtfImsPackage)
 * -----------------------------------------------------------------------------
 * General:
 *         Registers IMS callbacks to the MTF. This function should be called
 *         after rvMtfSipConstruct() is called.
 *
 * Arguments:
 * Input:  mtfHandle  - Handle to the MTF.
 *         imsClbks   - Pointer to the structure that contains IMS callbacks.
 *
 * Return Value: None.
 ****************************************************************************@*/
RVAPI void RVCALLCONV rvMtfRegisterImsCallbacks(
												IN RvMtfHandle		    hMtf,
												IN RvMtfImsClbks*		imsClbks);

#if defined(__cplusplus)
}
#endif

#endif  /* RV_SIP_IMS_ON */

#endif /* RV_MTF_IMS_API_H */
