/******************************************************************************
Filename:    rvMtfImsTypes.h
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_MTF_IMS_TYPES_H
#define RV_MTF_IMS_TYPES_H

#ifdef RV_SIP_IMS_ON
#include "ipp_inc_std.h"
#include "rvMtfHandles.h"
#include "rverror.h"
#include "RvSipStackTypes.h"
#include "rvMtfImsApi.h"

/*@*****************************************************************************
* Package: RvMtfImsPackage (root)
* -----------------------------------------------------------------------------
* Title: IMS MTF Add-on
*
* General: This package contains all type definitions and prototypes required 
*          for working with the IMS MTF Add-on.
****************************************************************************@*/

/*-----------------------------------------------------------------*/
/*							PROTOTYPES							   */
/*-----------------------------------------------------------------*/
/*@*****************************************************************************
* Enum: RvMtfSecAgreeReason (RvMtfImsPackage)
* -----------------------------------------------------------------------------
* This enumeration contains possible reasons for calling the sec-agree callback.
 ****************************************************************************@*/
typedef enum
{
	RV_MTF_SEC_AGREE_INIT_FAILED,
		/* Security agreement object was not initialized. */
		/* Possible reasons: object could not be created, its fields could
		   not be set. */
		RV_MTF_SEC_AGREE_CHOOSE_FAILED,
		/* Security mechanism was not chosen successfully. */
		/* Possible reasons: no list returned from the server, no match
		   to the server's list. */
		RV_MTF_SEC_AGREE_SUCCESS
		/* Security agreement object was initiated and mechanism was chosen. */
} RvMtfSecAgreeReason;

/*@*****************************************************************************
*  RvMtfSecAgreeNegCompleted (RvMtfImsPackage)
* -----------------------------------------------------------------------------
* General: The MTF calls this callback to update the application with the
*		   results of the security agreement selection.
*
*  Arguments:
*  Input:		 hTerm			- Handle to the terminal.
*				 hAppTerm		- Handle to the application data associated
*								  with the terminal.
*				 success		- Indication if the selection was successful.
*				 reason			- Reason of possible failure.
*				 chosenSecurity - The chosen security mechanism.
*
*  Return Value: None.
****************************************************************@*/
typedef void (RVCALLCONV *RvMtfSecAgreeNegCompleted)(
			   IN RvIppTerminalHandle			hTerm,
			   IN RvMtfTerminalAppHandle		hAppTerm,
			   IN RvBool						success,
			   IN RvMtfSecAgreeReason			reason,
			   IN RvSipSecurityMechanismType	chosenSecurity);

/*@*****************************************************************************
 * Type: RvMtfImsClbks (RvMtfImsPackage)
 * -----------------------------------------------------------------------------
 * Description: This structure includes IMS callbacks.
 ****************************************************************************@*/
typedef struct
{
	RvMtfSecAgreeNegCompleted	secAgreeNegCompletedEv;
}RvMtfImsClbks;

/*@*****************************************************************************
 * Type: RvImsSipPhoneCfg (RvMtfImsPackage)
 * -----------------------------------------------------------------------------
 * Description: This structure contains the IMS fields that are part of the
 *              RvIppSipPhoneCfg structure.
 ****************************************************************************@*/
typedef struct {
	RvBool				disableSecAgree;
	/* Indication if the security agreement feature is disabled. If set to
	   rvTrue, no requests to start the security agreement will be sent. */

	RvChar             PAccessNetworkInfo[RV_SHORT_STR_SZ];
	/* Pointer to the text of the P-Access-Network-Info header that will be
	   included in Register messages. Possible values of this parameter
	   are defined in the document 3GPP TS 24.229.
	   For example: "3GPP-UTRAN-TDD;utran-cell-id-3gpp=C359A3913B20E". */

	RvUint32			ipsecPortC;
	/* The port number used as the client port for the IPSec connection.
	   Relevant only if RV_SIP_IPSEC_NEG_ONLY is on. If RV_SIP_IPSEC_NEG_ONLY
	   is off, the IPSec Stack will select the port number randomly. */

	RvUint32			ipsecPortS;
	/* The port number used as the server port for the IPSec connection.
	   Relevant only if RV_SIP_IPSEC_NEG_ONLY is on. If RV_SIP_IPSEC_NEG_ONLY
	   is off, the IPSec Stack will select the port number randomly. */

	RvUint32			ipsecSpiRangeStart;
	/* The beginning of the range for the IPSec SPI (Security Parameters Index)
	   values. */

	RvUint32			ipsecSpiRangeEnd;
	/* The end of the range for the IPSec SPI (Security Parameters Index)
	   values. */

} RvImsSipPhoneCfg;

#endif /* RV_SIP_IMS_ON */

#endif /* RV_MTF_IMS_TYPES_H */
