/******************************************************************************
Filename   : ipptimer.c
Description: Implements Mdm Connection Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:	 23.02.05$
$Author: Assi Weinberger$
******************************************************************************/
#define LOGSRC	LOGSRC_UTIL
#include "ipp_inc_std.h"
#include "rvthread.h"



/***************************************************************************
 * IppThreadSleep
 * ------------------------------------------------------------------------
 * General: Suspends the current thread for the requested amount of time.
 *          
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	sec		-  second 
 *			msec	-  milli second
 *
 *			example -  sec=1,msec=50 the time will be 1 sec and 50 milli second
 ***************************************************************************/
RVAPI RvStatus IppThreadSleep(IN RvInt32 sec,
						IN RvInt32 msec)
{
	RvTime		tSleep;
	RvStatus	status = RV_OK;
	
	memset(&tSleep, 0, sizeof(tSleep));
	
	tSleep.sec  = sec;
	tSleep.nsec = msec*1000000;	
	
	status = RvThreadSleep(&tSleep, IppLogMgr ());

	if(status!=RV_OK)
	{
		RvLogError(ippLogSource, (ippLogSource,  "RvThreadSleep failed error = %d",status));
	}
	
	return status;
}

