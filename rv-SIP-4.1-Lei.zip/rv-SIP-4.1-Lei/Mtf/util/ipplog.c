/***********************************************************************
        Copyright (c) 2003 RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Ltd.. No part of this document may be reproduced in any
form whatsoever without written prior approval by RADVISION Ltd..

RADVISION Ltd. reserve the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
***********************************************************************/
#include "ipp_inc_std.h"
#include "rvloglistener.h"
#include "rvthread.h"
#include "ipplog.h"


#if (RV_LOGMASK != RV_LOGLEVEL_NONE)

/*
 *  Access to LogMgr.
 */
static RvLogListener    g_logListener;
static RvThread         g_th;
static RvBool           bLogInitialized = RV_FALSE;
static RvLogMgr*        g_logMgr = NULL;


/*
 *  logSrcTable (note: each name is limited to 11 letters!)
 */
RvLogSource             _logSrc[LOGSRC_NUMBER];
IppLogSourceElm         logSrcTable[LOGSRC_NUMBER] =
{
    {&_logSrc[LOGSRC_USERAPP    ], "IPP_USERAPP"},
    {&_logSrc[LOGSRC_CALLCONTROL], "IPP_CALLCON"},
    {&_logSrc[LOGSRC_MDM        ], "IPP_MDM"},
    {&_logSrc[LOGSRC_MDMCONTROL ], "IPP_MDMCONT"},
    {&_logSrc[LOGSRC_SIPCONTROL ], "IPP_SIPCONT"},
    {&_logSrc[LOGSRC_H323CONTROL], "IPP_H323CON"},
    {&_logSrc[LOGSRC_VIDEOPHONE ], "IPP_VIDEO"},
    {&_logSrc[LOGSRC_UTIL       ], "IPP_UTIL"},
    {&_logSrc[LOGSRC_RPOOL      ], "RPOOL"},
    {&_logSrc[LOGSRC_RA         ], "RA"},
    {&_logSrc[LOGSRC_CODEC      ], "IPP_CODEC"},
	{&_logSrc[LOGSRC_BASE       ], "MTF_BASE"},
	{&_logSrc[LOGSRC_IMS        ], "IPP_IMS"}

};


/***********************************************************/
/*
 *  filters for logSources used both by sip and by ipp (common core included)
 */
static void logSetFilters(IN IppLogSourceFilterElm* ippFilters)
{
    RvLogSource source;
    int i;

    /*
     *  do nothing for sip
     */

    for (i=0; ippFilters[i].logSrcName[0] !='\0'; i++)
    {
        if (RvLogGetSourceByName(g_logMgr, ippFilters[i].logSrcName, &source) == RV_OK)
            RvLogSourceSetMask(&source, ippFilters[i].messageMask);
    }
}

/* sample code for registering a callback function
static void RVCALLCONV rvIppMsgPrintListener(
    IN RvLogRecord* logRecord,
    IN void*        userData)
{

    RvChar* buf;

printf("@@->>>>>@@@@@@%s\n", logFormatMessage(logRecord, NULL));
}
*/


RVAPI RvLogMgr* IppLogMgr(void)
{
    return g_logMgr;
}

/******************************************************************************
 * IppLogInit
 * ----------------------------------------------------------------------------
 * General:
 *  Initialize the MTF's logging.
 *  This function should be called once, during the construction of an MTF
 *  instance.
 *
 * Arguments:
 * Input:  ippFilters   - An array of log filters to include in the log file.
 *                        The array must end with an element that has an empty
 *                        name for its log source.
 * Output: None.
 *
 * Return Value: RV_OK on success, other on failure.
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV IppLogInit(
    IN IppLogSourceFilterElm*   ippFilters,
    IN const RvChar*            szLogFileName)
{
    RvStatus status;
    int i;

    if (bLogInitialized)
    {
        return RV_OK;
    }

    status = RvMemoryAlloc(NULL, sizeof(*g_logMgr), NULL, (void**)&g_logMgr);
    if (status != RV_OK)
    {
        g_logMgr = NULL;
        return status;
    }

    status = RvLogConstruct(g_logMgr);
    if (status != RV_OK)
    {
        RvMemoryFree(g_logMgr, NULL);
        g_logMgr = NULL;
        return status;
    }

    RvThreadConstructFromUserThread(g_logMgr, &g_th);
    RvThreadSetName(&g_th,"MTF_LOG");

    for (i = 0; (i < (int)LOGSRC_NUMBER) && (status == RV_OK); i++)
        status = RvLogSourceConstruct(g_logMgr, logSrcTable[i].logSrc, logSrcTable[i].logSrcName, logSrcTable[i].logSrcName);

    /*
     *  construct listeners
     */

    /*
     *  terminal
     */
#if (RV_LOGLISTENER_TYPE == RV_LOGLISTENER_TERMINAL) ||(RV_LOGLISTENER_TYPE == RV_LOGLISTENER_FILE_AND_TERMINAL)||(RV_LOGLISTENER_TYPE == RV_LOGLISTENER_WIN32)
    if (status == RV_OK)
        status = RvLogListenerConstructTerminal(&g_logListener, g_logMgr, RV_TRUE);
#endif

#if (RV_LOGLISTENER_TYPE == RV_LOGLISTENER_FILE_AND_TERMINAL) ||(RV_LOGLISTENER_TYPE == RV_LOGLISTENER_WIN32)
    if (status == RV_OK)
        status = RvLogListenerConstructLogfile(&g_logListener, g_logMgr, szLogFileName, 1, 0, RV_TRUE);
#endif

    if (status == RV_OK)
    {
        /* ReSet masks to 0. Thus log only specified options */
        RvLogSetGlobalMask(g_logMgr, 0);

        logSetFilters(ippFilters);

        /* sample code for registering a user callback
        RvLogRegisterListener(IppLogMgr(), rvIppMsgPrintListener, NULL);
        */

        bLogInitialized = RV_TRUE;
    }
    else
    {
        RvLogDestruct(g_logMgr);
        RvMemoryFree(g_logMgr, NULL);
        g_logMgr = NULL;
    }

    return status;
}

/******************************************************************************
 * IppLogEnd
 * ----------------------------------------------------------------------------
 * General:
 *  Ends the use of the log in the MTF.
 *  This function must be called last, after the MTF has been terminated.
 * Arguments:
 * Input:  None
 * Output: None.
 *
 * Return Value: RV_OK on success, other on failure.
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV IppLogEnd(void)
{
    int         i;
    RvStatus    status = RV_OK;

    if (!bLogInitialized)
        return RV_ERROR_UNINITIALIZED;

	/* Threads which have made RvThreadConstructFromUserThread() call must call
	   RvThreadDestruct before exiting */
	RvThreadDestruct(&g_th);
    for (i = 0; i < (int)LOGSRC_NUMBER; i++)
    {
        RvLogSourceDestruct(logSrcTable[i].logSrc);
    }

    status = RvLogDestruct(g_logMgr);
    RvMemoryFree(g_logMgr, NULL);

    g_logMgr = NULL;
    bLogInitialized = RV_FALSE;

    return status;
}

/******************************************************************************
 * IppLogReload
 * ----------------------------------------------------------------------------
 * General:
 *  Reset the log sources that are used for logging.
 *  This function cannot be called before IppLogInit() is called.
 *
 * Arguments:
 * Input:  ippFilters   - An array of log filters to include in the log file.
 *                        The array must end with an element that has an empty
 *                        name for its log source.
 * Output: None.
 *
 * Return Value: RV_OK on success, other on failure.
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV IppLogReload(IN IppLogSourceFilterElm* ippFilters)
{
    RvLogSetGlobalMask(g_logMgr, 0);
    logSetFilters(ippFilters);

    return RV_OK;
}

/******************************************************************************
 * IppLogMessage
 * ----------------------------------------------------------------------------
 * General:
 *  Print a message into the MTF's log.
 *  The message will be printed under the IPP_USERAPP source.
 * Arguments:
 * Input:  isError  - RV_TRUE for an error message, RV_FALSE for an information
 *                    message.
 *         message  - The message itself. This string is handled in the same
 *                    manner of the ANSI C printf() function.
 * Output: None.
 *
 * Return Value: None.
 *****************************************************************************/
RVAPI void RVCALLCONV IppLogMessage(
    IN RvBool               isError,
    IN const RvChar*        message, ...)
{
    RvLogMessageType mType;

    if (isError)
        mType = RV_LOGLEVEL_ERROR;
    else
        mType = RV_LOGLEVEL_INFO;

    if (RvLogIsSelected(&_logSrc[LOGSRC_USERAPP], mType))
    {
        RvChar buf[1024];
        va_list v;
        va_start(v, message);
        RvVsnprintf(buf, sizeof(buf), message, v);
        buf[sizeof(buf)-1] = '\0';

        if (isError)
        {
            RvLogTextError(&_logSrc[LOGSRC_USERAPP], "%s", buf);
        }
        else
        {
            RvLogTextInfo(&_logSrc[LOGSRC_USERAPP], "%s", buf);
        }
    }
}

#else /* if (RV_LOGMASK != RV_LOGLEVEL_NONE) */
/*************************************************************************/
/* The following functions are invoked when working in a NOLOG mode      */
/*************************************************************************/

RVAPI RvLogMgr* IppLogMgr(void)
{
    return NULL;
}


RVAPI RvStatus RVCALLCONV IppLogInit(
    IN IppLogSourceFilterElm*   ippFilters,
    IN const RvChar*            szLogFileName)
{
    RV_UNUSED_ARG(ippFilters);
    RV_UNUSED_ARG(szLogFileName);

    return RV_OK;
}

RVAPI RvStatus RVCALLCONV IppLogEnd(void)
{
    return RV_OK;
}

RVAPI RvStatus RVCALLCONV IppLogReload(IN IppLogSourceFilterElm* ippFilters)
{
    RV_UNUSED_ARG(ippFilters);
    return RV_OK;
}

RVAPI void RVCALLCONV IppLogMessage(
                                    IN RvBool               isError,
                                    IN const RvChar*        message, ...)
{
    RV_UNUSED_ARG(isError);
    RV_UNUSED_ARG(message);
}
#endif /* if (RV_LOGMASK != RV_LOGLEVEL_NONE) */

#ifdef __cplusplus
}
#endif
