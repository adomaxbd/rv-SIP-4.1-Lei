/***********************************************************************
        Copyright (c) 2003 RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Ltd.. No part of this document may be reproduced in any
form whatsoever without written prior approval by RADVISION Ltd..

RADVISION Ltd. reserve the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
***********************************************************************/
#define LOGSRC	LOGSRC_UTIL
#include "ipp_inc_std.h"
#include "ippmisc.h"
#include "rvselect.h"

#include "rvccapi.h"
#include "ippevexchange.h"
#include "rvccprovidermdm.h"
#include "basephone.h"

static RvMutex msglock;   /* Only allow one message at a time. */
static RvSocket recvsock; /* Socket that will receive commands. */
static RvSocket sendsock; /* Socket to send commands (to receive socket). */
static RvAddress recvaddress; /* Address of receive socket. */
static RvSelectFd recvsockFd;
static RvSelectEngine*	engine;
static RvThread thread;
static RvBool initiated;


#define RV_PROTOCOLTHREAD_STACKSIZE 122880

static protocolConstruct* protocolConstructF[RV_MTF_PROTOCOL_NUM];
static void* protocolParam[RV_MTF_PROTOCOL_NUM];
static protocolConstruct* protocolDestructF[RV_MTF_PROTOCOL_NUM];

static RvSemaphore threadConstructed;


static void msgSocketCB (	
	IN RvSelectEngine*  selectEngine,
	IN RvSelectFd*      fd,
	IN RvSelectEvents   selectEvent,
	IN RvBool           error);

/* Call from thread where Seli callbacks will occur. */
static RvStatus createMsgSockets(void)
{
	RvAddress	localAddress;
	RvStatus	status;

    RvAddressConstructFromString("127.0.0.1", &localAddress);
	RvAddressSetIpPort(&localAddress, RV_ADDRESS_IPV4_ANYPORT);

	RvLogEnter(ippLogSource,(ippLogSource,  "<--createMsgSockets()"));
	status = RvSocketConstruct(localAddress.addrtype, RvSocketProtocolUdp, IppLogMgr (), &recvsock);
	if (RV_OK != status)
	{
		RvLogError(ippLogSource,(ippLogSource,"createMsgSockets(): cannot construct recvsock error %d",status));
		return status;
	}
	RvLogDebug(ippLogSource,(ippLogSource,"createMsgSockets(): recvsock(%d), AddrType(%d)",
        recvsock, localAddress.addrtype));

	if (localAddress.addrtype == RV_ADDRESS_TYPE_IPV4)
	{
		char szAddr[RV_ADDRESS_IPV4_STRINGSIZE];
		RvAddressIpv4ToString(szAddr, sizeof(szAddr), RvAddressIpv4GetIp( RvAddressGetIpv4(&localAddress)));
		RvLogDebug(ippLogSource,(ippLogSource,"createMsgSockets(): recvsock(%d), Addr(%s)",recvsock,szAddr));
	}
#if (RV_NET_TYPE & RV_NET_IPV6)
	else
		if(localAddress.addrtype == RV_ADDRESS_TYPE_IPV6)
		{
			char szAddr[RV_ADDRESS_IPV6_STRINGSIZE];
			RvAddressIpv6ToString( szAddr, sizeof(szAddr) , RvAddressIpv6GetIp( RvAddressGetIpv6(&localAddress)));
			RvLogDebug(ippLogSource,(ippLogSource,"createMsgSockets(): recvsock(%d), Addr(%s)",recvsock,szAddr));
		}	
#endif 	
		
	status = RvSocketConstruct(localAddress.addrtype, RvSocketProtocolUdp, IppLogMgr (), &sendsock);
	if (RV_OK != status)
	{
		RvLogError(ippLogSource,(ippLogSource,"createMsgSockets(): cannot construct sendsock"));
		return status;
	}
	RvLogDebug(ippLogSource,(ippLogSource,"createMsgSockets(): sendsock(%d), AddrType(%d)",sendsock,localAddress.addrtype));
	status = RvAddressConstructCopy(&localAddress, &recvaddress);
	
	status = RvSocketSetBlocking(&recvsock, RV_FALSE, IppLogMgr ());
	if(status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"createMsgSockets::set socket to non blocking fail error =%d",status));
	}

	status = RvSocketBind( &recvsock, &recvaddress, NULL, IppLogMgr ());
	if(RV_OK !=	status)
	{
		RvLogError(ippLogSource,(ippLogSource,"createMsgSockets(): cannot bind to recvsock"));
	}
	RvAddressDestruct(  &recvsock);
	/*
	 *	store socket local address in  recvaddress  
	 */
	RvSocketGetLocalAddress(  &recvsock, IppLogMgr(), &recvaddress);
	
	status = RvAddressConstructCopy(&recvaddress,&localAddress); 
	RvAddressSetIpPort(&localAddress,RV_ADDRESS_IPV4_ANYPORT);		
	
	if(RV_OK !=	RvSocketBind( &sendsock, &localAddress, NULL, IppLogMgr ()))
	{
		RvLogError(ippLogSource,(ippLogSource,"createMsgSockets(): cannot bind to sendsock"));
	}
	RvAddressDestruct(&localAddress);
	

	status = RvMutexConstruct( IppLogMgr(), &msglock);
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvMutexConstruct: error = %d",status));
	}	
	
	status = RvFdConstruct(&recvsockFd, &recvsock, IppLogMgr ());
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvFdConstruct: error = %d",status));
	}

	status = RvSelectGetThreadEngine( IppLogMgr (), &engine);
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvSelectGetThreadEngine: error = %d",status));
	}
	status = RvSelectAdd(engine, &recvsockFd, RvSelectRead, msgSocketCB);
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvSelectAdd: error = %d",status));
	}
	
	RvLogLeave(ippLogSource,(ippLogSource,  "-->createMsgSockets %d",status));
	return status;
}

static void destroyMsgSockets(void)
{
	RvStatus status;
	status = RvSelectRemove(engine, &recvsockFd);
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvSelectRemove: error = %d",status));
	}
	
	status = RvSocketDestruct(&sendsock, RV_FALSE, NULL, IppLogMgr ());
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvSocketDestruct: error = %d",status));
	}
	
	status = RvSocketDestruct(&recvsock, RV_FALSE, NULL, IppLogMgr ());
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvSocketDestruct: error = %d",status));
	}
	
	RvAddressDestruct(&recvaddress);
	status = RvMutexDestruct(&msglock,IppLogMgr());
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvMutexDestruct: error = %d",status));
	}
}


static void msgSocketCB (
										IN RvSelectEngine*  selectEngine,
										IN RvSelectFd*      fd,
										IN RvSelectEvents   selectEvent,
										IN RvBool           error)

{
	RvStatus rc;
	void*       data;
	RvAddress fromAddr;
	RvSize_t   bytesRcvd;
	
	RV_UNUSED_ARG(fd);
	RV_UNUSED_ARG(selectEngine);

	RvLogEnter(ippLogSource,(ippLogSource,  "<--msgSocketCB()"));
	if(error || (selectEvent != RvSelectRead))
	{
		RvLogError(ippLogSource,(ippLogSource,"Message socket event error or mismatch,error:%d, sEvent:%d",error,selectEvent ));
		return;
	}
	
	rc = RvSocketReceiveBuffer( &recvsock, (RvUint8*)&data,sizeof(data),IppLogMgr (),&bytesRcvd, &fromAddr);
	if((rc != RV_OK)|| (bytesRcvd !=sizeof(data)))
	{
		RvLogError(ippLogSource,(ippLogSource,"No data on message socket or socket closed." ));
		return;
	}

	if ((RvSize_t)data<RV_MTF_PROTOCOL_NUM)
		protocolConstructF[(RvSize_t)data](protocolParam[(RvSize_t)data]);
	else
		rvCCProviderMdmProcessTerminationEvent(data);
		
	RvLogLeave(ippLogSource,(ippLogSource,  "-->msgSocketCB"));
}
/*-------------------------------------------------------------------------------------*/
RvStatus sendEventToMsgSocket(IN void* data)
{
	RvSize_t    bytesSent;
	RvStatus    rc;

	RvLogEnter(ippLogSource,(ippLogSource,  "<--sendEventToMsgSocket(data(%s) )",(RvUint8*)&data));

	rc = RvSocketSendBuffer( &sendsock, (RvUint8*)&data, sizeof(data), &recvaddress, IppLogMgr(), &bytesSent);
	if (rc != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,  "SipMgr::Failed to Send Event to Socket"));
	}

	RvLogLeave(ippLogSource,(ippLogSource,  "-->sendEventToMsgSocket rc(%d)",rc));
	return rc;
}
/*-----------------------------------------------------*/


static void protocolThread(IN RvThread* t, IN void* data)
{
    RvStatus status;
	int protocol;

    RV_UNUSED_ARG(t);
    RV_UNUSED_ARG(data);
    /******
            Initialization
     ******/
    IppTimerInit();

	/*
     *  store Select engine pointer
     */
    status = RvSelectGetThreadEngine(IppLogMgr(), &engine);
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Application failed in RvSelectGetThreadEngine()"));
        engine = NULL;
    }

/*    rvSipStackStarted = 1;  ?????? */

    status = createMsgSockets();
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,  "Unable to create messages socket for MTF events"));
    }    
	RvSemaphorePost(&threadConstructed, IppLogMgr());


    /******
            Execution
     ******/
    {
        RvUint64 timeout = RvUint64Const(1000000, 0);

        /* Here we run the MTF until we decide otherwise */
        while (initiated)
        {
            if (status == RV_OK)
                status = RvSelectWaitAndBlock(engine, timeout);
        }
    }

   /******
            Destruction
     ******/
	for (protocol=0;protocol<RV_MTF_PROTOCOL_NUM;protocol++)
		if (protocolDestructF[protocol])
		{
			protocolDestructF[protocol](protocolParam[protocol]);
		}
    IppTimerEnd();
}



RvBool ProtocolThreadConstruct(int priority, protocolConstruct pcf, protocolDestruct pdf,void* param, int protocol)
{
	RvStatus rc;

	if (!initiated)
	{
		RvSemaphoreConstruct(0,IppLogMgr(),&threadConstructed);
		rc = RvThreadConstruct(protocolThread, NULL, IppLogMgr(), &thread);
		if(rc !=RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource,"ProtocolThreadConstruct(). Failed in RvThreadConstruct()"));
			return RV_FALSE;
		}

		rc = RvThreadSetPriority(&thread, priority);
		if(rc !=RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource,"ProtocolThreadConstruct(). Failed in RvThreadSetPriority()"));
			RvThreadDestruct(&thread);
			return RV_FALSE;
		}

		rc = RvThreadSetStack(&thread, NULL, RV_PROTOCOLTHREAD_STACKSIZE);
		if(rc !=RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource,"ProtocolThreadConstruct(). Failed in RvThreadSetStack()"));
			RvThreadDestruct(&thread);
			return RV_FALSE;
		}
		RvThreadSetName(&thread,"MTF_PRT");
		RvThreadCreate(&thread);
		initiated++;
		RvThreadStart(&thread);

		/*Wait until the stack thread constructed the stack*/
		RvSemaphoreWait(&threadConstructed, IppLogMgr());
	}
	else
		initiated++;
	protocolConstructF[protocol]=pcf;
	protocolDestructF[protocol]=pdf;
	protocolParam[protocol]=param;
	sendEventToMsgSocket((void*)protocol);
	return RV_TRUE;
}

RvBool ProtocolThreadStop(void)
{
	if (initiated == 1)
	{
		destroyMsgSockets();
	}
	initiated--;
	if (initiated==0)
	{
		if (RV_OK == RvSelectStopWaiting(engine, 0, IppLogMgr()))
		{
			/* This should be called after RvSipStackDestruct(). However, there is no
			   need for Semaphore since RvThreadDestruct() waits for internal semaphore
			   declaring thread exit*/
			RvSemaphoreDestruct(&threadConstructed,IppLogMgr());
			RvThreadDestruct(&thread);
			return RV_TRUE;
		}
		else
		{
			RvLogError(ippLogSource,(ippLogSource,"Failed in ProtocolThreadStop()"));
		}
	}
	return RV_FALSE;
}

