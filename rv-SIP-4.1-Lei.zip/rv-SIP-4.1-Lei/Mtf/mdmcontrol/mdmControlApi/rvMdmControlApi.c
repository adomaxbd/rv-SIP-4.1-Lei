/******************************************************************************
Filename   : rvMdmControlApi.c
Description: MDM Control APIs
******************************************************************************
                Copyright (c) 2004 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvmdm.h"
#include "rvMdmControlApi.h"
#include "rvmdmtermevent.h"
#include "mdmControlInt.h"
#include "rvccprovidermdm.h"
#include "rvccterminalmdm.h"
#include "rvccconnmdm.h"
#include "rvcctext.h"


/**********************************************************************************
                    P R I V A T E       F U N C T I O N S
**********************************************************************************/

static RvBool getNetworkConnection(RvIppConnectionHandle connHndl, RvCCConnection** conn)
{
    RvCCConnType connType;

    if (connHndl == NULL)
        return rvFalse;

    connType = rvIppMdmConnGetType(connHndl);

    if (connType == RV_CCCONNTYPE_MDM)
        *conn = (RvCCConnection*)rvIppMdmConnGetConnectParty(connHndl);
    else
        *conn = (RvCCConnection*)connHndl;

    if (*conn == NULL)
        return rvFalse;
    else
        return rvTrue;
}


/**********************************************************************************
                    P R O V I D E R         A P I s
**********************************************************************************/

RVAPI RvUint32 RVCALLCONV rvIppMdmProviderGetDialToneDuration(
    IN RvIppProviderHandle providerHndl)
{
    RvCCProvider* p = (RvCCProvider*)providerHndl;
    RvUint32 rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmProviderGetDialToneDuration(providerHndl=%p)", providerHndl));

    rc = rvCCProviderMdmGetDialToneDuration(p);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmProviderGetDialToneDuration()=%d", rc));

    return rc;
}

RVAPI void* RVCALLCONV rvIppMdmProviderGetDisplayData(
    IN RvIppProviderHandle providerHndl)
{
    RvCCProvider* p = (RvCCProvider*)providerHndl;
    void*  rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmProviderGetDisplayData(providerHndl=%p)", providerHndl));

    rc = rvCCProviderMdmGetDisplayData(p);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmProviderGetDisplayData()=%p", rc));

    return rc;
}

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmProviderFindTerminalByTermId(
    IN RvIppProviderHandle  providerHndl,
    IN const RvChar*        termId)
{
    RvCCProvider* p = (RvCCProvider*)providerHndl;
    RvIppTerminalHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmProviderFindTerminalByTermId(providerHndl=%p,termId=%s)", providerHndl, termId));

    rc = (RvIppTerminalHandle)rvCCProviderFindTerminalByTermId(p, termId);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmProviderFindTerminalByTermId()=%p", rc));

    return rc;
}

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmProviderFindTerminalByAddress(
    IN RvIppProviderHandle  providerHndl,
    IN const RvChar*        address)
{
    RvCCProvider* p = (RvCCProvider*)providerHndl;
    RvIppTerminalHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmProviderFindTerminalByAddress(providerHndl=%p,address=%s)", providerHndl, address));

    rc = (RvIppTerminalHandle)rvCCProviderFindTerminalByAddress(p, address);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmProviderFindTerminalByAddress()=%p", rc));

    return rc;
}

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmProviderFindAnyTerminal(
    IN RvIppProviderHandle providerHndl)
{
    RvCCProvider* p = (RvCCProvider*)providerHndl;
    RvIppTerminalHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmProviderFindAnyTerminal(providerHndl=%p)", providerHndl));

    rc = (RvIppTerminalHandle)rvCCProviderMdmFindAnyTerminal(p);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmProviderFindAnyTerminal()=%p", rc));

    return rc;
}

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmProviderFindTerminalByNumber(
    IN RvIppProviderHandle  providerHndl,
    IN const RvChar*        phoneNumber)
{
    RvCCProvider* p = (RvCCProvider*)providerHndl;
    RvIppTerminalHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmProviderFindTerminalByNumber(providerHndl=%p,phoneNumber=%s)", providerHndl, phoneNumber));

    rc = (RvIppTerminalHandle)rvCCProviderMdmFindTerminalByNumber(p, phoneNumber);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmProviderFindTerminalByNumber()=%p", rc));

    return rc;
}


/**********************************************************************************
                    T E R M I N A L     A P I s
**********************************************************************************/

RVAPI RvIppProviderHandle RVCALLCONV rvIppMdmTerminalGetProvider(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvIppProviderHandle rc;
    RvCCTerminalMdm* term;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetProvider(terminalHndl=%p)", terminalHndl));

    term = rvCCTerminalMdmGetImpl(t);
    rc = (RvIppProviderHandle)rvCCTerminalMdmGetProvider(term);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetProvider()=%p", rc));

    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalGetId(
    IN    RvIppTerminalHandle   terminalHndl,
    INOUT RvChar*               termId,
    IN    RvSize_t              termIdLen)
{
    RvCCTerminal*       t = (RvCCTerminal*)terminalHndl;
    RvBool              rc = RV_FALSE;
    RvCCTerminalMdm*    term;
    const RvChar*       pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetId(terminalHndl=%p,termId=%p,termIdLen=%d)", terminalHndl, termId, termIdLen));

    if (t != NULL)
    {
        term = rvCCTerminalMdmGetImpl(t);
        if (term != NULL)
        {
            if (rvCCTerminalMdmGetId(term) != NULL)
            {
                strncpy(termId, rvCCTerminalMdmGetId(term), termIdLen-1);
                termId[termIdLen-1] = '\0';
                rc = RV_TRUE;
                pStr = termId;
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetId(termId=%s)=%d", pStr, rc));

    return rc;
}

RVAPI RvCCTerminalType RVCALLCONV rvIppMdmTerminalGetType(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal*       t = (RvCCTerminal*)terminalHndl;
    RvCCTerminalType    rc;
    RvCCTerminalMdm*    term;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetType(terminalHndl)=%p", terminalHndl));

    term = rvCCTerminalMdmGetImpl(t);
    rc = rvCCTerminalMdmGetType(term);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetType()=%s", rvCCTextTermType(rc)));

    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalGetLastEvent(
    IN    RvIppTerminalHandle   terminalHndl,
    INOUT RvMdmEvent*           event)
{
    RvCCTerminal*       t = (RvCCTerminal*)terminalHndl;
    RvBool              rc = RV_FALSE;
    RvCCTerminalMdm*    term;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetLastEvent(terminalHndl=%p,event=%p)", terminalHndl, event));

    term = rvCCTerminalMdmGetImpl(t);
    if (rvCCTerminalMdmGetLastEvent(term) != NULL)
    {
        memcpy(event, rvCCTerminalMdmGetLastEvent(term), sizeof(*event));
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetLastEvent()=%d", rc));

    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalGetMediaCaps(
    IN    RvIppTerminalHandle   terminalHndl,
    INOUT RvSdpMsg*             mediaCaps)
{
    RvCCTerminal*       t = (RvCCTerminal*)terminalHndl;
    RvBool              rc = RV_FALSE;
    RvCCTerminalMdm*    term;
    const RvSdpMsg*     sdpMsg;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMediaCaps(terminalHndl=%p,mediaCaps=%p)", terminalHndl, mediaCaps));

    term = rvCCTerminalMdmGetImpl(t);
    sdpMsg = rvCCTerminalMdmGetMediaCaps(term);
    if (sdpMsg != NULL)
    {
        memcpy(mediaCaps, sdpMsg, sizeof(*mediaCaps));
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMediaCaps()=%d", rc));

    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalGetMediaStream(
    IN    RvIppTerminalHandle       terminalHndl,
    IN    RvUint32                  mediaStreamId,
    INOUT RvMdmMediaStreamInfo*     mediaStream)
{
    RvCCTerminal*           t = (RvCCTerminal*)terminalHndl;
    RvMdmMediaStreamInfo*   streamInfo;
    RvBool                  rc = RV_FALSE;
    RvCCTerminalMdm*        term;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMediaStream(terminalHndl=%p,mediaStreamId=%d,mediaStream=%p)", terminalHndl, mediaStreamId, mediaStream));

    term = rvCCTerminalMdmGetImpl(t);
    streamInfo = rvCCTerminalMdmGetMediaStream(term, mediaStreamId);
    if (streamInfo != NULL)
    {
        memcpy(mediaStream, streamInfo, sizeof(*mediaStream));
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMediaStream()=%d, ", rc));

    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalIsFirstDigit(IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalIsFirstDigit(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmIsFirstDigit(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalIsFirstDigit()=%d", rc));
    return rc;
}

RVAPI RvChar RVCALLCONV rvIppMdmTerminalGetLastDigit(IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvChar rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetLastDigit(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmGetLastDigit(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetLastDigit()=%c", rc));
    return rc;
}

RVAPI void RVCALLCONV rvIppMdmTerminalResetDialString(IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalResetDialString(terminalHndl=%p)", terminalHndl));
    rvCCTerminalMdmResetDialString(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalResetDialString()"));
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalIsOutOfBandDtmfEnabled(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalIsOutOfBandDtmfEnabled(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmIsOutOfBandDtmfEnabled(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalIsOutOfBandDtmfEnabled()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalIsDtmfPlayEnabled(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalIsDtmfPlayEnabled(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmIsDtmfPlayEnabled(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalIsDtmfPlayEnabled()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalGetPhoneNumber(
    IN    RvIppTerminalHandle   terminalHndl,
    INOUT RvChar*               phoneNumber,
    IN    RvSize_t              phoneNumberLen)
{
    RvCCTerminal*   t = (RvCCTerminal*)terminalHndl;
    RvBool          rc = RV_FALSE;
    const RvChar*   number;
    const RvChar*   pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetPhoneNumber(terminalHndl=%p,phone=%p,len=%d",
        terminalHndl, phoneNumber, phoneNumberLen));

    number = rvCCTerminalMdmGetPhoneNumber(t);
    if (number != NULL)
    {
        strncpy(phoneNumber, number, phoneNumberLen-1);
        phoneNumber[phoneNumberLen-1] = '\0';
        pStr = phoneNumber;
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetPhoneNumber(phone=%s)=%d", pStr, rc));
    return rc;
}


RVAPI RvCCTerminalAudioType RVCALLCONV rvIppMdmTerminalGetActiveAudioType(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvCCTerminalAudioType rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetActiveAudioType(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmGetActiveAudio(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetActiveAudioType()=%d", rc));
    return rc;
}

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmTerminalGetActiveAudioTerm(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvIppTerminalHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetActiveAudioType(terminalHndl=%p)", terminalHndl));
    rc = (RvIppTerminalHandle)rvCCTerminalMdmGetActiveAudioTerm(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetActiveAudioTerm()=%p", rc));
    return rc;
}

RVAPI void RVCALLCONV rvIppMdmTerminalStopSignals(IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStopSignals(terminalHndl=%p)", terminalHndl));
    rvCCTerminalMdmStopSignals(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStopSignals()"));
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartUserSignalUI(
    IN RvIppTerminalHandle  terminalHndl,
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmParameterList*  params)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartUserSignalUI(terminalHndl=%p,pkg=%s,id=%s,params=%p)", terminalHndl, pkg, id, params));
    rc = rvCCTerminalMdmStartSignalUI(t, pkg, id, params);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartUserSignalUI()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartUserSignalAT(
    IN RvIppTerminalHandle  terminalHndl,
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmParameterList*  params)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartUserSignalAT(terminalHndl=%p,pkg=%s,id=%s,params=%p)", terminalHndl, pkg, id, params));
    rc = rvCCTerminalMdmStartSignalAudio(t, pkg, id, params);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartUserSignalAT()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartDialToneSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartDialToneSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartDialToneSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartDialToneSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartRingingSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartRingingSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartRingingSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartRingingSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStopRingingSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStopRingingSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStopRingingSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStopRingingSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartRingbackSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartRingbackSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartRingbackSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartRingbackSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartCallWaitingSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartCallWaitingSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartCallWaitingSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartCallWaitingSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartCallWaitingCallerSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartCallWaitingCallerSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartCallWaitingCallerSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartCallWaitingCallerSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartBusySignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartBusySignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartBusySignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartBusySignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartWarningSignal(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartWarningSignal(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStartWarningSignal(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartWarningSignal()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStartDTMFTone(
    IN RvIppTerminalHandle  terminalHndl,
    IN RvChar               digit)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvDtmfParameters dtmfParam;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartDTMFTone(terminalHndl=%p,digit=%c)", terminalHndl, digit));
    rvDtmfParametersInit(&dtmfParam);
    dtmfParam.digit = digit;
    rc = rvCCTerminalMdmStartDTMFTone(t, 1, &dtmfParam);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStartDTMFTone()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalStopDTMFTone(
    IN RvIppTerminalHandle  terminalHndl,
    IN RvChar               digit)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RV_UNUSED_ARG(digit);

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalStopDTMFTone(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmStopDTMFTone(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalStopDTMFTone()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalSetHoldInd(
    IN RvIppTerminalHandle  terminalHndl,
    IN RvBool               on)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetHoldInd(terminalHndl=%p,on=%d)", terminalHndl, on));
    rc = rvCCTerminalMdmSetHoldInd(t, on);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetHoldInd()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalSetLineInd(
    IN RvIppTerminalHandle      terminalHndl,
    IN RvInt32                  lineId,
    IN RvCCTerminalIndState     state)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetLineInd(terminalHndl=%p,lineId=%d,state=%d)", terminalHndl, lineId, state));
    rc = rvCCTerminalMdmSetLineInd(t, lineId, state);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetLineInd()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalSendLineActive(
    IN RvIppTerminalHandle  terminalHndl,
    IN RvInt32              lineId,
    IN RvBool               active)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSendLineActive(terminalHndl=%p,lineId=%d,active=%d)", terminalHndl, lineId, active));
    rc = rvCCTerminalMdmSendLineActive(t, lineId, active);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSendLineActive()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalSetDisplay(
    IN RvIppTerminalHandle  terminalHndl,
    IN const RvChar*        text,
    IN RvInt32              row,
    IN RvInt32              column)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetDisplay(terminalHndl=%p,text=%s,row=%d,column=%d)", terminalHndl, text, row, column));
    rc = rvCCTerminalMdmSetDisplay(t, text, row, column);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetDisplay()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalClearDisplay(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalClearDisplay(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalMdmClearDisplay(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalClearDisplay()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalSendCallerId(
    IN RvIppTerminalHandle  terminalHndl,
    IN const RvChar*        callerName,
    IN const RvChar*        callerNumber,
    IN const RvChar*        address,
    IN const RvChar*        callerId)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvBool rc;

    // TODO: if any of the below strings can be NULL...
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSendCallerId(terminalHndl=%p,callerName=%s,callerNumber=%s,address=%s,callerId=%s)", terminalHndl, callerName, callerNumber, address, callerId));
    rc = rvCCTerminalMdmSendCallerId(t, callerName, callerNumber, address,callerId);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSendCallerId()=%d", rc));
    return rc;
}

RVAPI void RVCALLCONV rvIppMdmTerminalSetWaitForDigits(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetWaitForDigits(terminalHndl=%p)", terminalHndl));
    rvCCTerminalMdmSetWaitForDigits(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetWaitForDigits()"));
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalGetDialString(
    IN    RvIppTerminalHandle   terminalHndl,
    INOUT RvChar*               dialString,
    IN    RvSize_t              dialStringLen)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvChar* dial;
    const RvChar* pStr = "";
    RvBool rc = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetDialString(terminalHndl=%p,str=%p,len=%d", terminalHndl, dialString, dialStringLen));

    dial = rvCCTerminalMdmGetDialString(t);
    if ((dial != NULL) && (strcmp(dial, "")))
    {
        strncpy(dialString, dial, dialStringLen-1);
        dialString[dialStringLen-1] = '\0';
        pStr = dialString;
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetDialString(dial=%s)=%d", pStr, rc));
    return rc;
}

RVAPI RvInt32 RVCALLCONV rvIppMdmTerminalGetMaxConnections(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    int rc;
	
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMaxConnections(terminalHndl=%p)", terminalHndl));
    
#ifndef RV_MTF_N_LINES
	
    RV_UNUSED_ARG(t); /* leave argument as this might differ between terminations ? */
    /*lint -e{506}   although the below is constant it is better... */
    rc = ( (RV_CCTERMINALMDM_MAXCONNS > RV_CCTERMINAL_MAXCONNS) ?
RV_CCTERMINAL_MAXCONNS:RV_CCTERMINALMDM_MAXCONNS);
#else
	rc = rvCCTerminalGetNumberOfLines(t);
#endif /* RV_MTF_N_LINES */
	
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMaxConnections()=%d", rc));
    return (rc);
}

RVAPI RvInt32 RVCALLCONV rvIppMdmTerminalGetNumActiveConnections(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    int rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetNumActiveConnections(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalGetNumActiveConnections(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetNumActiveConnections()=%d", rc));
    return (rc);
}

RVAPI RvIppConnectionHandle RVCALLCONV rvIppMdmTerminalGetActiveConnection(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvIppConnectionHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetActiveConnection(terminalHndl=%p)", terminalHndl));
    rc = (RvIppConnectionHandle) rvCCTerminalGetActiveConnection(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetActiveConnection()=%p", rc));
    return (rc);
}

RVAPI RvInt32 RVCALLCONV rvIppMdmTerminalGetCurDisplayRow(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvInt32 rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetCurDisplayRow(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalGetCurDisplayRow(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetCurDisplayRow()=%d", rc));
    return (rc);
}

RVAPI RvInt32 RVCALLCONV rvIppMdmTerminalGetCurDisplayColumn(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvInt32 rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetCurDisplayColumn(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalGetCurDisplayColumn(t);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetCurDisplayColumn()=%d", rc));
    return (rc);
}

RVAPI RvBool RVCALLCONV rvIppMdmTerminalOtherHeldConnExist(
    IN RvIppTerminalHandle     terminalHndl,
    IN RvIppConnectionHandle   currConnHndl)
{
    RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalOtherHeldConnExist(terminalHndl=%p,currConnHndl=%p)", terminalHndl, currConnHndl));
    rc = rvCCTerminalMdmOtherHeldConnExist((RvCCTerminal*)terminalHndl,
                                             (RvCCConnection*) currConnHndl);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalOtherHeldConnExist()=%d", rc));
    return (rc);
}

RVAPI RvIppConnectionHandle rvIppMdmTerminalGetHeldConn(
    IN  RvIppTerminalHandle terminalHndl,
    OUT RvInt32*            lineId)
{
    RvCCTerminal* t= (RvCCTerminal*)terminalHndl;
    RvCCConnection* conn = NULL;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetHeldConn(terminalHndl=%p,lineId=%p)", terminalHndl, lineId));
    conn = rvCCTerminalMdmGetHoldingConn(t);
    if (conn != NULL)
        *lineId = rvCCConnectionGetLineId(conn);
    else
        *lineId = 0;

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetHeldConn(lineId=%d)=%p", *lineId, conn));
    return (RvIppConnectionHandle)conn;
}



RVAPI void RVCALLCONV rvIppMdmTerminalSetState(
    IN RvIppTerminalHandle  terminalHndl,
    IN RvCCTerminalState    state)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetState(terminalHndl=%p,state=%d)", terminalHndl, state));
    rvCCTerminalSetState((RvCCTerminal *)terminalHndl, state);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalSetState()"));
}



RVAPI RvCCTerminalState RVCALLCONV rvIppMdmTerminalGetState(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminalState rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetState(terminalHndl=%p)", terminalHndl));
    rc = rvCCTerminalGetState((RvCCTerminal *)terminalHndl);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetState()=%d", rc));
    return rc;
}


RVAPI RvMdmTerm* RVCALLCONV rvIppMdmTerminalGetMdmTerm(
    IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvCCTerminalMdm* term = NULL;
    RvMdmTerm* rc = NULL;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMdmTerm(terminalHndl=%p)", terminalHndl));
    term = rvCCTerminalMdmGetImpl(t);
    rc = rvCCTerminalMdmGetMdmTerm(term);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetMdmTerm()=%p", rc));
    return rc;
}

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmTerminalGetHandle(
    IN RvMdmTerm* mdmTerm)
{
    RvIppTerminalHandle hndl = NULL;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetHandle(memTerm=%p)", mdmTerm));

    if (mdmTerm != NULL)
        hndl = (RvIppTerminalHandle)rvMdmTermGetXTerm_(mdmTerm);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmTerminalGetHandle()=%p", hndl));

    return hndl;
}

/******************************************************************************
*  rvMtfTerminalMakeCall()
*****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfTerminalMakeCall(
    IN RvIppTerminalHandle  terminalHndl,
    IN const RvChar*        address)
{
    RvMdmTerm*  mdmTerm;
    RvChar      limitedAddress[RV_MEDIUM_STR_SZ];
    RvStatus    status = RV_ERROR_INVALID_HANDLE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCall(terminalHndl=%p,address=%s)",
        terminalHndl, ((address != NULL) ? address : "NULL")));

    if ((terminalHndl != NULL) && (address != NULL))
    {
        mdmTerm = rvIppMdmTerminalGetMdmTerm(terminalHndl);

        strncpy(limitedAddress, address, sizeof(limitedAddress)-1);
        limitedAddress[sizeof(limitedAddress)-1] = '\0';

        rvMdmTermProcessEvent(mdmTerm, "makecall", limitedAddress, NULL, NULL);

        status = RV_OK;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminalMakeCall()=%d", status));

    return status;
}


/**********************************************************************************
                    C O N N E C T I O N     A P I s
**********************************************************************************/

RVAPI RvIppTerminalHandle RVCALLCONV rvIppMdmConnGetTerminal(
    IN RvIppConnectionHandle connHndl)
{
    RvIppTerminalHandle rc = NULL;
    RvCCConnection* c = (RvCCConnection*)connHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetTerminal(connHndl=%p)", connHndl));
    rc = (RvIppTerminalHandle)rvCCConnMdmGetTerminal(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetTerminal()=%p", rc));
    return rc;
}

RVAPI RvInt32 RVCALLCONV rvIppMdmConnGetLineId(
    IN RvIppConnectionHandle connHndl)
{
    RvInt32 rc;
    RvCCConnection* c = (RvCCConnection*)connHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetLineId(connHndl=%p)", connHndl));
    rc = rvCCConnectionGetLineId(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetLineId()=%d", rc));
    return rc;
}

RVAPI RvCCConnState RVCALLCONV rvIppMdmConnGetState(
    IN RvIppConnectionHandle connHndl)
{
    RvCCConnState rc;
    RvCCConnection* c = (RvCCConnection*)connHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetState(connHndl=%p)", connHndl));
    rc = rvCCConnectionGetState(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetState()=%s", rvCCTextConnState(rc)));
    return rc;
}

RVAPI RvCCTermConnState RVCALLCONV rvIppMdmConnGetTermState(
    IN RvIppConnectionHandle connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvCCTermConnState rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetTermState(connHndl=%p)", connHndl));
    rc = rvCCConnectionGetTermState(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetTermState()=%s", rvCCTextTermConnState(rc)));
    return rc;
}

RVAPI RvCCMediaState RVCALLCONV rvIppMdmConnGetMediaState(
    IN RvIppConnectionHandle connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvCCMediaState rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetMediaState(connHndl=%p)", connHndl));
    rc = rvCCConnectionGetMediaState(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetMediaState()=%s", rvCCTextMediaState(rc)));
    return rc;
}

RVAPI RvCCConnType RVCALLCONV rvIppMdmConnGetType(
    IN RvIppConnectionHandle connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvCCConnType rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetType(connHndl=%p)", connHndl));
    rc = rvCCConnectionGetType(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetType()=%d", rc));
    return rc;
}

RVAPI RvIppConnectionHandle RVCALLCONV rvIppMdmConnGetConnectParty(
    IN RvIppConnectionHandle connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvIppConnectionHandle rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetConnectParty(connHndl=%p)", connHndl));
    rc = (RvIppConnectionHandle)rvCCConnectionGetConnectParty(c);
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetConnectParty()=%p", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmConnGetLocalMedia(
    IN    RvIppConnectionHandle     connHndl,
    INOUT RvSdpMsg*                 localMedia)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvSdpMsg*       sdpMsg;
    RvBool          rc = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetLocalMedia(connHndl=%p,localMedia=%p)", connHndl, localMedia));

    sdpMsg = rvCCConnMdmGetMedia(c);
    if (sdpMsg != NULL)
    {
        memcpy(localMedia, sdpMsg, sizeof(*localMedia));
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetLocalMedia()=%d", rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmConnGetMediaCaps(
    IN    RvIppConnectionHandle connHndl,
    INOUT RvSdpMsg*             mediaCaps)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvSdpMsg*       sdpMsg;
    RvBool          rc = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetMediaCaps(connHndl=%p,mediaCaps=%p)", connHndl, mediaCaps));

    sdpMsg = rvCCConnMdmGetMediaCaps(c);
    if (sdpMsg != NULL)
    {
        memcpy(mediaCaps, sdpMsg, sizeof(*mediaCaps));
        rc = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetMediaCaps()=%d", rc));
    return rc;

}

RVAPI RvStatus RVCALLCONV rvIppMdmConnSetUserData(
    IN RvIppConnectionHandle    connHndl,
    IN void*                    userData)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvStatus status = RV_ERROR_BADPARAM;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnSetUserData(connHndl=%p,userData=%p)", connHndl, userData));

    if (c != NULL)
    {
        c->userData = userData;
		status = RV_OK;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnSetUserData()=%d", status));

    return status;
}

RVAPI void* RVCALLCONV rvIppMdmConnGetUserData(
    IN RvIppConnectionHandle connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    void *rc = NULL;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetUserData(connHndl=%p)", connHndl));

    if (c != NULL)
    {
        rc = c->userData;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetUserData()=%p", rc));

    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmConnGetCallerName(
    IN    RvIppConnectionHandle     connHndl,
    INOUT RvChar*                   callerName,
    IN    RvSize_t                  callerNameLen)
{
    RvCCConnection* c = NULL;
    RvBool rc = RV_FALSE;
    const RvChar* pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerName(connHndl=%p,name=%p,len=%d", connHndl, callerName, callerNameLen));

    if (callerName != NULL)
    {
        callerName[0] = '\0';
        if (getNetworkConnection(connHndl, &c) == RV_TRUE)
        {
            const RvChar* name = rvCCConnectionGetCallerName(c);
            if (name != NULL)
            {
                strncpy(callerName, name, callerNameLen-1);
                callerName[callerNameLen-1] = '\0';
                pStr = callerName;
                rc = RV_TRUE;
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerName(name=%s)=%d", pStr, rc));
    return rc;
}

RVAPI RvBool RVCALLCONV rvIppMdmConnGetCallerNumber(
    IN    RvIppConnectionHandle connHndl,
    INOUT RvChar*               callerNumber,
    IN    RvSize_t              callerNumberLen)
{
    RvCCConnection* c = NULL;
    RvCCConnType connType;
    RvBool rc = RV_FALSE;
    const RvChar* pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerNumber(connHndl=%p,number=%p,len=%d", connHndl, callerNumber, callerNumberLen));

    if (callerNumber != NULL)
    {
        callerNumber[0] = '\0';
        if (connHndl != NULL)
        {
            connType = rvIppMdmConnGetType(connHndl);

            if (connType != RV_CCCONNTYPE_NETWORK)
                c = (RvCCConnection*)rvIppMdmConnGetConnectParty(connHndl);
            else
                c = (RvCCConnection*)connHndl;

            if (c != NULL)
            {
                const RvChar *number = rvCCConnectionGetCallerNumber(c, 0);
                if (number != NULL)
                {
                    strncpy(callerNumber, number, callerNumberLen-1);
                    callerNumber[callerNumberLen-1] = '\0';
                    pStr = callerNumber;
                    return RV_TRUE;
                }
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerNumber(number=%s)=%d", pStr, rc));
    return rc;

}

RVAPI RvBool RVCALLCONV rvIppMdmConnGetCallerNumberByIndex(
    IN    RvIppConnectionHandle connHndl,
    INOUT RvChar*               callerNumber,
    IN    RvSize_t              callerNumberLen,
    IN    RvSize_t              index)
{
    RvCCConnection* c = NULL;
    RvBool rc = RV_FALSE;
    const RvChar* pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerNumberByIndex(connHndl=%p,number=%p,len=%d,index=%d)", connHndl, callerNumber, callerNumberLen, index));

    if (callerNumber != NULL)
    {
        callerNumber[0] = '\0';
        if (getNetworkConnection(connHndl, &c) == RV_TRUE)
        {
            const RvChar *number = rvCCConnectionGetCallerNumber(c, (int)index);
            if (number != NULL)
            {
                strncpy(callerNumber, number, callerNumberLen-1);
                callerNumber[callerNumberLen-1] = '\0';
                pStr = callerNumber;
                rc = RV_TRUE;
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerNumberByIndex(number=%s)=%d", pStr, rc));
    return rc;

}


RVAPI RvBool RVCALLCONV rvIppMdmConnGetCallerAddress(
    IN    RvIppConnectionHandle connHndl,
    INOUT RvChar*               callerAddress,
    IN    RvSize_t              callerAddressLen)
{
    RvCCConnection* c = NULL;
    RvBool rc = RV_FALSE;
    const RvChar* pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerAddress(connHndl=%p,address=%p,len=%d", connHndl, callerAddress, callerAddressLen));

    if (callerAddress != NULL)
    {
        callerAddress[0] = '\0';
        if (getNetworkConnection(connHndl, &c) == RV_TRUE)
        {
            const RvChar *address = rvCCConnectionGetCallerAddress(c);
            if (address != NULL)
            {
                strncpy(callerAddress, address, callerAddressLen-1);
                callerAddress[callerAddressLen-1] = '\0';
                pStr = callerAddress;
                return RV_TRUE;
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerAddress(address=%s)=%d", pStr, rc));
    return rc;

}

RVAPI RvBool RVCALLCONV rvIppMdmConnGetCallerId(
    IN    RvIppConnectionHandle     connHndl,
    INOUT RvChar*                   callerId,
    IN    RvSize_t                  callerIdLen)
{
    RvCCConnection* c = NULL;
    RvBool rc = RV_FALSE;
    const RvChar* pStr = "";

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerId(connHndl=%p,id=%p,len=%d", connHndl, callerId, callerIdLen));

    if (callerId != NULL)
    {
        callerId[0] = '\0';
        if (getNetworkConnection(connHndl, &c) == RV_TRUE)
        {
            const RvChar *id = rvCCConnectionGetCallerId(c);
            if (id != NULL)
            {
                strncpy(callerId, id, callerIdLen-1);
                callerId[callerIdLen-1] = '\0';
                pStr = callerId;
                return RV_TRUE;
            }
        }
    }
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallerId(id=%s)=%d", pStr, rc));
    return rc;

}

/******************************************************************************
*  rvIppMdmConnGetRemotePresentationInfo
*  -------------------------------------
*  General :        Get Presentation information (name and permission) of
*                   remote party. This information was retrieved from incoming messages.
*
*                   Note: implemented in H323 only!
*  Return Value:    True if Presentation information was returned successfully,
*                   False, if not.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           terminalHndl -      terminal Handle
*  Output:          presentationInfo -  a pointer to Presentation information object.
****************************************************************************/
RVAPI RvBool RVCALLCONV rvIppMdmConnGetRemotePresentationInfo(
    IN  RvIppConnectionHandle       connHndl,
    OUT RvMdmTermPresentationInfo*  presentationInfo)
{
    RvCCConnection* c = NULL;
    RvBool rc = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetRemotePresentationInfo(connHndl=%p,info=%p)", connHndl, presentationInfo));

    if (getNetworkConnection(connHndl, &c) == RV_TRUE)
    {
        RvMdmTermPresentationInfo*  info = rvCCConnectionGetRemotePresentationInfo(c);
        if (info != NULL)
        {
            rvMdmTermPresentationInfoCopy(presentationInfo, info);
            rc = RV_TRUE;
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetRemotePresentationInfo()=%d", rc));
    return rc;
}

/******************************************************************************
*  rvIppMdmConnGetCallState
*  -------------------------------------
*  General :        Get Call state of this Connection
*
*  Return Value:    Call state
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           connHndl -          connection Handle
*  Output:          None
****************************************************************************/
RVAPI RvCCCallState RVCALLCONV rvIppMdmConnGetCallState(
                                    IN RvIppConnectionHandle    connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvCCCall* call;
    RvCCCallState rc = RV_CCCALLSTATE_NORMAL;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallState(connHndl=%p)", connHndl));

    if (c == NULL)
        rc =  RV_CCCALLSTATE_NORMAL; /*Should return an error value*/
    else
    {
        call = rvCCConnectionGetCall(c);

        if (call != NULL)
            rc = (rvCCCallGetState(call));
    }
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmConnGetCallState()=%d", rc));
    return rc;
}

RVAPI void* RVCALLCONV rvIppMdmTerminalGetUserData ( IN RvIppTerminalHandle terminalHndl)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvCCTerminalMdm* term;
    RvMdmTerm* mdmTerm;
    void* userData;

    RvLogEnter(ippLogSource,(ippLogSource, " rvIppMdmTerminalGetUserData (terminalHndl=%p)", terminalHndl));
    term = rvCCTerminalMdmGetImpl(t);
    mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
    userData =  rvMdmTermGetUserData (mdmTerm);
    RvLogLeave(ippLogSource,(ippLogSource, " rvIppMdmTerminalGetUserData()=%p", userData));
    return userData;
}
RVAPI void RVCALLCONV rvIppMdmTerminalSetUserData (
                               IN RvIppTerminalHandle   terminalHndl,
                               IN void*                 userData)
{
    RvCCTerminal* t = (RvCCTerminal*)terminalHndl;
    RvCCTerminalMdm* term;
    RvMdmTerm* mdmTerm;

    RvLogEnter(ippLogSource,(ippLogSource, " rvIppMdmTerminalSetUserData (terminalHndl=%p, userData=%p)",
		terminalHndl, userData));
    term = rvCCTerminalMdmGetImpl(t);
    mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
    rvMdmTermSetUserData(mdmTerm, userData);
    RvLogLeave(ippLogSource,(ippLogSource, " rvIppMdmTerminalSetUserData()"));
}

/****************************************************************************
*  rvMtfGetLogMgr()
*****************************************************************************/
RVAPI void* RVCALLCONV rvMtfGetLogMgr()
{
    return IppLogMgr();
}

