/******************************************************************************
Filename   : rvccprovidermdm.c
Description: Implements Mdm Provider Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#define LOGSRC  LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "mdmControlInt.h"
#include "rvccprovidermdm.h"
#include "rvccterminalmdm.h"
#include "rvccconnmdm.h"
#include "rvmdmtermevent.h"
#include "rvcctext.h"
#include "rvccapi.h"
#include "rvmdm.h"
#include "rvcccall.h"
#include "basephone.h"
#include "rvsdpenc.h"
#include "ippcodec.h"
#include "rvIppCfwApi.h"

#ifdef RV_MTF_VIDEO
#include "rvccmdmvideo.h"
#endif


int rvMdmControlStarted=0;


/*===============================================================================*/
/*================== I N T E R N A L    F U N C T I O N S   =====================*/
/*===============================================================================*/

static void rvInitConnFuncs(RvCCProviderMdm* x)
{
    RvCCConnectionFuncs* funcs = &x->connFuncs;

    memset(funcs,0,sizeof(RvCCConnectionFuncs));
    funcs->ringbackF = rvCCConnMdmRingback;
    funcs->disconnectF = rvCCConnMdmDisconnecting;
    funcs->getMediaF = rvCCConnMdmGetMedia;
    funcs->getMediaCapsF = rvCCConnMdmGetMediaCaps;
    funcs->makeCallF = rvCCConnMdmMakeCall;
    funcs->rejectF = rvCCConnMdmReject;
    funcs->callAnsweredF = rvCCConnMdmCallAnswered;
    funcs->createMediaF = rvCCConnMdmCreateMedia;
    funcs->setRemoteMediaF = rvCCConnMdmSetRemoteMedia;
    funcs->setLocalMediaF = rvCCConnMdmSetLocalMedia;
    funcs->restartMediaF = rvCCConnMdmRestartMedia;
    funcs->addressAnalyzeF = rvCCConnMdmAddressAnalyze;
    funcs->releaseF = rvCCConnMdmRelease;
    funcs->processTermEventF = rvCCConnMdmProcessEvent;
    funcs->joinConferenceF = rvCCConnMdmJoinConference;
    funcs->leaveConferenceF = rvCCConnMdmLeaveConference;
    funcs->transferOfferedF = rvCCConnMdmTransferOffered;
    funcs->transferConnectedF = rvCCConnMdmTransferConnected;
    funcs->isTransferedConnF = rvCCConnMdmIsTransferedConn;
    funcs->getCallerNumberF = rvCCConnMdmGetCallerNumber;
    funcs->terminateF = rvCCConnMdmTerminate;
    funcs->modifyMediaF         = rvCCConnMdmModifyMedia;
    funcs->modifyMediaDoneF     = rvCCConnMdmModifyMediaDone;

    /* Termination connection */
    funcs->holdF = rvCCConnTermMdmHold;
    funcs->unholdF = rvCCConnTermMdmUnhold;
    funcs->disconnectMediaF = rvCCConnMdmDisconnectMedia;
    /* temporary:until invoking functions correctly handle error cases */
    funcs->connectMediaF = (RvCCConnectionTermConnectMediaF)rvCCConnMdmConnectMedia;
    funcs->remoteHoldF = rvCCConnTermMdmRemoteHold;
    funcs->remoteUnholdF = rvCCConnTermMdmRemoteUnhold;
    funcs->setHoldIndicatorF = rvCCConnTermMdmSetHoldIndicator;
    funcs->playDtmfF         = rvCCConnTermMdmPlayDtmf;
    funcs->setMuteIndicatorF = rvCCConnTermMdmSetMuteIndicator;
    funcs->muteF             = rvCCConnTermMdmMute;
    funcs->UnmuteF           = rvCCConnTermMdmUnmute;
    /* Display */
    funcs->displayF = rvCCConnMdmDisplay;
}

static void rvInitConnCallbacks(RvCCProviderMdm* x)
{
    RvCCConnectionClbks* clbks = &x->connClbks;

    memset(clbks,0,sizeof(RvCCConnectionClbks));
    clbks->initiatedCB =        rvCCConnMdmInitiatedCB;
    clbks->newDigitCB =         rvCCConnMdmNewDigitCB;
    clbks->callAnsweredCB =     rvCCConnMdmCallAnsweredCB;
    clbks->callDeliveredCB =    rvCCConnMdmCallDeliveredCB;
    clbks->offeredCB =          rvCCConnMdmOfferedCB;
    clbks->transferInProcessCB = rvCCCallTransferInProcessCB;
    clbks->conferenceJoinedCB = rvCCCallConferenceJoinedCB;
    clbks->transferOfferedCB =  rvCCConnMdmTransferOfferedCB;
    clbks->sendUserEventCB =    rvCCCallSendUserEventCB;
    clbks->mediaModifiedCB      =       rvCCCallModifyMediaCB;
    clbks->mediaModifiedDoneCB  =       rvCCCallModifyMediaDoneCB;

    /*those will be registered by application:*/
    /*clbks->addressAnalyzeCB */
    /*clbks->inProcessCB */

}

/* Default function, does nothing - when a separate thread
   exist to process events */
/*1.4. porting: this code belong to very old version and is no use
static void defaultNotifyEvent(void* data)
{
}
*/

rvDefineMap(RvCharPtr,RvCCTerminalPtr)


static RvMdmTerm* mdmProviderFindTerm(
    IN RvMdmXTermMgr*   x,
    IN const RvChar*    id_)
{
    RvCharPtr id = (char*)id_;
    RvCCTerminal* t;
    RvCCProvider* p = (RvCCProvider*)x;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvCCTerminalMdm* term;
    const RvCCTerminalPtr* pt = rvMapGetValue(RvCharPtr,RvCCTerminalPtr)(&provider->terminals,&id);
    if (pt == NULL)
        return NULL;

    t = *pt;
    term = rvCCTerminalMdmGetImpl(t);

    return &term->mdmTerm;
}

static RvCCTerminalType getTerminalTypeById(const char* id)
{
    if (strstr(id, "at/"))
        return RV_CCTERMINALTYPE_AT;
    if (strstr(id, "rtp"))
        return RV_CCTERMINALTYPE_EPHEMERAL;

#ifdef RV_MTF_VIDEO
    return rvCCVideoMdmGetTerminalTypeById(id);
#else
    return RV_CCTERMINALTYPE_UNKNOWN;
#endif
}

static RvMdmTerm* mdmProviderGetIdleTerm(RvMdmXTermMgr * x,const char* id_)
{
    /* parameters not remove as is related to megaco termination mgr */
    RV_UNUSED_ARG(x);
    RV_UNUSED_ARG(id_);
    return 0;
}

static void rvCCProviderMdmAddTerminal(RvCCProviderMdm* x, RvCCTerminal* term)
{
    RvChar* id = (RvChar *)rvCCTerminalMdmGetTermId(term);

    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvCCProviderMdmAddTerminal(providerMdm:%p, term:%p)",x,term));

    rvMapSetValue(RvCharPtr,RvCCTerminalPtr)(&x->terminals,&id,&term);

    RvLogDebug(ippLogSource,(ippLogSource,"rvCCProviderMdmAddTerminal:id:%s",id));

    RvLogDebug(ippLogSource,(ippLogSource,"--> rvCCProviderMdmAddTerminal"));
}
/*
static void detachConnections(RvCCTerminal* t)
{
    int i;

    for (i=0 ; i<RV_CCTERMINAL_MAXCONNS ; ++i) {
        RvCCConnection* conn = t->connections[i];
        if (( conn != NULL) && (rvCCConnectionGetTerminal(conn) == t))
            rvCCConnectionSetTerminal(t->connections[i], NULL);
    }

}
*/
static void removeAllTerminals(RvCCProvider* p)
{
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter;
    RvCCTerminal** pt;
    RvCCTerminal* t;

    for(iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
		/* since rvCCProviderMdmRemoveTerminal() removes the terminal from the Map
		   next iteration must be started again from the Beginning of the Map */
		iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals))
    {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        t = *pt;

		rvCCProviderMdmRemoveTerminal(p, t);
		rvCCProviderMdmReleaseTerminal(t);
    }

    rvMapClear(&provider->terminals);
}

static void printMediaCaps(RvCCTerminalMdm* x)
{
    const RvSdpMsg* sdp = rvCCTerminalMdmGetMediaCaps(x);
    char    buf[2048];
    RvSdpStatus stat = RV_SDPSTATUS_OK;

    rvSdpMsgEncodeToBuf((RvSdpMsg*)sdp, buf, 2048, &stat);
	if (stat != RV_SDPSTATUS_OK)
	{
		/* SDP message failed to be encoded to buffer */
		RvLogError(ippLogSource, (ippLogSource, "printMediaCaps() - SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
			sdp, stat));
		return;
	}

    RvLogInfo(ippLogSource, (ippLogSource, "\n****** Media Caps: ******\n%s\n", buf));
}

/******************************************************************************
*  connectPhysicalTermsToUI
*  ----------------------------
*  General :        This function connects all existing audio/video physical terminations
*                   to UI termination. It is called when either UI or a physical termination
*                   is registered.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           x           Mdm provider
*
*
*  Output:         none.
******************************************************************************/
static void connectPhysicalTermsToUI(RvCCProvider* x)
{
    RvCCTerminal* uiTerm = rvCCProviderFindTermByType(x, RV_CCTERMINALTYPE_UI);
    RvCCTerminal* t;

    if (uiTerm == NULL)
        return;

    if ((t = rvCCProviderFindTerminalByTermId(x, "at/hs")) != NULL)
    {
        if(rvCCTerminalMdmGetHandsetTerm(uiTerm) == NULL)
            rvCCTerminalMdmSetHandsetTerm(uiTerm, t);
        /* Add for incoming call default audio*/
        rvCCTerminalMdmSetActiveAudioTerm(uiTerm, t);
    }

    if ((t = rvCCProviderFindTerminalByTermId(x, "at/ht")) != NULL)
    {
        /* Set this Headset only if no other Headset is registered*/
        if(rvCCTerminalMdmGetHeadsetTerm(uiTerm) == NULL)
            rvCCTerminalMdmSetHeadsetTerm(uiTerm, t);
    }

    if ((t = rvCCProviderFindTerminalByTermId(x, "at/hf")) != NULL)
    {
        /* Set this Handsfree only if no other Handsfree is registered*/
        if (rvCCTerminalMdmGetHandsfreeTerm(uiTerm) == NULL)
            rvCCTerminalMdmSetHandsfreeTerm(uiTerm, t);
    }

#ifdef RV_MTF_VIDEO
    rvCCVideoMdmConnectTermsToUI(x, uiTerm);
#endif

}

/******************************************************************************
*  disconnectPhysicalTermFromUI
*  ----------------------------
*  General :        This function disconnects an audio/video physical terminations
*                   from UI termination. It is called when the physical termination
*                   unregisters.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           x           Mdm provider
*                   t           physical termination
*
*  Output:         none.
******************************************************************************/
void disconnectPhysicalTermFromUI(RvCCProvider* x, RvCCTerminal* t)
{
    RvCCTerminal*       uiTerm  = rvCCProviderFindTermByType(x,RV_CCTERMINALTYPE_UI);
    RvCCTerminalMdm*    term    = rvCCTerminalMdmGetImpl(t);
    RvCCTerminalType    type    = rvCCTerminalMdmGetType(term);

    if ((type == RV_CCTERMINALTYPE_AT) && (uiTerm != NULL))
    {
        if (!strcmp(rvCCTerminalMdmGetId(term),"at/hs") )
            rvCCTerminalMdmSetHandsetTerm(uiTerm, NULL);

        if (!strcmp(rvCCTerminalMdmGetId(term),"at/ht") )
            rvCCTerminalMdmSetHeadsetTerm(uiTerm, NULL);

        if (!strcmp(rvCCTerminalMdmGetId(term),"at/hf") )
            rvCCTerminalMdmSetHandsfreeTerm(uiTerm, NULL);

#ifdef RV_MTF_VIDEO
        rvCCVideoMdmDisconnectTermFromUI(term, uiTerm);
#endif
    }
}

/*
void gracefulShutdown(RvCCProviderMdm* x)
{
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter;

    for(iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        RvCCTerminal** pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        RvCCTerminal* t = *pt;
        RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
        RvCCTerminalType type = rvCCTerminalMdmGetType(term);
        if (type == RV_CCTERMINALTYPE_UI)
            rvCCTerminalGracefulShutdown(t);

    }


}*/
static void loadTerminalProperties(
    IN RvCCTerminal*                t,
    IN RvMdmTermDefaultProperties*  termProperties)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

    if (termProperties != NULL)
    {
        rvMdmTermPhoneNumbersCopy(&(term->phoneNumbers), &(termProperties->phoneNumbers));
        rvCCTerminalMdmLoadPresentationInfo(term, termProperties);
    }
    else
    {
        RvLogWarning(ippLogSource,(ippLogSource,"No properties to load"));
    }
}

/*===============================================================================*/
/*=========== M D M     C A L L B A C K     I M P L E M E N T A T I O N S =======*/
/*===============================================================================*/
RvMdmTerm* rvMdmProviderRegisterPhysTerm(
    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties)
{
    RvCCProvider        * p = (RvCCProvider*)x;
    RvCCTerminal        * t;
    RvCCTerminalMdm     * term; /*Note: May check if term already exist!*/
    RvCCTerminalType    type = rvCCProviderMdmFindTerminalType(c, id);

    /* check if the terminal id is NULL. If so, the registration can't be completed */
    if ((id == NULL) || (id[0] == '\0'))
    {
        RvLogError(ippLogSource,(ippLogSource,"rvMdmProviderRegisterPhysTerm: NULL terminal id"));
        return NULL;
    }

    /* Check if terminal already exists */
    t = rvCCProviderFindTerminalByTermId(p, id);

    if (t != NULL)
    {
        RvLogWarning(ippLogSource,(ippLogSource,"rvMdmProviderRegisterPhysTerm: Terminal already exists, term id=%s", id));
        return NULL;
    }

    t = rvCCProviderMdmCreateTerminal(p, type, id, 0, termProperties);
    if (t == NULL)
        return NULL;

    term = rvCCTerminalMdmGetImpl(t);

    connectPhysicalTermsToUI(x);

    /* Construct the mdmTerm */
    rvMdmTermConstruct_(&term->mdmTerm, c, t);
    rvCCTerminalMdmSetType(term, RV_MDMTERMTYPE_PHYSICAL);

    /*Set media capabilities */
    term->mediaCaps = rvMdmTermClassGetMediaCapabilites_(c);

    /* Install digit map so the mapping function is available
       Note: DigitMap is not actually active at this point */
    rvCCTerminalMdmInstallDigitMap(t, RV_FALSE);

    term->inactive = RV_FALSE;

    /*Copy the phones list from termProperties  */
    loadTerminalProperties(t, termProperties);

    RvLogInfo(ippLogSource,(ippLogSource,"********** REGISTER TERMINATION ID: %s Type: %s",
            rvCCTerminalMdmGetId(term), rvCCTextTermType(rvCCTerminalMdmGetType(term))));

    return &term->mdmTerm;
}

RvMdmTerm* rvMdmProviderRegisterPhysTermAsync(
    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties,
    IN void*                        userData)
{
    RvCCProvider * p = (RvCCProvider*)x;
    RvCCTerminal * t;
    RvCCTerminalMdm * term; /*Note: may check if term already exist!*/
    RvCCTerminalType type = rvCCProviderMdmFindTerminalType(c, id);

    /* check if the terminal id is NULL. If so, the registration can't be completed */
    if ((id == NULL) || (id[0] == '\0'))
    {
        RvLogError(ippLogSource,(ippLogSource,"rvMdmProviderRegisterPhysTerm: failed to register termination - NULL terminal id"));
        return NULL;
    }
	
    t = rvCCProviderFindTerminalByTermId(p, id);

    if (t != NULL)
    {
        RvLogWarning(ippLogSource,(ippLogSource,"rvMdmProviderRegisterPhysTerm: Terminal already exists, term id=%s", id));
        return NULL;
    }

    t = rvCCProviderMdmCreateTerminal(p, type, id, 0, termProperties);
    if (t == NULL)
        return NULL;

    term = rvCCTerminalMdmGetImpl(t);

    /* Construct the mdmTerm */
    rvMdmTermConstruct_(&term->mdmTerm, c, t);
    rvCCTerminalMdmSetType(term, RV_MDMTERMTYPE_PHYSICAL);

    /*Set media capabilities */
    term->mediaCaps = rvMdmTermClassGetMediaCapabilites_(c);

    term->inactive = RV_FALSE;

    /*Copy the phones list from termProperties */
    loadTerminalProperties(t, termProperties);

    rvMdmTermSetUserData(&term->mdmTerm, userData);

    /*send an event to be processed later*/
    rvMdmTermQueueRegisterTermEvent(&term->mdmTerm);
    RvLogInfo(ippLogSource,(ippLogSource,"********** REGISTER TERMINATION (ASYNC) ID: %s Type: %s",
            rvCCTerminalMdmGetId(term), rvCCTextTermType(rvCCTerminalMdmGetType(term))));

    return &term->mdmTerm;
}


static RvMdmTerm* mdmProviderRegisterEphTerm(RvMdmXTermMgr * x,RvMdmTermClass * c,
                                  const char* id,RvMdmTermDefaultProperties* termProperties)
{

    RvCCProvider * p = (RvCCProvider*)x;
    RvCCTerminal * t;
    RvCCTerminalMdm * term;

    if (termProperties != NULL)
    {
        t = rvCCProviderMdmCreateTerminal(p, RV_CCTERMINALTYPE_EPHEMERAL, id, 0, termProperties);
        if (t == NULL)
            return NULL;
    }
    else
    {
        /*
         * here we checked termProperties
         * it shouldn't be NULL because in such a case terminal ctor will built unneeded digital map.
         * So if it's NULL we built and pass empty termPropertiesTmp instead.
         */
        RvMdmTermDefaultProperties termPropertiesTmp;
        rvMdmTermDefaultPropertiesConstruct(&termPropertiesTmp);

        t = rvCCProviderMdmCreateTerminal(p, RV_CCTERMINALTYPE_EPHEMERAL, id, 0, &termPropertiesTmp);
        if(t == NULL)
            return NULL;

        rvMdmTermDefaultPropertiesDestruct(&termPropertiesTmp);
    }

    term = rvCCTerminalMdmGetImpl(t);

    /* Construct the mdmTerm */
    rvMdmTermConstruct_(&term->mdmTerm, c, t);

    rvCCTerminalMdmSetType(term, RV_MDMTERMTYPE_EPHEMERAL);

    /*Set media capabilities */
    term->mediaCaps = rvMdmTermClassGetMediaCapabilites_(c);

    term->inactive = RV_FALSE;

    printMediaCaps(term);

    return &term->mdmTerm;
}

static RvBool mdmProviderUnregisterTermAsync(IN RvMdmXTermMgr* x, IN RvMdmXTerm* xTerm)
{
    RvCCTerminal* t = (RvCCTerminal*) xTerm;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

    RV_UNUSED_ARG(x);

    rvMdmTermQueueUnregTermEvent(&term->mdmTerm);

    return RV_TRUE;
}

RvBool rvMdmProviderUnregisterTerm(IN RvMdmXTermMgr* x, IN RvMdmXTerm* xTerm)
{
    RvCCProvider*        p = (RvCCProvider*)x;
    RvCCTerminal*        t = (RvCCTerminal*) xTerm;
	RvCCTerminalMdm*     mdmTerminal = rvCCTerminalMdmGetImpl(t);
	RvMtfTerminalType    termType = rvCCTerminalMdmGetType(mdmTerminal);


	/* Remove both physical and ephemeral terminations, notify the application and only then release MDM terminal*/
	disconnectPhysicalTermFromUI(p,t);
	rvCCProviderMdmRemoveTerminal(p, t);

	if ((termType == RV_CCTERMINALTYPE_ANALOG) || (termType == RV_CCTERMINALTYPE_UI))
	{
		RvUint8  i;
		/* At this stage we consider all protocols as unregistered. If persistent registration feature is on we 
		   don't wait for response from servers.
		 */
		for (i=0; i < RV_MTF_PROTOCOL_NUM; i++)
		{
			mdmTerminal->registerReportType = RV_REGISTER_REPORT_TYPE_UNREG_COMPLETE;
			mdmTerminal->protocolRegisterStateReported[i] = RV_TRUE;
			mdmTerminal->registrationStatus.protocolRegisterStateData[i].registrationState = RV_MTF_REG_STATE_NOT_REGISTERED;
			mdmTerminal->registrationStatus.protocolRegisterStateData[i].registrationStateReason = RV_MTF_REG_STATE_REASON_USER_REQUEST;
		}
		/* Notify the user application */
		rvMtfRegisterTermReportStatus( t, RV_FALSE);
	}
	rvCCProviderMdmReleaseTerminal(t);

    return RV_TRUE;
}



RvBool mdmProviderForEachPhysTerm(RvMdmXTermMgr* mgr,RvMdmProcessEachTermCB func,void* data)
{
    RvCCProvider* p = (RvCCProvider*)mgr;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter=NULL;
    RvCCTerminal** pt;
    RvCCTerminal* t;
    RvCCTerminalMdm* term;
    RvMdmTerm* mdmTerm;

    /* loop over all terminals */
    for (iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        t = *pt;
        term = rvCCTerminalMdmGetImpl(t);
        mdmTerm = rvCCTerminalMdmGetMdmTerm(term);

        if (rvMdmTermGetType(mdmTerm) == RV_MDMTERMTYPE_PHYSICAL)
            func(mdmTerm, data);
    }

    return rvTrue;
}


    /* The Callbacks structure */
    RvMdmXTermMgrClbks rvMdmTermMgrClbks = 
    {
    /*  RvMdmXTermMgrRegisterPhysTermCB     registerPhysTermF; */
        rvMdmProviderRegisterPhysTerm,
    /*  RvMdmXTermMgrRegisterPhysTermAsyncCB    registerPhysTermAsyncF; */
        rvMdmProviderRegisterPhysTermAsync,
    /*  RvMdmXTermMgrRegisterEphTermCB      registerEphTermF; */
        mdmProviderRegisterEphTerm,
    /*  RvMdmXTermMgrUnregisterTermCB       unregisterTermF; */
        rvMdmProviderUnregisterTerm, //
    /*  RvMdmXTermMgrUnregisterTermAsyncCB  unregisterTermAsyncF; */
        mdmProviderUnregisterTermAsync,     
    /*  RvMdmXTermMgrFindTermCB             findTermF; */
        mdmProviderFindTerm,
    /*  RvMdmXTermMgrFindTermCB             getIdleTermF; */
        mdmProviderGetIdleTerm,
    /*  RvMdmXTermMgrStart                  startF; */
        NULL,
    /*  RvMdmXTermMgrStop                   stopF; */
        NULL,
    /*  RvMdmXTermMgrDestructCB                 destructF; */
        NULL, 
    /*  RvMdmXTermMgrForEachPhysTermCB      forEachPhysTermF */
        mdmProviderForEachPhysTerm,

        /* NOT ALL CB have a default implementation - thus causing compiler warnings */
        NULL,/* RvMdmXTermMgrMediaCapsUpdatedCB         mediaCapsUpdatedF */
        NULL,/* RvMdmXTermMgrRegisterAllTermsToNetworkCB registerAllTermsToNetworkF */
        NULL, /*    RvMdmXTermMgrRegisterTermToNetworkCB    registerTermToNetworkF */
        NULL
    };


char* mapAddressToTermination(RvMdmTermMgr* mgr, const char* address)
{
    RvCCProvider* p = (RvCCProvider*)mgr->xTermMgr;
	RvCCProviderMdm* pm = (RvCCProviderMdm*)p->provider;
    RvCCTerminal* t;
    RvCCTerminalMdm* term;
    RvMdmTerm* mdmTerm;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- mapAddressToTermination"));
	if (strlen (address) == 0)
	{
		/* no address given, get first terminal */
		if ((t = rvCCProviderMdmFindAnyTerminal(p)) == NULL)
		{
			RvLogError(ippLogSource,(ippLogSource,"mapAddressToTermination(), empty address given and no terminations found, return NULL"));
			return NULL;
		}
		else
		{
			RvLogDebug(ippLogSource,(ippLogSource,"mapAddressToTermination(), empty address given, first termination taken."));
		}

	}

	else
	{
		/* get the correct terminal */
		if ((t = rvCCProviderFindTerminalByAddress(p, address)) == NULL)
		{
			/* incorrect user given */
			if (pm->acceptCallWhenUserNotFound)
			{
				/* MTF is configured to accept calls to user that is not found -> look for first terminal */
				if ((t = rvCCProviderMdmFindAnyTerminal(p)) == NULL)
				{
					RvLogError(ippLogSource,(ippLogSource,"mapAddressToTermination(), address %s is incorrect and no terminations found, return NULL", address));
					return NULL;
				}
				else
				{
					RvLogDebug(ippLogSource,(ippLogSource,"mapAddressToTermination(), address %s not found, first termination taken.", address));
				}

			}
			else
			{
				/* MTF is configured not to accept calls to other users -> return NULL */
				RvLogError(ippLogSource,(ippLogSource,"mapAddressToTermination(), address %s not found, return NULL", address));
				return NULL;
			}

		}
	}

    term = rvCCTerminalMdmGetImpl(t);
    mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
    if (rvMdmTermGetType(mdmTerm) == RV_MDMTERMTYPE_PHYSICAL)
    {
        RvLogDebug(ippLogSource,(ippLogSource,"--> mapAddressToTermination"));
        return (term->terminalId);
    }

    RvLogDebug(ippLogSource,(ippLogSource,"--> mapAddressToTermination NULL"));
    return NULL;
}

/*===============================================================================*/
/*======================= P R O V I D E R   A P I ===============================*/
/*===============================================================================*/

RvCCConnection* rvCCProviderMdmCreateConnection(RvCCProvider* p, RvCCTerminal* t)
{
    RvCCConnection* c = rvCCTerminalFindFreeConnection(t);

    RV_UNUSED_ARG(p); /* cannot remove parameter as it is used in network providers */

    if (c != NULL)
        rvIppMdmExtConnectionCreatedCB(c);
    return c;
}

/******************************************************************************
*  rvCCProviderMdmRemoveTerminal
*  -----------------------------
*  General :        This function removes a terminal from the list of provider's 
*                   terminals.
*                   In order to complete terminal removal make sure that proc
*                   rvCCProviderMdmReleaseTerminal() is called after this proc.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           x           Mdm provider
*                   t           Mdm terminal
*
*  Output:         none.
******************************************************************************/
void rvCCProviderMdmRemoveTerminal(RvCCProvider* x, RvCCTerminal* t)
{
    RvCCTerminalMdm*    term = rvCCTerminalMdmGetImpl(t);
    RvCCProviderMdm*    provider = rvCCProviderMdmGetImpl(x);
	/* id is an intermediate variable that is used in the call to rvMapRemove which expects
	   a char** poinetr whilst the terminalId is only char*     */
    RvChar*             id = (RvChar *)rvCCTerminalMdmGetTermId(t);

    /* detachConnections(t);  fix crash when close java gui in the middle of incoming call(alerting) RVrep00026852*/

    RvLogInfo(ippLogSource, (ippLogSource, "********** REMOVE TERMINATION ID: %s Type: %s",
        rvCCTerminalMdmGetId(term), rvCCTextTermType(rvCCTerminalMdmGetType(term))));

	rvMapRemove(RvCharPtr,RvCCTerminalPtr)(&provider->terminals, &id);
}

/******************************************************************************
*  rvCCProviderMdmReleaseTerminal
*  ------------------------------
*  General :        Release terminal resources. This proc should be called 
*                   after rvCCProviderMdmRemoveTerminal().
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          t           Mdm terminal
*
*  Output:         none.
******************************************************************************/
void rvCCProviderMdmReleaseTerminal(RvCCTerminal* t)
{
	RvLogDebug(ippLogSource, (ippLogSource, "rvCCProviderMdmReleaseTerminal() - releasing terminal %d resources", t));
	rvCCTerminalMdmDestruct(t);
	rvMtfAllocatorDealloc(t, sizeof(RvCCTerminal));
}

RvCCTerminal* rvCCProviderFindTermByType(IN RvCCProvider*       x,
                                         IN RvCCTerminalType    termType)
{
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(x);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter;

    for(iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        RvCCTerminal** pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        RvCCTerminal* t = *pt;
        RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
        RvCCTerminalType type = rvCCTerminalMdmGetType(term);

        if (type == termType)
            return *pt;
    }

    return NULL;
}

RvCCTerminal* rvCCProviderMdmCreateTerminal(
    IN RvCCProvider*                x,
    IN RvCCTerminalType             type,
    IN const RvChar*                id,
    IN RvCCTerminalClbks*           clbks,
    IN RvMdmTermDefaultProperties*  termProperties)
{
    RvCCProviderMdm* provider = x->provider;
    RvCCTerminal* t = NULL;
	rvMtfAllocatorAlloc(sizeof(RvCCTerminal), (void**)&t);

    if (t == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCProviderMdmCreateTerminal: Failed to allocate memory for term id=%s", id));
        return NULL;
    }

    rvCCTerminalMdmConstruct(t, x, id, type, clbks, termProperties,  provider->a);

    rvCCProviderMdmAddTerminal(provider, t);

    /* Connect Audio terminations to UI. This function covers 2 cases:
       UI registers after AT - When UI registers, connect all existing AT to it
       UI registers before AT - When AT registers, connect it UI*/
    if (type != RV_CCTERMINALTYPE_EPHEMERAL)
        connectPhysicalTermsToUI(x);

    return t;
}

RvCCTerminal* rvCCProviderFindTerminalByTermId(RvCCProvider* x, const char* termId)
{
    RvCharPtr id = (char*)termId;
    RvCCProvider* p = (RvCCProvider*)x;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    const RvCCTerminalPtr* pt;
    if(termId==NULL)
        return NULL;
    pt = rvMapGetValue(RvCharPtr,RvCCTerminalPtr)(&provider->terminals, &id);
    if(pt==NULL)
        return NULL;
    return *pt;

}

/* Find out if specific terminal exists in the mdm provider terminal list */
RvBool rvCCProviderMdmFindIfTerminalExist(RvCCProvider* x, RvMdmTerm *term)
{
    RvBool result = rvFalse;
    RvCCProvider* p = (RvCCProvider*)x;
    RvMapIter(RvCharPtr,RvCCTerminalPtr) i;
    const RvCCTerminalPtr* pt;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvCCTerminalMdm* terminalMdm;

    if (term == NULL)
    {
        return rvFalse;
    }

    for(i=rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i!=rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i=rvMapIterNext(i))
    {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(i);
        if (pt != NULL)
        {
            terminalMdm = rvCCTerminalMdmGetImpl((*pt));
            if (terminalMdm != NULL)
            {
                if (rvCCTerminalMdmGetMdmTerm(terminalMdm) == term)
                {
                    result = rvTrue;
                    break; /* The required terminal was found, break the search loop */
                }
            }
        }
    }
    return result;
}


/* Find first terminal of type ui, if not present find an anlog term */
RvCCTerminal* rvCCProviderMdmFindAnyTerminal(RvCCProvider* x)
{
    RvCCProvider* p = (RvCCProvider*)x;
    RvMapIter(RvCharPtr,RvCCTerminalPtr) i;
    const RvCCTerminalPtr* pt;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvCCTerminalMdm* term;

    for(i=rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i!=rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i=rvMapIterNext(i)) {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(i);
        term = rvCCTerminalMdmGetImpl((*pt));
        if( rvCCTerminalMdmGetType(term) == RV_CCTERMINALTYPE_UI )
            return *pt;
    }
    for(i=rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i!=rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i=rvMapIterNext(i)) {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(i);
        term = rvCCTerminalMdmGetImpl((*pt));
        if( rvCCTerminalMdmGetType(term) == RV_CCTERMINALTYPE_ANALOG )
            return *pt;
    }
    return NULL;
}

/* Find terminal by phone number */
RvCCTerminal* rvCCProviderMdmFindTerminalByNumber(RvCCProvider* x,const char* phoneNumber)
{
    RvCCProvider* p = (RvCCProvider*)x;
    RvMapIter(RvCharPtr,RvCCTerminalPtr) i;
    const RvCCTerminalPtr* pt;
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);

    if (phoneNumber==NULL)
        return NULL;

    for(i=rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i!=rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        i=rvMapIterNext(i))
    {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(i);
        {
            unsigned int j;
            RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl((*pt));
            RvMdmTermPhoneNumbers* phoneNumbers = rvCCTerminalMdmGetPhoneNumbers(term);
            for (j=0; j < rvMdmTermPhoneNumbersGetSize(phoneNumbers); j++)
            {
                const char *termNumber = rvMdmTermPhoneNumbersGetByIndex(phoneNumbers, j);

                if(!strcmp(phoneNumber, termNumber) )
                    return *pt;
            }
        }
    }
    return NULL;
}


RvCCTerminal* rvCCProviderFindTerminalByAddress(RvCCProvider* x, const char* address)
{
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(x);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter=NULL;
    const char* termId;

    for (iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        termId = *rvMapIterGetKey(RvCharPtr,RvCCTerminalPtr)(iter);
        if (!strcmp(termId, address))
            return *rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
    }

    return NULL;


}

void rvCCProviderMdmPrintMedia(const RvMdmStreamDescriptor* descr)
{
#define BUFLEN  2048
#define MSGLEN  48
    const RvSdpMsg  *sdp;
    char            buf[BUFLEN];
    char            logstr[BUFLEN*2+MSGLEN*3];
    RvSdpStatus     stat=RV_SDPSTATUS_OK;
    char            msg[BUFLEN+MSGLEN]; /* TODO: This can be removed altogether if written properly */
    const char      *tmpStr;
	
    tmpStr = rvCCTextStreamMode(rvMdmStreamDescriptorGetMode(descr));
		
    RvSprintf(logstr, "\n******Stream Mode: %s*******\n", tmpStr);
	
    if (rvMdmStreamDescriptorIsLocalDescriptorSet(descr) == rvTrue) {
        sdp = rvMdmStreamDescriptorGetLocalDescriptor(descr, 0);
        rvSdpMsgEncodeToBuf((RvSdpMsg*)sdp, buf, BUFLEN, &stat);
		if (stat != RV_SDPSTATUS_OK)
		{
			/* SDP message failed to be encoded to buffer */
			RvLogError(ippLogSource, (ippLogSource, "rvCCProviderMdmPrintMedia() - SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
				sdp, stat));
			return;
		}
        RvSnprintf(msg,sizeof(msg), "******Local Media*********\n%s\n", buf);
        strcat(logstr, msg);
    }
    if (rvMdmStreamDescriptorIsRemoteDescriptorSet(descr) == rvTrue) {
        sdp = rvMdmStreamDescriptorGetRemoteDescriptor(descr, 0);
        rvSdpMsgEncodeToBuf((RvSdpMsg*)sdp, buf, BUFLEN, &stat);
		if (stat != RV_SDPSTATUS_OK)
		{
			/* SDP message failed to be encoded to buffer */
			RvLogError(ippLogSource, (ippLogSource, "rvCCProviderMdmPrintMedia() - SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
				sdp, stat));
			return;
		}
        RvSnprintf(msg,sizeof(msg), "******Remote Media*********\n%s\n", buf);
        strcat(logstr, msg);
    }

    RvLogInfo(ippLogSource,(ippLogSource,logstr));
}

void rvCCProviderMdmConstruct(RvCCProvider*			p,
							  RvCCCallMgr*			callMgr,
							  RvMdmTermMgr*			termMgr,
                              RvMtfSipPhoneCfg*		cfg,
                              RvAlloc*				a)
{
    RvCCProviderMdm* provider;
    RvMdmDigitMapData dmData;
    RvMdmPackage* pkg;

    RvLogInfo(ippLogSource,(ippLogSource,
        "Multimedia Terminal Framework Version %s Copyright (c) RADVISION",
        RV_MTF_VERSION));
#if (RV_NET_TYPE & RV_NET_IPV6)
    RvLogInfo(ippLogSource,(ippLogSource,"Support IPv6"));
#endif

	rvMtfAllocatorAlloc(sizeof(RvCCProviderFuncs), (void**)&(p->funcs));

    p->funcs->createConnectionF = rvCCProviderMdmCreateConnection;
	rvMtfAllocatorAlloc(sizeof(RvCCProviderMdm), (void**)&(p->provider));
    provider = p->provider;

    provider->a = a;

    provider->callMgr = callMgr;

	provider->autoAnswer = cfg->autoAnswer;

	provider->autoDisconnect = cfg->autoDisconnect;

	provider->numberOfLines = cfg->numberOfLines;

	provider->acceptCallWhenUserNotFound = cfg->acceptCallWhenUserNotFound;

	/* zhuzhh, 2011/05/27, disable cwt for line, modify, start */
	// provider->disableCallWaiting = cfg->disableCallWaiting;
	/* zhuzhh, 2011/05/27, disable cwt for line, modify, end */

	provider->persistentRegisterEnabled      = cfg->persistentRegisterEnabled;
	provider->persistentRegisterRetryInterval = cfg->persistentRegisterRetryInterval;
	provider->registerCompleteTimeout        = cfg->registerCompleteTimeout;

    strncpy(provider->localAddress, cfg->localAddress, sizeof(provider->localAddress)-1);
    provider->localAddress[sizeof(provider->localAddress)-1] = '\0';

	/* set the displayName in the provider data. If displayName is not configured 
	   use the termId */
	if ((cfg->displayName != NULL) &&  (cfg->displayName[0] != '\0'))
	{
		strncpy(provider->displayName, cfg->displayName, sizeof(provider->displayName)-1);
		provider->displayName[sizeof(provider->displayName)-1] = '\0';
	}
	else
	{
		provider->displayName[0] = '\0';
	}
	

    rvMapConstruct(RvCharPtr, RvCCTerminalPtr)(&provider->terminals, a);
    RvMutexConstruct(IppLogMgr(), &provider->lock);

    rvInitConnFuncs(provider);
    rvInitConnCallbacks(provider);

    /* init mdm termination mgr */
    provider->mdmTermMgr = termMgr;
    provider->mdmTermMgr->xTermMgr = p;
    rvMdmTermMgrRegisterXTermMgrClbks_(provider->mdmTermMgr, &rvMdmTermMgrClbks);

    /* Digit map for Analog phone*/
    pkg = rvMdmTermMgrGetPackage(provider->mdmTermMgr, "dd");
    rvMdmDigitMapDataConstruct(&dmData,"ce",
                               rvMdmDigitMapBuildDDEvComplete,
                               rvMdmDigitMapTranslateDDEvent,
                               provider->mdmTermMgr->a);
    rvMdmPackageRegisterDigitMapData(pkg,&dmData);
    rvMdmDigitMapDataDestruct(&dmData);
	/* Copy digit map patterns as they were configured by the user */
	rvMdmDigitMapConstruct(&provider->digitMap);
	if (cfg->digitMapPtr != NULL)
	{	
		rvMdmDigitMapCopy(&provider->digitMap, cfg->digitMapPtr);
	}
	else
	{
		rvCCTerminalMdmCreateDefaultDigitMap(&provider->digitMap);
	}

    rvMapConstruct(RvCharPtr,RvCCTerminalPtr)(&provider->terminals, a);

    provider->dialToneDuration = cfg->dialToneDuration;
    provider->outOfBandDtmf = cfg->outOfBandDtmf;

    provider->cfwCallCfg.cfwCallBacks.activateCompleted = cfg->cfwCallCfg.cfwCallBacks.activateCompleted;
    provider->cfwCallCfg.cfwCallBacks.deactivateCompleted = cfg->cfwCallCfg.cfwCallBacks.deactivateCompleted;

    RvMutexConstruct( IppLogMgr(), &provider->mutex);

    rvMdmControlStarted = 1;


}



void rvCCProviderMdmDestruct(RvCCProvider* p)
{
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);

    rvMdmControlStarted = 0;

    removeAllTerminals(p);
    rvMapDestruct(&provider->terminals);

	rvMdmDigitMapDestruct(&provider->digitMap);

    RvMutexLock(&provider->lock,IppLogMgr());
    RvMutexUnlock(&provider->lock,IppLogMgr());
    RvMutexDestruct(&provider->lock,IppLogMgr());

	rvMtfAllocatorDealloc(p->funcs, sizeof(RvCCProviderFuncs));

    RvMutexDestruct(&provider->mutex,IppLogMgr());

	rvMtfAllocatorDealloc(provider, sizeof(RvCCProviderMdm));
}

/*Those callbacks will be registered by the Application, the rest will be implemented by RvCCCall*/
void rvCCProviderMdmRegisterAddressAnalyzeCB(RvCCProvider* x, RvCCConnectionAddressAnalyzeCB addressAnalyzeCB)
{
    RvCCProviderMdm* p = rvCCProviderMdmGetImpl(x);
    p->connClbks.addressAnalyzeCB = addressAnalyzeCB;

}

void rvCCProviderMdmRegisterInProcessCB(RvCCProvider* x, RvCCConnectionInProcessCB inProcessCB)
{
    RvCCProviderMdm* p = rvCCProviderMdmGetImpl(x);
    p->connClbks.inProcessCB = inProcessCB;
}

void rvCCProviderMdmRegisterNewDigitCB(RvCCProvider* x, RvCCConnectionNewDigitCB newDigitCB)
{
    RvCCProviderMdm* p = rvCCProviderMdmGetImpl(x);
    p->connClbks.newDigitCB = newDigitCB;
}

void rvCCProviderMdmSetDisplayData(RvCCProvider* x,void* data)
{
    RvCCProviderMdm* p = rvCCProviderMdmGetImpl(x);
    p->displayData = data;
}

void* rvCCProviderMdmGetDisplayData(RvCCProvider* x)
{
    RvCCProviderMdm* p = rvCCProviderMdmGetImpl(x);
    return p->displayData;
}

RvMdmDigitMap* rvCCProviderMdmGetDigitMapPtr(RvCCProvider* x)
{
    RvCCProviderMdm* p = rvCCProviderMdmGetImpl(x);
    return &p->digitMap;
}

/* Process an event from the queue of user events */
void rvCCProviderMdmProcessTerminationEvent(IN void* data)
 {
    RvCCTerminal* term	= (RvCCTerminal *)data;

    if (rvMdmControlStarted == 0)
        return;

    rvMdmTermProcessBlockedEvent(term);
}

/*Gets the terminal type by class, if not found then gets by terminal id */
RvCCTerminalType rvCCProviderMdmFindTerminalType(RvMdmTermClass * c, const char* id)
{
    /* important to check analog first, since analog supports packages of both ipp and analog */
    if (rvMdmTermClassIsPkgSupported_(c, "dd"))
    {
        return RV_CCTERMINALTYPE_ANALOG;
    }

    else
    {
        if (rvMdmTermClassIsPkgSupported_(c, "kp"))
        {
            return RV_CCTERMINALTYPE_UI;
        }
        else
        {
            return getTerminalTypeById(id);
        }
    }

}

