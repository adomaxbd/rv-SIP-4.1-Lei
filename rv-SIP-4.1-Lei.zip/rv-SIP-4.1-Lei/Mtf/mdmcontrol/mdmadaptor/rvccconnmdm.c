/******************************************************************************
Filename   : rvccconnmdm.c
Description: Implements Mdm Connection Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvccconnmdm.h"
#include "rvccterminalmdm.h"
#include "rvmdmtermevent.h"
#include "mdmControlInt.h"
#include "mtfMediaInt.h"

#ifdef RV_MTF_VIDEO
#include "rvccmdmvideo.h"
#include "mdmControlVideoInt.h"
#endif /* RV_MTF_VIDEO */

#include "rvsdpenc.h"
#include "rvccapi.h"
#include "rvcctext.h"
#include "rvansi.h"

#ifdef RV_MTF_N_LINES
#include "mtfBaseInt.h"
#include "rvMtfBaseTypes.h"
#endif

extern		RvMtfCallControlClbks	mdmExtClbks;  

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/


/***************************************************************************
 * getRtpMediaObjects
 * ------------------------------------------------------------------------
 * General:      Returns objects related to RTP media and needed to perform
 *               media operations on RTP termination.
 * Return Value: True if succeeded, False if failed.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x        -  Mdm connection
 * Output   ephTerm  -  RTP termination (CC)
 *          rtpTerm  -  RTP termination (MDM)
 *          rtpMedia -  RTP media stream
 ***************************************************************************/
static RvBool getRtpMediaObjects(
                IN  RvCCConnection*             x,
                OUT RvCCTerminalMdm**       ephTerm,
                OUT RvMdmTerm**             rtpTerm,
                OUT RvMdmMediaStreamInfo**  rtpMedia)
{
    RvCCConnMdm*    conn;
    RvCCTerminal*   eph;

    if (x == NULL)
    {
        RvLogWarning(ippLogSource,(ippLogSource,"getRtpMediaObjects - Failed to get objects: received NULL pointer for Connection"));
        return RV_FALSE;
    }

    if ((conn = rvCCConnMdmGetIns(x)) == NULL)
    {
        RvLogWarning(ippLogSource,
            (ippLogSource,"getRtpMediaObjects - Failed to get objects: conn = NULL for conn=0x%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));
        return RV_FALSE;
    }

    /* Check for a valid stream id*/
    if (conn->streamId == RV_MDM_STREAMID_NONE)
    {
        /* Log level is not error since this may happen in a valid scenario */
        RvLogDebug(ippLogSource,
            (ippLogSource, "getRtpMediaObjects - No stream ID for conn=0x%p, Line=%d",
             x, rvCCConnectionGetLineId(x)));
        return RV_FALSE;
    }

    if ((eph = rvCCConnMdmGetEphXTerm(x)) == NULL)
    {
        RvLogError(ippLogSource,
            (ippLogSource,"getRtpMediaObjects - Failed to get objects: eph = NULL for conn=0x%p, Line=%d",
             x, rvCCConnectionGetLineId(x)));
        return RV_FALSE;
    }

    /* Now ready to get the objects*/
    if ((*ephTerm = rvCCTerminalMdmGetImpl(eph)) == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"getRtpMediaObjects - Failed to get objects: ephTerm = NULL for conn=0x%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));
        return RV_FALSE;
    }

    *rtpTerm = rvCCConnMdmGetEphTerm(x);
    *rtpMedia = rvCCTerminalMdmGetMediaStream(*ephTerm, conn->streamId);

    return RV_TRUE;


}

/***************************************************************************
 * getLineMediaObjects
 * ------------------------------------------------------------------------
 * General:      Returns objects related to Line media and needed to perform
 *               media operations on Physical termination.
 * Return Value: True if succeeded, False if failed.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x        -  Mdm connection
 *          at       -  Physical termination
 * Output   atTerm  -   Physical termination (implementation)
 *          mdmTerm  -  MDM termination
 *          lineMedia -  Line media stream
 ***************************************************************************/
static RvBool getLineMediaObjects(RvCCConnection*           x,
                                  RvCCTerminal*             at,
                                  OUT RvCCTerminalMdm**     atTerm,
                                  OUT RvMdmTerm**           mdmTerm,
                                  OUT RvMdmMediaStreamInfo** lineMedia)
{

    if (x == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"getLineMediaObjects - Failed to get objects: received NULL pointer for Connection"));
        return RV_FALSE;
    }

    /* Get the objects*/
    if ((*atTerm = rvCCTerminalMdmGetImpl(at)) == NULL)
    {
        RvLogWarning(ippLogSource,
            (ippLogSource,"getLineMediaObjects - Failed to get objects: atTerm = NULL for conn=0x%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));
        return RV_FALSE;
    }

    *mdmTerm = rvCCTerminalMdmGetMdmTerm(*atTerm);
    *lineMedia = rvCCTerminalMdmGetMediaStream(*atTerm, PHYS_TERM_STREAM_ID);

    return RV_TRUE;


}

#ifdef RV_MTF_N_LINES 
/******************************************************************************
*  connectRtpTerms
*  ----------------
*  General :    connect rtp of the new connection with the other rtps in 
*				the conferenceMdmConnectionsList
*
*  Arguments:
*  Input:       newConn: The new connection that is going to be added to the conference call
*				conferenceMdmConnectionsList: The existent connections of the conference call
*  Output       None
*  Return Value:None
*
******************************************************************************/
static RvBool connectRtpTerms(RvCCConnection* newConn, RvPtrList	conferenceMdmConnectionsList)
{
	RvCCTerminal		*t = rvCCConnectionGetTerminal(newConn);
	RvCCTerminal		*at = rvCCTerminalMdmGetActiveAudioTerm(t);
	RvCCTerminalMdm		*term = rvCCTerminalMdmGetImpl(at);
	RvMdmError			error;
	RvMdmTerm			*rtpTerm1, *rtpTerm2;
	RvMdmMediaStreamInfo *media1, *media2;
	RvCCTerminalMdm		*ephTerm1,  *ephTerm2;	
	unsigned int		index;
	RvCCConnection		*conn;
	RvPtrListIter		i;
	RvPtrList			rtpList, mediaList, ephTermList;
	RvBool				rc = rvTrue;

	getRtpMediaObjects(newConn, &ephTerm1, &rtpTerm1, &media1);
	
	/* If the list size is 1, it means that it is a 3-Way conference:
	X is the new line, and the one in the list is the other line of the conference.
	Therefore, it is needed to handle it with the old prototype */
	if (rvListSize(&conferenceMdmConnectionsList) == 1)  /* 3-Way conference */
	{
		RvCCConnection* otherConn = (RvCCConnection *)RvPtrListIterData(rvListBegin(&conferenceMdmConnectionsList));
		getRtpMediaObjects(otherConn, &ephTerm2, &rtpTerm2, &media2);
		
		rvMdmTermMgrConnectMediaStreams_(rvCCTerminalMdmGetTermMgr(term), rtpTerm1, media1,
			rtpTerm2, media2, RV_MDMSTREAMDIRECTION_BOTHWAYS, &error);
		
		/* Assume no error */
		rvMdmMediaStreamInfoSetStatusConnected(media1);
		rvMdmMediaStreamInfoSetStatusConnected(media2);
		
/*		printMedia(otherConn, media2); */
	}
	else /* N-way conference.*/
	{
		RvMtfBaseMgr* mtfMgr = rvGetMtfMgrByMdmTerm(rtpTerm1);

		/* Construct a list of the rtps of the connections in the conference */
		rvPtrListConstruct(&rtpList, conferenceMdmConnectionsList.allocator);
		
		/* Construct a list of the media of the connections in the conference */
		rvPtrListConstruct(&mediaList, conferenceMdmConnectionsList.allocator);
				
		/* Construct a list of the ephemeral termination for lock/unlock usage */
		rvPtrListConstruct(&ephTermList, conferenceMdmConnectionsList.allocator);

		/* 1st, put in the lists the info of the new connection of the conference call */
		rvPtrListPushBack(&rtpList, rtpTerm1);
		rvPtrListPushBack(&mediaList, media1);				
		rvPtrListPushBack(&ephTermList, ephTerm1);				
		
		i=rvListBegin(&conferenceMdmConnectionsList);	
		for (index = 0; index < rvListSize(&conferenceMdmConnectionsList); index++)
		{
			conn = (RvCCConnection *)RvPtrListIterData(i);
			getRtpMediaObjects(conn, &ephTerm2, &rtpTerm2, &media2);
			rvPtrListPushBack(&rtpList, rtpTerm2);
			rvPtrListPushBack(&mediaList, media2);
			rvPtrListPushBack(&ephTermList, ephTerm2);				
			i=rvListIterNext(i);
		}

		/* Call user callback to do the media mixing */
		if (mtfMgr->mediaClbks.connectMultiStreamsCB != NULL)
		{
			RvLogDebug(ippLogSource,(ippLogSource, "connectMultiStreamsCB() - before user callback, newConn =0x%p", newConn));
			rc = (mtfMgr->mediaClbks.connectMultiStreamsCB(rtpList) == RV_OK);
			RvLogDebug(ippLogSource,(ippLogSource, "connectMultiStreamsCB() - after user callback, newConn =0x%p", newConn));
		}
		else
		{
			RvLogInfo(ippLogSource,(ippLogSource,"connectMultiStreamsCB() - this callback was not registered by application, newConn=0x%p",
				                    newConn));
		}

		/* Assume no error. Set the new media to be in status connected */
		rvMdmMediaStreamInfoSetStatusConnected(media1);

		/* Unlock ephemeral terminations */
		i=rvListBegin(&ephTermList);	
		for (index = 0; index < rvListSize(&ephTermList); index++)
		{
			ephTerm2 = (RvCCTerminalMdm *)RvPtrListIterData(i);
			i=rvListIterNext(i);
		}
		rvPtrListDestruct(&rtpList);
		rvPtrListDestruct(&mediaList);
		rvPtrListDestruct(&ephTermList);
	}

/*	rvCCTextPrintMedia(x, rtpMedia1, "connectRtpTerms (Term 1)", RV_LOGLEVEL_DEBUG);*/

	return rc;
}


/******************************************************************************
*  disconnectRtpTerms
*  ----------------
*  General :    disconnect rtp of the connection from the other rtps in 
*				the conferenceMdmConnectionsList
*
*  Arguments:
*  Input:       newConn: The new connection that is going to be disconnected from the conference call
*				conferenceMdmConnectionsList: The existent connections of the conference call
*  Output       None
*  Return Value:None
*
******************************************************************************/
static void disconnectRtpTerms(RvCCConnection* newConn, RvPtrList	conferenceMdmConnectionsList)
{
	RvCCTerminal		*t = rvCCConnectionGetTerminal(newConn);
	RvCCTerminal		*at = rvCCTerminalMdmGetActiveAudioTerm(t);
	RvCCTerminalMdm		*term = rvCCTerminalMdmGetImpl(at);
	RvMdmError			error;
	RvMdmTerm			*rtpTerm1, *rtpTerm2;
	RvMdmMediaStreamInfo *media1, *media2;
	RvCCTerminalMdm		*ephTerm1,  *ephTerm2;	
	unsigned int		index;
	RvCCConnection		*conn;
	RvPtrListIter		i;
	RvPtrList			rtpList, mediaList, ephTermList;

	getRtpMediaObjects(newConn, &ephTerm1, &rtpTerm1, &media1);
/* Mutex 		RvMutexLock(&ephTerm1->mutex,IppLogMgr()); */
	
	/* If the list size is 1, it means that it is a 3-Way conference:
	X is the new line, and the one in the list is the other line of the conference.
	Therefore, it is needed to handle it with the old prototype */
	if (rvListSize(&conferenceMdmConnectionsList) == 1)  /* 3-Way conference */
	{
		RvCCConnection* otherConn = (RvCCConnection *)RvPtrListIterData(rvListBegin(&conferenceMdmConnectionsList));
		getRtpMediaObjects(otherConn, &ephTerm2, &rtpTerm2, &media2);
		
/* Mutex 			RvMutexLock(&ephTerm2->mutex,IppLogMgr()); */
		
		rvMdmTermMgrDisconnectMediaStreams_(rvCCTerminalMdmGetTermMgr(term), rtpTerm1, media1,
			rtpTerm2, media2, &error);
		
/* Mutex 			RvMutexUnlock(&ephTerm2->mutex,IppLogMgr()); */
	}
	else /* N-way conference.*/
	{
		RvMtfBaseMgr* mtfMgr = rvGetMtfMgrByMdmTerm(rtpTerm1);

		/* Construct a list of the rtps of the connections in the conference */
		rvPtrListConstruct(&rtpList, conferenceMdmConnectionsList.allocator);
		
		/* Construct a list of the media of the connections in the conference */
		rvPtrListConstruct(&mediaList, conferenceMdmConnectionsList.allocator);
				
		/* Construct a list of the ephemeral termination for lock/unlock usage */
		rvPtrListConstruct(&ephTermList, conferenceMdmConnectionsList.allocator);

		/* 1st, put in the lists the info of the new connection of the conference call */
		rvPtrListPushBack(&rtpList, rtpTerm1);
		rvPtrListPushBack(&mediaList, media1);				
		rvPtrListPushBack(&ephTermList, ephTerm1);				
		
		i=rvListBegin(&conferenceMdmConnectionsList);	
		for (index = 0; index < rvListSize(&conferenceMdmConnectionsList); index++)
		{
			conn = (RvCCConnection *)RvPtrListIterData(i);
			getRtpMediaObjects(conn, &ephTerm2, &rtpTerm2, &media2);
			rvPtrListPushBack(&rtpList, rtpTerm2);
			rvPtrListPushBack(&mediaList, media2);
			rvPtrListPushBack(&ephTermList, ephTerm2);				
/* Mutex 				RvMutexLock(&ephTerm2->mutex,IppLogMgr()); */
			i=rvListIterNext(i);
		}

		/* Call user callback to do the media mixing */
		if (mtfMgr->mediaClbks.disconnectMultiStreamsCB != NULL)
		{
			RvLogDebug(ippLogSource,(ippLogSource, "disconnectMultiStreamsCB() - before user callback, newConn =0x%p", newConn));		
			mtfMgr->mediaClbks.disconnectMultiStreamsCB(rtpList);
			RvLogDebug(ippLogSource,(ippLogSource, "disconnectMultiStreamsCB() - after user callback, newConn =0x%p", newConn));
		}
		else
		{
			RvLogInfo(ippLogSource,(ippLogSource,"disconnectMultiStreamsCB() - this callback was not registered by application, newConn=0x%p",
			                       	newConn));
		}
		
		/* Unlock ephemeral terminations */
		for(i=rvListBegin(&ephTermList); i!=rvListEnd(&ephTermList); i=rvListIterNext(i))
		{
			ephTerm2 = (RvCCTerminalMdm *)RvPtrListIterData(i);
/* Mutex 				RvMutexUnlock(&ephTerm2->mutex,IppLogMgr()); */
		}
		rvPtrListDestruct(&rtpList);
		rvPtrListDestruct(&mediaList);
		rvPtrListDestruct(&ephTermList);
	}
/* Mutex 		RvMutexUnlock(&ephTerm1->mutex,IppLogMgr()); */
}


#else /* RV_MTF_N_LINES */

static RvBool connectRtpTerms(
                RvCCConnection*     x,
                RvCCConnection*     otherConn)
{
    RvCCTerminal*           t = rvCCConnectionGetTerminal(x);
    RvCCTerminal*           at = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvCCTerminalMdm*        term = rvCCTerminalMdmGetImpl(at);
    RvCCTerminalMdm*        ephTerm1 = NULL, *ephTerm2 = NULL;
    RvMdmTerm*              rtpTerm1 = NULL, *rtpTerm2 = NULL;
    RvMdmMediaStreamInfo*   rtpMedia1 = NULL, *rtpMedia2 = NULL;
    RvBool                  res;

    /* Get RTP Media objects for 1st termination*/
    if ((getRtpMediaObjects(x, &ephTerm1, &rtpTerm1, &rtpMedia1)) == RV_FALSE)
        return RV_FALSE;

    /* Get RTP Media objects for 2nd termination*/
    if ((getRtpMediaObjects(otherConn, &ephTerm2, &rtpTerm2, &rtpMedia2)) == RV_FALSE)
        return RV_FALSE;

    /* Lock terminations*/
    RvMutexLock(&ephTerm1->mutex, IppLogMgr());
    RvMutexLock(&ephTerm2->mutex, IppLogMgr());

    RvLogInfo(ippLogSource,
        (ippLogSource,"connectRtpTerms:: Connecting 2 RTP terminations %s and %s for Line=%d and Line=%d",
         rvCCTerminalMdmGetId(ephTerm1), rvCCTerminalMdmGetId(ephTerm2),
         rvCCConnectionGetLineId(x), rvCCConnectionGetLineId(otherConn)));

    /* Connect media*/
		res = rvRtpConnectIntCB(x, rvCCTerminalMdmGetTermMgr(term), rtpTerm1, rtpMedia1,
							rtpTerm2, rtpMedia2, RV_MDMSTREAMDIRECTION_BOTHWAYS);

    if (res == RV_TRUE)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"connectRtpTerms:: RTP terminations %s and %s were connected successfully for Line=%d and Line=%d",
            rvCCTerminalMdmGetId(ephTerm1), rvCCTerminalMdmGetId(ephTerm2),
            rvCCConnectionGetLineId(x), rvCCConnectionGetLineId(otherConn)));

        rvMdmMediaStreamInfoSetStatusConnected(rtpMedia1);
        rvMdmMediaStreamInfoSetStatusConnected(rtpMedia2);
    }
    else
    {
        RvLogError(ippLogSource,
            (ippLogSource,"connectRtpTerms:: Failed to connect RTP terminations %s and %s for Line=%d and Line=%d",
            rvCCTerminalMdmGetId(ephTerm1), rvCCTerminalMdmGetId(ephTerm2),
            rvCCConnectionGetLineId(x), rvCCConnectionGetLineId(otherConn)));
    }

    /* Unlock terminations*/
    RvMutexUnlock(&ephTerm1->mutex,IppLogMgr());
    RvMutexUnlock(&ephTerm2->mutex,IppLogMgr());

    rvCCTextPrintMedia(x, rtpMedia1, "connectRtpTerms (Term 1)", RV_LOGLEVEL_DEBUG);
    rvCCTextPrintMedia(x, rtpMedia2, "connectRtpTerms (Term 2)", RV_LOGLEVEL_DEBUG);

    return res;

}

static RvBool disconnectRtpTerms(
                RvCCConnection*     x,
                RvCCConnection*     otherConn)
{
    RvCCTerminal*           t = rvCCConnectionGetTerminal(x);
    RvCCTerminal*           at = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvCCTerminalMdm*        term = rvCCTerminalMdmGetImpl(at);
    RvCCTerminalMdm*        ephTerm1 = NULL, *ephTerm2 = NULL;
    RvMdmTerm*              rtpTerm1 = NULL, *rtpTerm2 = NULL;
    RvMdmMediaStreamInfo*   rtpMedia1 = NULL, *rtpMedia2 = NULL;
    RvBool                  res;

    /* Get RTP Media objects for 1st termination*/
    if ((getRtpMediaObjects(x, &ephTerm1, &rtpTerm1, &rtpMedia1)) == RV_FALSE)
        return RV_FALSE;

    /* Get RTP Media objects for 2nd termination*/
    if ((getRtpMediaObjects(otherConn, &ephTerm2, &rtpTerm2, &rtpMedia2)) == RV_FALSE)
        return RV_FALSE;

    /* Lock both RTP terminations*/
    RvMutexLock(&ephTerm1->mutex,IppLogMgr());
    RvMutexLock(&ephTerm2->mutex,IppLogMgr());

    RvLogInfo(ippLogSource,
        (ippLogSource,"disconnectRtpTerms:: Disconnecting 2 RTP terminations %s and %s for Line=%d and Line=%d",
        rvCCTerminalMdmGetId(ephTerm1), rvCCTerminalMdmGetId(ephTerm2),
        rvCCConnectionGetLineId(x), rvCCConnectionGetLineId(otherConn)));

    /* Disconnect media*/
    res = rvRtpDisconnectIntCB(x, rvCCTerminalMdmGetTermMgr(term),
                               rtpTerm1, rtpMedia1, rtpTerm2, rtpMedia2);

    if (res == RV_TRUE)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"disconnectRtpTerms:: RTP terminations %s and %s were disconnected successfully for Line=%d and Line=%d",
            rvCCTerminalMdmGetId(ephTerm1), rvCCTerminalMdmGetId(ephTerm2),
            rvCCConnectionGetLineId(x), rvCCConnectionGetLineId(otherConn)));
    }
    else
    {
        RvLogError(ippLogSource,
            (ippLogSource,"disconnectRtpTerms:: Failed to disconnect RTP terminations %s and %s for Line=%d and Line=%d",
            rvCCTerminalMdmGetId(ephTerm1), rvCCTerminalMdmGetId(ephTerm2),
            rvCCConnectionGetLineId(x), rvCCConnectionGetLineId(otherConn)));
    }

    /* Unlock terminations*/
    RvMutexUnlock(&ephTerm1->mutex,IppLogMgr());
    RvMutexUnlock(&ephTerm2->mutex,IppLogMgr());

    return res;

}
#endif /* RV_MTF_N_LINES */

static RvBool stopMedia(RvCCConnection* x)
{
    RvCCConnMdm*            conn = rvCCConnMdmGetIns(x);
    RvCCTerminalMdm*        ephTerm = NULL;
    RvMdmTerm*              rtpTerm = NULL;
    RvMdmMediaStreamInfo*   rtpMedia = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
    {
        return RV_FALSE;
    }

    if (rvCCConnectionGetMediaState(x) == RV_CCMEDIASTATE_CONNECTED)
    {
       RvLogInfo(ippLogSource,(ippLogSource, "stopMedia:: Disconnecting media for Term=%s, conn=0x%p, Line=%d",
            rvCCTerminalMdmGetId(ephTerm), x, rvCCConnectionGetLineId(x)));

       rvCCConnMdmDisconnectMedia(x);
    }

    RvMutexLock(&ephTerm->mutex, IppLogMgr());

    RvLogInfo(ippLogSource,(ippLogSource, "stopMedia:: Destroying media for Term=%s, conn=0x%p, Line=%d",
        rvCCTerminalMdmGetId(ephTerm), x, rvCCConnectionGetLineId(x)));


    /*Close RTP media, leave line media always open*/
    if (rvRtpDestroyMediaIntCB(x, rtpTerm, rtpMedia) == RV_FALSE)
    {
        RvLogError(ippLogSource,(ippLogSource, "stopMedia:: Failed to Destroy media for Term=%s, conn=0x%p, Line=%d",
            rvCCTerminalMdmGetId(ephTerm), x, rvCCConnectionGetLineId(x)));
    }

	/* Call a deprecated callback */
	if (rvCCTerminalMdmGetTermMgr(ephTerm)->deleteEphF != NULL)
	{
		rvMdmTermMgrDeleteEphTerm_(rvCCTerminalMdmGetTermMgr(ephTerm), rtpTerm);
	}

    /*Remove this media stream from the termination*/
    rvCCTerminalMdmClearMediaStream(ephTerm, conn->streamId);
    conn->streamId = RV_MDM_STREAMID_NONE;

    RvMutexUnlock(&ephTerm->mutex, IppLogMgr());

    RvLogInfo(ippLogSource,(ippLogSource, "stopMedia:: Unregistering Term=%s, conn=0x%p, Line=%d",
        rvCCTerminalMdmGetId(ephTerm), x, rvCCConnectionGetLineId(x)));

    rvMdmTermMgrUnregisterTermination(rvCCTerminalMdmGetTermMgr(ephTerm), rtpTerm, NULL);

    /*We don't want to overwrite some problematic states like MEDIA_FAILED */
    if (rvCCConnectionGetMediaState(x) == RV_CCMEDIASTATE_CONNECTED)
    {
       rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_DISCONNECTED);
    }

    RvLogInfo(ippLogSource,(ippLogSource, "stopMedia:: Media was destroyed successfully for conn=0x%p, Line=%d",
        x, rvCCConnectionGetLineId(x)));

    return RV_TRUE;
}

static void setResponseMedia(
                RvMdmMediaStreamInfo*   media,
                RvMdmMediaDescriptor*   rspMedia)
{
    const RvSdpMsg*                 sdp;
    const RvMdmStreamDescriptor*    descr = rvMdmMediaDescriptorGetStream(rspMedia, rvMdmMediaDescriptorGetNumStreams(rspMedia)-1);

    if (rvMdmStreamDescriptorIsLocalDescriptorSet(descr) == RV_TRUE)
    {
        /* Always take the first one */
        sdp = rvMdmStreamDescriptorGetLocalDescriptor(descr, 0);
        rvMdmStreamDescriptorClearLocalDescriptors(&media->streamDescr);
        rvMdmMediaStreamInfoAddLocalDescriptor(media,(RvSdpMsg *)sdp);
    }
}

/*Note: Check if mode,parameters,reserve can also be absent,what to do...*/
static void fillMdmInfo(
                RvMdmMediaStreamInfo*   x,
                RvMdmMediaStreamDescr*  descr)
{
    RvSdpMsgList* local = NULL, *remote = NULL;

    if(rvMdmStreamDescriptorIsLocalDescriptorSet(&x->streamDescr))
    {
        local = &x->streamDescr.localDescriptors;
    }
    else
    {
        local = NULL;
    }

    if( rvMdmStreamDescriptorIsRemoteDescriptorSet(&x->streamDescr))
    {
        remote = &x->streamDescr.remoteDescriptors;
    }
    else
    {
        remote = NULL;
    }

    rvMdmMediaStreamDescrConstruct_(
        descr, rvMdmStreamDescriptorGetMode(&x->streamDescr), local, remote);
}

/***************************************************************************
 * setStreamMode
 * ------------------------------------------------------------------------
 * General:      This function sets stream direction in "media" parameter
 *               according to TermConn state.
 *
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x        -  Mdm connection
 *          media    -  Local media
 * Output   media  -   stream mode will be changed
 *
 ***************************************************************************/
static void setStreamMode(
                          IN RvCCConnection*            x,
                          INOUT RvMdmMediaStreamInfo*   media)
{
    RvMdmStreamDescriptor*  streamDescr = rvMdmMediaStreamInfoGetStreamDescriptor(media);
    RvMdmStreamMode streamMode;

    switch (rvCCConnectionGetTermState(x))
    {
        case RV_CCTERMCONSTATE_REMOTE_HELD:
        case RV_CCTERMCONSTATE_MUTE:
            streamMode = RV_MDMSTREAMMODE_RECVONLY;
            break;

        case RV_CCTERMCONSTATE_HELD:
            streamMode = RV_MDMSTREAMMODE_SENDONLY;
            break;

        case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:
            streamMode = RV_MDMSTREAMMODE_INACTIVE;
            break;

        default:
            streamMode = RV_MDMSTREAMMODE_SENDRECV;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    rvMdmStreamDescriptorSetMode(streamDescr, streamMode);

    RvLogInfo(ippLogSource,
        (ippLogSource, "setStreamMode:: Stream Mode was set to: %s, conn=0x%p",
        rvCCTextStreamMode(streamMode), x));

}

static RvBool modifyMedia(
                RvCCConnection*         x,
                RvMdmMediaCommand       cmd,
                RvCCTerminalMdm*        ephTerm,
                RvMdmMediaStreamInfo*   media,
                RvSdpMsg*               sdpMediaCaps)
{
    RvMdmMediaStreamDescr   mdmMediaInfo;
    RvMdmMediaParam*        param = &mdmMediaInfo.param;
    RvSdpMsg*               localSdp  = rvSdpMsgListGetElement( &media->streamDescr.localDescriptors, 0);
    RvSdpMsg*               remoteSdp = rvSdpMsgListGetElement( &media->streamDescr.remoteDescriptors, 0);

	/* Change stream mode according to connTerm state*/
    setStreamMode(x, media);

    /* Fill the mdm object with the media information */
    fillMdmInfo( media,  &mdmMediaInfo);

    param->cmd = cmd;
    switch (param->cmd)
    {
    case RVMDM_CMD_MUTE_ALL:
    case RVMDM_CMD_UNMUTE_ALL:
        param->mute_all.remoteSdp = remoteSdp;
        break;

    case RVMDM_CMD_HOLD_REMOTE:
    case RVMDM_CMD_UNHOLD_REMOTE:
    case RVMDM_CMD_HOLD_LOCAL_TO_INACTIVE:
    case RVMDM_CMD_UNHOLD_INACTIVE_TO_LOCAL:
        param->hold_remote.remoteSdp = remoteSdp;
        break;

    case RVMDM_CMD_HOLD_LOCAL:
    case RVMDM_CMD_UNHOLD_LOCAL:
    case RVMDM_CMD_HOLD_REMOTE_TO_INACTIVE:
    case RVMDM_CMD_UNHOLD_INACTIVE_TO_REMOTE:
        param->hold_local.localSdp = localSdp;
        break;

    case RVMDM_CMD_NORMAL:
        param->normal.localSdp = localSdp;
        param->normal.remoteSdp= remoteSdp;
        param->normal.localCapsSdp = sdpMediaCaps;
        break;

    case RVMDM_CMD_IDLE:
    case RVMDM_CMD_CREATE:
    case RVMDM_CMD_UNKNOWN:
    default:
        RvLogWarning(ippLogSource,(ippLogSource,"modifyMedia::Command is Not Supported (%d), Terminal=%s, Line:%d (0x%p)",
                                      param->cmd , rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"modifyMedia::Modifying Media (command=%d) for Terminal=%s, Line:%d (0x%p)",
        param->cmd, rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));

    rvCCTextPrintMedia(x, media, "modifyMedia::Offering Local Capabilities", RV_LOGLEVEL_INFO);

	if  (rvRtpModifyMediaIntCB(x, &ephTerm->mdmTerm, &mdmMediaInfo)== RV_FALSE)
    {
        RvLogError(ippLogSource,(ippLogSource,"modifyMedia::Failed to Modify Media (command=%d) for Terminal=%s, Line:%d (0x%p)",
            param->cmd, rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));

        rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_FAILED);
        return RV_FALSE;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"modifyMedia::Media was Modified Successfully for:%s, Line:%d (%p)",
        rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));

    rvCCTextPrintSdpMsg(
        rvSdpMsgListGetElement(rvMdmMediaStreamDescrGetLocalDescr(&mdmMediaInfo), 0),
        "Capabilities Chosen by User", RV_LOGLEVEL_INFO);

    return RV_TRUE;
}

#ifdef RV_MTF_SECOND_VIDEO
RvBool rvCCConnMdmModifyPresentationStream(RvCCConnection* x, RvSdpMsg* sdp,
										   RvMtfMediaStreamHandle streamHndl, 
										   RvSdpMediaDescr *streamDescr,
										   RvMtfMediaType type,
										   RvMtfMediaStreamDirection streamDirection,
										   RvMtfMediaAction action,
										   RvMtfMediaStreamAppHandle* applStreamHndl)
{
	RvCCTerminal* eph           = NULL;
	RvCCTerminalMdm* ephTerm    = NULL;
	RvMtfMediaStreamParams  mediaStreamParams;
	RvChar		str[256];

	/* get terminal */
	eph = rvCCConnMdmGetEphXTerm(x);
	if (eph == NULL)
		return RV_FALSE;

	ephTerm = rvCCTerminalMdmGetImpl(eph);
	if (ephTerm == NULL)
		return RV_FALSE;

	/* fill in media stream params */
	mediaStreamParams.action = action;  
	mediaStreamParams.streamDescriptor = streamDescr;
	mediaStreamParams.type = type;
	mediaStreamParams.streamDirection = streamDirection;
	mediaStreamParams.sdp = sdp;

	RvLogInfo(ippLogSource,
		(ippLogSource,"rvCCConnMdmModifyPresentationStream:: Terminal=%s, Line:%d (0x%p)",
		rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));
	if (streamDirection == RVMTF_MEDIA_STREAM_SEND)
	{
		sprintf(str, "rvCCConnMdmModifyPresentationStream() streamHndl=%p applStreamHndl=%p Action=%d on transmitter for media stream:",
			          streamHndl, *applStreamHndl, mediaStreamParams.action);
		rvCCTextPrintMediaStreamDescr(streamDescr, str, RV_LOGLEVEL_INFO);
	}
	else
	{
		sprintf(str, "rvCCConnMdmModifyPresentationStream() streamHndl=%p applStreamHndl=%p Action=%d on transmitter for media stream:",
			streamHndl, *applStreamHndl, mediaStreamParams.action);
		rvCCTextPrintMediaStreamDescr(streamDescr, str, RV_LOGLEVEL_INFO);	
	}

	/* invoke modify media callback */
	if  (rvRtpModifySpecificMediaStreamIntCB(x, streamHndl, &ephTerm->mdmTerm, &mediaStreamParams, applStreamHndl)== RV_FALSE)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnMdmModifyPresentationStream::Failed to Modify Media Stream for Terminal=%s, Line:%d (0x%p)",
			rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));

		rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_FAILED);
		return RV_FALSE;
	}

	RvLogInfo(ippLogSource,
		(ippLogSource,"rvCCConnMdmModifyPresentationStream::modified Successfully for:%s, Line:%d (%p)",
		rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));

	if (streamDirection == RVMTF_MEDIA_STREAM_RECEIVE)
 	{
		rvCCTextPrintMediaStreamDescr(streamDescr, "rvCCConnMdmModifyPresentationStream(): media capabilities with port Chosen by User", RV_LOGLEVEL_INFO);
 	}
	return RV_TRUE;
}
#endif /* RV_MTF_SECOND_VIDEO */

/* Reset the connection state back to idle,and internal values as well */
void rvCCConnMdmClear(RvCCConnection* x)
{
    RvCCConnMdm* conn = rvCCConnMdmGetIns(x);

    rvIppMdmExtConnectionDestructedCB(x);

    conn->ephTerm = NULL;
    rvStringDestruct(&conn->dialString);

    conn->ephTerm = NULL;
    rvStringConstruct(&conn->dialString, "", conn->alloc);
    conn->streamId = RV_MDM_STREAMID_NONE;

    rvCCConnectionResetState(x);

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCConnMdmClear::Cleared Connection=0x%p, Line=%d",
        x, rvCCConnectionGetLineId(x)));

}

/***************************************************************************
 * rvCCConnMdmAcceptCallWaiting
 * ------------------------------------------------------------------------
 * General: This function is called when a new call arrives as a Call Waiting,
 *          we open media for the new call and apply Call Waiting signals
 *          on the terminal.
 * Return Value: media(!) state
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  MDM connection
 ***************************************************************************/
static RvCCMediaState rvCCConnMdmAcceptCallWaiting(RvCCConnection* x)
{
    RvCCTerminal*   t = rvCCConnectionGetTerminal(x);
    RvCCMediaState  state;

    RvLogInfo(ippLogSource,(ippLogSource,"rvCCConnMdmAcceptCallWaiting: creating media for the new call, c=%p (line:%d)",
        x, rvCCConnectionGetLineId(x)));

    /* Create media for the new call */
    state = rvCCConnectionCreateMedia(x, NULL);

    if((state != RV_CCMEDIASTATE_FAILED) && (state != RV_CCMEDIASTATE_NOTSUPPORTED))
    {
        RvCCConnection* activeConn = rvCCTerminalGetActiveConnection(t);
        /* If there is already a connection ringing in the phone,
           don't play the call waiting to avoid the ringing being stopped */
        if (activeConn->state == RV_CCCONNSTATE_CONNECTED)
        {
            rvCCTerminalMdmStartCallWaitingSignal(t);
        }
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_FAST_BLINK);

        RvLogInfo(ippLogSource,(ippLogSource,"rvCCConnMdmAcceptCallWaiting: starting call waiting signals for c=%p (line:%d), activeConn=%p (line:%d)",
            x, rvCCConnectionGetLineId(x), activeConn, rvCCConnectionGetLineId(activeConn)));
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCConnMdmAcceptCallWaiting: creating media failed for c=%p (line:%d)",
            x, rvCCConnectionGetLineId(x)));
    }

    return state;
}


/***************************************************************************
 * rvCCConnMdmAccept
 * ------------------------------------------------------------------------
 * General: Mdm connection accepts a call from Network connection
 * Return Value: media(!) state
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  MDM connection
 ***************************************************************************/
static RvCCMediaState rvCCConnMdmAccept(RvCCConnection* x)
{
    RvCCTerminal*   t = rvCCConnectionGetTerminal(x);
    RvCCMediaState  state;

    RvLogInfo(ippLogSource,(ippLogSource,"rvCCConnMdmAccept: creating media for the new call, c=%p (line:%d)",
        x, rvCCConnectionGetLineId(x)));

    state = rvCCConnectionCreateMedia(x, NULL);

    if ((state != RV_CCMEDIASTATE_FAILED) && (state != RV_CCMEDIASTATE_NOTSUPPORTED))
    {
        rvCCTerminalMdmStartRingingSignal(t);
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_FAST_BLINK);

        RvLogInfo(ippLogSource,(ippLogSource,"rvCCConnMdmAccept: starting signals for the new call, c=%p (line:%d)",
            x, rvCCConnectionGetLineId(x)));
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCConnMdmAccept: creating media failed for c=%p (line:%d)",
            x, rvCCConnectionGetLineId(x)));
    }

    return state;
}

/***************************************************************************
 * isOtherLineRinging
 * ------------------------------------------------------------------------
 * General: This function checks whether another connection is ringing
 * Return Value: True if any other connection is ringing, False if not.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to MDM connection
 *
 * Output   None
 ***************************************************************************/
static RvBool isOtherLineRinging(RvCCConnection* x)
{
    RvCCTerminal*   t = rvCCConnectionGetTerminal(x);
    int             i;

    for(i=0; ;i++)
    {
        RvCCConnection* c = rvCCTerminalGetConnectionByIndex(t, i);

        if (c == NULL)
        {
            /* Done looping through connections, no ringing line was found */
            RvLogDebug(ippLogSource,
                (ippLogSource,"isOtherLineRinging::returning False for conn=0x%p, Line=%d",
                x, rvCCConnectionGetLineId(x)));

            return RV_FALSE;
        }

        if (c == x)
        {
            /* Same connection, keep on to next one */
            continue;
        }

        if (c->state == RV_CCCONNSTATE_ALERTING)
        {
            /* We found a ringing line, and it's not us */
            RvLogDebug(ippLogSource,
                (ippLogSource,"isOtherLineRinging::returning True (found conn=0x%p, Line=%d) for conn=0x%p, Line=%d",
                 c, rvCCConnectionGetLineId(c), x, rvCCConnectionGetLineId(x)));

            return RV_TRUE;
        }
    }
}

/***************************************************************************
 * initRtpMedia
 * ------------------------------------------------------------------------
 * General: This function initializes objects required for RTP media, and calls
 *          user callback RvMdmTermMgrSelectRtpTermCB() for creating RTP termination.
 * Return Value: The media capabilities
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          conn -  pointer to Mdm connection
 *          term -  Mdm terminal
 * Output   eph  -  Created or obtained Ephimeral RTP terminal
 ***************************************************************************/
static RvMdmMediaStreamInfo* initRtpMedia(
                RvCCConnection*         x,
                RvCCConnMdm*            conn,
                RvCCTerminalMdm*        term,
                RvCCTerminal**          eph)
{
    RvCCTerminalMdm*        ephTerm;
    RvMdmMediaStreamInfo*   media;

    RvLogInfo(ippLogSource,(ippLogSource, "initRtpMedia: creating RTP Media for term=%s, c=%p, conn=%p (line=%d)",
        rvCCTerminalMdmGetId(term), x, conn, rvCCConnectionGetLineId(x)));

    if (conn->streamId == RV_MDM_STREAMID_NONE)
    {
        if ((*eph = rvCCTerminalMdmSelectRtpTerm(term, x)) == NULL)
        {
            RvLogError(ippLogSource,(ippLogSource, "initRtpMedia: user callback for selecting RTP termination returned NULL, term=%s, c=%p, conn=%p (line=%d)",
                rvCCTerminalMdmGetId(term), x, conn, rvCCConnectionGetLineId(x)));

            return NULL;
        }

        RvLogInfo(ippLogSource,(ippLogSource, "initRtpMedia: user callback for selecting RTP termination returned eph=%s, term=%s, c=%p, conn=%p (line=%d)",
            rvCCTerminalGetId(*eph), rvCCTerminalMdmGetId(term), x, conn, rvCCConnectionGetLineId(x)));

        ephTerm = rvCCTerminalMdmGetImpl((*eph));
        conn->streamId = rvCCTerminalMdmAddEmptyMediaStream(ephTerm);

        RvLogInfo(ippLogSource,(ippLogSource, "initRtpMedia: added a new stream: %d,  eph=%s, term=%s, c=%p, conn=%p (line=%d)",
            conn->streamId, rvCCTerminalMdmGetId(ephTerm), rvCCTerminalMdmGetId(term), x, conn, rvCCConnectionGetLineId(x)));

    }
    else
    {
        *eph = rvCCConnMdmGetEphXTerm(x);
        ephTerm = rvCCTerminalMdmGetImpl((*eph));

        RvLogInfo(ippLogSource,(ippLogSource, "initRtpMedia: stream already exists: %d, eph=%s, term=%s, c=%p, conn=%p (line=%d)",
            conn->streamId, rvCCTerminalMdmGetId(ephTerm), rvCCTerminalMdmGetId(term), x, conn, rvCCConnectionGetLineId(x)));

    }

    RvMutexLock(&ephTerm->mutex,IppLogMgr());

    media =  rvCCTerminalMdmGetMediaStream(ephTerm, conn->streamId);

    RvMutexUnlock(&ephTerm->mutex,IppLogMgr());

    rvCCTextPrintMedia(x, media, "initRtpMedia::RTP media was initiated successfully", RV_LOGLEVEL_INFO);

    return media;
}

/***************************************************************************
 * isDialStringMatching
 * ------------------------------------------------------------------------
 * General: This function checks whether the digits pressed by the user match
 *          a predefined digitmap pattern.
 * Return Value: True if there is a match, False if not.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   term -  pointer to the termination
 *
 * Output   None
 ***************************************************************************/
static RvBool isDialStringMatching(RvCCTerminalMdm* term)
{
    RvMdmEvent*                 event;
    const RvMdmParameterValue*  param;
    const RvMdmParameterList*   args;
    const char*                 value;

    event = rvCCTerminalMdmGetLastEvent(term);
    args = rvMdmEventGetParameterList(event);
    param = rvMdmParameterListGet2(args, "Meth");

    if (param == NULL)
    {
        return RV_FALSE;
    }

    value = rvMdmParameterValueGetValue(param);
    if (!strcmp("UM", value) || !strcmp("FM", value))
    {
        RvLogDebug(ippLogSource,
            (ippLogSource, "isDialStringMatching::Returning True (matching result=%s) for Terminal=%s (0x%p)",
            value, rvCCTerminalMdmGetId(term), term));
        return RV_TRUE;
    }
    else
    {
        RvLogDebug(ippLogSource,
            (ippLogSource, "isDialStringMatching::Returning False (matching result=%s) for Terminal=%s (0x%p)",
            value, rvCCTerminalMdmGetId(term), term));
        return RV_FALSE;
     }
}


/***************************************************************************
 * createRtpMedia
 * ------------------------------------------------------------------------
 * General: This function is calling user callback to indicate a new RTP session
 *          should be created.
 * Return Value: media state indicating whether RTP session was created or not.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          term -  pointer to the termination
 * Output   None
 ***************************************************************************/
RvCCMediaState createRtpMedia(
                RvCCConnection*     x,
                RvCCTerminal*       t)
{
    RvCCTerminalMdm*        term = rvCCTerminalMdmGetImpl(t);
    RvCCTerminal*           eph;
    RvCCTerminalMdm*        ephTerm;
    RvCCConnMdm*            conn = rvCCConnMdmGetIns(x);
    RvMdmMediaStreamInfo*   media;
    RvMdmMediaStreamDescr   mdmMediaInfo;
    RvMdmMediaParam*        param = &mdmMediaInfo.param;
    RvCCMediaState          mediaState;

    RvLogInfo(ippLogSource,
        (ippLogSource, "createRtpMedia::Creating RTP media for Terminal=%s, Line=%d",
         rvCCTerminalGetId(t), rvCCConnectionGetLineId(x)));

    /* Create Ephemeral Termination*/
    if ((media = initRtpMedia(x, conn, term, &eph)) == NULL)
    {
        RvLogError(ippLogSource,
            (ippLogSource, "createRtpMedia::Initiating RTP media failed for Terminal=%s, Line=%d",
             rvCCTerminalGetId(t), rvCCConnectionGetLineId(x)));
        return RV_CCMEDIASTATE_FAILED;
    }

    if (rvMdmMediaStreamInfoIsLocalDescriptorSet( media))
    {
        RvLogInfo(ippLogSource,
            (ippLogSource, "createRtpMedia::RTP Media already exists for Terminal=%s, Line=%d",
             rvCCTerminalGetId(t), rvCCConnectionGetLineId(x)));
        return RV_CCMEDIASTATE_CREATED;
    }

    rvCCTerminalMdmSetDefaultMedia(eph, (int)conn->streamId, rvCCTerminalMdmGetTermId(t));

    ephTerm = rvCCTerminalMdmGetImpl(eph);

    param->cmd = RVMDM_CMD_CREATE;
    param->normal.localSdp  = rvSdpMsgListGetElement( &media->streamDescr.localDescriptors, 0);
    param->normal.remoteSdp = rvSdpMsgListGetElement( &media->streamDescr.remoteDescriptors, 0);
    param->normal.localCapsSdp = rvCCConnMdmGetMediaCaps(x);

    RvMutexLock(&ephTerm->mutex,IppLogMgr());

    /* Fill the mdm object with the media information */
    fillMdmInfo( media,  &mdmMediaInfo);

    rvCCTextPrintMedia(x, media, "createRtpMedia::Offering local capabilities", RV_LOGLEVEL_INFO);


        /* Call MTF internal callback to create a new media stream and set parameters */
    if (rvRtpCreateMediaIntCB(x, &ephTerm->mdmTerm, &mdmMediaInfo) == rvFalse)
	{
		if (x->state == RV_CCCONNSTATE_OFFERED)
		{
				mediaState = RV_CCMEDIASTATE_NOTSUPPORTED;
		}
		else
		{
				mediaState = RV_CCMEDIASTATE_FAILED;
		}

		rvCCConnectionSetMediaState(x, mediaState);
		RvMutexUnlock(&ephTerm->mutex,IppLogMgr());

		RvLogError(ippLogSource,
			(ippLogSource, "createRtpMedia::Creating RTP Media failed for Term=%s, Line=%d, media state=%s",
			 rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), rvCCTextMediaState(mediaState)));

		return mediaState;
	}
	
    RvMutexUnlock(&ephTerm->mutex,IppLogMgr());

    RvLogInfo(ippLogSource,
        (ippLogSource, "createRtpMedia::RTP Media was created successfully for Term=%s, Line=%d",
         rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x)));

    rvCCTextPrintSdpMsg(
        rvSdpMsgListGetElement(rvMdmMediaStreamDescrGetLocalDescr(&mdmMediaInfo), 0),
        "Capabilities chosen by user for creating media", RV_LOGLEVEL_INFO);

    return RV_CCMEDIASTATE_CREATED;
}

/*===============================================================================*/
/*===============      U T I L I T Y    F U N C T I O N S    ====================*/
/*===============================================================================*/

/***************************************************************************
 * rvCCConnMdmIsReInviteForHold
 * ------------------------------------------------------------------------
 * General: This function checks whether the Re-Invite was received for
 *          Hold, by processing the SDP message received in message body.
 *
 *
 * Return Value: True if message was received for Hold
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     c      -    pointer to the call connection object
 *            sdpMsg -    The SDP message received in message body
 *
 *
 ***************************************************************************/
RvBool rvCCConnMdmIsReInviteForHold(RvCCConnection *c, RvSdpMsg* sdpMsg)
{
    RvSdpMediaDescr*    descr;
    RvSdpConnection*    sdpConn;
    RvBool              hold = RV_FALSE;
    RvSdpConnectionMode mode;
    RvSize_t            n, i;
	RvCCTermConnState   termState;

    /*
     *  we 3 checks
     * 1. if c=IN IP4 0.0.0.0  exists on msg level
     * 2. if a= sendonly  exists on msg level
     * 3. if c=IN IP4 0.0.0.0  exists on m= level for audio m=
     * 4. if a= sendonly  exists on m=  level for audio m=
     */

    sdpConn = rvSdpMsgGetConnection(sdpMsg);
    /* Check field "c=IN IP4 0.0.0.0" */
    if(sdpConn)
    {
        hold = ((strcmp( rvSdpConnectionGetAddress(sdpConn),"0.0.0.0") == 0) ||
                (strcmp( rvSdpConnectionGetAddress(sdpConn),"0:0:0:0:0:0:0:0") == 0));
        if (hold)
        {
            return RV_TRUE;
        }
    }

	termState = rvCCConnectionGetTermState(c);
    mode = rvSdpMsgGetConnectionMode(sdpMsg);
    hold = (mode == RV_SDPCONNECTMODE_SENDONLY) || 
		   ((mode == RV_SDPCONNECTMODE_INACTIVE) && (termState == RV_CCTERMCONSTATE_HELD));
    if (hold)
    {
        return RV_TRUE;
    }

    /* Check field "a=sendonly" or "a=inactive" */
    n = rvSdpMsgGetNumOfMediaDescr(sdpMsg);
    for( i=0; i < n; i++)
    {
        descr = rvSdpMsgGetMediaDescr(sdpMsg, i);

        if (rvSdpMediaDescrGetMediaType(descr) == RV_SDPMEDIATYPE_AUDIO ||
            rvSdpMediaDescrGetMediaType(descr) == RV_SDPMEDIATYPE_VIDEO)
        {
            sdpConn = rvSdpMediaDescrGetConnection(sdpMsg);
            if (sdpConn)
            {
                hold = ((strcmp( rvSdpConnectionGetAddress(sdpConn),"0.0.0.0") == 0) ||
                    (strcmp( rvSdpConnectionGetAddress(sdpConn),"0:0:0:0:0:0:0:0") == 0));
                if (hold)
                {
                    return RV_TRUE;
                }
            }

            mode = rvSdpMediaDescrGetConnectionMode(descr);
            hold = (mode == RV_SDPCONNECTMODE_SENDONLY) || 
				  ((mode == RV_SDPCONNECTMODE_INACTIVE) && (termState == RV_CCTERMCONSTATE_HELD));
            if (hold)
            {
                return RV_TRUE;
            }
        }
    }

    RvLogDebug(ippLogSource,
        (ippLogSource,"isReInviteForHold:: Returning False for sdp=0x%p", sdpMsg));

    return RV_FALSE;
}

/***************************************************************************
 * rvCCConnMdmIsReInviteForUnhold
 * ------------------------------------------------------------------------
 * General: This function checks whether the Re-Invite was received for
 *          Unhold, by checking the connection state.
 *
 *
 * Return Value: True if message was received for Unhold
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   c   -   pointer to connection
 *
 *
 ***************************************************************************/
RvBool rvCCConnMdmIsReInviteForUnhold(RvCCConnection* c)
{
    RvBool              rc = RV_FALSE;
    RvCCTermConnState   termState;

    termState = rvCCConnectionGetTermState(c);
    rc = (  termState == RV_CCTERMCONSTATE_REMOTE_HELD ||
            termState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD);

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCConnMdmIsReInviteForUnhold:: Returning %d for conn=0x%p, Line=%d", rc, c, rvCCConnectionGetLineId(c)));

    return rc;
}
/*===============================================================================*/
/*===============    C O N N E C T I O N   C A L L B A C K S ====================*/
/*===============================================================================*/

/***************************************************************************
 * rvCCConnMdmInitiatedCB
 * ------------------------------------------------------------------------
 * General: This callback is called when a new line was activated by the user
 *          (meaning, user pressed off-hook or line). Dial tone starts and
 *          digits are expected.
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *
 * Output   None
 ***************************************************************************/
void rvCCConnMdmInitiatedCB(RvCCConnection* x)
{
    RvCCTerminal*       t = rvCCConnectionGetTerminal(x);
    RvCCTerminalMdm*    term = rvCCTerminalMdmGetImpl(t);
    RvCCProvider*       p = rvCCTerminalMdmGetProvider(term);

    rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_ON);
    rvCCTerminalMdmSendLineActive(t, rvCCConnectionGetLineId(x), RV_TRUE);
    rvCCTerminalMdmStartDialToneSignal(t);
    IppTimerStart(rvCCTerminalMdmGetDialToneTimer(t),IPP_TIMER_RESTART_IF_STARTED,rvCCProviderMdmGetDialToneDuration(p));

    rvCCTerminalMdmSetWaitForDigits(t);

    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnMdmInitiatedCB::Connection was initiated, dial tone timer=%d, conn=0x%p, Line=%d",
         rvCCTerminalMdmGetDialToneTimer(t), x, rvCCConnectionGetLineId(x)));
}

/***************************************************************************
 * rvCCConnMdmNewDigitCB
 * ------------------------------------------------------------------------
 * General: This callback is called whenever user presses a digit.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          reason - indicates whether digit was pressed (RV_CCCAUSE_EVENT_BEGIN)
 *          or released (RV_CCCAUSE_EVENT_END)
 * Output   None
 ***************************************************************************/
void rvCCConnMdmNewDigitCB(
                RvCCConnection*     x,
                RvCCEventCause      reason)
{
    RvCCTerminal*       t = rvCCConnMdmGetTerminal(x);
    char                digit = rvCCTerminalMdmGetLastDigit(t);
    RvDtmfParameters    dtmfParam;
	RvInt32             lineId = rvCCConnectionGetLineId(x);

    rvDtmfParametersInit(&dtmfParam);
    dtmfParam.digit = digit;

    /* Ignore digits if terminal is in dialing state, or in cfw activation process. */
    if ((x->state != RV_CCCONNSTATE_DIALING)
        && (rvCCTerminalGetState(t) != RV_CCTERMINAL_CFW_ACTIVATING_STATE))
    {
        RvLogInfo(ippLogSource,
            (ippLogSource, "rvCCConnMdmNewDigitCB::terminal is not in Dialing or CFW states, ignoring digit =%c, c=0x%p, Line=%d",
            dtmfParam.digit, x, lineId));
        return;
    }

    /*Stop signals after first digit is pressed (call it once)*/
    if ((rvCCTerminalMdmIsFirstDigit(t)) && (reason == RV_CCCAUSE_EVENT_BEGIN))
    {
        RvLogInfo(ippLogSource,
            (ippLogSource, "rvCCConnMdmNewDigitCB::first digit was pressed, stopping signals, digit =%c, c=0x%p, Line=%d",
            dtmfParam.digit, x, lineId));

        IppTimerStop(rvCCTerminalMdmGetDialToneTimer(t));
        rvCCTerminalMdmStopSignals(t);
    }

    if (rvCCTerminalMdmIsDtmfPlayEnabled(t))
    {
        if (reason == RV_CCCAUSE_EVENT_BEGIN)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCConnMdmNewDigitCB::start DTMF tone, digit =%c, duration=%d, c=0x%p, Line=%d",
                dtmfParam.digit, dtmfParam.duration, x, lineId));

            rvCCTerminalMdmStartDTMFTone(t, lineId, &dtmfParam);
        }
        else if (reason == RV_CCCAUSE_EVENT_END)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCConnMdmNewDigitCB::stop DTMF tone, digit =%c, duration=%d, c=0x%p, Line=%d",
                dtmfParam.digit, dtmfParam.duration, x, lineId));

            rvCCTerminalMdmStopDTMFTone(t);
        }
    }
    else
    {
        RvLogInfo(ippLogSource,
            (ippLogSource, "rvCCConnMdmNewDigitCB::play DTMF is off, digit =%c, duration=%d, c=0x%p, Line=%d",
            dtmfParam.digit, dtmfParam.duration, x, lineId));
    }
}

/***************************************************************************
 * rvCCConnMdmCallDeliveredCB
 * ------------------------------------------------------------------------
 * General: This callback is called when a new outgoing call was delivered.
 *          The function starts the appropriate signals.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          reason - indicates whether call is normal (RV_CCCAUSE_NORMAL)
 *          or call waiting (RV_CCCAUSE_CALL_WAITING)
 * Output   None
 ***************************************************************************/
void rvCCConnMdmCallDeliveredCB(
                RvCCConnection*     x,
                RvCCEventCause      reason)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCConnMdmCallDeliveredCB::outgoing call is delivered, reason=%s, c=0x%p, Line=%d",
        rvCCTextCause(reason), x, rvCCConnectionGetLineId(x)));

    if (reason == RV_CCCAUSE_CALL_WAITING)
    {
        rvCCTerminalMdmStartCallWaitingCallerSignal(t);
    }
    else
    {
        rvCCTerminalMdmStartRingbackSignal(t);
    }
}

/***************************************************************************
 * rvCCConnMdmOfferedCB
 * ------------------------------------------------------------------------
 * General: This callback is called when a new incoming call was arrived. The
 *          function starts the appropriate signals and creates a new media session
 *          for the call.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          reason - indicates whether call is normal (RV_CCCAUSE_NORMAL)
 *          or call waiting (RV_CCCAUSE_CALL_WAITING)
 * Output   None
 ***************************************************************************/
RvCCMediaState rvCCConnMdmOfferedCB(
                RvCCConnection*     x,
                RvCCEventCause      reason)
{
    RvCCTerminal*   t = rvCCConnectionGetTerminal(x);
    RvCCMediaState  mediaState;

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCConnMdmOfferedCB::incoming call is offered, reason=%s, c=0x%p, Line=%d",
        rvCCTextCause(reason), x, rvCCConnectionGetLineId(x)));

    /* Line sends "active" signal only for incoming call,
       for outgoing call it was already sent in the off-hook */
    rvCCTerminalMdmSendLineActive(t, rvCCConnectionGetLineId(x),RV_TRUE);

    if (reason == RV_CCCAUSE_CALL_WAITING)
    {
        mediaState = rvCCConnMdmAcceptCallWaiting(x);
    }
    else
    {
        mediaState = rvCCConnMdmAccept(x);
    }

    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnMdmOfferedCB::returning media state=%s, c=0x%p, Line=%d",
        rvCCTextMediaState(mediaState), x, rvCCConnectionGetLineId(x)));

    return mediaState;
}

/***************************************************************************
 * rvCCConnMdmCallAnsweredCB
 * ------------------------------------------------------------------------
 * General: This callback is called when a new incoming call was answered by local
 *          user (meaning, off hook or Line was pressed). The function stops the
 *          playing signals and connects the media session with remote party.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          reason - indicates whether call is normal (RV_CCCAUSE_NORMAL)
 *          or call waiting (RV_CCCAUSE_CALL_WAITING)
 * Output   None
 ***************************************************************************/
RvBool rvCCConnMdmCallAnsweredCB(RvCCConnection* x)
{
    RvCCTerminal*   t = rvCCConnectionGetTerminal(x);
    RvBool          res = RV_TRUE;

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCConnMdmCallAnsweredCB::incoming call is answered - stopping signals and connecting media, c=0x%p, Line=%d",
          x, rvCCConnectionGetLineId(x)));

    rvCCTerminalMdmStopRingingSignal(t);
    rvCCTerminalMdmStopSignals(t);

    rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_ON);

    /* Line sends "active" signal only for incoming call,
       for outgoing call it was already sent in the off-hook */

    if (rvCCConnectionGetState(x) != RV_CCCONNSTATE_CONNECTED)
    {
        res = rvCCConnMdmConnectMedia(x);
    }

    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnMdmCallAnsweredCB::connected media result=%d, c=0x%p, Line=%d",
        res, x, rvCCConnectionGetLineId(x)));

    return res;
}

RvCCMediaState rvCCConnMdmTransferOfferedCB(RvCCConnection* x)
{
    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCConnMdmTransferOfferedCB::connecting media for c=0x%p, Line=%d",
         x, rvCCConnectionGetLineId(x)));

    /*We don't destroy media when connection is disconnected, so no need
      to create it here*/

    rvCCConnMdmConnectMedia(x);

    return RV_CCMEDIASTATE_CREATED;
}

/*===============================================================================*/
/*=======================    C O N N E C T I O N   A P I ========================*/
/*===============================================================================*/

void rvCCConnMdmProcessEvent(RvCCConnection* conn,RvCCTerminalEvent eventId,
                             RvBool* callStillAlive, RvCCEventCause reason)
{
    RvCCTerminal*       t = rvCCConnectionGetTerminal(conn);
    RvCCTerminalMdm*    term = rvCCTerminalMdmGetImpl(t);
    RvCCProvider*       p = rvCCTerminalMdmGetProvider(term);
    RvCCTerminalEvent   nextEvent;
    RvCCTerminalEvent   orgEventId = eventId;
    RvCCEventCause      eventReason = reason;
    RvCCEventCause      origReason = reason;

    do
    {
        /* Process the event at the TermConn state machine */
        eventId =  rvCCTermConnProcessEvents(conn, eventId, &eventReason);

        rvCCTextPrintEvent(conn, &orgEventId, eventId, &origReason, eventReason);

        /* User Pre-process event */
        eventId = rvIppMdmExtPreProcessEventCB(conn, eventId, &eventReason);

        rvCCTextPrintEvent(conn, &orgEventId, eventId, &origReason, eventReason);

        /* Process the event in Connection state machine*/
        nextEvent = rvCCConnectionStateMachine(conn, eventId, &eventReason,callStillAlive);

        rvCCTextPrintEvent(conn, &orgEventId, eventId, &origReason, eventReason);

        rvCCConnectionDisplay(conn, t, eventId, eventReason, rvCCProviderMdmGetDisplayData(p));

        /* User Post-process event */
        rvIppMdmExtPostProcessEventCB(conn, eventId,eventReason);

        eventId = nextEvent;

    } while (nextEvent != RV_CCTERMEVENT_NONE);
}

/***************************************************************************
 * rvCCConnMdmConstruct
 * ------------------------------------------------------------------------
 * General: This function constructs MDM connection. It is called only during
 *          registration of terminals.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 *          term -  pointer to terminal
 *          p    -  pointer to provider
 *          a    -  pointer to allocator
 * Output   None
 ***************************************************************************/
void rvCCConnMdmConstruct(
                RvCCConnection*     x,
                RvCCTerminal*       term,
                RvCCProviderMdm*    p,
                RvAlloc*            a)
{
    RvUint cfnrTimeout;
    RvCCConnMdm* conn = NULL;

    rvMtfAllocatorAlloc(sizeof(RvCCConnMdm), (void**)&conn);

    conn->terminal = term;
    conn->ephTerm = NULL;
    conn->streamId = RV_MDM_STREAMID_NONE;
    rvStringConstruct(&conn->dialString, "", a);
    conn->alloc = a;

    rvCCCfwGetCfnrTimeout(term, &cfnrTimeout);

    IppTimerConstruct(&conn->cfnrTimer, cfnrTimeout, rvCCfwNoReplyTimerExpires, term);

    rvCCConnectionConstruct(x, term, conn, RV_CCCONNTYPE_MDM, &p->connFuncs, &p->connClbks);

    RvLogInfo(ippLogSource,
        (ippLogSource, "MDM Connection Constructed (%p) Line=%d for Terminal=%s, CFNR timeout=%d",
                    x, rvCCConnectionGetLineId(x), rvCCTerminalGetId(term), cfnrTimeout));
}

/***************************************************************************
 * rvCCConnMdmDestruct
 * ------------------------------------------------------------------------
 * General: This function destructs MDM connection. It is called only during
 *          unregistrations of terminals.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 * Output   None
 ***************************************************************************/
void rvCCConnMdmDestruct(RvCCConnection* x)
{
    RvCCConnMdm* conn = rvCCConnMdmGetIns(x);

    RvLogInfo(ippLogSource, (ippLogSource,
        "MDM Connection Destructed (%p), Line:%d", x, rvCCConnectionGetLineId(x)));

    rvStringDestruct(&conn->dialString);

    IppTimerStop(&conn->cfnrTimer);
    IppTimerDestruct(&conn->cfnrTimer);

    rvMtfAllocatorDealloc(conn, sizeof(RvCCConnMdm));

    rvCCConnectionDestruct(x);

}

/***************************************************************************
 * rvCCConnMdmGetTerminalImpl
 * ------------------------------------------------------------------------
 * General: This function returns a pointer to the terminal that is related
 *          to the connection.
 *
 * Return Value: pointer to terminal
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   c    -  pointer to connection
 * Output   None
 ***************************************************************************/
RvCCTerminalMdm* rvCCConnMdmGetTerminalImpl(RvCCConnection* c)
{
    RvCCConnMdm*        conn = rvCCConnMdmGetIns(c);
    RvCCTerminalMdm*    terminal = rvCCTerminalMdmGetImpl(conn->terminal);

    return terminal;
}

/***************************************************************************
 * modifyMediaOnHoldReinvite
 * ------------------------------------------------------------------------
 * General: This function is called when Re-Invite for Hold was received, it
 *          calls user callback to modify the media for Hold.
 *
 * Return Value:
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  pointer to connection
 * Output   None
 ***************************************************************************/
static RvBool modifyMediaOnHoldReinvite(
                RvCCConnection*         x,
                RvMdmMediaStreamInfo*   mediaStream)
{
    RvBool              res;
    RvCCTerminalMdm*    ephTerm = NULL;
    RvMdmTerm*          rtpTerm = NULL;
    RvMdmMediaStreamInfo* media = NULL;
    RvSdpMsg*           sdpMsgCap =     rvCCConnMdmGetMediaCaps(x);
    RvSdpMsg*           localSdp;
    RvSdpMsg*           remoteSdp;

    /* Get RTP Media objects */
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &media)) == RV_FALSE)
    {
        return RV_FALSE;
    }

    localSdp  = rvSdpMsgListGetElement( &media->streamDescr.localDescriptors, 0);
    remoteSdp = rvSdpMsgListGetElement( &media->streamDescr.remoteDescriptors, 0);

    if ( localSdp && remoteSdp )
    {
        RvChar str[256];

        /* Get remote media from "mediaStream" as was just received in signaling message, and update
           our connection with it. "media" is holding the last remote media */
        remoteSdp = rvSdpMsgListGetElement( &mediaStream->streamDescr.remoteDescriptors, 0);

        if (rvMdmMediaStreamInfoIsRemoteDescriptorSet(media) == RV_TRUE)
        {
            rvMdmMediaStreamInfoClearRemote(media);
        }

        rvMdmMediaStreamInfoAddRemoteDescriptor(media, remoteSdp);

        /* Print remote SDP to log */
        RvSprintf(str, "modifyMediaOnHoldReinvite: SDP received from remote party for c=%p", x);
        rvCCTextPrintSdpMsg(remoteSdp, str, RV_LOGLEVEL_DEBUG);

        /* This will result with calling modifyMedia() */
        res = rvCCConnectionTermRemoteHold( x);

        /* Update outgoing SDP -
                  Get local media from "media" since it's holding SDP returned by user application after calling ModifyMediaCB.
                  and update "mediaStream" with it. "mediaStream" will be sent in the signaling reply message */
        if (rvMdmMediaStreamInfoIsLocalDescriptorSet(media) == RV_TRUE)
        {
            RvCCConnMdm* conn = rvCCConnMdmGetIns(x);

            RvSdpMsg* localSdp2 = (RvSdpMsg*)rvMdmMediaStreamInfoGetLocalDescriptor(media, conn->streamId-1);
            if (localSdp2 != NULL)
            {
                /* Print local SDP to log */
                RvSprintf(str, "modifyMediaOnHoldReinvite: local SDP returned from user to be sent out for c=%p", x);
                rvCCTextPrintSdpMsg(localSdp2, str, RV_LOGLEVEL_DEBUG);

                if (rvMdmMediaStreamInfoIsLocalDescriptorSet(mediaStream) == RV_TRUE)
                {
                    rvMdmMediaStreamInfoClearLocal(mediaStream);
                }
                rvMdmMediaStreamInfoAddLocalDescriptor(mediaStream, localSdp2);
            }
        }
    }
    else
    {
        /* Transfer failed, and we want the call to be back between A and B. In this case rtpMedia has no remote
           media descriptor it may be result of replacing MDM connection on B during transfer.
           In such case we receives not standard hold request but re-invite from A as result of transfer failure.
           Treat the case accordingly.  */
        if (!remoteSdp)
        {
            RvSdpMsg*   pmsg = rvSdpMsgListAddMsg( &media->streamDescr.remoteDescriptors);
            remoteSdp = rvSdpMsgListGetElement( &mediaStream->streamDescr.remoteDescriptors, 0);
            rvSdpMsgConstructCopy( pmsg, remoteSdp);

            rvCCConnectionSetTermState( x, RV_CCTERMCONSTATE_REMOTE_HELD);
        }

        RvLogWarning(ippLogSource, (ippLogSource,
            "modifyMediaOnHoldReinvite: transfer failed, resuming media between A and B, c=%p, Line:%d",
            x, rvCCConnectionGetLineId(x)));

        res = modifyMedia(x, RVMDM_CMD_NORMAL, ephTerm, mediaStream, sdpMsgCap);
    }

    return res;
}

static RvBool modifyMediaOnUnholdReinvite( RvCCConnection *x, RvMdmMediaStreamInfo* mediaStream)
{
    RvBool              res;
    RvCCTerminalMdm*    ephTerm = NULL;
    RvMdmTerm*          rtpTerm = NULL;
    RvMdmMediaStreamInfo* media = NULL;
    RvSdpMsg*           remoteSdp;
    RvChar              str[256];

    /* Get RTP Media objects */
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &media)) == RV_FALSE)
        return RV_FALSE;

    /* Get remote media from "mediaStream" as was just received in signaling message, and update
       our connection with it. "media" is holding the last remote media */
    remoteSdp = rvSdpMsgListGetElement( &mediaStream->streamDescr.remoteDescriptors, 0);

    if (rvMdmMediaStreamInfoIsRemoteDescriptorSet(media) == RV_TRUE)
    {
        rvMdmMediaStreamInfoClearRemote(media);
    }

    rvMdmMediaStreamInfoAddRemoteDescriptor(media, remoteSdp);

    /* Print remote SDP to log */
    RvSprintf(str, "modifyMediaOnUnholdReinvite: SDP received from remote party for c=%p", x);
    rvCCTextPrintSdpMsg(remoteSdp, str, RV_LOGLEVEL_DEBUG);

    /*Set local indicators and states to Unhold, and call modifyMedia()*/
    res = rvCCConnectionTermRemoteUnhold( x);

    /* Update outgoing SDP -
       Get local media from "media" since it's holding SDP returned by user application after calling ModifyMediaCB.
       and update "mediaStream" with it. "mediaStream" will be sent in the signaling reply message */
    if (rvMdmMediaStreamInfoIsLocalDescriptorSet(media) == RV_TRUE)
    {
        RvCCConnMdm* conn = rvCCConnMdmGetIns(x);
         RvSdpMsg*  localSdp = (RvSdpMsg*)rvMdmMediaStreamInfoGetLocalDescriptor(media, conn->streamId-1);

         if (localSdp != NULL)
         {
             if (rvMdmMediaStreamInfoIsLocalDescriptorSet(mediaStream) == RV_TRUE)
             {
                 rvMdmMediaStreamInfoClearLocal(mediaStream);
             }
             rvMdmMediaStreamInfoAddLocalDescriptor(mediaStream, localSdp);

             /* Print local SDP to log */
             RvSprintf(str, "modifyMediaOnUnholdReinvite: local SDP returned from user to be sent out for c=%p", x);
             rvCCTextPrintSdpMsg(localSdp, str, RV_LOGLEVEL_DEBUG);
         }
    }

    return res;
}

/***************************************************************************
 * rvCCConnMdmModifyMedia
 * ------------------------------------------------------------------------
 * General: This function is be called when remote side requests for changing
 *          the parameters of the existing media.
 *
 * Return Value: RV_TRUE on success
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x           -   MDM connection
 *          streamDescr -   contains new media parameters as received from remote
 *
 ***************************************************************************/
RvBool rvCCConnMdmModifyMedia(RvCCConnection *x, RvMdmMediaStreamInfo* mediaStream )
{
    RvCCTerminal*           t = rvCCConnectionGetTerminal(x);
    RvCCTerminal*           eph;
    RvCCTerminalMdm*        ephTerm = NULL;
    RvSdpMsg                *sdpMsgCap, *sdpMsgCurrent;
    RvBool                  res = RV_TRUE;
    RvBool                  callModifyMedia = RV_FALSE;

    if (mediaStream == NULL)
    {
        return RV_FALSE;
    }

    if ((eph = rvCCConnMdmGetEphXTerm(x)) == NULL)
    {
        return RV_FALSE;
    }

    if ((ephTerm = rvCCTerminalMdmGetImpl(eph)) == NULL)
    {
        return RV_FALSE;
    }

    /*Set our media capabilities in local new media and set default info in it*/
    sdpMsgCap = rvCCConnMdmGetMediaCaps(x);
    sdpMsgCurrent = rvCCConnMdmGetMedia(x);

    rvCCTerminalMdmFillSdpDefaultInfo(t, sdpMsgCap, rvCCTerminalMdmGetTermId(t));

    /* if we don't have a remote descriptor this is a case of outgoing re-invite.
       In this case we should skip the checks for hold/unhold.    */
    if (!rvMdmStreamDescriptorIsRemoteDescriptorSet(&mediaStream->streamDescr))
    {
        RvLogInfo(ippLogSource, (ippLogSource,
            "rvCCConnMdmModifyMedia: modifying media for outgoing Re-Invite, c=%p, Line:%d", x, rvCCConnectionGetLineId(x)));

        callModifyMedia = RV_TRUE;
    }
    else
    {
    /* if ReInvite For remote Hold
    * we check remote descriptor because in SIP local data is stored in remote
        */

        /* we suppose that hold/unhold re-invite change nothing more in media
        * here we distinguish these cases and call modifyMedia() with different 2nd parameter in each case
        */
        if( rvCCConnMdmIsReInviteForHold( x, rvSdpMsgListGetElement( &mediaStream->streamDescr.remoteDescriptors, 0)))
        {
            RvLogInfo(ippLogSource, (ippLogSource,
                "rvCCConnMdmModifyMedia: modifying media for Hold, c=%p, Line:%d", x, rvCCConnectionGetLineId(x)));

            /* make sure there is a local descriptor before Hold */
            rvMdmMediaStreamInfoAddLocalDescriptor(mediaStream, (RvSdpMsg*)sdpMsgCurrent);

            modifyMediaOnHoldReinvite( x, mediaStream );
        }
        else if (rvCCConnMdmIsReInviteForUnhold( x))
        {
            RvLogInfo(ippLogSource, (ippLogSource,
                "rvCCConnMdmModifyMedia: modifying media for Unhold, c=%p, Line:%d", x, rvCCConnectionGetLineId(x)));

            /* make sure there is a local descriptor before UnHold */
            rvMdmMediaStreamInfoAddLocalDescriptor(mediaStream, (RvSdpMsg*)sdpMsgCurrent);

            modifyMediaOnUnholdReinvite( x, mediaStream );

        }
        else
        {
        /* if the local descriptor is not set take the media capabilities.
        This is the case of incoming re-invite when a media is oferred by the
            remote side and needs to be negotiated against the local capabilities */

            RvLogInfo(ippLogSource, (ippLogSource,
                "rvCCConnMdmModifyMedia: modifying media for incoming Re-Invite, c=%p, Line:%d", x, rvCCConnectionGetLineId(x)));

            if (!rvMdmStreamDescriptorIsLocalDescriptorSet(&mediaStream->streamDescr))
            {
                rvMdmMediaStreamInfoAddLocalDescriptor(mediaStream, (RvSdpMsg*)sdpMsgCap);
            }

            callModifyMedia = RV_TRUE;
        }
    }

    if (callModifyMedia)
    {
        /* before modifying media make sure that the local descriptor contains all
        the required data */
        RvSdpMsg* sdp;
        RvSdpConnection* sdpConn;

        sdp = (RvSdpMsg*)rvMdmStreamDescriptorGetLocalDescriptor(&mediaStream->streamDescr, 0);
        if (sdp == NULL)
            return RV_FALSE;

        sdpConn = rvSdpMsgGetConnection(sdp);

        rvCCTerminalMdmFillSdpDefaultInfo(t, sdp, rvCCTerminalMdmGetTermId(t));

        res = modifyMedia(x, RVMDM_CMD_NORMAL, ephTerm, mediaStream, sdpMsgCap);
    }

    return res;
}

/***************************************************************************
 * rvCCConnMdmModifyMediaDone
 * ------------------------------------------------------------------------
 * General: This function will be called when response for modify media from
 *          remote party was received.
 *          This function will do the following:
 *          1. If modify media succeeded - replace existing media with new one.
 *             The new media will be used from now on as the opened media.
 *          2. Notify the user that the process was completed -
 *                  a. Inform the user of the status of the process.
 *                  b. Send the remote media as received from remote party
 *                  c. User can use output parameter "response" to modify local
 *                     media based on the remote.
 *          3. Store response media from user to connection.
 *          4. Reset new media in the connection.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x           -   MDM connection
 *          newMedia    - media parameters received from remote
 *          reason      - status of modifying media
 *
 ***************************************************************************/
void rvCCConnMdmModifyMediaDone(RvCCConnection* x,
                                RvBool status,
                                RvMdmMediaStreamInfo* newMedia,
                                RvMdmTermReasonModifyMedia reason)
{
    RvCCTerminalMdm*        term        = rvCCConnMdmGetTerminalImpl(x);
    RvCCTerminal*           eph         = NULL;
    RvCCTerminalMdm*        ephTerm     = NULL;
    RvMdmMediaDescriptor    rspMedia;

    if ((eph = rvCCConnMdmGetEphXTerm(x)) == NULL)
    {
        return;
    }

    if ((ephTerm = rvCCTerminalMdmGetImpl(eph)) == NULL)
    {
        return;
    }

    rvMdmMediaDescriptorConstructA(&rspMedia, term->alloc);

    /*If modifying media succeeded, replace local media with the new one*/
    if (status == RV_TRUE)
    {
        RvCCConnMdm* conn = rvCCConnMdmGetIns(x);
        RvMdmMediaStreamInfo* oldMedia = rvCCTerminalMdmGetMediaStream(ephTerm, conn->streamId);
        RvChar              str[256];

        /* Use the original stream id in the new media */
        RvUint32 oldStreamId = rvMdmMediaStreamInfoGetId(oldMedia);
        rvMdmMediaStreamInfoSetId(newMedia, oldStreamId);

        /* Replace existing local media with the new media stored in connection*/
        /* first release already allocated memory.*/
        RvMdmMediaStreamInfoDestruct(oldMedia);
        RvMdmMediaStreamInfoConstructCopy(oldMedia, newMedia, prvDefaultAlloc);

        RvLogInfo(ippLogSource, (ippLogSource,
            "rvCCConnMdmModifyMediaDone: dynamic modify media was completed successfully, calling user callback, c=%p, Line:%d", x, rvCCConnectionGetLineId(x)));

        /* Print new media to log */
        RvSprintf(str, "rvCCConnMdmModifyMediaDone: setting new media for c=%p", x);
        rvCCTextPrintMedia(x, newMedia, str, RV_LOGLEVEL_DEBUG);


        /*Notify the user of the result*/
        rvMdmMediaStreamInfoModifyMediaDone((void*)x, newMedia, ephTerm, status, &rspMedia, RV_MDMTERMREASON_SUCCESS);

        /* Replace existing media with the final media returned from the user */
        setResponseMedia(oldMedia, &rspMedia);

        /* Print media returned by user application to log */
        RvSprintf(str, "rvCCConnMdmModifyMediaDone: media returned by user for c=%p", x);
        rvCCTextPrintMedia(x, newMedia, str, RV_LOGLEVEL_DEBUG);

    }
    /*Modify media failed, stay with existing media */
    else
    {
        RvLogError(ippLogSource, (ippLogSource,
            "rvCCConnMdmModifyMediaDone: dynamic modify media failed with reason=%s, calling user callback, c=%p, Line:%d",
            rvCCTextModifyMediaReason(reason), x, rvCCConnectionGetLineId(x)));

        /*Notify the user of the result*/
        rvMdmMediaStreamInfoModifyMediaDone((void*)x, newMedia, ephTerm, status, &rspMedia, reason);
    }

    rvMdmMediaDescriptorDestruct(&rspMedia);

    /*Reset new media in the connection unless another modify is in process. */
	if (reason != RV_MDMTERMREASON_IN_PROCESS)
	{
		RvCCConnection* party = rvCCConnectionGetConnectParty(x);
		rvCCConnectionClearNewMedia(x);
	
		if (rvCCConnectionGetMediaState(x) == RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED)
		{
			rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_CREATED);
			rvCCConnectionSetMediaState(party, RV_CCMEDIASTATE_CREATED);
		}
		else
		{
			rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_CONNECTED);
			rvCCConnectionSetMediaState(party, RV_CCMEDIASTATE_CONNECTED);
		}
	}
}

void rvCCConnMdmReject(RvCCConnection* x, RvCCEventCause reason)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);

    if ( (x->state == RV_CCCONNSTATE_IDLE) ||
        /* connection failed because media is not supported */
         ((x->state == RV_CCCONNSTATE_FAILED) && (reason == RV_CCCAUSE_MEDIA_NOT_SUPPORTED)) )
    {
        RvLogWarning(ippLogSource, (ippLogSource,
            "rvCCConnMdmReject: media failed or not supported, connection state=%s, c=%p, Line:%d",
            rvCCTextConnState(x->state), x, rvCCConnectionGetLineId(x)));

        return; /* do not bother the user */
    }

    if (reason == RV_CCCAUSE_BUSY)
    {
        rvCCTerminalMdmStartBusySignal(t);
    }
    else
    {
        rvCCTerminalMdmStartWarningSignal(t);
    }

    RvLogInfo(ippLogSource, (ippLogSource,
        "rvCCConnMdmReject: connection state=%s, reason=%s, c=%p, Line:%d",
        rvCCTextConnState(x->state), rvCCTextCause(reason), x, rvCCConnectionGetLineId(x)));


}

void rvCCConnMdmMakeCall(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvCCEventCause      reason;
    RvBool              callStillAlive;
    RvCCTerminal*       t               = rvCCConnectionGetTerminal(x);
    RvCCTerminalEvent   termEvent;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvCCConnMdmMakeCall(conn:%p, inMedia:%p)",x, inMedia));
    /* At this point the incoming connection is still in an idle state so is
       not counted. Check if there are already max connections
    */
    if (rvCCTerminalGetNumActiveConnections(t) >= (rvCCTerminalGetNumberOfLines(t)-1))
    {
        termEvent = RV_CCTERMEVENT_REJECTCALL;
        reason    = RV_CCCAUSE_BUSY;
        /*rvCCConnMdmProcessEvent(x, RV_CCTERMEVENT_REJECTCALL, NULL, RV_CCCAUSE_BUSY);
        return;*/
    }
    else
    /* SIP protocol uses this function to set remote media
       H323 should have remote media already set in event,
       raised by channel state changed to connected
     */
    if ((rvCCConnectionSetRemoteMedia(x, inMedia)) == RV_FALSE)
    {
        termEvent = RV_CCTERMEVENT_REJECTCALL;
        reason    = RV_CCCAUSE_MEDIA_NOT_SUPPORTED;
        /*rvCCConnMdmProcessEvent(x, RV_CCTERMEVENT_REJECTCALL, NULL, RV_CCCAUSE_MEDIA_NOT_SUPPORTED);
        return;*/
    }
    else
    {
        termEvent   = RV_CCTERMEVENT_MAKECALL;
        reason      = RV_CCCAUSE_INCOMING_CALL;
    }


    rvCCConnMdmProcessEvent(x, termEvent,&callStillAlive,reason);
    RvLogDebug(ippLogSource,(ippLogSource,"--> rvCCConnMdmMakeCall"));
}

/*** This is a sanity check to be sure that transferLine is pointed to real connection
static RvBool transferLineIsValid(RvCCConnection* x)
{
    RvCCConnection *c = rvCCConnectionGetTransferLine(x);
    RvBool res = RV_FALSE;

    if (c != NULL)
    {
        if ((c->mediaState >= RV_CCMEDIASTATE_CREATED) &&
            (c->mediaState <= RV_CCMEDIASTATE_FAILED))
        {
            res = RV_TRUE;
        }
    }

    return res;
}
***/

/*Either remote side or local disconnected,handle media and signals accordingly.
  Objects will be released only when local hangs up.
  The state of disconnecting connection will be RV_CCCONNSTATE_DISCONNECTED.*/
void rvCCConnMdmDisconnecting(RvCCConnection* x,RvCCEventCause reason)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvBool callStillAlive;
	RvCCTermConnState  termState;

    RvCCConnection* originConn = rvCCConnectionGetTransferLine(x); /*it's NETWORK connection */
    RvCCConnection* connParty = rvCCConnectionGetConnectParty(x);
    RvCCCall* originCall,*activeCall;
    RvCCConnection*             ptOtherConnection = NULL;

    termState = rvCCConnectionGetTermState(x);
    rvCCConnMdmDisconnectMedia(x);

	/*If hold indicator is on ,switch it off */ 
	if((termState == RV_CCTERMCONSTATE_HELD) ||
		(termState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD)||
		(termState == RV_CCTERMCONSTATE_REMOTE_HELD))
	{

		rvCCConnectionTermSetHoldIndicator(x, RV_FALSE);
	}

    switch(rvCCConnectionGetState(x))
    {
        /* For an outgoing call or a call already connected, the other side hang up,
           so : If not held play warning tone, else just release the connection */
        case RV_CCCONNSTATE_DIALING:
        case RV_CCCONNSTATE_INPROCESS:
        case RV_CCCONNSTATE_CALL_DELIVERED:
        case RV_CCCONNSTATE_CONNECTED:
            if((termState == RV_CCTERMCONSTATE_HELD) ||
               (termState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD))
            {
                /* notify the call that the connection is being released */
                rvCCCallPartyReleased(x);
                rvCCConnMdmRelease(x);
                /* (1) Make sure that termState stays idle ! */
            }
            else
            {
                rvCCTerminalMdmStopSignals(t);
                rvCCTerminalMdmStopRingingSignal(t);

                rvCCConnectionSetState(x, RV_CCCONNSTATE_DISCONNECTED);
                activeCall=rvCCConnectionGetCall(x);
                /* To prevent busy signal when transfered call (B to C) gets busy or
                warning tone when transfered call (A to C) is dropped
                */
                if ((originConn == NULL)/*** ||
                    (transferLineIsValid(x) == RV_FALSE)***/)
                {
#ifdef USE_GPON_OVERSEA_VERSION   
    			ptOtherConnection = vpsipUtil_GetNextActiveConnection(t,x);
//rvCCCallGetState(activeCall) !=RV_CCCALLSTATE_CONFERENCE_COMPLETED
                    if(ptOtherConnection==NULL||(ptOtherConnection!=NULL&&rvCCConnectionGetTermState(ptOtherConnection) !=RV_CCTERMCONSTATE_TALKING))/*Add by Happy Su 2011-11-30 US conference call flow*/
                    {
#endif
                         if(reason==RV_CCCAUSE_BUSY)
                              rvCCTerminalMdmStartBusySignal(t);
                         else
                              rvCCTerminalMdmStartWarningSignal(t);
#ifdef USE_GPON_OVERSEA_VERSION						 
                     }
#endif					
                }
                else
                {
                    originCall = rvCCConnectionGetCall(originConn);


                    /*for B: return MDM connection to the call,
                    which has initiated the transfer, from where the MDM connection was rented
                    */
                    if (rvCCCallGetConnNum(originCall) == 1)
                    {
                        rvCCCallAddParty(originCall, x);

                        /* restory connection parties */
                        RvLogDebug(ippLogSource,(ippLogSource,"rvCCConnMdmDisconnecting %p->curParty=%p",x,originConn));
                        rvCCConnectionSetConnectParty(x, originConn);

                        /* Restory mdm connection's party's party and state.
                        The Network connection is currently in a wrong state,
                        which it got after a transfer command had been obtained for the 1st (A - B) call.
                        I want to set a state that will permit to accept "Re-Invite for hold" from A
                        A little bit artificial, I have to admit
                        */
                        RvLogDebug(ippLogSource,(ippLogSource,"rvCCConnMdmDisconnecting %p->curParty=%p",originConn,x));
                        rvCCConnectionSetConnectParty(originConn, x);
                        rvCCConnectionSetState(originConn, RV_CCCONNSTATE_CONNECTED);

                        /* no more transferLines */
                        rvCCConnectionSetTransferLine(x, NULL);

                        return;
                    }
                    else if (rvCCConnectionGetTransferState(x) == RV_CCCONNSTATE_TRANSFERROR_2ND_CALL)
                    {
                    /* In the full-attended transfer process, a BYE message is sent from C,
                    and this procedure is called on the mdm of the sip connection.
                    It is needed to release the MDM connection, and to clear the transferState of the connection.
                    Note that, because of the fact that this mdm release connection is done here,
                    there is no need to release the connection in the function ...TransferDisconnecting.
                        The otherCall on line2 won't exist anymore */
                        rvCCCallPartyReleased(x);
                        rvCCConnMdmRelease(x);
                        rvCCConnectionSetTransferState(x, RV_CCCONNSTATE_TRANSFER_IDLE);
                    }
                }

            }

            /* This is here mainly for the display */
            rvCCConnMdmProcessEvent(x,RV_CCTERMEVENT_REMOTE_DISCONNECTED,&callStillAlive,reason);
            break;

        case RV_CCCONNSTATE_REJECTED:
            /* notify the call that the connection is being released */
            rvCCCallPartyReleased(x);
            rvCCConnMdmRelease(x);
            /* (1) Make sure that termState stays idle ! */
            break;

        /* In this case, we got disconnected on an incoming call
           which hasn't been answered yet */
        /* In addition, in case of CFW, the state here is idle,
        and it is needed to disconnect the mdm connection */
        case RV_CCCONNSTATE_IDLE:
        case RV_CCCONNSTATE_ALERTING:
        case RV_CCCONNSTATE_ALERTING_REJECTED:
            /* Stop signals only if
            1. This is the active connection
            2. There is no other connection ringing
            */
            if(x==rvCCTerminalGetActiveConnection(t) && isOtherLineRinging(x)==RV_FALSE) {
                rvCCTerminalMdmStopSignals(t);
                rvCCTerminalMdmStopRingingSignal(t);
            }
            rvCCConnMdmProcessEvent(x,RV_CCTERMEVENT_DISCONNECTED,&callStillAlive,RV_CCCAUSE_NORMAL);
            break;
#if USE_GPON_OVERSEA_VERSION /* zhuzhh, modify for oversea, 2011/11/24 */
        case RV_CCCONNSTATE_DISCONNECTED:
            /* B should start busy signal while c cannceled to connection while do transfer actions */
            if ( RV_CCCAUSE_NEW_CALL == reason )
            {
                rvCCTerminalMdmStartBusySignal(t);
            }
            break;
#endif
        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }
    /* Put this check here for the case that the connection
       was already released, then the termState has to stay idle ,
       see (1) above. Could return in (1) but wants to send
       something to the display
    */
    if(x->termState != RV_CCTERMCONSTATE_IDLE)
        rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_DROPPED);
}


/*Start a ringback in the connection
Connection must be in ESTABLISHED state
Ringback will stop in modify media or moving out of ESTABLISHED ?*/
void rvCCConnMdmRingback(RvCCConnection* x, RvCCEventCause reason)
{

    rvCCConnMdmProcessEvent(x, RV_CCTERMEVENT_RINGBACK, NULL, reason);

}


/* returns local media */
RvSdpMsg* rvCCConnMdmGetMedia(RvCCConnection* x)
{
    RvCCConnMdm* conn = rvCCConnMdmGetIns(x);
    RvCCTerminal* eph = rvCCConnMdmGetEphXTerm(x);
    RvCCTerminalMdm* ephTerm = rvCCTerminalMdmGetImpl(eph);
    RvSdpMsg* sdp = NULL;
    RvMdmMediaStreamInfo* media;

    RvMutexLock(&ephTerm->mutex,IppLogMgr());

    media = rvCCTerminalMdmGetMediaStream(ephTerm, conn->streamId);
    if (rvMdmMediaStreamInfoIsLocalDescriptorSet(media) == RV_TRUE)
        sdp = (RvSdpMsg*)rvMdmStreamDescriptorGetLocalDescriptor(&media->streamDescr, 0);

    RvMutexUnlock(&ephTerm->mutex,IppLogMgr());
    return sdp;
}

/* returns media capabilities*/
RvSdpMsg* rvCCConnMdmGetMediaCaps(RvCCConnection* x)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCTerminal* at = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(at);

    return (RvSdpMsg *)rvCCTerminalMdmGetMediaCaps(term);

}




RvCCTerminal* rvCCConnMdmGetEphXTerm(RvCCConnection* x)
{
    RvCCTerminal* ephT;
    RvMdmTerm *rtpTerm;

    rtpTerm = rvCCConnMdmGetEphTerm(x);
    if (rtpTerm == NULL)
    {
        return NULL;
    }

    ephT = (RvCCTerminal*)rvMdmTermGetXTerm_(rtpTerm);

    return ephT;
}



/***************************************************************************
 * rvCCConnMdmCreateMedia
 * ------------------------------------------------------------------------
 * General:      Creates line media and RTP media.
 *               Line media is created for a physical termination:
 *                  1. If Audio capabilities exist - will create media for Audio termination
 *                  2. If Video capabilities exist - will create media for Video termination
 *               RTP media is created if at least Audio or Video was created.
 * Return Value: Media state -
 *                  RV_CCMEDIASTATE_FAILED - if either line media or RTP media failed.
 *                  RV_CCMEDIASTATE_CREATED - if at least one line media and RTP media were
 *                  created successfully.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  Mdm connection
 *          inMedia  -  unused argument
 *
 * Output   None
 ***************************************************************************/
RvCCMediaState rvCCConnMdmCreateMedia(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCTerminal* at = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvBool res1 = RV_FALSE, res2 = RV_FALSE;
    RvMdmMediaStreamInfo* lineMedia = NULL;
    RvCCMediaState mediaState;

    RV_UNUSED_ARG(inMedia);

    /* Line Media*/
    /*-----------*/
/*TODO: OPEN AUDIO ANYWAY, OR CHECK CAPS INCLUDE AUDIO???*/
    /* Create Line Media for Audio Termination*/
    lineMedia = rvCCTerminalMdmCreateLineMedia(t, at);
    if (lineMedia != NULL)
        res1 = RV_TRUE;

#ifdef RV_MTF_VIDEO
    /* Create Line Media for Video Terminations*/
    if (rvCCVideoMdmCreateLineMedia(t, lineMedia) == RV_TRUE)
        res2 = RV_TRUE;
#endif

    /* Continue if at least one media type (Audio or Video) succeeded*/
    if ((res1 == RV_FALSE) && (res2 == RV_FALSE))
    {
        rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_FAILED);
        return RV_CCMEDIASTATE_FAILED;
    }

    /* RTP Media*/
    /*-----------*/
    mediaState = createRtpMedia(x, t);

    rvCCConnectionSetMediaState(x, mediaState);
    return mediaState;
}




RvBool rvCCConnMdmSetRemoteMedia(RvCCConnection* x,RvSdpMsg* inMedia, RvBool modify)  
{
    RvCCConnMdm* conn           = rvCCConnMdmGetIns(x);
    RvCCTerminal* t             = rvCCConnectionGetTerminal(x);
    RvCCTerminalMdm* term       = rvCCTerminalMdmGetImpl(t);
    RvCCTerminal* eph           = NULL;
    RvCCTerminalMdm* ephTerm    = NULL;
    RvMdmMediaStreamInfo* media;
    RvBool needModifyMedia=RV_FALSE; /* let's presume we do not have to modify RtpMedia */
    RvBool result;
	RvCCMediaState  mediaState = RV_CCMEDIASTATE_NONE;

    if (inMedia == NULL)
        return RV_TRUE;

    /* if the connection has no stream  - the rtp media was not created
       and we have to create it*/
    if (conn->streamId == RV_MDM_STREAMID_NONE)
    {
        if ((media = initRtpMedia(x, conn, term, &eph)) == NULL)
            return RV_FALSE;
    }
    else
    {
        /* The rtp media WAS already created - get it.
         We have to set the new one, that means to modify existed media.
        */
        eph = rvCCConnMdmGetEphXTerm(x);
        if (eph == NULL)
			return RV_FALSE;

        ephTerm = rvCCTerminalMdmGetImpl(eph);
        if (ephTerm == NULL)
			return RV_FALSE;
		mediaState = (rvCCConnectionGetMediaState(x));

        if ((mediaState == RV_CCMEDIASTATE_MODIFYING)||
		    (mediaState == RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED))
            /* In the process of media modifying take the media from the
               connection newMediaStream  */
            media = rvCCConnectionGetNewMedia(x);
        else
            media = rvCCTerminalMdmGetMediaStream(ephTerm, conn->streamId);

        
		if (modify)
		{
			needModifyMedia = RV_TRUE;
		}
    }

    if (rvMdmMediaStreamInfoIsRemoteDescriptorSet(media) == RV_TRUE)
        rvMdmMediaStreamInfoClearRemote(media);

    rvMdmMediaStreamInfoAddRemoteDescriptor(media, inMedia);

    /* The remote descriptor is just set.
       The media state can be marked as "ready for SEND&RECV"
     */
    rvMdmStreamDescriptorSetMode(&media->streamDescr, RV_MDMSTREAMMODE_SENDRECV);

    /*modify existing media if we have to*/
    if (needModifyMedia)
    {
		if (x->termState == RV_CCTERMCONSTATE_HELD)
		{
			/* we get here when we receive SDP answer without a=recvonly or a=inactive for outgoing Hold  */
			rvMdmStreamDescriptorSetMode(&media->streamDescr, RV_MDMSTREAMMODE_SENDONLY);
			result = modifyMedia(x, RVMDM_CMD_HOLD_LOCAL,ephTerm,media, rvCCConnMdmGetMediaCaps(x));
		}
		else if (x->termState == RV_CCTERMCONSTATE_REMOTE_HELD)
		{
			/* we get here when we receive SDP answer without a=recvonly or a=inactive for outgoing Hold  */
			// rvMdmStreamDescriptorSetMode(&media->streamDescr, RV_MDMSTREAMMODE_RECVONLY);
			result = modifyMedia(x, RVMDM_CMD_HOLD_REMOTE,ephTerm,media, rvCCConnMdmGetMediaCaps(x));
		}
		else
		{
			result = modifyMedia(x, RVMDM_CMD_NORMAL,ephTerm,media, rvCCConnMdmGetMediaCaps(x));
		}
    }
    else result = RV_TRUE;

    return result;
}


RvSdpMsg* rvCCConnMdmSetLocalMedia(RvCCConnection* x,RvSdpMsg* caps)
{
    /* set local media */

    RvCCConnMdm* conn = rvCCConnMdmGetIns(x);
    RvCCTerminal* eph = rvCCConnMdmGetEphXTerm(x);
    RvCCTerminalMdm* ephTerm = rvCCTerminalMdmGetImpl(eph);
    RvMdmMediaStreamInfo* media;

    RvMutexLock(&ephTerm->mutex,IppLogMgr());

    media = rvCCTerminalMdmGetMediaStream(ephTerm, conn->streamId);
    if (rvMdmMediaStreamInfoIsLocalDescriptorSet(media) == RV_TRUE)
        rvMdmStreamDescriptorClearLocalDescriptors(&media->streamDescr);
    rvMdmMediaStreamInfoAddLocalDescriptor(media, (RvSdpMsg *)caps);

    RvMutexUnlock(&ephTerm->mutex,IppLogMgr());

    return NULL;
}


/***************************************************************************
 * rvCCConnMdmConnectLineAndRtpTerms
 * ------------------------------------------------------------------------
 * General:      Connects media between a physical termination and an ephemeral
 *               termination.
 * Return Value: True if succeeded, False if failed.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  Mdm connection
 *          at  -  physical termination
 *          direction - direction to connect media
 *          ephTerm - rtp termination
 *          rtpTerm - rtp mdm termination
 *          rtpMedia - rtp media stream
 * Output   None
 ***************************************************************************/
RvBool rvCCConnMdmConnectLineAndRtpTerms(RvCCConnection*        x,
                                         RvCCTerminal*          at,
                                         RvCCTerminalMdm*       ephTerm,
                                         RvMdmTerm*             rtpTerm,
                                         RvMdmMediaStreamInfo*  rtpMedia)
{
    RvCCTerminal*           t           = rvCCConnectionGetTerminal(x);
    RvCCTerminalMdm*        atTerm      = NULL;
    RvMdmTerm*              mdmTerm     = NULL;
    RvMdmMediaStreamInfo    *lineMedia  = NULL;
    RvBool                  res         = RV_TRUE;

    RvLogDebug(ippLogSource,(ippLogSource, "<-- rvCCConnMdmConnectLineAndRtpTerms conn:%p",x));
    /* Get Line Media objects*/
    if ((getLineMediaObjects(x, at, &atTerm, &mdmTerm, &lineMedia)) == RV_FALSE)
    {
        res = RV_FALSE;
    }

    if (res != RV_FALSE)
    {
        /*Line media may not be open (for example, when switching between HF/HS during a call)*/
        if (lineMedia == NULL)
        {
            lineMedia = rvCCTerminalMdmCreateLineMedia(t, at);
        }

        RvMutexLock(&ephTerm->mutex, IppLogMgr());


        /* Connect Media between RTP termination and line termination*/
        if ((res = rvRtpConnectIntCB(x, rvCCTerminalMdmGetTermMgr(ephTerm), mdmTerm,
            lineMedia, rtpTerm, rtpMedia, RV_MDMSTREAMDIRECTION_BOTHWAYS)) == RV_TRUE)
        {
            rvMdmMediaStreamInfoSetStatusConnected(lineMedia);

			RvLogInfo(ippLogSource,(ippLogSource, "Terminal=%s - Media Connected between: %s and %s, Line:%d (%p)",
				rvCCTerminalGetId(t), rvCCTerminalGetId(at), rvCCTerminalMdmGetId(ephTerm),
				rvCCConnectionGetLineId(x), x));
		}
		else
		{
			RvLogInfo(ippLogSource,(ippLogSource, "Term: %s - Failed to Connect Media between: %s and %s, Line:%d (%p)",
				rvCCTerminalGetId(t), rvCCTerminalGetId(at), rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));
		}
		

        RvMutexUnlock(&ephTerm->mutex, IppLogMgr());
    }

    RvLogDebug(ippLogSource,(ippLogSource, "<-- rvCCConnMdmConnectLineAndRtpTerms %d",res));

    return res;
}


/***************************************************************************
 * rvCCConnMdmConnectMedia
 * ------------------------------------------------------------------------
 * General:      Connects physical termination with RTP termination.
 *               2 types of physical terminations will be connected to the same
 *               RTP termination:
 *                  1. Audio termination - if Audio capabilities exist.
 *                  2. Video termination - if Video capabilities exist.
 *               Media will be considered as connected if either one physical
 *               termination (audio/video) is connected to RTP termination.
 * Return Value: True if succeeded, False if failed.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  Mdm connection
 *
 * Output   None
 ***************************************************************************/
RvBool rvCCConnMdmConnectMedia(RvCCConnection* x)
{
    RvCCTerminal*           t           = rvCCConnectionGetTerminal(x);
    RvCCTerminal*           at          = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvCCTerminalMdm*        ephTerm     = NULL;
    RvMdmTerm*              rtpTerm     = NULL;
    RvMdmMediaStreamInfo*   rtpMedia    = NULL;
    RvBool                  res1        = RV_FALSE;/* default is False, so we won't fail if video is not supported*/
    RvBool                  res2        = RV_FALSE;/* default is False, so we won't fail if video is not supported*/
    RvBool                  rc          = RV_TRUE;

    RvLogDebug(ippLogSource,(ippLogSource, "<-- rvCCConnMdmConnectMedia conn:%p",x));

    /* check if media was already connected. It could have been connected if a 183 message
       arrived as a reponse to an outgoing INVITE prior to the final response (OK)    */
    if (x->mediaState == RV_CCMEDIASTATE_CONNECTED)
    {
        return RV_TRUE;
    }

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
    {
        RvLogError(ippLogSource,(ippLogSource, "rvCCConnMdmConnectMedia::getRtpMediaObjects Failed "));
        rc = RV_FALSE;
/*      return RV_FALSE;*/
    }

    if (rc != RV_FALSE)
    {
        /* Connect Audio*/
        /* -------------*/
        /* Check if RTP media contains Audio capabilities.
        If not, no need to connect Audio terminations*/
        if ((RvMdmMediaStreamInfoDoesMediaTypeExist(rtpMedia, RV_SDPMEDIATYPE_AUDIO)) == RV_TRUE)
        {
            /* Connect Audio and RTP terminations*/
            if ((res1 = rvCCConnMdmConnectLineAndRtpTerms(x, at, ephTerm,
                rtpTerm, rtpMedia)) == RV_FALSE)
            {
                RvLogError(ippLogSource,(ippLogSource, "rvCCConnMdmConnectMedia - Failed to Connect Audio Media for Conn (%p) LineID: %d",
                    x, rvCCConnectionGetLineId(x)));
            }
            else
            {
                RvLogInfo(ippLogSource,(ippLogSource, "rvCCConnMdmConnectMedia - Connected Audio Media for Conn (%p) LineID: %d",
                    x, rvCCConnectionGetLineId(x)));
            }
        }
        else
        {
            RvLogInfo(ippLogSource,(ippLogSource, "rvCCConnMdmConnectMedia - No Audio Capabilities for Conn (%p) LineID: %d",
            x, rvCCConnectionGetLineId(x)));
		}


#ifdef RV_MTF_VIDEO
        /* Connect Video*/
        /* -------------*/
        if ((res2 = rvCCVideoMdmConnectMedia(x, RV_MDMSTREAMDIRECTION_BOTHWAYS, ephTerm, rtpTerm, rtpMedia)) == RV_FALSE)
        {
            RvLogError(ippLogSource,(ippLogSource, "rvCCConnMdmConnectMedia - Failed to Connect Video Media for Conn (%p) LineID: %d",
                x, rvCCConnectionGetLineId(x)));
        }
        else
        {
            RvLogInfo(ippLogSource,(ippLogSource, "rvCCConnMdmConnectMedia - Connected Video Media for Conn (%p) LineID: %d",
                x, rvCCConnectionGetLineId(x)));
        }
#endif

        /* If at least one is connected - audio or video - set media states to Connected*/
        if ((res1 == RV_TRUE) || (res2 == RV_TRUE))
        {
            rvMdmMediaStreamInfoSetStatusConnected(rtpMedia);
            rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_CONNECTED);
            rvCCTextPrintMedia(x, rtpMedia, "rvCCConnMdmConnectMedia: media is connected", RV_LOGLEVEL_DEBUG);

            rc = RV_TRUE;
        }
    }


    RvLogDebug(ippLogSource,(ippLogSource, "--> rvCCConnMdmConnectMedia %d",rc));
    return rc;

}

/***************************************************************************
 * rvCCConnMdmDisconnectLineAndRtpTerms
 * ------------------------------------------------------------------------
 * General:      Disconnects media of a physical termination from an ephemeral
 *               termination.
 * Return Value: True if succeeded, False if failed.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  Mdm connection
 *          at  -  physical termination
 *          ephTerm - rtp termination
 *          rtpTerm - rtp mdm termination
 *          rtpMedia - rtp media stream
 * Output   None
 ***************************************************************************/
RvBool rvCCConnMdmDisconnectLineAndRtpTerms(RvCCConnection*         x,
                                             RvCCTerminal*          at,
                                             RvCCTerminalMdm*       ephTerm,
                                             RvMdmTerm*             rtpTerm,
                                             RvMdmMediaStreamInfo*  rtpMedia)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCTerminalMdm* atTerm = NULL;
    RvMdmTerm* mdmTerm = NULL;
    RvMdmMediaStreamInfo *lineMedia = NULL;
    RvBool res = RV_FALSE;

     /* Get Line Media objects*/
    if ((getLineMediaObjects(x, at, &atTerm, &mdmTerm, &lineMedia)) == RV_FALSE)
        return RV_FALSE;

    RvMutexLock(&ephTerm->mutex, IppLogMgr());

    /* Disconnect Line and RTP terminations*/
    if ((lineMedia != NULL) &&
        (res = rvRtpDisconnectIntCB(x, rvCCTerminalMdmGetTermMgr(ephTerm),
                            mdmTerm, lineMedia, rtpTerm, rtpMedia)) == RV_FALSE)
    {
            RvLogError(ippLogSource,(ippLogSource, "Term: %s - Failed to Disconnect Media between: %s and %s, Line:%d (%p)",
                    rvCCTerminalGetId(t), rvCCTerminalGetId(at),
                    rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource, "Term: %s - Media Disconnected between: %s and %s, Line:%d (%p)",
                    rvCCTerminalGetId(t), rvCCTerminalGetId(at),
                    rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(x), x));
    }


    RvMutexUnlock(&ephTerm->mutex, IppLogMgr());

    return res;

}

/***************************************************************************
 * rvCCConnMdmDisconnectMedia
 * ------------------------------------------------------------------------
 * General:      Disconnects Line media for Audio and Video (if supported).
 *
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  Mdm connection
 *
 * Output   None
 ***************************************************************************/
void rvCCConnMdmDisconnectMedia(RvCCConnection* x)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCTerminal* at = rvCCTerminalMdmGetActiveAudioTerm(t);
    RvCCTerminalMdm* ephTerm = NULL;
    RvMdmTerm* rtpTerm = NULL;
    RvMdmMediaStreamInfo* rtpMedia = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
        return;

    /* Disconnect Audio*/
    /* ----------------*/
    /* Check if RTP media contains Audio capabilities.
       If not, no need to connect Audio terminations*/
    if ((RvMdmMediaStreamInfoDoesMediaTypeExist(rtpMedia, RV_SDPMEDIATYPE_AUDIO)) == RV_TRUE)
    {
        /* Connect Audio and RTP terminations*/
        if (rvCCConnMdmDisconnectLineAndRtpTerms(x, at, ephTerm, rtpTerm, rtpMedia) == RV_FALSE)
        {
            RvLogError(ippLogSource,(ippLogSource, "rvCCConnMdmDisconnectMedia - Failed to Disconnect Audio Media for Conn (%p) LineID: %d",
                        x, rvCCConnectionGetLineId(x)));
        }
        else
        {
            RvLogInfo(ippLogSource,(ippLogSource, "rvCCConnMdmDisconnectMedia - Disconnected Audio Media for Conn (%p) LineID: %d",
                        x, rvCCConnectionGetLineId(x)));
        }
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource, "rvCCConnMdmDisconnectMedia - No Audio Capabilities for Conn (%p) LineID: %d",
                        x, rvCCConnectionGetLineId(x)));
	}


#ifdef RV_MTF_VIDEO
    /* Disconnect Video*/
    /* ----------------*/
    if (rvCCVideoMdmDisconnectMedia(x, ephTerm, rtpTerm, rtpMedia) == RV_FALSE)
    {
        RvLogError(ippLogSource,(ippLogSource, "rvCCConnMdmDisconnectMedia - Failed to Disconnect Video Media for Conn (%p) LineID: %d",
                    x, rvCCConnectionGetLineId(x)));
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource, "rvCCConnMdmDisconnectMedia - Disconnected Video Media for Conn (%p) LineID: %d",
                    x, rvCCConnectionGetLineId(x)));
    }
#endif
    rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_DISCONNECTED);
}


/***************************************************************************
 * rvCCConnMdmRestartMedia
 * ------------------------------------------------------------------------
 * General: stop "current" media, remove connection party and create media again
 *          During TRANSFER this function permits B,
 *          which is already connected to A, to send all of its codecs to C.
 * Return Value: always TRUE
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x    -  MDM connection
 ***************************************************************************/
RvBool rvCCConnMdmRestartMedia(RvCCConnection* x)
{
    stopMedia(x);

    /* The connection party must be set to NULL.
       Otherwise when rvCCTerminalMdmSetDefaultMedia is called from rvCCConnMdmCreateMedia
       the media will be set from the connection party,
       instead of being set from capabilties
    */

    RvLogDebug(ippLogSource,(ippLogSource,"rvCCConnMdmRestartMedia %p->curParty=NULL",x));
    rvCCConnectionSetConnectParty(x, NULL);

    rvCCConnMdmCreateMedia(x, NULL);
    return RV_TRUE;
}


void rvCCConnMdmCallAnswered(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCEventCause reason = RV_CCCAUSE_OUTGOING_CALL;
    RvCCTerminalAudioType audioType;
    RvBool res;
    RvBool  callStillAlive = RV_TRUE;          

    RV_UNUSED_ARG(inMedia);

    rvCCTerminalMdmStopSignals(t);
    rvCCTerminalMdmStopRingingSignal(t);


    res=rvCCConnMdmConnectMedia(x);
    if (res==RV_TRUE)
    {
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_ON);

        /* Fix the bug to turn on audio indicator in ep A*/
        /* after transfer the call from ep B to ep C */
        audioType = rvCCTerminalMdmGetActiveAudio(t);
        switch (audioType)
        {
        case RV_CCTERMAUDIO_HANDSFREE:
            rvCCTerminalMdmSetAudioInd(t,"hf", RV_INDSTATE_ON);
            break;

        case RV_CCTERMAUDIO_HEADSET:
            rvCCTerminalMdmSetAudioInd(t,"ht", RV_INDSTATE_ON);
            break;

        case RV_CCTERMAUDIO_NONE:
        case RV_CCTERMAUDIO_HANDSET:
        default:
            break;
        }
        /* fix the bug of hold indicator stay on in ep (A) after transfer the call from */
        /* ep B to ep C*/
        rvCCConnectionTermSetHoldIndicator(x, RV_FALSE);
        rvCCConnMdmProcessEvent(x, RV_CCTERMEVENT_CALLANSWERED, &callStillAlive, reason);
    }

    else
    {
        RvBool stillAlive;
        x->mediaState = RV_CCMEDIASTATE_FAILED;
        rvCCConnMdmProcessEvent(x,  RV_CCTERMEVENT_MEDIAFAIL/*DISCONNECTING*/,
             &stillAlive, reason);
    }
}



/* Connection can be released */
void rvCCConnMdmRelease(RvCCConnection* x)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCConnection* activeConn = rvCCTerminalGetActiveConnection(t);
    int numActiveConn = rvCCTerminalGetNumActiveConnections(t);
	RvMtfCallStateReason	reason = rvCCConnectionGetLastReceivedCallStateReason(x);
    RvCCMediaState oldMediaState;

    if (x==activeConn)
    {
        if ((x->state != RV_CCCONNSTATE_CALL_DELIVERED) && (x->termState != RV_CCTERMCONSTATE_HELD))
        {
            /* if there is just one active connection, the Term Signal may be stopped */
            if ((x->mediaState != RV_CCMEDIASTATE_FAILED) || (numActiveConn == 1))
                rvCCTerminalMdmStopSignals(t);
        }
    }
    else
    {
        /* solve the bug when
           1. there is a connected call: line 1
           2. there is a waiting tone from waiting call (call waiting line 2)
           3. disconnect call from line 2 (This is connection x)
           now we do not here waiting tone any more
         */
        if ((x->state == RV_CCCONNSTATE_DISCONNECTED) && (x->termState == RV_CCTERMCONSTATE_BRIDGED))
        {
            /* waiting connection (x) is disconnecting... */
            /* we need to stop signals only if the active connection
            is not playing any, otherwise we may stop the active conn signals e.g
            ringback tone, dial tone. */
            if (activeConn->state ==  RV_CCCONNSTATE_CONNECTED)
                rvCCTerminalMdmStopSignals(t);
        }

    }

    stopMedia(x);

    /* Rejected calls doesn't reach the stage where they are 'active' */
    /* In addition, In semi-attended transfer case, line2 is rejected,
       so it is needed to inform on lineActive as RV_FALSE.
       Use transferLine !=NULL as indication to semi-attended transfer case */
    if((x->state!=RV_CCCONNSTATE_REJECTED) || (x->transferLine != NULL))
        rvCCTerminalMdmSendLineActive(t, rvCCConnectionGetLineId(x), RV_FALSE);

	/* Call a user callback to inform that the call state has changed. This call must come before rvCCConnMdmClear()
	   so that the user can still get data from MDM objects.  */

	rvMtfConnStateChangedCB(x, RV_CCCONNSTATE_TERMINATED, reason);

    rvCCConnMdmClear(x);

    /* Reset active connection ONLY if the connection that we are releasing now is active.
     */
    if (activeConn == x)
    {
        rvCCTerminalResetActiveConnection(t);
        IppTimerStop(rvCCTerminalMdmGetDialToneTimer(t));

        /* solve the bug when we
           1. receive call from a (connected call line 1)
           2. receive call from c (call waiting line 2)
           3. disconnect call from b(thats us)
               now we can hear ringing tone.
         */
        if (rvCCTerminalMdmOtherAlertingConnExist(t,x)==RV_TRUE)
        {
            rvCCTerminalMdmStartRingingSignal(t);
        }
    }

    oldMediaState=x->mediaState;


    if ((oldMediaState != RV_CCMEDIASTATE_FAILED) || (numActiveConn == 1))
    {
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_OFF);
    }
}

/* returns NULL if dial string was not matched or not found.*/
RvCCConnection* rvCCConnMdmAddressAnalyze(RvCCConnection* x, RvCCEventCause* reason)
{
    RvCCConnMdm* conn = rvCCConnMdmGetIns(x);
    RvCCTerminalMdm* term = rvCCConnMdmGetTerminalImpl(x);
    RvCCConnection* newConn = NULL;
    rvStringCopy(&conn->dialString, &term->dialString);
//add by zhuhaibo 20110401 for tightcoupless of conference or cw
    //if (strcmp(rvStringGetData(&term->dialString),  "LucentTISPANFlashReques") != 0)
    if (strcmp(rvStringGetData(&term->dialString),  "nodial") != 0)
    {
//add end
#ifdef USE_GPON_OVERSEA_VERSION
        isDialStringMatching(term);
#else
        if (isDialStringMatching(term) == RV_FALSE)
            return NULL;
#endif
//add by zhuhaibo 20110401 for tightcoupless of conference or cw
    }
//add end
    newConn = rvCCConnectionAddressAnalyzeCB(x, rvStringGetData(&conn->dialString),
                                            RV_CCCAUSE_OUTGOING_CALL, reason);

    //if ( (term->dialString[0] == '*') || (term->dialString[0] == '#') )
    //{
    //    return NULL;
    //}

    /* Store dial string for redial */
    rvStringCopy(&term->redialString, &term->dialString);

    /*reset dial string in termination*/
    rvStringAssign(&term->dialString, "");


    return newConn;
}

void rvCCConnMdmTransferOffered(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvBool callStillAlive = RV_TRUE;

    /* TO DO: remove caps from function parameters */

    /* If this is not called, Transfer in SIP doesn't work ! */
    rvCCConnMdmDisconnectMedia(x);
    if ((rvCCConnectionSetRemoteMedia(x, inMedia)) == RV_FALSE)
    {
        rvCCConnMdmProcessEvent(x, RV_CCTERMEVENT_REJECTCALL, NULL, RV_CCCAUSE_MEDIA_NOT_SUPPORTED);
        return;
    }

    rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_DISCONNECTED);
    rvCCConnectionSetState(x, RV_CCCONNSTATE_CONNECTED);
    rvCCConnMdmProcessEvent(x, RV_CCTERMEVENT_TRANSFER_OFFERED, &callStillAlive, RV_CCCAUSE_TRANSFER);
}

/*This function is called in the second step of Transfer, when a new call should be
  established in order to transfer the old one. It creates a new Call and MDM connection,
  and creates local media, x is the MDM connection which belongs to the old call. */
RvCCConnection* rvCCConnMdmTransferConnected(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCProvider* p = rvCCTerminalMdmGetProvider(term);
    RvCCConnection* newConn = rvCCProviderCreateConnection(p, t);

    rvCCConnMdmCreateMedia(newConn, inMedia);
    rvCCConnectionSetState(newConn, RV_CCCONNSTATE_INPROCESS);

    return newConn;
}

RvBool rvCCConnMdmIsTransferedConn(RvCCConnection* x, char* data)
{
    RvCCTerminal* term = rvCCConnectionGetTerminal(x);
    if (strcmp(rvCCTerminalGetId(term), data))
        return RV_FALSE;

    return RV_TRUE;
}

#ifdef RV_MTF_N_LINES 
/******************************************************************************
*  rvCCConnMdmJoinConference
*  --------------------------
*  General :    Unhold the existent connections in the list, and then, 
*				Activate local conferencing:Move rtp to where conference control is 
*				(audio term is there). 
*
*  Arguments:
*  Input:       x: The new connection that is going to be connected to the conference call
*				conferenceMdmConnectionsList: The existent connections of the conference call
*  Output       RvBool: rvTrue: succeeded to connect the connection to the conference call
*  Return Value:None
*
******************************************************************************/
RvBool rvCCConnMdmJoinConference(RvCCConnection* x, RvPtrList	conferenceMdmConnectionsList) 
{
	unsigned int index;
	RvPtrListIter i;
	RvCCConnection* conn;
	
	/* Unhold the connections of the conference */
	i=rvListBegin(&conferenceMdmConnectionsList);
	for (index =0; index < rvListSize(&conferenceMdmConnectionsList); index++)
	{		
		conn = (RvCCConnection *)RvPtrListIterData(i);
		rvCCConnectionTermUnhold(conn);
		i=rvListIterNext(i);
		
	}
	/* Connect media of the connections of the conference call */
	return connectRtpTerms(x, conferenceMdmConnectionsList); 
	
}

/******************************************************************************
*  rvCCConnMdmLeaveConference
*  --------------------------
*  General :    Deactivate local conferencing:disconnect connection from conference call
*
*  Arguments:
*  Input:       x: The connection that is going to be disconnected from the conference call
*				conferenceMdmConnectionsList: The existent connections of the conference call
*  Output       RvBool: rvTrue: succeeded to disconnect the connection from the conference call
*  Return Value:None
*
******************************************************************************/
RvBool rvCCConnMdmLeaveConference(RvCCConnection* x, RvPtrList	conferenceMdmConnectionsList) 
{
	/* Disonnect media of the connections of the conference call */
	disconnectRtpTerms(x, conferenceMdmConnectionsList);
	
	
	return rvTrue;
}


#else /* RV_MTF_N_LINES */


/* Activate local conferencing */
/* Move rtp to where conference control is (audio term is there)
   Unhold
   State is already conferenced
*/
RvBool rvCCConnMdmJoinConference(RvCCConnection* x, RvCCConnection* confControl)
{
    /*Unhold this connection*/
    rvCCConnectionTermUnhold(x, NULL);

    /*Connect media of 2 sides of the call*/
    return connectRtpTerms(x, confControl);

}

/* Deactivate local conferencing */
RvBool rvCCConnMdmLeaveConference(RvCCConnection* x, RvCCConnection* confControl)
{

    /*Connect media of 2 sides of the call*/
    return disconnectRtpTerms(x, confControl);

}
#endif /* RV_MTF_N_LINES */

void rvCCConnMdmTerminate(RvCCConnection* x)
{
    /*
    * call to stopMedia() was added in order to handle unregister while active call persists.
    * In all other cases we get here with term state == RV_CCTERMCONSTATE_IDLE
    */
    if( rvCCConnectionGetType(x) == RV_CCCONNTYPE_MDM && rvCCConnectionGetTermState(x) != RV_CCTERMCONSTATE_IDLE)
        stopMedia(x);

    rvCCConnMdmClear(x);
}

/*==================================================================================
============= T E R M I N A L   C O N N E C T I O N     F U N C T I O N S ==========
===================================================================================*/

void rvCCConnTermMdmSetHoldIndicator(RvCCConnection* x, RvBool on)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);

    /*Don't turn Hold indicator off if at least one more connection is on Hold */
    if ((on == RV_FALSE) && (rvCCTerminalMdmOtherHeldConnExist(t, x) == RV_TRUE))
        return;

    rvCCTerminalMdmSetHoldInd(t, on);
}

/* Set terminal on HOLD:
 *   - set line indicator to blink
 *   - set proper (RV_CCTERMCONSTATE_HELD) terminal state.
 *     we do NOT disconnect the media!
 */
RvBool rvCCConnTermMdmHold(RvCCConnection* x)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
    RvCCTermConnState termState;
    RvCCTerminalMdm*    ephTerm = NULL;
    RvMdmTerm*          rtpTerm = NULL;
    RvMdmMediaStreamInfo* rtpMedia = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
    {
        return RV_FALSE;
	}

    RvLogInfo(ippLogSource,(ippLogSource, "Term: %s - Hold Connection Local, Line: %d (%p)",
            rvCCTerminalGetId(t), rvCCConnectionGetLineId(x), x));

    termState=rvCCConnectionGetTermState(x);
    if (termState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD)
    {
        if(!modifyMedia( x, RVMDM_CMD_HOLD_REMOTE_TO_INACTIVE, ephTerm, rtpMedia, NULL))
        {
            RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmHold() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
		}
    }
    else
    {
        if(!modifyMedia( x, RVMDM_CMD_HOLD_LOCAL, ephTerm, rtpMedia, NULL))
        {
            RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmHold() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
		}

        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_BLINK);
        rvCCConnectionTermSetHoldIndicator(x, RV_TRUE);

        if (termState == RV_CCTERMCONSTATE_REMOTE_HELD)
        {
            rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD);
        }
        else
        {
            rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_HELD);
        }
    }

    return RV_TRUE;
}

/* Remove terminal from HOLD:
 *   - set line indicator to ON
 *   - set proper (RV_CCTERMCONSTATE_TALKING) terminal state.
 *     we do NOT connect the media!
 */
RvBool rvCCConnTermMdmUnhold(RvCCConnection* x, RvMdmMediaStreamInfo* streamDescr)
{
    RvCCTerminal*           t           = rvCCConnectionGetTerminal(x);
    RvCCTermConnState     state;
    RvCCTerminalMdm*    ephTerm = NULL;
    RvMdmTerm*          rtpTerm = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &streamDescr)) == RV_FALSE)
        return RV_FALSE;


    RvLogInfo(ippLogSource,(ippLogSource, "Term: %s - Unhold Connection Local, Line: %d (%p)",
                rvCCTerminalGetId(t), rvCCConnectionGetLineId(x), x));

    state = rvCCConnectionGetTermState(x);

    if (state == RV_CCTERMCONSTATE_REMOTE_HELD)
    {
       modifyMedia( x, RVMDM_CMD_UNHOLD_INACTIVE_TO_REMOTE, ephTerm, streamDescr, NULL);
    }
    else
    {
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_ON);
        rvCCConnectionTermSetHoldIndicator(x, RV_FALSE);
        rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_TALKING);

        modifyMedia( x, RVMDM_CMD_UNHOLD_LOCAL, ephTerm, streamDescr, NULL);

    }
    return RV_TRUE;
}

RvBool rvCCConnTermMdmRemoteHold(RvCCConnection* x)
{
    RvCCConnection*     party   = rvCCConnectionGetConnectParty(x);
    RvCCTerminal*       t       = rvCCConnectionGetTerminal(x);
    RvCCTerminalMdm*    ephTerm = NULL;
    RvMdmTerm*          rtpTerm = NULL;
    RvMdmMediaStreamInfo* rtpMedia = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
        return RV_FALSE;

    RvLogInfo(ippLogSource,(ippLogSource,"Term: %s - Hold Connection Remote, Line: %d (%p)",
                rvCCTerminalGetId(t), rvCCConnectionGetLineId(x), x));

    if (x->termState == RV_CCTERMCONSTATE_TALKING)
    {
        rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_REMOTE_HELD);
        rvCCConnectionSetTermState(party, RV_CCTERMCONSTATE_REMOTE_HELD);

        rvCCConnectionTermSetHoldIndicator(x, RV_TRUE);
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_BLINK);

        /* TODO: if media fails, we should go back to original states */
        if(!modifyMedia( x, RVMDM_CMD_HOLD_REMOTE, ephTerm, rtpMedia, NULL))
        {
            RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmRemoteHold() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
		}

    }
    else  if (x->termState == RV_CCTERMCONSTATE_HELD)
    {

        rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD);
        rvCCConnectionSetTermState(party, RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD);

        if(!modifyMedia( x, RVMDM_CMD_HOLD_LOCAL_TO_INACTIVE, ephTerm, rtpMedia, NULL))
        {
            RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmRemoteHold() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
		}
    }

    return RV_TRUE;
}

RvBool rvCCConnTermMdmRemoteUnhold(RvCCConnection* x)
{
    RvCCConnection*     party       = rvCCConnectionGetConnectParty(x);
    RvCCTerminal*       t           = rvCCConnectionGetTerminal(x);
    RvCCTermConnState   termState   = rvCCConnectionGetTermState(x);
    RvCCTerminalMdm*    ephTerm     = NULL;
    RvMdmTerm*          rtpTerm     = NULL;
    RvMdmMediaStreamInfo* rtpMedia  = NULL;
    RvBool              res;

    /* Get RTP Media objects - use the same ones for audio and video*/
    res = getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia);
    if (!res)
        goto err_exit;

    RvLogInfo(ippLogSource,(ippLogSource, "Term: %s - Unhold Connection Remote, Line: %d, conn(%p), termState: %s ",
        rvCCTerminalGetId(t), rvCCConnectionGetLineId(x), x, rvCCTextTermConnState(termState) ));

    if (termState == RV_CCTERMCONSTATE_REMOTE_HELD)
    {

        rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_TALKING);
        rvCCConnectionSetTermState(party, RV_CCTERMCONSTATE_TALKING);

        rvCCConnectionTermSetHoldIndicator(x, RV_FALSE);
        rvCCTerminalMdmSetLineInd(t, rvCCConnectionGetLineId(x), RV_INDSTATE_ON);

        /* TODO: if media fails, we should go back to original states */
        res = modifyMedia( x, RVMDM_CMD_UNHOLD_REMOTE, ephTerm, rtpMedia, NULL);
        if(!res)
            goto err_exit;

        /* if the media is disconnected - let's connect it again
        (this could happen during transfer, when B calls to C)
        */
        if (x->mediaState != RV_CCMEDIASTATE_CONNECTED)
        {
            rvCCConnMdmConnectMedia(x);
        }

        /* Repair also connection state: */
        if (rvCCConnectionGetState(x) != RV_CCCONNSTATE_CONNECTED)
        {
            rvCCConnectionSetState(x, RV_CCCONNSTATE_CONNECTED);
        }
    }
    else if (termState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD)
    {
        rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_HELD);
        rvCCConnectionSetTermState(party, RV_CCTERMCONSTATE_HELD);

        /* TODO: if media fails, we should go back to original states */
        res = modifyMedia( x, RVMDM_CMD_UNHOLD_INACTIVE_TO_LOCAL, ephTerm, rtpMedia, NULL);
        if(!res)
            goto err_exit;
    }
    return res;
err_exit:
    RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmRemoteUnhold() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
    return res;
}


void rvCCConnTermMdmPlayDtmf(IN RvCCConnection* x, IN RvDtmfParameters* dtmfParam)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);
	RvInt32       lineId = rvCCConnectionGetLineId(x);

    rvCCTerminalMdmStartDTMFTone(t, lineId, dtmfParam);
}

void rvCCConnTermMdmPlayDtmfEnd(RvCCConnection* x, char digit)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);

    RV_UNUSED_ARG(digit);

    rvCCTerminalMdmStopDTMFTone(t);
}


void rvCCConnTermMdmSetMuteIndicator(RvCCConnection* x, RvBool on)
{
    RvCCTerminal* t = rvCCConnectionGetTerminal(x);

    /*Don't turn Hold indicator off if at least one more connection is on Hold */
    /*if ((on == RV_FALSE) && (otherHeldConnExist(t, x) == RV_TRUE))
        return;*/

    if (t != NULL)
        rvCCTerminalMdmSetMuteInd(t, on);
}

/* mute */

void rvCCConnTermMdmMute(RvCCConnection* x)
{
    RvCCTerminalMdm* ephTerm = NULL;
    RvMdmTerm* rtpTerm = NULL;
    RvMdmMediaStreamInfo* rtpMedia = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
    {
        return;
	}

    rvCCConnectionTermSetMuteIndicator( x,RV_TRUE);
    rvCCConnectionSetTermState( x, RV_CCTERMCONSTATE_MUTE);

    if(!modifyMedia( x, RVMDM_CMD_MUTE_ALL, ephTerm, rtpMedia, NULL))
    {
        RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmMute() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
	}
}

/* Unmute */
void rvCCConnTermMdmUnmute(RvCCConnection* x)
{
    RvCCTerminalMdm* ephTerm = NULL;
    RvMdmTerm* rtpTerm = NULL;
    RvMdmMediaStreamInfo* rtpMedia = NULL;

    /* Get RTP Media objects - use the same ones for audio and video*/
    if ((getRtpMediaObjects(x, &ephTerm, &rtpTerm, &rtpMedia)) == RV_FALSE)
    {
        return;
	}

    rvCCConnectionTermSetMuteIndicator( x,RV_FALSE);
    rvCCConnectionSetTermState( x,RV_CCTERMCONSTATE_TALKING);

    if(!modifyMedia( x, RVMDM_CMD_UNMUTE_ALL, ephTerm, rtpMedia, NULL))
    {
        RvLogError(ippLogSource,(ippLogSource, "rvCCConnTermMdmUnmute() failed in modifyMedia:Line: %d, conn(%p)", rvCCConnectionGetLineId(x), x));
	}
}

const char* rvCCConnMdmGetCallerNumber(RvCCConnection* x,int index)
{
    RvCCTerminalMdm* term = rvCCConnMdmGetTerminalImpl(x);
    RvMdmTermPhoneNumbers* phoneNumbers = rvCCTerminalMdmGetPhoneNumbers(term);

    return rvMdmTermPhoneNumbersGetByIndex(phoneNumbers, (RvUint32)index);
}

/*==================================================================================
============= D E F A U L T  D I S P L A Y  F U N C T I O N               ==========
===================================================================================*/
/*For analog line, display only call-id*/
static void rvCCConnMdmAnalogDisplay(RvCCConnection* x, RvCCTerminal* t,
                        RvCCTerminalEvent event, RvCCEventCause cause,
                        void* displayData)
{
    RvCCConnState connState = rvCCConnectionGetState(x);

    RV_UNUSED_ARG(displayData);
    RV_UNUSED_ARG(cause);

    if (event == RV_CCTERMEVENT_MAKECALL)
    {
        if (connState==RV_CCCONNSTATE_OFFERED)
        {
            if ((x->mediaState != RV_CCMEDIASTATE_FAILED) &&
                (x->mediaState != RV_CCMEDIASTATE_DISCONNECTED))
            {
                RvCCConnection* party = rvCCConnectionGetConnectParty(x);
                /* Send all the caller id info so the application
                  can build the signal */
                rvCCTerminalMdmSendCallerId(t,
                    rvCCConnectionGetCallerName(party),
                    rvCCConnectionGetCallerNumber(party,0),
                    rvCCConnectionGetCallerAddress(party),
                    rvCCConnectionGetCallerId(party));
            }
        }
    }

}

/* this function should be transfered to user!!! to decide what to display */
static void displayCallerId(RvCCConnection* x, RvCCTerminal* t)
{
    char buf[64];
    const char*     callerId        =NULL;
    RvCCConnection* party           = rvCCConnectionGetConnectParty(x);
    const int       OURDISPLAY_SIZE =15;
    RvSize_t        length          =0;
    /* Functions available for caller id information are :
       rvCCConnectionGetCallerAddress()
       rvCCConnectionGetCallerNumber()
       rvCCConnectionGetCallerName()
       rvCCConnectionGetCallerId()
    */
    callerId = rvCCConnectionGetCallerId(party);
    if (!callerId)
    /* the callerId is NULL only!!! when calling party set Identification Restriction flag */
        callerId = "Private";
    length = strlen(callerId);
    if (length > (RvSize_t)(OURDISPLAY_SIZE-5) /*leave a room for "from:")*/)
        callerId = rvCCConnectionGetCallerAddress(party);
    RvSnprintf(buf, sizeof(buf), "From:%s", callerId);
    rvCCTerminalMdmClearDisplay(t);
    rvCCTerminalMdmSetDisplay(t, buf, 0, 0);
}

static RvBool rvCCConnMdmUiDisplay(RvCCConnection* x, RvCCTerminal* t,
                        RvCCTerminalEvent event, RvCCEventCause cause,
                        void* displayData)
{
    char buf[64];
    const char* dialString;

    RvCCConnState state = rvCCConnectionGetState(x);
    RvBool keepDisplay = RV_FALSE;

    RV_UNUSED_ARG(cause);
    /* Clear display if not active connections left -
       this is the only processing done for not active conn */
    if (rvCCTerminalGetNumActiveConnections(t)==0 )
    {
        rvCCTerminalMdmClearDisplay(t);
        rvCCTerminalMdmSetDisplay(t,(char*)displayData, 0, 0);
    }

    switch(state)
    {
        case RV_CCCONNSTATE_CONNECTED:
            rvCCTerminalMdmClearDisplay(t);
            rvCCTerminalMdmSetDisplay(t, "Connected...", 0, 0);
            break;

        case RV_CCCONNSTATE_INITIATED:
            rvCCTerminalMdmClearDisplay(t);
            break;

        case RV_CCCONNSTATE_ALERTING:
            displayCallerId(x,t);
            keepDisplay = RV_TRUE;
            break;

        case RV_CCCONNSTATE_DIALING:
            if (event == RV_CCTERMEVENT_DIGITS)
            {
                RvSize_t strLen;
                dialString = rvCCTerminalMdmGetDialString(t);
                strLen = strlen(dialString);

                if (strLen == 1)
                {
                    /* First digit collected*/
                    rvCCTerminalMdmClearDisplay(t);
                }
                /* Echo digit */
                buf[0] = dialString[strLen-1];
                buf[1] = '\0';
                rvCCTerminalMdmSetDisplay(t, buf, 0, rvCCTerminalGetCurDisplayColumn(t));
            }
            break;
        default: /* Do nothing */
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    return keepDisplay;
}


void rvCCConnMdmDisplay(RvCCConnection* x, RvCCTerminal* t,
                        RvCCTerminalEvent event, RvCCEventCause cause,
                        void* displayData) {

    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCTerminalType termType = rvCCTerminalMdmGetType(term);
    RvCCConnection* activeConn = rvCCTerminalGetActiveConnection(t);
    RvBool keepDisplay;

    switch (termType)
    {
        case RV_CCTERMINALTYPE_ANALOG:
            rvCCConnMdmAnalogDisplay(x, t, event, cause, displayData);
            break;
        case RV_CCTERMINALTYPE_UI:
            /* Process the event for the connection and the
               active connection if they are different */
            keepDisplay = rvCCConnMdmUiDisplay(x, t, event, cause, displayData);
            if(keepDisplay==RV_FALSE && activeConn!=x)
                rvCCConnMdmUiDisplay(activeConn, t, event, cause, displayData);
            break;
        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

}


#ifdef RV_MTF_VIDEO
/************************************************************************************
 * rvCCConnMdmVideoFastUpdatePicture
 *     The function uses extension API to call the callback function
 *     supplied by the user to inform the application that
 *     Fast Update Picture command has arrived to encoder (camera)
 * Parameters:
 *     conn - MDM connection
 *     hStream -  video stream handle
 *     hAppStream - application video stream handle 
 ************************************************************************************/
void rvCCConnMdmVideoFastUpdatePicture(RvCCConnection *conn,
									   RvMtfMediaStreamHandle hStream,
									   RvMtfMediaStreamAppHandle hAppStream)  
{
    rvIppMdmVideoExtFastUpdatePictureCB(conn, hStream, hAppStream);
}

/************************************************************************************
 * rvCCConnMdmVideoFastUpdateGOB
 *     The function uses extension API to call the callback function
 *     supplied by the user to inform the application that
 *     Fast Update Group Of Blocks command has arrived to encoder (camera)
 * Parameters:
 *     conn      - MDM connection
 *     hStream -  video stream handle
 *     hAppStream - application video stream handle 
 *     firstGob  - first Group of Blocks,
 *                        the parameter of FastUpdateto command to be past to encoder
 *     numMbs    - number of Group Of Blocks,
 *                         the parameter of FastUpdateto command to be past to encoder
 ************************************************************************************/
void rvCCConnMdmVideoFastUpdateGOB(RvCCConnection *conn,
									RvMtfMediaStreamHandle hStream,
									RvMtfMediaStreamAppHandle hAppStream,
									RvUint firstGob,
									RvUint numGobs)
{
    rvIppMdmVideoExtFastUpdateGobCB(conn, hStream, hAppStream, firstGob, numGobs);
}

/************************************************************************************
 * rvCCConnMdmVideoFastUpdateMB
 *     The function uses extension API to call the callback function
 *     supplied by the user to inform the application that
 *     Fast Update Multi Blocks command has arrived to encoder (camera)
 * Parameters:
 *     conn     - MDM connection
 *     hStream -  video stream handle
 *     hAppStream - application video stream handle 
 *     firstGob - first Group of Blocks,
 *                        the parameter of FastUpdateto command to be past to encoder
 *     firstMb  - first Multi Block,
 *                         the parameter of FastUpdateto command to be past to encoder
 *     numMbs   - number of Multi Blocks,
 *                         the parameter of FastUpdateto command to be past to encoder
 ************************************************************************************/
void rvCCConnMdmVideoFastUpdateMB(RvCCConnection *conn,
									RvMtfMediaStreamHandle hStream,
									RvMtfMediaStreamAppHandle hAppStream,								  
									RvUint firstGob,
									RvUint firstMb,
									RvUint numMbs)
{
    rvIppMdmVideoExtFastUpdateMbCB(conn, hStream, hAppStream, firstGob, firstMb, numMbs);
}

/************************************************************************************
 * rvCCConnMdmVideoFastUpdatePictureFreeze
 *     The function uses extension API to call the callback function
 *     supplied by the user to inform the application that
 *     Fast Update Picture Freeze command has arrived to decoder (screen)
 * Parameters:
 *     conn - MDM connection
 *     hStream -  video stream handle
 *     hAppStream - application video stream handle 
 ************************************************************************************/
void rvCCConnMdmVideoFastUpdatePictureFreeze(RvCCConnection *conn,
											 RvMtfMediaStreamHandle hStream,
											 RvMtfMediaStreamAppHandle hAppStream)  

{
    rvIppMdmVideoExtFastUpdatePictureFreezeCB(conn, hStream, hAppStream);
}

/***************************************************************************
 * rvCCConnMdmSendFastUpdatePicture
 *    Send FastUpdatePicture command to the network (to other party of the call)
 *    This command is sent to encoder (camera termination)
 * Parameters:
 *     conn - mdm connection
 *	   hStream - stream handle
 ***************************************************************************/
RvStatus rvCCConnMdmSendFastUpdatePicture(RvCCConnection *conn, 
										  RvMtfMediaStreamHandle hStream)
{
    RvStatus res;
    RvCCConnection* networkConn = rvCCConnectionGetConnectParty(conn);

    if (networkConn != NULL)
      res = rvCCConnectionSendFastUpdatePicture(networkConn, hStream);
    else res = RV_ERROR_NULLPTR;

    return res;
}

/***************************************************************************
 * rvCCConnMdmSendFastUpdateGOB
 *    Send FastUpdateGOB command to the network (to other party of the call)
 *    This command is sent to encoder (camera termination)
 * Parameters:
 *     conn - mdm connection
 *     hStream - stream handle
 ***************************************************************************/
RvStatus rvCCConnMdmSendFastUpdateGOB(RvCCConnection *conn,
									RvMtfMediaStreamHandle hStream,
                                    RvUint firstGob,
                                    RvUint numGobs)
{
    RvStatus res;
    RvCCConnection* networkConn = rvCCConnectionGetConnectParty(conn);

    if (networkConn != NULL)
        res = rvCCConnectionSendFastUpdateGOB(networkConn, hStream, firstGob, numGobs);
    else res = RV_ERROR_NULLPTR;

    return res;
}

/***************************************************************************
 * rvCCConnMdmSendFastUpdateMB
 *    Send FastUpdateMB command to the network (to other party of the call)
 *    This command is sent to encoder (camera termination)
 * Parameters:
 *     conn - mdm connection
 *     hStream - stream handle
 ***************************************************************************/
RvStatus rvCCConnMdmSendFastUpdateMB(RvCCConnection *conn,
                                    RvMtfMediaStreamHandle hStream,
									RvUint firstGob,
                                    RvUint firstMb,
                                    RvUint numMbs)
{
    RvStatus res;
    RvCCConnection* networkConn = rvCCConnectionGetConnectParty(conn);

    if (networkConn != NULL)
        res = rvCCConnectionSendFastUpdateMB(networkConn, hStream, firstGob, firstMb, numMbs);
    else res = RV_ERROR_NULLPTR;

    return res;
}

/***************************************************************************
 * rvCCConnMdmSendFastUpdatePictureFreeze
 *    Send FastUpdatePicture command to the network (to other party of the call)
 *    This command is sent to decoder (screen termination)
 * Parameters:
 *     conn - mdm connection
 *     hStream - stream handle
 ***************************************************************************/
RvStatus rvCCConnMdmSendFastUpdatePictureFreeze(RvCCConnection *conn,
												RvMtfMediaStreamHandle hStream)
{
    RvStatus res;
    RvCCConnection* networkConn = rvCCConnectionGetConnectParty(conn);

    if (networkConn != NULL)
        res = rvCCConnectionSendFastUpdatePictureFreeze(networkConn, hStream);
    else res = RV_ERROR_NULLPTR;

    return res;
}

#endif /* RV_MTF_VIDEO*/
