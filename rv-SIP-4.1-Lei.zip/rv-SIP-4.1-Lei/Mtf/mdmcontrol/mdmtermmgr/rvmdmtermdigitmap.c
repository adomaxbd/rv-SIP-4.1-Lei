/******************************************************************************
Filename:    rvmdmtermdigitmap.c
Description:
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC	LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvmdmtermevent.h"

static void flipCurrentTimer( RvCCTerminalMdm* x)
{
	if(x->digitMapCurTimer == &x->digitMapTimer[0])
		(x)->digitMapCurTimer = &x->digitMapTimer[1];
	else
		(x)->digitMapCurTimer = &x->digitMapTimer[0];
}


#define RvMdmDigitMapConstructCopy		rvMdmDigitMapConstructCopy
#define RvMdmDigitMapDestruct		    rvMdmDigitMapDestruct

rvDefineMap(RvIString,RvMdmDigitMap)

void rvMdmDigitMapDBConstruct(RvMdmDigitMapDB* db,RvAlloc* alloc) {
	rvMapConstruct(RvIString,RvMdmDigitMap)(&db->maps,alloc);
	RvMutexConstruct( IppLogMgr(), &db->mutex);
}

void rvMdmDigitMapDBDestruct(RvMdmDigitMapDB* db) {
	rvMapDestruct(&db->maps);
	RvMutexDestruct(&db->mutex, IppLogMgr());
}

void rvMdmDigitMapDBCopy(RvMdmDigitMapDB* dest,const RvMdmDigitMapDB* src) {
	rvMapCopy(&dest->maps,&src->maps);
}

static RvMdmDigitMap* findLocalDigitMap(RvMdmDigitMapDB* db,const RvString* id) {
	return (RvMdmDigitMap*)rvMapGetValue(RvIString,RvMdmDigitMap)(&db->maps,id);
}

/* Get a local digitmap */
static const RvMdmDigitMap* getLocalDigitMap(RvMdmDigitMapDB* db,const RvString* id) {
	RvMdmDigitMap* map;
	RvMutexLock(&db->mutex,IppLogMgr());
	map = findLocalDigitMap(db,id);
	RvMutexUnlock(&db->mutex,IppLogMgr());
	return map;
}

/* Will define or overwrite a local digitmap */
static void setLocalDigitMap(RvMdmDigitMapDB* db,const RvString* id,const RvMdmDigitMap* newMap) {
	RvMdmDigitMap* map;
	RvMutexLock(&db->mutex,IppLogMgr());
	map = findLocalDigitMap(db,id);
	if(map==NULL) {
		rvMapSetValue(RvIString,RvMdmDigitMap)(&db->maps,id,newMap);
	}
	else {
		rvMdmDigitMapCopy(map,newMap);
	}
	RvMutexUnlock(&db->mutex,IppLogMgr());
	return;
}

static void deleteLocalDigitMap(RvMdmDigitMapDB* db,const RvString* id) {
	RvMutexLock(&db->mutex,IppLogMgr());
	rvMapRemove(RvIString,RvMdmDigitMap)(&db->maps,id);
	RvMutexUnlock(&db->mutex,IppLogMgr());
	return;
}

/* Look for the digtmap,first in the termination and then in the root termination */
RvBool setCurrentDigitMap(RvCCTerminalMdm* x,const RvString* id) {
	const RvMdmDigitMap* map = getLocalDigitMap(&x->storedDigitMaps,id);
	if(map==NULL) {
/*		RvCCTerminalMdm* rootTerm = rvMdmTermMgrGetRootTermination(x->context->termMgr);
		map = getLocalDigitMap(&rootTerm->storedDigitMaps,id);
		map = getLocalDigitMap(&x->storedDigitMaps,id);*/
	}
	if(map!=NULL) {
		rvMdmDigitMapCopy(&x->digitMap,map);
		return rvTrue;
	}
	return rvFalse;
}



/* Process the digitmap descriptor */
void rvMdmTermProcessDigitMap(RvCCTerminalMdm * x,const RvMdmDigitMapDescriptor * digitMapDescr) {
	RvBool isNameSet,isDigitMapSet;
	const RvMdmDigitMap* map;

	if(!rvMdmDigitMapDescriptorIsSet(digitMapDescr))
		return ; /* Nothing to process */

	isNameSet = (rvMdmDigitMapDescriptorGetName(digitMapDescr)[0] != '\0');
	map = rvMdmDigitMapDescriptorGetDigitMap(digitMapDescr);
	isDigitMapSet = (rvMdmDigitMapGetSize(map) > 0);

	/* Both set: define or redefine a digitmap */
	if(isNameSet && isDigitMapSet)
		setLocalDigitMap(&x->storedDigitMaps,&digitMapDescr->name,map);

	/* Only name set: find and install map */
	else if(isNameSet) {
		deleteLocalDigitMap(&x->storedDigitMaps,&digitMapDescr->name);
	}

	return;
}

/* Timers */
static RvBool digitMapTimerProcess0( void* term)
{
	RvCCTerminalMdm * x = (RvCCTerminalMdm *)term;

	/* Verify that is the correct timer,otherwise
	   ignore */
	RvMutexLock(&x->mutex, IppLogMgr());
/*  if( rvTimerGetId(t) == rvTimerGetId(&x->digitMapTimer[x->digitMapCurTimer]) ) */
    if( &x->digitMapTimer[0] == x->digitMapCurTimer)
    {
		rvMdmTermDigitMapTimerProcess(x);
	}
	RvMutexUnlock(&x->mutex, IppLogMgr());
    return RV_TRUE;
}

static RvBool digitMapTimerProcess1( void* term)
{
	RvCCTerminalMdm * x = (RvCCTerminalMdm *)term;

	/* Verify that is the correct timer,otherwise
	   ignore */
	RvMutexLock(&x->mutex, IppLogMgr());
    if (&x->digitMapTimer[1] == x->digitMapCurTimer)
    {
		rvMdmTermDigitMapTimerProcess(x);
	}
	RvMutexUnlock(&x->mutex, IppLogMgr());
    return RV_TRUE;
}


static void digitMapTimerStop(RvCCTerminalMdm* x)
{
	RvMutexLock(&x->mutex,IppLogMgr());
	IppTimerStop(x->digitMapCurTimer);
	flipCurrentTimer(x);
	RvMutexUnlock(&x->mutex,IppLogMgr());
}

void rvMdmTermDigitMapTimerRestart(RvCCTerminalMdm* x,RvMilliseconds timeout)
{
	RvMutexLock(&x->mutex,IppLogMgr());
	IppTimerStop(x->digitMapCurTimer);
	flipCurrentTimer(x);
	IppTimerStart(x->digitMapCurTimer, IPP_TIMER_RESTART_IF_STARTED,timeout);
	RvMutexUnlock(&x->mutex,IppLogMgr());
}

static void digitMapTimerStart(RvCCTerminalMdm* x,RvMilliseconds timeout)
{
	RvMutexLock(&x->mutex,IppLogMgr());
	IppTimerStart(x->digitMapCurTimer, IPP_TIMER_RESTART_IF_STARTED, timeout);
	RvMutexUnlock(&x->mutex,IppLogMgr());
}

void rvMdmTermDigitMapTimerConstruct(RvCCTerminalMdm* x)
{
    x->digitMapCurTimer = 0;

	IppTimerConstruct(&x->digitMapTimer[0],0,digitMapTimerProcess0,x);
	IppTimerConstruct(&x->digitMapTimer[1],0,digitMapTimerProcess1,x);
	x->digitMapCurTimer = &x->digitMapTimer[0];
}

void rvMdmTermDigitMapTimerDestruct(RvCCTerminalMdm* x)
{
	IppTimerDestruct(&x->digitMapTimer[0]);
	IppTimerDestruct(&x->digitMapTimer[1]);
}

void rvMdmTermDeactivateDigitMap(RvCCTerminalMdm * x)
{
	/* Shouldn't usually be true,check for sanity*/
	if (x->digitMapActive == RV_TRUE)
    {
		digitMapTimerStop(x);
		x->digitMapActive = RV_FALSE;
	}
}

void rvMdmTermActivateDigitMap(RvCCTerminalMdm * x)
{
	RvMilliseconds timeout = rvMdmDigitMapGetStartTimeout(&x->digitMap)*1000;
	digitMapTimerStart(x, timeout);

	/* Set the flag */
	x->digitMapActive = RV_TRUE;
}

/* Install an active digitMap */
RvBool rvMdmTermProcessDigitMapParameter(RvCCTerminalMdm * x,
										 const RvMdmRequestedEvent* reqEvent,
										 RvBool toActivateDigitMap)
{
	RvBool isNameSet,isDigitMapSet;
	const RvMdmDigitMap* map;
	const RvMdmDigitMapDescriptor * digitMapDescr;
	const RvMdmPackageItem* name;

	digitMapDescr = rvMdmRequestedEventGetEmbDigitMap(reqEvent);
	name = rvMdmRequestedEventGetName(reqEvent);

	if(!rvMdmDigitMapDescriptorIsSet(digitMapDescr))
		return rvTrue; /* Nothing to process */

	rvMdmTermDeactivateDigitMap(x);

	/* Initialize DigitMap state variables */
	rvStringResize(&x->dialString,0);
	/* If first timer expires with no digits, match is partial */
	x->digitMapStat = RV_MDMDIGITMAP_PARTIALMATCH;
	x->digitMapMedia = NULL;
	x->digitMapReqEvent = reqEvent;

	/* Set the digitMap information */
	x->digitMapEC = rvMdmTermMgrGetDigitMapPkgInfo_(rvCCTerminalMdmGetTermMgr(x),
													   rvMdmPackageItemGetPackage(name));
	if (x->digitMapEC==NULL)
    {
/*		rvMdmTermSendErrorMsg(x,&error,RV_MDMERROR_NO_DIGITMAP,
									 "Media Gateway does not have a digit map",commReply);*/
		return rvFalse;/*ERROR*/
	}

	isNameSet = (rvMdmDigitMapDescriptorGetName(digitMapDescr)[0] != '\0');
	map = rvMdmDigitMapDescriptorGetDigitMap(digitMapDescr);
	isDigitMapSet = (rvMdmDigitMapGetSize(map) > 0);

	/* Assume that name and map are not both set. First try map, then name */
	if (isDigitMapSet)
    {
		rvMdmDigitMapCopy(&x->digitMap,rvMdmDigitMapDescriptorGetDigitMap(digitMapDescr));
	}

	/* Only name set: find and install map */
	else if (isNameSet)
    {
		if (!setCurrentDigitMap(x,&digitMapDescr->name))
        {
/*			rvMdmTermSendErrorMsg(x,&error,RV_MDMERROR_NO_DIGITMAP,
									 "Media Gateway does not have a digit map",commReply);*/
			return rvFalse;
		}
	}

	if(toActivateDigitMap==rvTrue)
		rvMdmTermActivateDigitMap(x);

	return rvTrue;
}

void rvMdmTermAddDigitMap(RvCCTerminalMdm * x, const RvMdmDigitMap* map, const RvString* name)
{
	/*rvMapSetValue(RvIString,RvMdmDigitMap)(&db->maps,id,newMap);*/
	setLocalDigitMap(&x->storedDigitMaps, name, map);
}

const RvMdmDigitMap* rvMdmTermGetDigitMap(RvCCTerminalMdm * x, const RvString* name)
{
	return getLocalDigitMap(&x->storedDigitMaps, name);
}
