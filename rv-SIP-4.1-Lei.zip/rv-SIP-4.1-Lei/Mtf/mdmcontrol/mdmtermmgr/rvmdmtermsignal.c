/******************************************************************************
Filename:    rvmdmtermsignal.c
Description:
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC	LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvmdmtermsignal.h"
#include "rvccterminalmdm.h"


static void rvMdmCurSignalDestruct(RvMdmCurSignal* x);

typedef RvListRevIter(RvMdmCurSignal) RvMdmCurSignalIter;

static void buildMdmSignal(struct RvCCTerminalMdm_ * x,RvMdmSignal * mdmSignal,const RvMdmSignalEx * signal)
{
	const RvMdmPackageItem * pkgItem;

	RV_UNUSED_ARG(x);
	pkgItem  = rvMdmSignalExGetName(signal);

	rvMdmSignalConstruct_(mdmSignal,rvMdmPackageItemGetItem(pkgItem),
							 rvMdmPackageItemGetPackage(pkgItem),
							 rvMdmSignalExGetParameterList(signal));

}

/* Set iterator to next after removing this one */
static void removeSignal(struct RvCCTerminalMdm_* x,RvMdmCurSignalIter* i)
{
	/* Delete signal from list */
	*i = rvListErase(RvMdmCurSignal)(&x->curSignals,*i);
}

static RvBool stopMdmSignal(struct RvCCTerminalMdm_* x,const RvMdmSignalEx* signal)
{
	RvMdmSignal mdmSignal;
	RvMdmError* error=NULL;

	buildMdmSignal(x, &mdmSignal, signal);
	return rvMdmTermStopSignal_(&x->mdmTerm,&mdmSignal,error);
}

/*
	RV_MDMSIGNAL_COMPLETED = 1,
	RV_MDMSIGNAL_GOTEVENT = 2,
	RV_MDMSIGNAL_NEWSIGDESCR = 4,
	RV_MDMSIGNAL_OTHERREASON = 8
*/

static char* completeEventReason[] = {"TO","EV","SD","NC"};
static char* getReasonStr(RvMdmSignalNotificationReasons reason)
{
	switch(reason)
    {
		case RV_MDMSIGNAL_COMPLETED :   return completeEventReason[0];
		case RV_MDMSIGNAL_GOTEVENT :    return completeEventReason[1];
		case RV_MDMSIGNAL_NEWSIGDESCR : return completeEventReason[2];
		case RV_MDMSIGNAL_OTHERREASON :
		default						 :  return completeEventReason[3];
	}
}


static void generateCompleteEvent(struct RvCCTerminalMdm_* x,const RvMdmSignalEx* signal,int listId,
								  RvMdmSignalNotificationReasons reason)
{
	RvMdmParameterList args;
	RvMdmParameterValue value;
	RvMdmPackageItem name;
	const RvMdmPackageItem * sigName;
        const RvChar *charStr;
	RvString sigArg;
/*	RvMdmSignalNotificationReasons reqReason = rvMdmSignalGetNotifyReasons(signal);*/
	char list[32];

/*	if( !(reqReason & reason) )
		return;*/

	/* Generate completion event */
	rvStringConstruct(&sigArg,"",x->alloc);

	rvMdmParameterListConstructA(&args,x->alloc);

	/* Set signal id */
	sigName  = rvMdmSignalExGetName(signal);
    charStr = rvMdmPackageItemGetPackage(sigName);
	if (listId != 0)
    {
		rvStringConcatenate(&sigArg, charStr);
		RvSnprintf(list, sizeof(list), "/%d", listId);
		rvStringConcatenate(&sigArg,list);
		rvStringConcatenate(&sigArg,"{");
	}
	rvStringConcatenate(&sigArg, charStr);
	rvStringConcatenate(&sigArg,"/");
    charStr = rvMdmPackageItemGetItem(sigName);
	rvStringConcatenate(&sigArg, charStr);
	if(listId!=0)
		rvStringConcatenate(&sigArg,"}");

	rvMdmPackageItemConstructA(&name,"g","SigId",x->alloc);
	rvMdmParameterValueConstructA(&value,rvStringGetData(&sigArg),x->alloc);
	rvMdmParameterListSet(&args,&name,&value);
	rvMdmPackageItemDestruct(&name);
	rvMdmParameterValueDestruct(&value);
	rvStringDestruct(&sigArg);

	/* Set reasons */
	rvMdmPackageItemConstructA(&name,"g","Meth",x->alloc);
	rvMdmParameterValueConstructA(&value,getReasonStr(reason),x->alloc);
	rvMdmParameterListSet(&args,&name,&value);
	rvMdmParameterValueDestruct(&value);
	rvMdmPackageItemDestruct(&name);

	/* Send event */
	rvMdmTermProcessEvent(rvCCTerminalMdmGetMdmTerm(x),"g","sc", NULL,&args);

	/* Free local objects */
	rvMdmParameterListDestruct(&args);

}

/* Return the next iterator after removing this one */
static RvBool stopCurSignal(struct RvCCTerminalMdm_* x,RvMdmCurSignalIter* i,
							RvMdmSignalNotificationReasons reason)
{
	RvBool retval;
	RvMdmCurSignal* curSignal = rvListIterData(*i);

	RV_UNUSED_ARG(reason);

	retval = stopMdmSignal(x,&curSignal->signal);

	removeSignal(x,i);
	return retval;
}

static void rvMdmCurSignalConstruct(RvMdmCurSignal* x,
									   struct RvCCTerminalMdm_* term,const RvMdmSignalEx* signal)
{
	x->term = term;
	rvMdmSignalExConstructCopy(&x->signal,signal,rvListGetAllocator(&term->curSignals));
	x->timer = NULL;
}

static void rvMdmCurSignalDestruct(RvMdmCurSignal* x)
{
	rvMdmSignalExDestruct(&x->signal);
	rvMdmTermTimerCancel(x->timer);
}

/* This will be an empty function to allow unconstructed objects to be inserted */
RvMdmCurSignal* RvMdmCurSignalConstructCopy(RvMdmCurSignal* d,const RvMdmCurSignal* s,RvAlloc* a)
{
	RV_UNUSED_ARG(s);
	RV_UNUSED_ARG(a);
	return d;
}

static RvBool signalMatch(const RvMdmSignalEx* s1,const RvMdmSignalEx* s2)
{
	const RvMdmPackageItem* n1 = rvMdmSignalExGetName(s1);
	const RvMdmPackageItem* n2 = rvMdmSignalExGetName(s2);

	/* Check if both name and media id match */
	return ( rvMdmPackageItemEqual(n1,n2)) ;
}

RvBool RvMdmCurSignalEqual(const RvMdmCurSignal* x,const RvMdmCurSignal* y)
{
	return signalMatch(&x->signal,&y->signal);
}

rvDefineList(RvMdmCurSignal)
rvDefineListAllocBack(RvMdmCurSignal)

static void addCurSignal(struct RvCCTerminalMdm_* x,const RvMdmSignalEx* signal,RvMilliseconds timeout)
{
	RvMdmCurSignal * cur;
	RV_UNUSED_ARG(timeout);
	cur = rvListAllocBack(RvMdmCurSignal)(&x->curSignals);
	rvMdmCurSignalConstruct(cur,x,signal);
	}

static void stopActiveSignals(struct RvCCTerminalMdm_ * x,
								const RvMdmSignalsDescriptor * signalsDescr,
								RvMdmSignalNotificationReasons reason)
{
	RvMdmCurSignalIter i, next;

	RV_UNUSED_ARG(reason);
	RV_UNUSED_ARG(signalsDescr);
	
	for (i=rvListBegin(&x->curSignals);i!=rvListEnd(&x->curSignals);i=next)
    {
		next=rvListIterNext(i);

			/* stopCurSignal will set next iterator */
		stopCurSignal(x,&i,reason);
			}
	return;
}

static RvMdmSignalType getType(const RvMdmSignalEx* s,const RvMdmSignalInfo* i,RvMilliseconds* timeout)
{
	RvMdmSignalType type;
	if( rvMdmSignalExGetType(s)==RV_MDMSIGNAL_DEFAULTTYPE )
		type =	i->type ;
	else
		type = rvMdmSignalExGetType(s);

	/* Add timeout type signals to list of currently playing signals*/
	if(type==RV_MDMSIGNAL_TIMEOUT)
    {
		if(rvMdmSignalExGetDuration(s)==0)
			*timeout = i->duration;
		else
			*timeout = rvMdmSignalExGetDuration(s)*10;
	}
	else
		*timeout=0;
	return type;
}

static RvBool rvMdmTermStartSignal(struct RvCCTerminalMdm_* x,const RvMdmSignalEx* signal,
						  RvMdmSignalType* type,RvMilliseconds* timeout)
{
	const RvMdmPackageItem* name;
	const RvMdmSignalInfo* info = NULL;
	RvMdmError error;
	RvBool reportCompletion;
	RvMdmSignal mdmSignal;
	RvMdmTermMgr * mdmMgr = rvCCTerminalMdmGetTermMgr(x);

	/* Validate the signal */
	name = rvMdmSignalExGetName(signal);
	if (rvMdmTermIsPkgSupported_(rvCCTerminalMdmGetMdmTerm(x),rvMdmPackageItemGetPackage(name)))
    {
		info = rvMdmTermMgrGetSignalInfo_(mdmMgr,&name->package,&name->item);

		if (info != NULL)
        {
			/* Start the signal */
			buildMdmSignal(x,&mdmSignal,signal);
			*type = getType(signal,info,timeout);
			if (*type==RV_MDMSIGNAL_BRIEF)
            {
				reportCompletion=0;
				if (rvMdmTermPlaySignal_(&x->mdmTerm,&mdmSignal,reportCompletion,&error))
                {
					return RV_TRUE;
				}
			}
			else
            {
				if (rvMdmTermStartSignal_(&x->mdmTerm,&mdmSignal,&error))
                {
					return RV_TRUE;
				}
			}
		}
	}

	return RV_FALSE;
}

/*
1. Stop active signals and signalLists except if a new signal with
keepAlive is present. Generate completion if required.
For each signal:
2. Validate the signal
3. Get the signal type,duration (Note: Is 0 used for default duration? )
4. Start the signal. If fails,report error
5. If type==timeout, start timer
6. For signal lists,process sequentially
*/
RvBool rvMdmTermProcessNewSignals(struct RvCCTerminalMdm_ * x,const RvMdmSignalsDescriptor * signalsDescr)
{
	unsigned int i;
	RvMdmCurSignalIter iter;
	const RvMdmSignalEx * signal;
	RvMilliseconds timeout;
	RvMdmSignalType type;
	RvMdmCurSignal* curSignal;
	RvBool          startTheSignal = RV_FALSE;

	for(i=0;i<rvMdmSignalsDescriptorGetNumSignals(signalsDescr);i++)
	{
		signal = rvMdmSignalsDescriptorGetSignal(signalsDescr,i);
		startTheSignal = RV_TRUE;

		/* Loop over the list of active signals, check if the requested signal is already active */
		if (rvMdmSignalExGetType(signal) != RV_MDMSIGNAL_BRIEF)
		{
			for(iter=rvListBegin(&x->curSignals);iter!=rvListEnd(&x->curSignals);iter = rvListIterNext(iter))
			{
				curSignal = rvListIterData(iter);
				/* don't start the signal if it is already in the list */
				if (signalMatch(signal,&curSignal->signal))
				{
					startTheSignal = RV_FALSE;
					break;
				}
			}
		}

		if (startTheSignal)
		{
			/* Start the signal */
			/* If an error is received,stop processing */
			if(!rvMdmTermStartSignal(x,signal,&type,&timeout))
				return rvFalse;

			/* Add the signal to the active signals list */
			if( type!=RV_MDMSIGNAL_BRIEF )
				addCurSignal(x,signal,timeout);
		}
	}

	return rvTrue;
}


/*------------------------------------------------------------*/
/* Signal lists												  */
/*------------------------------------------------------------*/
rvDefineList(RvMdmCurSignalList)
rvDefineListAllocBack(RvMdmCurSignalList)
typedef RvListIter(RvMdmCurSignalList) RvMdmCurSigListIter;

RvMdmCurSignalList* RvMdmCurSignalListConstructCopy(RvMdmCurSignalList* d,const RvMdmCurSignalList* s,RvAlloc* a)
{
	RV_UNUSED_ARG(s);
	RV_UNUSED_ARG(a);

	return d;
}

RvBool rvMdmCurSignalListEqual(const RvMdmCurSignalList* x,const RvMdmCurSignalList* y)
{
	return rvMdmSignalExListGetId(&x->list)==rvMdmSignalExListGetId(&y->list);
}

void rvMdmCurSignalListDestruct(RvMdmCurSignalList* x)
{
	rvMdmTermTimerCancel(x->timer);
	rvMdmSignalExListDestruct(&x->list);
}

static void rvMdmCurSignalListConstruct(RvMdmCurSignalList* x,struct RvCCTerminalMdm_* term,
										   const RvMdmSignalExList* list)
{
	x->term = term;
	x->curElem = 0;
	rvMdmSignalExListConstructCopy(&x->list,list,rvListGetAllocator(&term->curSignals));
}

static RvBool processSignalList(RvMdmCurSigListIter* i);

/* Callback function for signal lists */
static void processSigListTimeout(void* data)
{
	RvMdmTermTimer* mdmTimer = (RvMdmTermTimer*)data;
	RvMdmCurSigListIter iter = (RvMdmCurSigListIter)mdmTimer->data;
	processSignalList(&iter);
}

static void removeSignalList(struct RvCCTerminalMdm_* x,RvMdmCurSigListIter* i)
{
	*i = rvListErase(RvMdmCurSignalList)(&x->curSignalLists,*i);
}

/* Sequentially process the signal list, starting from current element.
   Stop when the signal is not brief */
/* Set iterator to next valid value */
static RvBool processSignalList(RvMdmCurSigListIter* i)
{
	RvMdmCurSignalList* curList = rvListIterData(*i);
	struct RvCCTerminalMdm_* x = curList->term;
	RvMdmSignalExList* list = &curList->list;
	size_t j;

	for(j=curList->curElem;j<rvMdmSignalExListGetSize(list);j++)
    {
		RvMilliseconds timeout;
		RvMdmSignalType type;
		const RvMdmSignalEx* signal = rvMdmSignalExListGetElem(list,j);
		/* Start the signal */
		/* If an error is received,stop processing */
		if(!rvMdmTermStartSignal(x,signal,&type,&timeout))
			return rvFalse;

		/* Increment the current element */
		curList->curElem++;

		/* Restore timer value to NULL */
		curList->timer = NULL;

		/* Keep processing as long as signals are brief */
		if( type==RV_MDMSIGNAL_BRIEF )
			continue;

		/* Start the timer for this signal, type is TIMEOUT */
		if( timeout )
        {
			curList->timer = rvMdmTermTimerCreate(x->alloc,timeout,
													 processSigListTimeout,i,&x->mutex);
		}
		break;
	}
	/* The list end was reached */
	if(j==rvMdmSignalExListGetSize(list))
    {
		removeSignalList(x,i);
	}
	else
		*i = rvListIterNext(*i);

	return rvTrue;
}

/*  Stop the currently playing signal in the list */
/* Returns the next iterator after removing this one */
static RvBool stopCurSignalList(struct RvCCTerminalMdm_* x,RvMdmCurSigListIter* i,RvMdmSignalNotificationReasons reason)
{
	RvBool retval;
	RvMdmCurSignalList* curList = rvListIterData(*i);
	RvMdmSignalExList* list = &curList->list;
	const RvMdmSignalEx* signal = rvMdmSignalExListGetElem(list,curList->curElem);

	retval = stopMdmSignal(x,signal);
	generateCompleteEvent(x, signal, (int)rvMdmSignalExListGetId(list), reason);

	*i = rvListErase(RvMdmCurSignalList)(&x->curSignalLists,*i);

	return retval;
}

static void addSignalList(struct RvCCTerminalMdm_ * x,const RvMdmSignalExList *signalList)
{
	RvMdmCurSignalList * cur;
	cur = rvListAllocBack(RvMdmCurSignalList)(&x->curSignalLists);
	rvMdmCurSignalListConstruct(cur,x,signalList);
}

/* calling this with signalsDescr==NULL will effectively remove all signal lists */
/* Otherwise will remove all except the keepActive and activate the new ones */
static void processNewSignalLists(struct RvCCTerminalMdm_ * x,const RvMdmSignalsDescriptor * signalsDescr,
								  RvMdmSignalNotificationReasons reason)
{
	RvMdmCurSigListIter i;
	const RvMdmSignalExList * signalList;
	RvMdmCurSignalList* cur;
	size_t j, newLists = 0;
	unsigned int cnt=0,oldSize = (unsigned int)rvListSize(&x->curSignalLists);

	if(signalsDescr!=NULL)
		newLists = rvMdmSignalsDescriptorGetNumSignalLists(signalsDescr);

	/* Loop over active signal lists, new signal lists */
	/* If there are matching id's the old list stays alive */
	/* Otherwise the new list is add to the list */
	for(i=rvListBegin(&x->curSignalLists);cnt<oldSize;i=rvListIterNext(i),cnt++)
    {
		cur = rvListIterData(i);
		for(j=0;j<newLists;j++)
        {
			signalList = rvMdmSignalsDescriptorGetSignalList(signalsDescr,j);
			if(rvMdmSignalExListGetId(&cur->list)!=rvMdmSignalExListGetId(signalList) )
				addSignalList(x,signalList);
		}
	}

	/* Stop and remove list with status DONE */
	for(i=rvListBegin(&x->curSignalLists);i!=rvListEnd(&x->curSignalLists);)
    {
		cur = rvListIterData(i);
		if(!stopCurSignalList(x,&i,reason))
				return;
		else
			i=rvListIterNext(i);
	}
	/* Start list with status NEW */
	for(;i!=rvListEnd(&x->curSignalLists);) 
    {
		cur = rvListIterData(i);
			if(!processSignalList(&i))
				return;
		}
	return;
}



static void moveActiveSignals(struct RvCCTerminalMdm_*			src ,
							  struct RvCCTerminalMdm_*			dst ,
							  const  RvMdmSignalsDescriptor*	signalsDescr,
							  RvMdmSignalNotificationReasons	reason)
{
	RvMdmCurSignal*		curSignal;
	RvMdmCurSignalIter i,next;
	RvMilliseconds		timeout;
	RvMdmSignalType		type;

	RV_UNUSED_ARG(signalsDescr);

	for (i=rvListBegin(&src->curSignals) ; i!=rvListEnd(&src->curSignals) ; i=next)
    {
		next= rvListIterNext(i);
		curSignal= rvListIterData(i);

			/* stopCurSignal will set next iterator */
			rvMdmTermStartSignal(dst,&curSignal->signal,&type,&timeout);
			if( type!=RV_MDMSIGNAL_BRIEF )
				addCurSignal(dst,&curSignal->signal,timeout);
		stopCurSignal(src,&i,reason);
	}
}

void rvMdmTermEventMoveSignals(struct RvCCTerminalMdm_* src,struct RvCCTerminalMdm_* dst)
{
	moveActiveSignals(src,dst,NULL,RV_MDMSIGNAL_GOTEVENT);
	processNewSignalLists(src,NULL,RV_MDMSIGNAL_GOTEVENT);
}
/* Use to stop all signals when a requested event is detected or some other
   case like term going down */
void rvMdmTermEventStopSignals(struct RvCCTerminalMdm_ * x)
{
	stopActiveSignals(x,NULL,RV_MDMSIGNAL_GOTEVENT);
	processNewSignalLists(x,NULL,RV_MDMSIGNAL_GOTEVENT);
}

/* If the interrupted signal was timeout or on-off, the completion reason is
   always 'other'. Otherwise (for BRIEF) can be completed or other. */
RvMdmSignalNotificationReasons getStopReason(RvMdmSignalType type,RvBool normal)
{
	if(type==RV_MDMSIGNAL_ONOFF || type==RV_MDMSIGNAL_TIMEOUT)
		return RV_MDMSIGNAL_OTHERREASON;

	if (normal==rvTrue)
		return RV_MDMSIGNAL_COMPLETED;

	return RV_MDMSIGNAL_OTHERREASON;
}

