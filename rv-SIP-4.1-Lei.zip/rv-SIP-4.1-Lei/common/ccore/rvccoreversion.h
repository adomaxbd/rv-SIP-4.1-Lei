/***********************************************************************
        Copyright (c) 2003 RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Ltd.. No part of this document may be reproduced in any
form whatsoever without written prior approval by RADVISION Ltd..

RADVISION Ltd. reserve the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
***********************************************************************/


/* The version of the common core library */
#define RV_COMMON_CORE_VERSION "1.4.19"

/* This value is used for WinCE and Win32 version information in the properties of the DLL file */
#define RV_COMMON_CORE_VERSION_RC 1,4,19

