/*******************************************************************************************************************

NOTICE:
This document contains information that is proprietary to RADVision LTD..
No part of this publication may be reproduced in any form whatsoever without
written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.

********************************************************************************************************************/


/*************************************************************************************************************************
 *                                              HASH.h                                                                   *
 *                                                                                                                       *
 * The HASH module contains generic implementation of open hash table for the use of other stack module that need to     *
 * use HASH functionality.                                                                                               *
 * The HASH structure is implemented above the ra data structure ( as defined in ra.h ).                           *
 * The HASH module provides its user the ability to define the hash table size , the max number of user element that     *
 * will be included in it.                                                                                               *
 * The user also defined a hash routine that will operate on several parameters/keys ( according to user definition )    *
 * to provide one key , the final hash routine ( on the final key ) is always a mod.                                     *
 *                                                                                                                       *
 *                Written by                    Version & Date                            Change                         *
 *               ------------                   ---------------                          --------                        *
 *                Ayelet Back                      NG 3.0                                                                *
 *                                                                                                                       *
 *************************************************************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/*-------------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                             */
/*-------------------------------------------------------------------------*/
#include "RV_ADS_DEF.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "AdsRa.h"
#include "AdsHash.h"
#include "rvmemory.h"
#include "rvmutex.h"

/*-------------------------------------------------------------------------*/
/*                          TYPE DEFINITIONS                               */
/*-------------------------------------------------------------------------*/

/* Description of an HASH table
   Includes the following fields :
   NumOfUserElements  : The max number of used elements allocated for the hash table.
   UserRecSize        : Size of the user record that we want to save in bytes.
   UserParamsSize     : Size of the key params structure in bytes.
   HashTableBuffer    : Buffer for the table records of the keys.
   UserRAHandle       : Handle for the RA allocation for user data. ( the elements themselves )
   HashFunc           : Pointer to the hash function provided at construction time.
   HashFuncExt        : Pointer to the extended hash function provided at construction time.
   ctx                : Context set into the table on construction and provided
                        to the callback HashFunc.
   KeysSize           : Keys resources values.
   LogRegisterId      : ID provided at registration time to the log module
   pEntryLocks        : Pointer to an array of locks (for each hash entry), to be allocated
                        and initialized due to application demand, through the API
                        function HASH_ConstructEntLocks(). The locks might be used separately
                        for protecting a specific hash entry ("bucket") instead of locking the
                        whole hash. */

typedef struct {
    RvUint          NumOfUserElements;
    RvUint          UserRecSize;
    RvUint          UserParamsSize;
    RvUint8*        HashTableBuffer;
    HRA             UserRAHandle;
    HASH_func       HashFunc;
    HASH_func_ext   HashFuncExt;
    void*           ctx;
    RV_Resource     KeysSize;
    RvLogSource     logSource;
	RvLogSource    *pLogSource;
    RvMutex        *pEntryLocks;
} HASH_TableType;


/* The open hash is implemented using two types of records that are allocated in the ra.
   First type is the hash table entry ( which mainly contain a pointers to the list of
   user elements that are mapped to the same hash entry ).
   The second type of RA record is user record along with management record that used to manage the list of elements of
   the same type */

/* The hash table entry contains the following fields :
   FirstElementPtr : A pointer ( RA pointer ) of the first element in the list of elements that were mapped to this entry. */



typedef struct {
  RA_Element FirstElementPtr;
} HASH_TableEntryType;




/* This structure will be included in any user element and serve for pointing to the next and prev
   elements in the list of elements that were mapped to the same entry ( collision )
   Fields :
   Next,Prev      : pointers to the next and prev user elements that were mapped to the same place
                    in the hash table.
   EntryNum       : The entry num in the hash table to which the element was mapped ( collision list ) */
typedef struct HASH_ListElement_tag HASH_ListElement;
struct HASH_ListElement_tag {
  HASH_ListElement* next;
  HASH_ListElement* prev;
  int EntryNum;
};



/*-------------------------------------------------------------------------*/
/*                          MACRO DEFINITIONS                              */
/*-------------------------------------------------------------------------*/

#define HASH_ENTRY(hash,i) \
    ((HASH_TableEntryType *)( &(hash)->HashTableBuffer[sizeof(HASH_TableEntryType)*(i)] ))

/*-------------------------------------------------------------------------*/
/*                          STATIC FUNCTIONS                               */
/*-------------------------------------------------------------------------*/
static RvStatus RVCALLCONV HashInsertElement(
                                IN  HASH_TableType      *pHashTable,
                                IN  void                *pParams,
                                IN  HASH_ENTRY_ID       *pHashEntId,
                                IN  HASH_TableEntryType *pHashEntry,
                                IN  void                *UserElement,
                                OUT void               **ElementPtr);

static RvBool RVCALLCONV HashFindElement(IN  HASH_TableType    *pHashTable,
                                         IN  void              *pParams,
                                         IN  HASH_ENTRY_ID     *pHashEntId,
                                         IN  HASH_CompareFunc   CompareFunc,
                                         OUT void             **ElementPtr);

static RvBool RVCALLCONV HashFindElementByPartKey(
                                        IN    HASH_TableType    *pHashTable,
                                        IN    void              *pParams,
                                        IN    HASH_ENTRY_ID     *pHashEntId,
                                        IN    HASH_CompareFunc   CompareFunc,
                                        INOUT void             **ppElem);

static RvBool RVCALLCONV HashFindNextElemByPartKey(
                                        IN    HASH_TableType    *pHashTable,
                                        IN    HASH_ENTRY_ID     *pHashEntId,
                                        INOUT void             **ppElem);

/*-------------------------------------------------------------------------*/
/*                          FUNCTIONS IMPLEMENTATION                       */
/*-------------------------------------------------------------------------*/

/*************************************************************************************************************
 * HASH_Construct
 * purpose : The routine is used to build a hash table.
 *           It gets the hash table specifications ( as described in detailed in the parameter list )
 *           and using ra it allocates the memory and built the required hash table.
 *           Note - No partial allocation is done , if there is no enough memory to do all allocations
 *           nothing is allocated and a NULL pointer is returned.
 * input   : HashTableSize      - The hash table size , this parameter refers to the size of the table
 *                                and not to the number of user records in it ( actually it is the
 *                                number that will use in the mod routine ).
 *           NumOfUserElements  - The max number of user elements that this hash table should support.
 *           hfunc              - The hash function ( perform on key parameters before the module function.
 *           UserElementRecSize - The size of the user element structure in bytes.
 *           UserKeyParamsSize  - The size of the user key params structure in bytes.
 *           pLogMgr       : pointer to a log manager.
 * output  : None.
 * return  : Handle to the allocated HASH table ( NULL if there was a resource allocation problem ).
 ************************************************************************************************************************/
HASH_HANDLE RVAPI RVCALLCONV HASH_Construct (IN RvUint        HashTableSize,
                                             IN RvUint        NumOfUserElements,
                                             IN HASH_func     hfunc,
                                             IN RvUint        UserElementRecSize,
                                             IN RvUint        UserKeyParamsSize,
 					                	     IN RvLogMgr*     pLogMgr,
                                             IN const char*   Name)
{
    void                *ptr;
    HASH_TableType      *hHandle;
    RvUint              i;
    HASH_TableEntryType *HashEntry;
	RvStatus            crv;

    crv = RV_OK;

    if (RV_OK != RvMemoryAlloc(NULL, sizeof(HASH_TableType), pLogMgr, (void*)&ptr))
       return NULL;

    memset(ptr, 0, sizeof(HASH_TableType));

    /* save the internal hash parameters */
    hHandle = (HASH_TableType *)ptr;
    hHandle->NumOfUserElements = NumOfUserElements;
    hHandle->UserRecSize       = UserElementRecSize;
    hHandle->UserParamsSize    = UserKeyParamsSize;
    hHandle->HashFunc          = hfunc;
    hHandle->pEntryLocks       = NULL;

    hHandle->KeysSize.maxNumOfElements  = HashTableSize;
#if (RV_LOGMASK != RV_LOGLEVEL_NONE)
    if(pLogMgr != NULL)
	{
		crv = RvLogSourceConstruct(pLogMgr,&hHandle->logSource,ADS_HASH,Name);
		if(crv != RV_OK)
		{
			RvMemoryFree(hHandle,pLogMgr);
			return NULL;
		}
		hHandle->pLogSource = &hHandle->logSource;
	}
	else
	{
		hHandle->pLogSource = NULL;
	}
#else
    hHandle->pLogSource = NULL;
#endif /*#if (RV_LOGMASK != RV_LOGLEVEL_NONE)*/

    if (RV_OK != RvMemoryAlloc(NULL, sizeof(HASH_TableEntryType) * HashTableSize, NULL, (void*)&hHandle->HashTableBuffer))
    {
 	    RvLogError(hHandle->pLogSource, (hHandle->pLogSource,
		         "HASH_Construct - failed to allocate memory"));

		if(hHandle->pLogSource != NULL)
        {
            RvLogSourceDestruct(hHandle->pLogSource);
        }
        RvMemoryFree(hHandle ,NULL);
        return NULL;
    }


    hHandle->UserRAHandle = RA_Construct (
                         UserElementRecSize + UserKeyParamsSize + sizeof(HASH_ListElement),
                         NumOfUserElements,
                         NULL,
                         pLogMgr,
                         Name);
    if (hHandle->UserRAHandle == NULL)
    {
 	    RvLogError(hHandle->pLogSource, (hHandle->pLogSource,
		         "HASH_Construct - construct RA"));

        if(hHandle->pLogSource != NULL)
        {
            RvLogSourceDestruct(hHandle->pLogSource);
        }
        RvMemoryFree( hHandle->HashTableBuffer,NULL );
        RvMemoryFree( hHandle ,NULL);
        return NULL;
    }

    /* Initialize the hash table entries */
    for ( i = 0 ; i < HashTableSize ; i++ )
    {
        HashEntry = HASH_ENTRY(hHandle, i);
        HashEntry->FirstElementPtr = NULL;
    }

 	RvLogLeave(hHandle->pLogSource, (hHandle->pLogSource,
        "HASH_Construct (HashTableSize=%u, NumOfUserElements=%u,UserElementRecSize=%u,UserKeyParamsSize=%u,Name=%s)=0x%p",
        HashTableSize, NumOfUserElements,UserElementRecSize,
        UserKeyParamsSize, NAMEWRAP(Name), hHandle));
    return (HASH_HANDLE)hHandle;
}

/*************************************************************************************************************
 * HASH_ConstructExt
 * purpose : same as HASH_Construct.
 * input   : same as HASH_Construct.
 *           HASH_funcEx : the Hash Function that was extended with CONTEXT parameter.
 *           ctx         : the context to be passed with the Hash Function callback.
 * output  : same as HASH_Construct.
 * return  : same as HASH_Construct.
 ************************************************************************************************************************/
HASH_HANDLE RVAPI RVCALLCONV HASH_ConstructExt (
                                        IN RvUint         HashTableSize ,
                                        IN RvUint         NumOfUserElements,
                                        IN HASH_func_ext  hfunc,
                                        IN void*          ctx,
                                        IN RvUint         UserElementRecSize,
                                        IN RvUint         UserKeyParamsSize,
 					                	IN RvLogMgr*      pLogMgr,
                                        IN const char*    Name)
{
    HASH_HANDLE     hHash;
    HASH_TableType* pHash;

    hHash = HASH_Construct (HashTableSize, NumOfUserElements, NULL /*hfunc*/,
                            UserElementRecSize, UserKeyParamsSize, pLogMgr, Name);
    if (hHash == NULL)
    {
        return NULL;
    }

    pHash = (HASH_TableType*)hHash;
    pHash->HashFuncExt = hfunc;
    pHash->ctx = ctx;
    return hHash;
}


/*************************************************************************************************************
* HASH_ConstructEntLocks
* purpose : The routine is used to construct private locks for every entry within the hash table.
*           Note - No partial allocation is done , if there is no enough memory to do all allocations
*           nothing is allocated and a NULL pointer is returned.
* input   : hHash   - Handle to the hash table that should be destructed.
* output  : None.
* return  : RvStatus
************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_ConstructEntLocks(IN HASH_HANDLE hHash)
{
    RvStatus        rv;
    RvUint32        currEnt;
    RvMutex        *pCurrMutex;
    HASH_TableType *pHashTable = (HASH_TableType *)hHash;
    RvUint32        numOfEnts;

    if (NULL == hHash)
	{
        return RV_ERROR_NULLPTR;
    }

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_ConstructEntLocks (hHash=0x%p)",hHash));

    numOfEnts  = pHashTable->KeysSize.maxNumOfElements;
    rv = RvMemoryAlloc(NULL,sizeof(RvMutex) * numOfEnts, NULL,(void*)&(pHashTable->pEntryLocks));
    if (RV_OK != rv)
    {
        RvLogError(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_ConstructEntLocks (hHash=0x%p) - Failed to allocate entry locks (%d)",pHashTable,rv));

        return rv;
    }

    for (currEnt = 0, pCurrMutex = pHashTable->pEntryLocks ;
         currEnt < numOfEnts ;
         currEnt++ , pCurrMutex++)
    {
        rv = RvMutexConstruct(NULL,pCurrMutex);
        if (RV_OK != rv)
        {
            RvMemoryFree(pHashTable->pEntryLocks,NULL);
            RvLogError(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HASH_ConstructEntLocks (hHash=0x%p) - Failed to initialize entry lock %d (%d)",
                pHashTable,currEnt,rv));

            return rv;
        }
    }

    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_ConstructEntLocks (hHash=0x%p)=%d",hHash,rv));

    return RV_OK;
}



/*************************************************************************************************************
* HASH_DestructEntLocks
* purpose : The routine is used to destruct private locks for every entry within the hash table.
*           Note - No partial allocation is done , if there is no enough memory to do all allocations
*           nothing is allocated and a NULL pointer is returned.
* input   : hHash   - Handle to the hash table that should be destructed.
* output  : None.
* return  : RvStatus
************************************************************************************************************************/
void RVAPI RVCALLCONV HASH_DestructEntLocks(IN HASH_HANDLE hHash)
{
    RvUint32        currEnt;
    RvMutex        *pCurrMutex;
    HASH_TableType *pHashTable = (HASH_TableType *)hHash;

    if (NULL == pHashTable)
    {
        return;
    }

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_DestructEntLocks (hHash=0x%p)",hHash));

    /* The locks array might not be allocated at all */
    if (NULL == pHashTable->pEntryLocks)
    {
        return;
    }
    for (currEnt = 0, pCurrMutex = pHashTable->pEntryLocks ;
         currEnt < pHashTable->KeysSize.maxNumOfElements ;
         currEnt++ , pCurrMutex++)
    {
        /* Verify that the lock is not captured by any other thread */
        RvMutexLock(pCurrMutex,NULL);
        RvMutexUnlock(pCurrMutex,NULL);
        /* Destruct the mutex */
        RvMutexDestruct(pCurrMutex,NULL);
    }

    RvMemoryFree((void*)pHashTable->pEntryLocks,NULL);
    /* Set NULL into the mutex array */
    pHashTable->pEntryLocks = NULL;

    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_DestructEntLocks (hHash=0x%p)",hHash));
}

/*************************************************************************************************************
* HASH_LockEnt
* purpose : The routine locks an entry of hash table. The entry
*           position is concluded from the given key parameters.
* NOTE: Please assure that the entry ID (pEntId) is initialized before
*       calling this function by one of the following:
*       1. Preceding call to HASH_INIT_ENTRY_ID()
*       2. Using pEntId from previous call for HASH_LockEnt() - in case you
*          access the same hash element as this previous call. In other
*          words, you might use the pEntId, returned (as an output parameter)
*          from a previous call to HASH_LockEnt(), if you access an element
*          with a key, similar to the key used through the previous
*          call to HASH_LockEnt().
*
* input   : hHash       - Handle to the hash table .
*           pEntParams  - Pointer to the structure of the key parameters.
*                         This parameter might be NULL as long as the pEntId
*                         is induced from previous call to HASH_LockEnt (with
*                         the same element key).
* input/output :
*           pEntId      - ID of the locked entity.
*
* return  : RvStatus
************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_LockEnt(IN    HASH_HANDLE    hHash,
                                       IN    void          *pEntParams,
                                       INOUT HASH_ENTRY_ID *pEntId)
{
    RvStatus        rv; 
    HASH_TableType *pHashTable = (HASH_TableType *)hHash;

    if (NULL == pHashTable)
    {
        return RV_ERROR_NULLPTR;
    }
    if (NULL == pHashTable->pEntryLocks)
    {
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_LockEnt (hHash=0x%p) - Entry locks are not initialized",pHashTable));

        return RV_OK;
    }


    if (ADS_UNDEFINED == *pEntId)
    {
        RvInt Key;

        if (NULL == pEntParams)
        {
            RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HASH_LockEnt (hHash=0x%p) - Entry ID is UNDEFINED and no key is provided",pHashTable));

            return RV_ERROR_UNINITIALIZED;
        }
        Key     = pHashTable->HashFunc (pEntParams);
        Key     = Key % pHashTable->KeysSize.maxNumOfElements;
        *pEntId = Key;
    }
    /* Verify that the entity ID is valid */
    else if (*pEntId < 0 || (RvUint32) *pEntId >= pHashTable->KeysSize.maxNumOfElements)
    {
        RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_LockEnt (hHash=0x%p) - Entity ID is invalid (%d)",pHashTable,*pEntId));

        return RV_ERROR_BADPARAM;
    }

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_LockEnt (hHash=0x%p) - Locking hash entry %d (0x%p)", 
        pHashTable, *pEntId, &(pHashTable->pEntryLocks[*pEntId])));

    rv = RvMutexLock(&(pHashTable->pEntryLocks[*pEntId]),NULL);

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_LockEnt (hHash=0x%p) - Locking entry %d (0x%p) succeeded", 
        pHashTable, *pEntId, &(pHashTable->pEntryLocks[*pEntId])));

    return rv;
}

/*************************************************************************************************************
* HASH_UnlockEnt
* purpose : The routine unlocks an entry of hash table according to a given entry ID.
* input   : hHash       - Handle to the hash table .
*           pEntId      - ID of the entity to be unlocked
* return  : RvStatus
************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_UnlockEnt(IN  HASH_HANDLE    hHash,
                                         IN  HASH_ENTRY_ID *pEntId)
{
    HASH_TableType *pHashTable = (HASH_TableType *)hHash;

    if (NULL == pHashTable)
    {
        return RV_ERROR_NULLPTR;
    }

    if (NULL == pHashTable->pEntryLocks)
    {
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_UnlockEnt (hHash=0x%p) - Entry locks are not initialized",pHashTable));

        return RV_OK;
    }

    /* Check if the given entry ID is initialized */
    if (ADS_UNDEFINED == *pEntId)
    {
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_UnlockEnt (hHash=0x%p) - Entity ID is not initialized",pHashTable));

        return RV_ERROR_UNINITIALIZED;
    }
    /* Check if the given entry ID is valid */
    else if (*pEntId < 0 || (RvUint32) *pEntId >= pHashTable->KeysSize.maxNumOfElements)
    {
        RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_UnlockEnt (hHash=0x%p) - Entity ID is invalid (%d)",pHashTable,*pEntId));

        return RV_ERROR_BADPARAM;
    }

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_UnlockEnt (hHash=0x%p) - Unlocking hash entry %d (0x%p)", 
        pHashTable, *pEntId, &(pHashTable->pEntryLocks[*pEntId])));

    return RvMutexUnlock(&(pHashTable->pEntryLocks[*pEntId]),NULL);
}

/*************************************************************************************************************
* HASH_LockAllEnts
* purpose : The routine locks all the entries of hash table. 
*
* input   : hHash       - Handle to the hash table that should be destructed.
*
* return  : RvStatus
************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_LockAllEnts(IN HASH_HANDLE hHash)
{
    RvStatus        rv;
    HASH_TableType *pHashTable = (HASH_TableType *)hHash;
    RvUint32        currEnt;
    RvMutex        *pCurrMutex;

    if (NULL == pHashTable)
    {
        return RV_ERROR_NULLPTR;
    }
    if (NULL == pHashTable->pEntryLocks)
    {
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_LockAllEnts (hHash=0x%p) - Entry locks are not initialized",pHashTable));

        return RV_OK;
    }

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_LockAllEnts (hHash=0x%p) - Locking all the entries in the hash", pHashTable));

    /* Going over the HASH table entries and lock each of them */
    for (currEnt = 0, pCurrMutex = pHashTable->pEntryLocks ;
         currEnt < pHashTable->KeysSize.maxNumOfElements ;
         currEnt++ , pCurrMutex++)
    {
        /* Perform locking */
        rv = RvMutexLock(pCurrMutex,NULL);
        /* Restore the original locking state */
        if (rv != RV_OK)
        {
            RvUint32 subCurrEnt; 

            RvLogError(pHashTable->pLogSource ,(pHashTable->pLogSource ,
                "HASH_LockAllEnts (hHash=0x%p) - Locking all the entries in the hash failed in entry %d (%d)", 
                pHashTable,currEnt,rv));
            for (subCurrEnt = 0, pCurrMutex = pHashTable->pEntryLocks;
                 subCurrEnt < currEnt; 
                 subCurrEnt++, pCurrMutex++)
            {
                RvMutexUnlock(pCurrMutex,NULL);
            }
            
            return rv;
        }
    }

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_LockAllEnts (hHash=0x%p) - Locking all the entries in the hash, succeeded", pHashTable));

    return RV_OK;
}

/*************************************************************************************************************
* HASH_UnlockAllEnts
* purpose : The routine unlocks all the entries of hash table. 
* input   : hHash       - Handle to the hash table .
* return  : RvStatus
************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_UnlockAllEnts(IN  HASH_HANDLE hHash)
{
    RvStatus        rv;
    HASH_TableType *pHashTable = (HASH_TableType *)hHash;
    RvUint32        currEnt;
    RvMutex        *pCurrMutex;

    if (NULL == pHashTable)
    {
        return RV_ERROR_NULLPTR;
    }

    if (NULL == pHashTable->pEntryLocks)
    {
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_UnlockAllEnts (hHash=0x%p) - Entry locks are not initialized",pHashTable));

        return RV_OK;
    } 

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_UnlockAllEnts (hHash=0x%p) - Unlocking all the entries in hash", pHashTable));

    /* Going over the HASH table entries and lock each of them */
    for (currEnt = 0, pCurrMutex = pHashTable->pEntryLocks ;
         currEnt < pHashTable->KeysSize.maxNumOfElements ;
         currEnt++ , pCurrMutex++)
    {
        /* Perform locking */
        rv = RvMutexUnlock(pCurrMutex,NULL);
        /* Restore the original locking state */
        if (rv != RV_OK)
        {
            RvUint32 subCurrEnt; 

            RvLogError(pHashTable->pLogSource ,(pHashTable->pLogSource ,
                "HASH_LockAllEnts (hHash=0x%p) - Locking all the entries in the hash failed in entry %d (%d)", 
                pHashTable,currEnt,rv));
            for (subCurrEnt = 0, pCurrMutex = pHashTable->pEntryLocks;
                 subCurrEnt < currEnt; 
                 subCurrEnt++, pCurrMutex++)
            {
                RvMutexLock(pCurrMutex,NULL);
            }

            return rv;
        }
    }

    RvLogSync(pHashTable->pLogSource ,(pHashTable->pLogSource ,
        "HASH_UnlockAllEnts (hHash=0x%p) - Unlocking all the entries in hash succeeded", pHashTable));

    return RV_OK;
}

/***********************************************************************************************************************
* HASH_Destruct
* purpose : Destruct a given hash table. All memory is freed.
* input   : hHash  - Handle to the hash table that should be destructed.
* output  : None.
***********************************************************************************************************************/
void RVAPI RVCALLCONV HASH_Destruct (IN HASH_HANDLE hHash)
{
    HASH_TableType *pHashTable;

    pHashTable = ( HASH_TableType *)hHash;
	if(pHashTable->pLogSource != NULL)
    {
 	    RvLogInfo(pHashTable->pLogSource, (pHashTable->pLogSource,
		         "HASH_Destruct (hHash=0x%p)",hHash));
        RvLogSourceDestruct(pHashTable->pLogSource);
    }
    RvMemoryFree ( pHashTable->HashTableBuffer ,NULL);
	RA_Destruct ( pHashTable->UserRAHandle );
    HASH_DestructEntLocks(hHash);
    RvMemoryFree( pHashTable ,NULL);
}


/*************************************************************************************************************************
 * HASH_InsertElement
 * purpose : Add a new user element to a given hash table.
 * input   : hHash              - handle to the hash table to which the element should be entered.
 *           Params             - Pointer to the structure of the key parameters.
 *           UserElement        - Pointer to the user element that should be inserted to the hash table.
 *           bLookup            - A boolean indication, if true a search is done before the insersion
 *                                to check that the element is not already inserted to the table ( and
 *                                then nothing is done ) , If false no search is done before the insersion.
 *           CompareFunc        - In case a search before insertion is needed the user should provide a
 *                                comparison function.
 * output  : pbInserted        - A boolean indication if the element was inserted ( or not - in case a
 *                                search was done and it is already exist in the hash table ).
 *           ElementPtr          - Pointer to the record that was allocated to this user element.
 * return  : RV_OK - In case of insertion success ( or no insertion if the element is already exist ).
 *           RV_ERROR_OUTOFRESOURCES - If there is no more available user element records.
 *************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_InsertElement (IN HASH_HANDLE        hHash,
                                               IN void               *Params,
                                               IN void               *UserElement,
                                               IN RvBool            bLookup,
                                               OUT RvBool            *pbInserted,
                                               OUT void               **ElementPtr,
                                               IN HASH_CompareFunc   CompareFunc)
{
   RvStatus             rv;
   RvInt                Key=-1;
   RvBool               Continue = RV_TRUE;
   HASH_TableEntryType *HashEntry;
   HASH_TableType      *pHashTable;

   pHashTable = (HASH_TableType *)hHash;

   RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
		     "HASH_InsertElement (hHash=0x%p,Params=0x%p,UserElement=0x%p,bLookup=%d,pbInserted=0x%p,ElementPtr=0x%p)",
             hHash,Params,UserElement,bLookup,pbInserted,ElementPtr));


   if (bLookup)
   {
       if ( HASH_FindElement (hHash, Params, CompareFunc, ElementPtr) )
       {
          *pbInserted = RV_FALSE;
          Continue     = RV_FALSE;
       }
   }

    if ( Continue )
    {
        /* We know here that this is a new record */
        if (pHashTable->HashFuncExt != NULL)
        {
            Key = pHashTable->HashFuncExt( Params, pHashTable->ctx );
        }
        else
        {
            Key = pHashTable->HashFunc( Params );
        }
        Key = Key % pHashTable->KeysSize.maxNumOfElements;
        HashEntry = HASH_ENTRY(pHashTable, Key);

        rv = HashInsertElement(pHashTable,Params,&Key,HashEntry,UserElement,ElementPtr);
        if (RV_OK != rv)
        {
            RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HASH_InsertElement - hHash=0x%p: Failed to insert element 0x%p (rv=%d)", hHash,UserElement,rv));

            return rv;
        }
        *pbInserted = RV_TRUE;
    }
    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HASH_InsertElement - hHash=0x%p: *pbInserted=%d, key=%d",
                hHash, *pbInserted, Key));
    return RV_OK;
}



/************************************************************************************************************************
 * HASH_FindElement
 * purpose : The routine is used to find the location of an element in the hash table acoording to its key params.
 * input   : hHash   - Handle to the hash table.
 *           Params  - The parameters ( key parameters ) that should be used. What is done is that the hash routine that
 *                     is given in construction time is activated to get one key from the set of parameters , and the
 *                     search is done on the hash table using this key ( assuming the hash function is mod ).
 *                     Note that this key is saved along with the user elemnt record in the hash table and is used to identify
 *                     the searched record.
 *           CompareFunc - Pointer to the user function ( hash module user ) that make the compare between the hash table
 *                         element and the new params.
 * output  : ElementId - A pointer to the user element record that was found.
 * return   : TRUE  : If the searched element was found.
 *           FALSE : If not.
 *************************************************************************************************************************/
RvBool RVAPI RVCALLCONV HASH_FindElement (IN  HASH_HANDLE      hHash,
                                           IN  void             *Params,
                                           IN  HASH_CompareFunc CompareFunc,
                                           OUT void             **ElementPtr)
{
    RvInt                Key;
    RvBool               Found = RV_FALSE;
    HASH_TableType      *pHashTable;

    pHashTable = (HASH_TableType *)hHash;
    *ElementPtr = NULL;

    if (pHashTable->HashFuncExt != NULL)
    {
        Key = pHashTable->HashFuncExt( Params, pHashTable->ctx );
    }
    else
    {
        Key = pHashTable->HashFunc( Params );
    }
    Key = Key % pHashTable->KeysSize.maxNumOfElements;

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_FindElement (hHash=0x%p,Params=0x%p,ElementPtr=0x%p,key=%d)",
        hHash,Params,ElementPtr,Key));

    Found = HashFindElement(pHashTable,Params,&Key,CompareFunc,ElementPtr);

    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_FindElement (hHash=0x%p,Params=0x%p,ElementPtr=0x%p,key=%d)=%d",
        hHash,Params,ElementPtr,Key,Found));

    return Found;
}

/*************************************************************************************************************************
* HASH_InsertElemByEntId
* purpose : Add a new user element to a given hash table by a given entry ID.
* input   : hHash              - handle to the hash table to which the element should be entered.
*           pParams            - Pointer to the structure of the key parameters.
*           UserElement        - Pointer to the user element that should be inserted to the hash table.
*           bLookup            - A boolean indication, if true a search is done before the inversion
*                                to check that the element is not already inserted to the table ( and
*                                then nothing is done ) , If false no search is done before the insertion.
*           pHashEntId         - Pointer to the entry ID which will contain the new element. This
*                                parameter is provided by the HASH through HASH_LockEnt().
*           CompareFunc        - In case a search before insertion is needed the user should provide a
*                                comparison function.
* output  : pbInserted         - A boolean indication if the element was inserted ( or not - in case a
*                                search was done and it is already exist in the hash table ).
*           ElementPtr         - Pointer to the record that was allocated to this user element.
*
* return  : RV_OK - In case of insertion success ( or no insertion if the element is already exist ).
*           RV_ERROR_OUTOFRESOURCES - If there is no more available user element records.
*************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_InsertElemByEntId(
                                              IN     HASH_HANDLE       hHash,
                                              IN     void             *pParams,
                                              IN     void             *UserElement,
                                              IN     RvBool            bLookup,
                                              OUT    RvBool           *pbInserted,
                                              OUT    void            **ElementPtr,
                                              IN     HASH_ENTRY_ID     *pHashEntId,
                                              IN     HASH_CompareFunc   CompareFunc)
{
    RvBool               Continue = RV_TRUE;
    HASH_TableEntryType *HashEntry;
    HASH_TableType      *pHashTable;
    RvStatus             rv;

    pHashTable  = (HASH_TableType *)hHash;
    *pbInserted = RV_FALSE;
    *ElementPtr = NULL;

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_InsertElemByEntId (hHash=0x%p,Params=0x%p,UserElement=0x%p,bLookup=%d,pbInserted=0x%p,ElementPtr=0x%p,*pHashEntId=%d)",
        hHash,pParams,UserElement,bLookup,pbInserted,ElementPtr,*pHashEntId));

    if (*pHashEntId < 0 || (RvUint32)*pHashEntId > pHashTable->KeysSize.maxNumOfElements)
    {
        RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_InsertElemByEntId (hHash=0x%p,*pHashEntId=%d) - Hash entry ID is invalid",
            hHash,*pHashEntId));

        return RV_ERROR_BADPARAM;
    }
    if (bLookup)
    {
        if (RV_TRUE == HASH_FindElemByEntId(hHash, pParams, CompareFunc, pHashEntId,ElementPtr))
        {
            *pbInserted = RV_FALSE;
            Continue    = RV_FALSE;
        }
    }

    if (Continue)
    {
        /* We know here that this is a new record */
        HashEntry = HASH_ENTRY(pHashTable, *pHashEntId);

        rv = HashInsertElement(pHashTable,pParams,pHashEntId,HashEntry,UserElement,ElementPtr);
        if (RV_OK != rv)
        {
            RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HASH_InsertElemByEntId - hHash=0x%p: Failed to insert element 0x%p (rv=%d)", hHash,UserElement,rv));

            return rv;
        }
        *pbInserted = RV_TRUE;
    }
    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_InsertElemByEntId - hHash=0x%p (*pHashEntId=%d): *pbInserted=%d to ", hHash,*pHashEntId,*pbInserted));
    return RV_OK;
}

/************************************************************************************************************************
* HASH_FindElemByEntId
* purpose : The routine is used to find the location of an element in the hash table according to its key params.
* input   : hHash    - Handle to the hash table.
*           pParams  - The parameters ( key parameters ) that should be used. What is done is that the hash routine that
*                      is given in construction time is activated to get one key from the set of parameters , and the
*                      search is done on the hash table using this key ( assuming the hash function is mod ).
*                      Note that this key is saved along with the user element record in the hash table and is used to identify
*                      the searched record.
*           CompareFunc - Pointer to the user function ( hash module user ) that make the compare between the hash table
*                         element and the new params.
*           pHashEntId  - Pointer to the entry ID which will contain the new element. This
*                         parameter is provided by the HASH through HASH_LockEnt().
* output  : ElementId - A pointer to the user element record that was found.
* return   : TRUE  : If the searched element was found.
*           FALSE : If not.
*************************************************************************************************************************/
RvBool RVAPI RVCALLCONV HASH_FindElemByEntId (IN     HASH_HANDLE        hHash,
                                              IN     void              *pParams,
                                              IN     HASH_CompareFunc   CompareFunc,
                                              IN     HASH_ENTRY_ID     *pHashEntId,
                                              OUT    void             **ElementPtr)
{
    RvBool               Found = RV_FALSE;
    HASH_TableType      *pHashTable;

    pHashTable  = (HASH_TableType *)hHash;
    *ElementPtr = NULL;

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_FindElemByEntId (hHash=0x%p,pParams=0x%p,*pHashEntId=0x%d,ElementPtr=0x%p)",
        hHash,pParams,*pHashEntId,ElementPtr));

    if (*pHashEntId < 0 || (RvUint32)*pHashEntId > pHashTable->KeysSize.maxNumOfElements)
    {
        RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_FindElemByEntId (hHash=0x%p,*pHashEntId=%d) - Hash entry ID is invalid",
            hHash,*pHashEntId));

        return RV_FALSE;
    }

    Found = HashFindElement(pHashTable,pParams,pHashEntId,CompareFunc,ElementPtr);

    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_FindElemByEntId (hHash=0x%p,pParams=0x%p,*pHashEntId=0x%d,ElementPtr=0x%p)=%d",
        hHash,pParams,*pHashEntId,ElementPtr,Found));

    return Found;
}

/************************************************************************************************************************
* HASH_FindElemByPartKey
* purpose : The routine is used to find an element in the hash table according to partial key params.
*           Since the key is not complete there might be several elements, matching the given key.        
*
* input   : hHash       - Handle to the hash table.
*           pParams     - The parameters ( key parameters ) that should be used for search. 
*                         The key parameters might be partial, thus might identify several 
*                         elements in the given hash table.
*           CompareFunc - Pointer to the user function ( hash module user ) that make the compare between the hash table
*                         element and the given params.
*           pHashEntId  - Pointer to the entry ID which will be searched for the new element. This
*                         parameter is provided by the HASH through HASH_LockEnt(). This parameter
*                         might be NULL if the whole hash table is searched in but not only a 
*                         specific hash entry.
* input/output  : 
*           ppElem      - A pointer to pointer to the user element record that was found. This
*                         pointer should point to NULL upon calling this function on
*                         the first time. Then, the calling function would have to use 
*                         the ppElem, which was returned in the previous call to 
*                         HASH_FindElemByPartKey() (if any element was found) for consequent 
*                         search.
*                         
* return   : TRUE  : If the searched element was found.
*            FALSE : If not.
*************************************************************************************************************************/
RvBool RVAPI RVCALLCONV HASH_FindElemByPartKey (IN     HASH_HANDLE        hHash,
                                                IN     void              *pParams,
                                                IN     HASH_CompareFunc   CompareFunc,
                                                IN     HASH_ENTRY_ID     *pHashEntId,
                                                INOUT  void             **ppElem)
{
    RvBool               Found = RV_FALSE;
    HASH_TableType      *pHashTable;

    pHashTable  = (HASH_TableType *)hHash;

    if (NULL == ppElem)
    {
        RvLogError(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_FindElemByPartKey (hHash=0x%p) ppElem is NULL",hHash));

        return RV_FALSE;
    }

    if (pHashEntId != NULL &&
        (*pHashEntId < 0 || (RvUint32)*pHashEntId > pHashTable->KeysSize.maxNumOfElements))
    {
        RvLogError(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_FindElemByPartKey (hHash=0x%p,*pHashEntId=%d) - Hash entry ID is invalid",
            hHash,*pHashEntId));

        return RV_FALSE;
    }

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_FindElemByPartKey (hHash=0x%p,pParams=0x%p,*pHashEntId=0x%d,*ppElem=0x%p)",
        hHash,pParams,(pHashEntId == NULL) ? -1 : *pHashEntId,ppElem));

    Found = HashFindElementByPartKey(pHashTable,pParams,pHashEntId,CompareFunc,ppElem);

    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_FindElemByPartKey (hHash=0x%p,pParams=0x%p,*pHashEntId=0x%d,ElementPtr=0x%p)=%d",
        hHash,pParams,(pHashEntId == NULL) ? -1 : *pHashEntId,ppElem,Found));

    return Found;
}

/************************************************************************************************************************
 * HASH_GetUserElement
 * purpose : Return the a user element from the hash table according to the user record element ID.
 * input   : hHash       - Pointer to the hash table.
 *           ElementPtr   - The position pointer of the user element that should be read.
 * output  : UserElement - The read user element
 * return  : RV_OK  - In case of success.
 *           RV_ERROR_UNKNOWN   - No such element.
 ************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_GetUserElement (IN HASH_HANDLE hHash,
                                                IN void        *ElementPtr,
                                                OUT void       *UserElement)
{
    HASH_TableType  *pHashTable;

	void            *RAElement = ElementPtr;

    pHashTable = (HASH_TableType *)hHash;

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_GetUserElement (hHash=0x%p,ElementPtr=0x%p,UserElement=0x%p)",
        hHash,ElementPtr,UserElement));


    if (NULL == RAElement)
    {
        RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_GetUserElement - (hHash=0x%p) , RAGet failed",hHash));
        return RV_ERROR_UNKNOWN;
    }

    memcpy ( UserElement ,
             &((char *)RAElement)[sizeof(HASH_ListElement) + pHashTable->UserParamsSize] ,
             pHashTable->UserRecSize );
    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_GetUserElement (hHash=0x%p,ElementPtr=0x%p)=%d",
        hHash,ElementPtr,RV_OK));

    return RV_OK;

}

/************************************************************************************************************************
 * HASH_SetUserElement
 * purpose : Set a user element record to a given location/ID in a given Hash table.
 * input   : hHash       - Pointer to the hash table.
 *           ElementId   - The position pointer of the user element that should be written.
 *           UserElement - The user element that should be written.
 * output  : None.
 * return  : RV_OK  - In case of success.
 *           RV_ERROR_UNKNOWN     - No such element.
 ************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_SetUserElement (IN HASH_HANDLE hHash,
                                                IN void        *ElementPtr,
                                                IN void        *UserElement)
{
    void             *RAElement = ElementPtr;
    HASH_TableType   *pHashTable;

    pHashTable = (HASH_TableType *)hHash;

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_SetUserElement (hHash=0x%p,ElementPtr=0x%p,UserElement=0x%p)",
        hHash,ElementPtr,UserElement));

    if (NULL == RAElement)
    {
        RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HASH_SetUserElement - (hHash=0x%p) , RAGet failed",hHash));
        return RV_ERROR_UNKNOWN;
    }

    memcpy ( &((char *)RAElement)[sizeof(HASH_ListElement) + pHashTable->UserParamsSize] ,
             UserElement ,
             pHashTable->UserRecSize );

    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_SetUserElement (hHash=0x%p,ElementPtr=0x%p)=%d",
        hHash,ElementPtr,RV_OK));
    return RV_OK;
}



/*************************************************************************************************************************
 * HASH_RemoveElement
 * purpose : Remove an element from the hash table.
 * input   : hHash     - Pointer to the hash table.
 *           ElementPtr - The location pointer of the element that should be removed.
 * output  : None.
 * return  : RV_OK  - In case of success.
 *           RV_ERROR_UNKNOWN     - No such element.
 ************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_RemoveElement (IN HASH_HANDLE hHash,
                                              IN void        *ElementPtr)
{
    HASH_ListElement    *NextListRec;
    HASH_ListElement    *PrevListRec;
    HASH_ListElement    *ListRec = (HASH_ListElement    *)ElementPtr;
    HASH_TableEntryType *HashEntry;
    HASH_TableType      *pHashTable;

    pHashTable = (HASH_TableType *)hHash;

    RvLogEnter(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_RemoveElement (hHash=0x%p,ElementPtr=0x%p)",
        hHash,ElementPtr));

    if ( ListRec->prev != NULL )
    {
        /* We've got previous elements in here... */
        PrevListRec = (HASH_ListElement *)ListRec->prev;
        PrevListRec->next = ListRec->next;
    }
    else
    {
       HashEntry = HASH_ENTRY(pHashTable, ListRec->EntryNum);
       HashEntry->FirstElementPtr = (RA_Element)ListRec->next;

       /* Check if this thing is empty for the resources */
       if (ListRec->next == NULL)
	   {
           pHashTable->KeysSize.numOfUsed--;
	   }
    }


    if ( ListRec->next != NULL )
    {
        NextListRec = (HASH_ListElement *)ListRec->next;
        NextListRec->prev = ListRec->prev;
    }

    RA_DeAlloc (pHashTable->UserRAHandle , (RA_Element)ElementPtr);
    RvLogLeave(pHashTable->pLogSource, (pHashTable->pLogSource,
        "HASH_RemoveElement (hHash=0x%p,ElementPtr=0x%p)=%d",
        hHash,ElementPtr,RV_OK));

    return RV_OK;
}


/************************************************************************************************************************
 * HASH_GetUserKeyElement
 * purpose : Return the key of user element from the hash table according to the user record
 *           elemnt pointer.
 * input   : hHash       - Pointer to the hash table.
 *           ElementPtr   - The position pointer of the user element that should be read.
 * output  : KeyUserElement - The key user element.
 * return  : RV_OK          - In case of success.
 *           RV_ERROR_BADPARAM - Element not in use.
 *           RV_ERROR_UNKNOWN             - No such element.
 ************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_GetUserKeyElement (IN  HASH_HANDLE hHash,
                                                   IN  void        *ElementPtr,
                                                   OUT void        *KeyUserElement)
{
    void            *RAElement = ElementPtr;
    HASH_TableType  *pHashTable;
	RvInt32         ElementId;


    pHashTable = (HASH_TableType *)hHash;

	ElementId = RA_GetByPointer(pHashTable->UserRAHandle,(RA_Element)RAElement);

    if (RA_ElementIsVacant (pHashTable->UserRAHandle, ElementId))
    {
        /* element not in use */
        KeyUserElement = NULL;
        return RV_ERROR_BADPARAM;
    }
    else
    {

        if (NULL == RAElement)
        {
		  	RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
                        "HASH_GetUserKeyElement , RAGet failed"));
            return RV_ERROR_UNKNOWN;
        }

        memcpy (KeyUserElement ,
                &((char *)RAElement)[sizeof(HASH_ListElement)] ,
                pHashTable->UserParamsSize );
        return RV_OK;
    }
}


/************************************************************************************************************************
 * HASH_GetResourcesStatus
 * purpose : Return information about the resource allocation of this HASH
 * input   : hHash      - Pointer to the array.
 * output  : resources  - Includes the following information:
 * return  : RV_OK         - In case of success.
 *           RV_ERROR_BADPARAM   - Invalid hHash handle (NULL)
 ************************************************************************************************************************/
RvStatus RVAPI RVCALLCONV HASH_GetResourcesStatus(IN  HASH_HANDLE          hHash,
                                                   OUT RV_HASH_Resource*    resources)
{
    HASH_TableType  *pHashTable;

    if (hHash == NULL)
        return RV_ERROR_BADPARAM;

    pHashTable = (HASH_TableType *)hHash;

    RA_GetResourcesStatus(pHashTable->UserRAHandle, &resources->elements);
    memcpy(&resources->keys, &pHashTable->KeysSize, sizeof(RV_Resource));

    return RV_OK;
}

/*-------------------------------------------------------------------------*/
/*                          STATIC FUNCTIONS                               */
/*-------------------------------------------------------------------------*/

/*************************************************************************************************************************
* HashInsertElement
* purpose : Add a new user element to a given hash table entry
* input   : pHashTable         - Pointer to the hash table to which the element should be entered.
*           pParams            - Pointer to the structure of the key parameters.
*           pHashEntId         - Pointer to the hash entry ID.
*           pHashEntry         - Pointer to the entry which will contain the new element.
*
*           UserElement        - Pointer to the user element that should be inserted to the hash table.
* output  : ElementPtr         - Pointer to the record that was allocated to this user element.
* return  : RV_OK - In case of insertion success ( or no insertion if the element is already exist ).
*           RV_ERROR_OUTOFRESOURCES - If there is no more available user element records.
*************************************************************************************************************************/
static RvStatus RVCALLCONV HashInsertElement(
                                IN  HASH_TableType      *pHashTable,
                                IN  void                *pParams,
                                IN  HASH_ENTRY_ID       *pHashEntId,
                                IN  HASH_TableEntryType *pHashEntry,
                                IN  void                *UserElement,
                                OUT void               **ElementPtr)
{
    RA_Element           Tmp;
    HASH_ListElement     ListRec;
    HASH_ListElement    *ListRec1;
    RvStatus             rv;

    rv = RA_Alloc(pHashTable->UserRAHandle,(RA_Element *)ElementPtr);
    if (RV_OK != rv)
    {
        RvLogError(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HashInsertElement - pHashTable=0x%p: no more user elements are available", pHashTable));
        return RV_ERROR_OUTOFRESOURCES;
    }

    Tmp = (RA_Element)pHashEntry->FirstElementPtr;
    if (Tmp != NULL)
    {
        /* Key already in use... */
        ListRec1       = (HASH_ListElement *)Tmp;
        ListRec1->prev = (HASH_ListElement *)*ElementPtr;
    }
    else
    {
        pHashTable->KeysSize.numOfUsed++;
        if (pHashTable->KeysSize.numOfUsed > pHashTable->KeysSize.maxUsage)
            pHashTable->KeysSize.maxUsage = pHashTable->KeysSize.numOfUsed;
    }

    /* Fill the user element */
    pHashEntry->FirstElementPtr = (RA_Element)*ElementPtr;
    ListRec.prev                = NULL;
    ListRec.next                = (HASH_ListElement *)Tmp;
    ListRec.EntryNum            = *pHashEntId;

    /* Copy to the user element the following structures :
        - List element with the pointers to the previous and next element
        - Key params that the element was inserted according to
        - User data (at last..) */
    memcpy ( *ElementPtr , &ListRec , sizeof(HASH_ListElement));
    memcpy ( &((char *)*ElementPtr)[sizeof(HASH_ListElement)] , pParams , pHashTable->UserParamsSize );
    memcpy ( &((char *)*ElementPtr)[sizeof(HASH_ListElement) + pHashTable->UserParamsSize] ,
            UserElement , pHashTable->UserRecSize );

    return RV_OK;
}

/************************************************************************************************************************
* HashFindElement
* purpose : The routine is used to find the location of an element in the hash table according to its key params.
* input   : hHash    - Handle to the hash table.
*           pParams  - The parameters ( key parameters ) that should be used. What is done is that the hash routine that
*                      is given in construction time is activated to get one key from the set of parameters , and the
*                      search is done on the hash table using this key ( assuming the hash function is mod ).
*                      Note that this key is saved along with the user element record in the hash table and is used to identify
*                      the searched record.
*           pHashEntId  - Pointer to the entry ID which will be looked within.

*
*           CompareFunc - Pointer to the user function ( hash module user ) that make the compare between the hash table
*                         element and the new params.
* output  : ElementId - A pointer to the user element record that was found.
* return   : TRUE  : If the searched element was found.
*           FALSE : If not.
*************************************************************************************************************************/
static RvBool RVCALLCONV HashFindElement(IN  HASH_TableType    *pHashTable,
                                         IN  void              *pParams,
                                         IN  HASH_ENTRY_ID     *pHashEntId,
                                         IN  HASH_CompareFunc   CompareFunc,
                                         OUT void             **ElementPtr)
{
    HASH_TableEntryType *HashEntry;
    RA_Element           ElemPtr;
    RvBool               Found = RV_FALSE;
    HASH_ListElement     ListRec;

    *ElementPtr = NULL;
    HashEntry   = HASH_ENTRY(pHashTable, *pHashEntId);

    if ( HashEntry->FirstElementPtr != NULL )
    {
        /* check all the elements of the relevant hash entry */
        ElemPtr = (RA_Element) HashEntry->FirstElementPtr;
        while ( ( ElemPtr != NULL ) && (!Found))
        {
#ifdef HASH_DEBUG
            RvUint32 userDataPrefix;
            memcpy(&userDataPrefix,
                &((char*)ElemPtr)[sizeof(ListRec) + pHashTable->UserParamsSize],
                sizeof(RvUint32));
            RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HashFindElement(hHash=0x%p): check element with the first 4 bytes of user data 0x%p",
                hHash, userDataPrefix));
#endif /*#ifdef HASH_DEBUG*/

            if ( CompareFunc ( pParams , &((char *)ElemPtr)[sizeof(ListRec)] ) )
            {
                Found = RV_TRUE;
                *ElementPtr = (void *)ElemPtr;
            }
            else
            {
                memcpy ( &ListRec , ElemPtr , sizeof(ListRec));
                ElemPtr =(RA_Element) ListRec.next;
            }
        }
    }

    return Found;
}


/************************************************************************************************************************
* HashFindElementByPartKey
* purpose : The routine is used to find the location of an element in the hash table according to partial key params.
* input   : hHash       - Handle to the hash table.
*           pParams     - The parameters ( partial key parameters ) that should be used. 
*           pHashEntId  - Pointer to the entry ID which will be looked within. If this parameter is NULL, the
*                         hash table is searched in.
*           CompareFunc - Pointer to the user function ( hash module user ) that make the compare between the hash table
*                         element and the partial key params.
* input/output  : 
*           ppElem      - A pointer to pointer to the user element record that was found. This
*                         pointer should point to NULL upon calling this function on
*                         the first time. Then, the calling function would have to use 
*                         the ppElem, which was returned in the previous call to 
*                         HASH_FindElemByPartKey() (if any element was found) for consequent 
*                         search.
* return  : TRUE  : If the searched element was found.
*           FALSE : If not.
*************************************************************************************************************************/
static RvBool RVCALLCONV HashFindElementByPartKey(
                                         IN    HASH_TableType    *pHashTable,
                                         IN    void              *pParams,
                                         IN    HASH_ENTRY_ID     *pHashEntId,
                                         IN    HASH_CompareFunc   CompareFunc,
                                         INOUT void             **ppElem)
{
    void                *pLocalElem  = *ppElem;
    RvBool               bFound      = RV_FALSE;
    RvBool               bFoundStart = RV_FALSE;

    bFoundStart = HashFindNextElemByPartKey(pHashTable,pHashEntId,&pLocalElem);
    
    while (bFoundStart == RV_TRUE && bFound == RV_FALSE)
    {
#ifdef HASH_DEBUG
        RvUint32 userDataPrefix;
        memcpy(&userDataPrefix,
            &((char*)pLocalElem)[sizeof(ListRec) + pHashTable->UserParamsSize],
            sizeof(RvUint32));
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HashFindElement(hHash=0x%p): check element with the first 4 bytes of user data 0x%p",
            hHash, userDataPrefix));
#endif /*#ifdef HASH_DEBUG*/

        if ( CompareFunc ( pParams , &((char *)pLocalElem)[sizeof(HASH_ListElement)] ) )
        {
            *ppElem = pLocalElem;
            bFound  = RV_TRUE;
        }
        else
        {
            bFoundStart = HashFindNextElemByPartKey(pHashTable,pHashEntId,&pLocalElem);
        }
    }

    return bFound;
}

/************************************************************************************************************************
* HashFindNextElemByPartKey
* purpose : The routine is used to find the start location of elements search according to partial key params.
* input   : hHash       - Handle to the hash table.
*           pHashEntId  - Pointer to the entry ID which will be looked within. If this parameter is NULL, the
*                         hash table is searched in.
*           bStartFromEntId -
*                         Indication if the search of the start element should begin within the given pHashEntId
*                         and go on through the next entries (RV_TRUE) or if the search of the start element 
*                         should focus on the given entry only (if it's value is RV_FALSE). 
*                         NOTE: This parameter is referred only if pHashEntId is not NULL.
* input/output  : 
*           ppElem      - A pointer to pointer to the user element record to start the search from. 
* return  : TRUE  : If the searched element was found.
*           FALSE : If not.
*************************************************************************************************************************/
static RvBool RVCALLCONV HashFindNextElemByPartKey(
                                IN    HASH_TableType    *pHashTable,
                                IN    HASH_ENTRY_ID     *pHashEntId,
                                INOUT void             **ppElem)
{
    HASH_TableEntryType *HashEntry;
    HASH_ENTRY_ID        entId = (pHashEntId != NULL) ? *pHashEntId : 0;;

    /* Place the current position to start the search */

    /* If the user has provided non-zero element we are in the middle of search */
    if (*ppElem != NULL) 
    {
        HASH_ListElement ListRec;

        memcpy (&ListRec,*ppElem,sizeof(ListRec));
        /* NOTE: We shouldn't compare entId to ListRec.EntryNum since pHashEntId might be NULL  */
        if (pHashEntId != NULL && *pHashEntId != ListRec.EntryNum)
        {
            RvLogExcep(pHashTable->pLogSource, (pHashTable->pLogSource,
                "HashFindNextElemByPartKey(hHash=0x%p): The pHashEntId (%d) is different than ListRec.EntryNum (%d)",
                pHashTable, *pHashEntId,ListRec.EntryNum));

            return RV_FALSE; 
        }
        /* Move on to the next element since we're in the middle of search */
        if (NULL != ListRec.next)
        {
            *ppElem = ListRec.next;

            return RV_TRUE;
        }
        else
        {
            /* We try to move on looking for the next entry only if pHashEntId != NULL */
            entId = (pHashEntId != NULL) ? ADS_UNDEFINED : (ListRec.EntryNum + 1);
        }
    }
    /* Otherwise, we just start the search from the beginning of an entry */

    /* Check if we're still at the hash entries scope */
    if (entId >= (HASH_ENTRY_ID) pHashTable->KeysSize.maxNumOfElements || entId == ADS_UNDEFINED)
    {
        return RV_FALSE; 
    }

    HashEntry = HASH_ENTRY(pHashTable, entId);
    /* We look for all the entries within the hash. We stop at pHashTable->KeysSize.maxNumOfElements-1 since we would
       like to avoid memory overflow in the last loop step on our last iteration. If no pHashEntId was provided then 
       we go over the hash entries */
    while (pHashEntId == NULL && 
           HashEntry->FirstElementPtr == NULL && 
           entId < (HASH_ENTRY_ID) (pHashTable->KeysSize.maxNumOfElements-1))
    {
        entId += 1; 
        HashEntry = HASH_ENTRY(pHashTable, entId);
    }
    if (HashEntry->FirstElementPtr == NULL)
    {
        RvLogDebug(pHashTable->pLogSource, (pHashTable->pLogSource,
            "HashFindNextElemByPartKey(hHash=0x%p,entId=%d): Couldn't find non empty element",
            pHashTable, entId));

        return RV_FALSE;
    }

    *ppElem = (void *)HashEntry->FirstElementPtr;

    return RV_TRUE;
}

#ifdef __cplusplus
}
#endif


