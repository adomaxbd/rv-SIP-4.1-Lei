/******************************************************************************
Filename:    simpleMtfandSimpleMain.c
Description: 

-----------------------------------------------------------------------------------------

This file implements the following functionality:
				1. Initialize the MTF 
				2. Initialize the PUA (SIMPLE client)
				3. Create a presentity subscription (with PUA)
				4. Establish a new call (with MTF)

-----------------------------------------------------------------------------------------

Here is the flow of the MTF and SIMPLE sample:
															 SIMPLE					       MTF
	  CLIENT                                                 SERVER					     SERVER
		|                                                       |							|
	create call-leg obj											|							|   
		|                                                       |							|
		|			------------------------- INVITE ----------------------------->			|
		|                                                       |							|
		|			<------------------------- 180 Ringing ------------------------			|
		|													    |					Auto-answer is on 
		|													    |					answer the call.
		|			<--------------------------- 200 OK ---------------------------  		|
		|													    |					call-leg is connected.
		|			<------------------------------ ACK ----------------------------  		|
		|													    |							|
	call-leg is connected.										|							|
		|                                                       |							|
		|														|
		|                                                       |
	create presentity obj										|   
		|                                                       |
		|    ------------- SUBSCRIBE ----------------->         |
		|                  event:presence.winfo                 |
		|                                               Accept the subscription and send 
		|                                               initial Notify request.
		|    <------------ 200 -----------------------          |
		|    <------------ NOTIFY (presentity) ----------       |
		|     ------------ 200 ----------------------->         |
	presentity subs is active.									|
		|                                                       |
	create watcher obj.											|   
		|                                                       |
		|    ------------- SUBSCRIBE ----------------->         |
		|                  event:presence                       |
		|                                               Accept the subscription and send 
		|                                               initial Notify request.
		|    <------------ 200 -----------------------          |
		|    <------------ NOTIFY (watcher)--------------       |
		|     ------------ 200 ----------------------->         |
	watcher is active.											|
		|                                                       |
		|                                               Send Notify to the presentity
		|                                               informing the new watcher.
		|    <------------ NOTIFY (presentity)-----------       |
		|     ------------ 200 ----------------------->         |
		|                                                       |
	create publisher obj.										|   
		|                                                       |
		|    ------------- PUBLISH ------------------->         |
		|                  event:presence                       |
		|                                               Accept the publish request.
		|    <------------ 200 -----------------------          |
		|                                               Send Notify to the watcher
		|                                               informing of the resource state.
		|    <------------ NOTIFY (watcher)--------------       |
		|     ------------ 200 ----------------------->         |

-----------------------------------------------------------------------------------------
In order to allow co-existence between the MTF and the SIMPLE client, the following steps 
should be followed:

  1. Compile the application and MTF with RV_MTF_SIMPLE_ON
  
  2. SIMPLE client application should not initialize the SIP stack 
     (the SIP stack will be initialized by the MTF).

  3. SIMPLE client application should not use the EventDispatcher 
     (the SIP stack event dispatching will be done by the MTF).

  4. Set the handle to PUA (SIMPLE client) in MTF so it can be retrieved by MTF and passed to application 
	 when SIP stack callbacks are called, this is done by calling the following API after SIMPLE client
	 was initialized:
		rvMtfSetSimpleClientHandle()

  5. Configure the SIP stack parameter "maxSubscriptions" to consider MTF terminations and SIMPLE client objects 
    (Presentities and Watchers).

  6. MTF should be dependent on SIMPLE client toolkit

-----------------------------------------------------------------------------------------

In order to run this sample under windows you must run 3 applications:
		1. The demoSimpleServer
		2. The demoMtfClient
		3. The simpleMTFandSIMPLE

-----------------------------------------------------------------------------------------

TODO:

  1. Shutdown MTF and SIMPLE client gracefully

  2. Disconnect the call (?)
  3. Handle authentication
  4. Hierarchy of client & servers (should both be under one directory)
  5. Add TCP/TLS/SCTP
  6. Debug/Release

*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
Author                         Date
------                        ------
Yochi Moran                 Mar 2009
*****************************************************************************/

#include "IppStdInc.h"
#include "ippthread.h"
#include "simpleMtf/rvMtfSample.h"
#include "rvsdp.h"
#include "rvthread.h"
#include "rvmtfalloc.h"
#include "rvMtfHandles.h"
#include "RvSimpleCltPuaTypes.h"
#include "rvMtfBaseTypes.h"
#include "rvMtfBaseApi.h"
#include "rvMdmControlApi.h"
#include "simpleSimpleClient.h"

/*============================================================================================*/
/*=================================   G L O B A L S  =========================================*/
/*============================================================================================*/

extern RvMtfHandle			g_hMtf;
RvSimpleCltPuaHandle		g_phPua;
extern RvSipStackHandle		g_hSipStack;

#define DESTINATION_ADDRESS		"sip:bob@127.0.0.1:5070"

void AppSimpleClientInitialize(RvMtfHandle			hMtf);

void AppSetCallBackFunctions(void);

/*============================================================================================*/
/*=======================   S T A R T / E N D		F U N C T I O N S ========================*/
/*============================================================================================*/

RvStatus rvMtfSampleStart(void)
{
    RvStatus    rv;
	RvIppTerminalHandle			hTerm;

 	/* Initialize MTF and sample application */
	/* ------------------------------------ */
	printf("Initializing MTF client...\r\n");

	/* Initialize SIP stack and construct MTF */
	rvMtfSystemInit();
    rv = rvMtfSampleConstruct();
	if (rv != RV_OK)
    {
        printf("ERROR: failed to initialize MTF, status = %d\n", rv);
        return rv;
    }
	
	/* Start processing events */
    rvMtfStart(g_hMtf);

	/* Register terminations */
	rvMtfRegisterIPPhoneTerminations(g_hMtf, "alice", NULL, &hTerm);

	printf("MTF Client was initialized successfully!\r\n");
	printf("========================================\n\n");

	/* Initialize SIMPLE client */
	/* ------------------------ */

	printf("Initializing SIMPLE client toolkit...\r\n");
    /* Initialize the RADVISION SIMPLE client add-on above the SIP stack.*/
    AppSimpleClientInitialize(g_hMtf);
    /* Set the callback functions in the pua managers.*/
    AppSetCallBackFunctions();
	printf("SIMPLE client toolkit was initialized successfully!\r\n");

	/* Establish SIMPLE session (Create a presentity subscription) */
	/* ----------------------------------------------------------- */

    AppCreatePresentity();

	/* Establish MTF session (make call)*/
	/* --------------------------------- */

	rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_OFFHOOK, NULL);

	rv = rvMtfTerminalMakeCall(hTerm, DESTINATION_ADDRESS);
	
	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "ERROR: failed to make call to: %s", DESTINATION_ADDRESS);
	}

	getchar();

    return rv;
}

void rvMtfSampleEnd(void)
{
	/* Destruct MTF and sample application */
	/* ----------------------------------- */
    rvMtfSampleDestruct();
    rvIppSipSystemEnd();
}
/*============================================================================================*/
/*=======================   M A I N		F U N C T I O N  =====================================*/
/*============================================================================================*/

#if (RV_OS_TYPE != RV_OS_TYPE_WINCE)
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int MtfSipSample(int argc)
#else
int main(int argc, char **argv)
#endif
{
    RvStatus    status = RV_OK;
	RvTime st;

	RvTimeConstruct(10, 0, &st);

	RV_UNUSED_ARG(argc);

#if (RV_OS_TYPE != RV_OS_TYPE_VXWORKS)
	RV_UNUSED_ARG(argv);
#endif

    /* Run MTF for the first time */
    if ((status = rvMtfSampleStart()) != RV_OK)
    {
        printf("*******rvMtfSampleStart error = %d*******\n", status);
        return status;
    }

	while (1)
	{
		/*  Sleep (10); */

		RvThreadSleep(&st, NULL); 

	}
	
    /* Shut down MTF*/
    rvMtfSampleEnd();

    return 0;
}
#endif
/*============================================================================================*/
/*=========================== V X W O R K S  =================================================*/
/*============================================================================================*/

/* In vxWorks we can either call vxMain() with no arguments for running application from seperated
   process (so we don't block the shell), or we can call MtfSipSample() directly
   (and block the shell) with one argument: number of warm restarts*/
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int vxMain()
{
    taskSpawn("User IPP",100,0,100000, MtfSipSample, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return 0;

}
#endif /*(RV_OS_TYPE_VXWORKS)*/

