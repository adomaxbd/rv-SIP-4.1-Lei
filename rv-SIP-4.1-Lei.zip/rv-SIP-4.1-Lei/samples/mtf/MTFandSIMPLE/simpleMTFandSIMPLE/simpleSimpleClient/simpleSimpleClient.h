/*********************************************************************************
 *                              <simpleSimpleClient.h>
 *   This file gives a complete example of how to:
 *   (1) Initiate the RADVISION SIMPLE Client add-on (also referred as PUA=Presence 
 *       User Agent) above the SIP stack.
 *       (File: simpleSimpleClient.c)
 *   (2) Initiate an outgoing Presentitiy object (event:presence.winfo).
 *       (File: simplePresentityClient.c)
 *   (3) Initiate an outgoing Watcher object (event:presence).
 *       (File: simpleWatcherClient.c)
 *   (4) Publish the client status using a Publisher object.
 *       (File: simplePublisherClient.c)
 *
 *   the sample message flow:
 *   =============================================================================
 *   CLIENT                                                 SERVER
 *      |                                                       |
 *   create presentity obj                                      |   
 *      |                                                       |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |                  event:presence.winfo                 |
 *      |                                               Accept the subscription and send 
 *      |                                               initial Notify request.
 *      |    <------------ 200 -----------------------          |
 *      |    <------------ NOTIFY (presentity) ----------       |
 *      |     ------------ 200 ----------------------->         |
 *      |                                               presentity subs is active.
 *   create watcher obj                                         |   
 *      |                                                       |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |                  event:presence                       |
 *      |                                               Accept the subscription and send 
 *      |                                               initial Notify request.
 *      |    <------------ 200 -----------------------          |
 *      |    <------------ NOTIFY (watcher)--------------       |
 *      |     ------------ 200 ----------------------->         |
 *      |                                               watcher is active.
 *      |                                                       |
 *      |                                               Send Notify to the presentity
 *      |                                               informing the new watcher.
 *      |    <------------ NOTIFY (presentity)-----------       |
 *      |     ------------ 200 ----------------------->         |
 *      |                                                       |
 *   create publisher obj                                       |   
 *      |                                                       |
 *      |    ------------- PUBLISH ------------------->         |
 *      |                  event:presence                       |
 *      |                                               Accept the publish request.
 *      |    <------------ 200 -----------------------          |
 *      |                                               Send Notify to the watcher
 *      |                                               informing of the resource state.
 *      |    <------------ NOTIFY (watcher)--------------       |
 *      |     ------------ 200 ----------------------->         |
 *
 *   ==============================================================================
 *   The sample should be run against the demo SIMPLE server, running on the same
 *   machine. In order to use remote machine you should change the PUBLISH_RESOURCE_URI
 *   address defined bellow.
 *   Notice that the application exits on errors.
 *
 * ------------------------------------------------------------------
 * Note: In order to run this sample under windows you must first
 *       Compile the stack, the SIMPLE client add-on and the event-dispatcher from 
 *       the rvsip.dsw workspace with the following configurations:
 *       - Win32 Debug configuration for Debug execution
 *       - Win32 Release configuration for Release execution.
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                 Feb 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"
#include <stdio.h>
#include <stdarg.h>

#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif

#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSimpleCltPuaTypes.h"
#include "RvSimpleCltPublisherTypes.h"
#include "RvSimpleCltWatcherTypes.h"
#include "RvSimpleCltPresentityTypes.h"
#include "RvSimpleCltPua.h"
#include "RvSimpleCltPublisher.h"
#include "RvSimpleCltPresentity.h"
#include "RvSimpleCltWatcher.h"

/*internal usage only*/
#ifdef USE_INTERNAL_SAMPLE_DEFS
#include "samplesInternalDefs.h"
#endif

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/
/*Define the resource and watcher addresses as strings*/

#ifndef USE_INTERNAL_SAMPLE_DEFS

#define PUBLISH_RESOURCE_URI "sip:Joe@127.0.0.1:6060" /* the resource name at the demoSimpleServer address*/
#define PUBLISH_FROM_URI     "sip:Joe@127.0.0.1:5060" /* the resource name ar the local simpleClient address */
#define WATCHER_FROM_URI     "sip:Watcher@127.0.0.1:5060" /* the watcher name ar the local simpleClient address */


#define SUBS_EXPIRES 360
#define PUB_EXPIRES  30

#endif /*#ifndef USE_INTERNAL_SAMPLE_DEFS*/


/*-----------------------------------------------------------------------*/
/*                        F U N C T I O N S                              */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
void AppPrintMessage(IN RvSipMsgHandle hMsg);

/***************************************************************************
 * AppExitOnError
 * ------------------------------------------------------------------------
 * General: prints an error message and exits.
  ***************************************************************************/
void AppExitOnError(RvChar* str);

/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Implementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameters according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
int OSPrintf(IN const char *format,... );


/*---- P U B L I S H E R   F U N C T I O N S ----------*/
/***************************************************************************
 * AppCreatePublisher
 * ------------------------------------------------------------------------
 * General: Creates a publisher object, and send PUBLISH.
 *          To publish the client status the application should:
 *          1. Create a new publisher using RvSimpleCltPubMgrCreatePublisher().
 *			2. Initialize the publisher object using RvSimpleCltPubSetInitParams().
 *          3. Set the body describing it's status to the publisher outbound message.
 *          4. Call RvSimpleCltPubPublish(). This will cause the PUBLISH message
 *             to be sent to the destination.
 ***************************************************************************/
void AppCreatePublisher(void);

/***************************************************************************
 * AppSimplePublisherStateChangedEv
 * ------------------------------------------------------------------------
 * General: Client handling of the PublisherStateChangedEvHandler.
 *          Here we only print the new state.
 * 
 * Arguments:
 * Input:   hPub      - A handle to SIMPLE client Publisher.
 *          hAppPub   - The application handle for this Publisher object.
 *          eNewState - The new state of the Publisher object.
 *          eReason   - The reason for the change in state.
 * Output:  pbDefBehavior - Indication if Publisher default behavior should
 *							take place (as defined above). 
 * Return Value: None.
 ***************************************************************************/
void RVCALLCONV AppSimplePublisherStateChangedEv(
                            IN  RvSimpleCltPubHandle            hPub,
                            IN  RvSimpleCltAppPubHandle         hAppPub,
                            IN  RvSimpleCltPubState				eNewState,
                            IN  RvSimpleCltPubStateReason		eReason,
							OUT RvBool                         *pbDefBehavior);

/***************************************************************************
 * AppSimplePublisherTimerExpiredEv
 * ------------------------------------------------------------------------
 * General: Client handling of the PublisherTimerExpiresEvHandler.
 *          Here we refresh the publish client automatically, and send a
 *          new status in this refresh.
 * 
 * Arguments:
 * Input:   hPub         - A handle to SIMPLE client Publisher.
 *          hAppPub      - The application handle for this Publisher object.
 *          eTimerType   - The type of the expired timer. 
 * Output:  pbHandleAuto - Indication 
 *
 * Return Value: None.
 ***************************************************************************/
void RVCALLCONV AppSimplePublisherTimerExpiredEv(
							IN  RvSimpleCltPubHandle         hPub,
							IN  RvSimpleCltAppPubHandle      hAppPub,
							OUT RvBool						*pbHandleAuto);

/***************************************************************************
* AppSimplePublisherMsgRcvdEv
* ------------------------------------------------------------------------
* General: Application implementation to the message received event handler.
*          Here we only print the message that was received.
*
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:   hPub          - A handle to SIMPLE client Publisher.
*          hAppPub       - The application handle for this Publisher object.
*		   hReceivedMsg  - The message that was received.
* Output:  None
***************************************************************************/
RvStatus RVCALLCONV AppSimplePublisherMsgRcvdEv(
					  IN  RvSimpleCltPubHandle         hPub,
					  IN  RvSimpleCltAppPubHandle      hAppPub,
					  IN  RvSipMsgHandle			   hReceivedMsg);

/***************************************************************************
* AppSimplePublisherMsgToSendEv
* ------------------------------------------------------------------------
* General: Application implementation to the message to send event handler.
*          Here we only print the message that is about to be sent.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:   hPub        - A handle to SIMPLE client Publisher.
*          hAppPub     - The application handle for this Publisher object.
*		   hMsgToSend  - The message that was received.
* Output:  None
***************************************************************************/
RvStatus RVCALLCONV AppSimplePublisherMsgToSendEv(
					  IN  RvSimpleCltPubHandle         hPub,
					  IN  RvSimpleCltAppPubHandle      hAppPub,
					  IN  RvSipMsgHandle			   hMsgToSend);

/*---- W A T C H E R   F U N C T I O N S ----------*/

/***************************************************************************
 * AppCreateWatcher
 * ------------------------------------------------------------------------
 * General: Creates a watcher object, and subscribe it.
 *          To subscribe a watcher the application should:
 *          1. create a new watcher using RvSimpleCltWatcherMgrCreateWatcher().
 *			2. initialize the watcher object using RvSimpleCltWatcherSetInitParams().
 *          3. call RvSimpleCltWatcherSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 ***************************************************************************/
void AppCreateWatcher(void);

/***************************************************************************
* AppSimpleWatcherStateChangedEv
* ------------------------------------------------------------------------
* General: Client handling of the WatcherStateChangedEvHandler.
*          Here we only print the new state.
*
* Arguments:
* Input:     hWatcher    - Handle to the Watcher instance. 
*            hAppWatcher - The application handle for this Watcher instance.
*            eState		 - The new Watcher's Subscription state.
*            eReason     - The reason for the state transition.
*
* Output:  pbDefBehavior - Indication if Watcher default behavior should
*						   take place.
*
* Return Value: None.
***************************************************************************/
void RVCALLCONV AppSimpleWatcherStateChangedEv(
					IN  RvSimpleCltWatcherHandle       hWatcher,
					IN  RvSimpleCltAppWatcherHandle    hAppWatcher,
					IN  RvSimpleCltWatcherState        eState,
					IN  RvSimpleCltWatcherStateReason  eReason,
					OUT RvBool                        *pbDefBehavior);

/***************************************************************************
* AppSimpleWatcherNewUpdatesEv
* ------------------------------------------------------------------------
* General: Application handling of the WatcherNewUpdatesEvHandler.
*          The callback indicates that new presence information (about the 
*          remote buddy) was received within a NOTIFY request from the server.
*          The callback supplies PIDF-XML object containing all the received 
*          information. Here we use the Pidf-XML API to observe this information,  
*          and print it.
*
* Arguments:
* Input:   hWatcher    - The SIMPLE Client Watcher's handle.
*          hAppWatcher - The application handle of this Watcher.
*		   hMsg        - The received NOTIFY request containing PIDF data
*		   hBuddyPidf  - The handle to the updated remote buddy PIDF data. 
*
* Return Value: None.
***************************************************************************/
void RVCALLCONV AppSimpleWatcherNewUpdatesEv(
					 IN  RvSimpleCltWatcherHandle      hWatcher,
					 IN  RvSimpleCltAppWatcherHandle   hAppWatcher,
					 IN  RvSipMsgHandle                hMsg,
					 IN  RvSimpleCltPidfHandle		   hBuddyPidf);

/***************************************************************************
 * AppSimpleWatcherMsgRcvdEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 *
 * Arguments:
 * Input:   hWatcher    - The SIMPLE Client Watcher's handle.
 *          hAppWatcher - The application handle of this Watcher.
 *          hMsg        - The received message
 *
 * Return Value: None
 ***************************************************************************/
RvStatus RVCALLCONV AppSimpleWatcherMsgRcvdEv(
						IN  RvSimpleCltWatcherHandle      hWatcher,
						IN  RvSimpleCltAppWatcherHandle   hAppWatcher,
						IN  RvSipMsgHandle                hMsg);

/***************************************************************************
 * AppSimpleWatcherMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Arguments:
 * Input:   hWatcher    - The SIMPLE Client Watcher's handle.
 *          hAppWatcher - The application handle of this Watcher.
 *          hMsg        - The message about to be sent
 *
 * Return Value: None.
 ***************************************************************************/
RvStatus RVCALLCONV AppSimpleWatcherMsgToSendEv(
						  IN  RvSimpleCltWatcherHandle      hWatcher,
						  IN  RvSimpleCltAppWatcherHandle   hAppWatcher,
						  IN  RvSipMsgHandle                hMsg);

/*---- P R E S E N T I T Y   F U N C T I O N S ----------*/
/***************************************************************************
 * AppCreatePresentity
 * ------------------------------------------------------------------------
 * General: Creates a presentity object, and subscribe it.
 *          To subscribe a presentity the application should:
 *          1. create a new presentity using RvSimpleCltPresMgrCreatePresentity().
 *			2. initialize the presentity object using RvSimpleCltPresSetInitParams().
 *          3. call RvSimpleCltPresSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 ***************************************************************************/
void AppCreatePresentity(void);

/***************************************************************************
 * AppSimplePresStateChangedEv
 * ------------------------------------------------------------------------
 * General: Client handling of the PresentityStateChangedEvHandler.
 *          Here we only print the new state.
 *
 * Arguments:
 * Input:   hPres	   - The Presentity object whose state has changed
 *          hAppPres   - The application Presentity object
 *          eState     - The new Presentity state
 *          eReason    - The reason for the change in state
 *
 * Return Value: none
 ***************************************************************************/
void RVCALLCONV AppSimplePresStateChangedEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSimpleCltPresState             eState,
						   IN  RvSimpleCltPresStateChangeReason eReason);

/***************************************************************************
 * AppSimplePresSubsMsgRcvdEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Arguments:
 * Input:   hPres		- The Presentity object 
 *          hAppPres	- The application Presentity object
 *          hSubs       - The subscription receiving a message
 *          hMsg        - The received message
 * Return Value: none
 ***************************************************************************/
RvStatus RVCALLCONV AppSimplePresSubsMsgRcvdEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipMsgHandle                   hMsg);

/***************************************************************************
 * AppSimplePresSubsMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 *
 * Arguments:
 * Input:   hPres		- The Presentity object 
 *          hAppPres	- The application Presentity object
 *          hSubs       - The subscription sending a message
 *          hMsg        - The message about to be sent
 * Return Value: none
 ***************************************************************************/
RvStatus RVCALLCONV AppSimplePresSubsMsgToSendEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipMsgHandle                   hMsg);

/***************************************************************************
 * AppSimplePresSubsStateChangedEv
 * ------------------------------------------------------------------------
 * General: Application handling of the PresentitySubsStateChangedEvHandler.
 *          Here we print the new state.
 *          When the state is active, we initiate a watcher object.
 *
 * Arguments:
 * Input:   hPres			  - The Presentity object 
 *          hAppPres		  - The application Presentity object
 *          hSubs             - The subscription that changed its state
 *          eState            - The new subscription state
 *          eReason           - The reason for the change in state
 * Output:	pbDefaultBehavior - Indication whether the Presentity object should
 *                              apply the default behavior defined for this state. 
 *
 * Return Value: none
 ***************************************************************************/
void RVCALLCONV AppSimplePresSubsStateChangedEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipSubsState                   eState,
						   IN  RvSipSubsStateChangeReason       eReason,
                           OUT RvBool                          *pbDefaultBehavior);

/***************************************************************************
 * AppSimplePresWatcherNewUpdatesEv
 * ------------------------------------------------------------------------
 * General: Application handling of the PresentityWatcherNewUpdatesEvHandler.
 *			The callback indicates that new watcher information was received
 *          within a NOTIFY request from the server, and supplies a
 *          Watcher-XML object containing all the received information.
 *          Here we use the Watcher-XML API to observe this information, and 
 *          print it.
 * Arguments:
 * Input:   hPres		 	 - The Presentity object receiving a NOTIFY request
 *          hAppPres		 - The application Presentity object
 *          hSubs            - An inner subscription of the Presentity object that
 *                             is the specific subscription that received the NOTIFY request.
 *          hMsg             - The received NOTIFY request containing watcher XML
 *          hWatcherXML      - A Watcher-XML object containing all parsed watcher 
 *                             information received.
 *
 * Return Value: none
 ***************************************************************************/
void RVCALLCONV AppSimplePresWatcherNewUpdatesEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipMsgHandle                   hMsg,
						   IN  RvSimpleCltWinfoXMLHandle        hWatcherXML);


