

/*********************************************************************************
 *                              <simpleWatcherClient.c>
 *   This file implements the watcher part in the simpleSimpleClient sample.
 *   The watcher object subscribes to presence information, and handles
 *   presence notifications from the server.
 *   The watcher actions done in this sample:
 *   1) Initiate the watcher object.
 *   2) Handles the watcher event handlers.
 *   3) When receiving Notification of a new presnece status, extracts its parameters
 *      from the NOTIFY request, and display it on screen.
 *********************************************************************************/

// #ifdef RV_MTF_SIMPLE_ON

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "simpleSimpleClient.h"
/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
extern RvSimpleCltWatcherMgrHandle    g_hWatcherMgr;

/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static void RVCALLCONV AppExtractPidfInformation(
					 IN  RvSimpleCltPidfHandle		   hBuddyPidf);
static const RvChar*  AppGetWatcherStateName (IN  RvSimpleCltWatcherState  eState);

static const RvChar*  AppGetWatcherBasicStatusName (
                          IN  RvSimpleCltPidfTupleBasicStatus  eStatus);

/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppCreateWatcher
 * ------------------------------------------------------------------------
 * General: Creates a watcher object, and subscribe it.
 *          To subscribe a watcher the application should:
 *          1. create a new watcher using RvSimpleCltWatcherMgrCreateWatcher().
 *			2. initialize the watcher object using RvSimpleCltWatcherSetInitParams().
 *          3. call RvSimpleCltWatcherSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 ***************************************************************************/
void AppCreateWatcher(void)
{
	RvStatus              rv          = RV_OK;
    RvSimpleCltWatcherHandle hWatcher = NULL;
    RvSimpleCltCommonObjParamStrs initParams;
	RvSimpleCltCommonExpires expiresParam;

	/*--------------------------
      1. Create a new watcher
    ----------------------------*/
    OSPrintf("===========================================================\n");
    OSPrintf("Creating a new watcher for resource %s\n",PUBLISH_RESOURCE_URI);
    OSPrintf("===========================================================\n");
	
	rv = RvSimpleCltWatcherMgrCreateWatcher(
                g_hWatcherMgr, (RvSimpleCltAppWatcherHandle )NULL, &hWatcher);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create new watcher");
    }

	/*-----------------------------
      2. Initialize the new watcher
    -------------------------------*/
	memset((void*)&initParams, 0, sizeof(initParams));
	initParams.strFrom   = WATCHER_FROM_URI;
	initParams.strReqUri = PUBLISH_RESOURCE_URI;
	initParams.strTo     = PUBLISH_RESOURCE_URI;
	rv = RvSimpleCltWatcherSetParamStrs(hWatcher, &initParams, sizeof(initParams));
	if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to initialize the new watcher");
    }

    OSPrintf("\nwatcher %p was created\n",hWatcher);
    
	/*--------------------------------
      Initialize the expires parameter
    ----------------------------------*/
	memset((void*)&expiresParam, 0, sizeof(expiresParam));
	expiresParam.bResides = RV_TRUE;
	expiresParam.value    = SUBS_EXPIRES;

	OSPrintf("\nSubscribing from watcher: \n\t%s -> %s\n\n",WATCHER_FROM_URI,PUBLISH_RESOURCE_URI);
	/*------------------------------------------------------------------------
      3. Call the subscribe function in order to establish the presence subscription.
    --------------------------------------------------------------------------*/
    rv = RvSimpleCltWatcherSubscribe(hWatcher, &expiresParam, sizeof(expiresParam));
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to subscribe for watcher");
    }
}

/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/

/***************************************************************************
* AppSimpleWatcherStateChangedEv
* ------------------------------------------------------------------------
* General: Client handling of the WatcherStateChangedEvHandler.
*          Here we only print the new state.
*
* Arguments:
* Input:     hWatcher    - Handle to the Watcher instance. 
*            hAppWatcher - The application handle for this Watcher instance.
*            eState		 - The new Watcher's Subscription state.
*            eReason     - The reason for the state transition.
*
* Output:  pbDefBehavior - Indication if Watcher default behavior should
*						   take place.
*
* Return Value: None.
***************************************************************************/
void RVCALLCONV AppSimpleWatcherStateChangedEv(
					IN  RvSimpleCltWatcherHandle       hWatcher,
					IN  RvSimpleCltAppWatcherHandle    hAppWatcher,
					IN  RvSimpleCltWatcherState        eState,
					IN  RvSimpleCltWatcherStateReason  eReason,
					OUT RvBool                        *pbDefBehavior)
{
    /*print the new state on screen*/
    OSPrintf("\n watcher %p - State changed to %s\n\n",
             hWatcher, AppGetWatcherStateName(eState));

	*pbDefBehavior = RV_TRUE;
    RV_UNUSED_ARG(hAppWatcher);
    RV_UNUSED_ARG(eReason);
}


/***************************************************************************
 * AppSimpleWatcherMsgRcvdEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 *
 * Arguments:
 * Input:   hWatcher    - The SIMPLE Client Watcher's handle.
 *          hAppWatcher - The application handle of this Watcher.
 *          hMsg        - The received message
 *
 * Return Value: None
 ***************************************************************************/
RvStatus RVCALLCONV AppSimpleWatcherMsgRcvdEv(
						IN  RvSimpleCltWatcherHandle      hWatcher,
						IN  RvSimpleCltAppWatcherHandle   hAppWatcher,
						IN  RvSipMsgHandle                hMsg)
{
	OSPrintf("<-- Message Received (Watcher %p)\n",hWatcher);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppWatcher);

    return RV_OK;
}

/***************************************************************************
 * AppSimpleWatcherMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Arguments:
 * Input:   hWatcher    - The SIMPLE Client Watcher's handle.
 *          hAppWatcher - The application handle of this Watcher.
 *          hMsg        - The message about to be sent
 *
 * Return Value: None.
 ***************************************************************************/
RvStatus RVCALLCONV AppSimpleWatcherMsgToSendEv(
						  IN  RvSimpleCltWatcherHandle      hWatcher,
						  IN  RvSimpleCltAppWatcherHandle   hAppWatcher,
						  IN  RvSipMsgHandle                hMsg)
{
	OSPrintf("\n--> Message Sent (watcher %p)\n",hWatcher);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppWatcher);
    
    return RV_OK;
}


/***************************************************************************
* AppSimpleWatcherNewUpdatesEv
* ------------------------------------------------------------------------
* General: Application handling of the WatcherNewUpdatesEvHandler.
*          The callback indicates that new presence information (about the 
*          remote buddy) was received within a NOTIFY request from the server.
*          The callback supplies PIDF-XML object containing all the received 
*          information. Here we use the Pidf-XML API to observe this information,  
*          and print it.
*
* Arguments:
* Input:   hWatcher    - The SIMPLE Client Watcher's handle.
*          hAppWatcher - The application handle of this Watcher.
*		   hMsg        - The received NOTIFY request containing PIDF data
*		   hBuddyPidf  - The handle to the updated remote buddy PIDF data. 
*
* Return Value: None.
***************************************************************************/
void RVCALLCONV AppSimpleWatcherNewUpdatesEv(
					 IN  RvSimpleCltWatcherHandle      hWatcher,
					 IN  RvSimpleCltAppWatcherHandle   hAppWatcher,
					 IN  RvSipMsgHandle                hMsg,
					 IN  RvSimpleCltPidfHandle		   hBuddyPidf)
{
	RV_UNUSED_ARG(hMsg);
	RV_UNUSED_ARG(hAppWatcher);

    OSPrintf("===========================================================\n");
    OSPrintf(" watcher %p - new status information was received \n",hWatcher);
    AppExtractPidfInformation(hBuddyPidf);
    OSPrintf("\n===========================================================\n");
}

/***************************************************************************
 * AppExtractPidfInformation
 * ------------------------------------------------------------------------
 * General: Use the Pidf-XML API to observe presence information, and 
 *          print it.
 *          There may be several documents in a Pidf document.
 *          Each document contains several tuples for a specific Resource (URI) 
 *          and Package (presence).
 *          Each tuple object encapsulates the presence information of a 
 *          specific buddy.
 * Arguments:
 * Input:   hWinfoXML      - A Winfo-XML object containing all parsed watcher 
 *                             information received.
 * Return Value: none
 ***************************************************************************/
static void RVCALLCONV AppExtractPidfInformation(
					 IN  RvSimpleCltPidfHandle		   hBuddyPidf)
{
    RvStatus rv = RV_OK;
    RvSimpleCltPidfAttrs        pidfAttrs;
    RvSimpleCltPidfGetStrAttrs  getStrAttrs, getStrAttrs2;
    RvSimpleCltPidfTupleBasicStatus eTupleStatus;
    RvDouble					contactPriority;
#define TEMP_PIDF_STRING_LEN 30
    RvChar    tempString[TEMP_PIDF_STRING_LEN], tempString2[TEMP_PIDF_STRING_LEN];
    
    /* RvSimpleCltPidfAttrs structure contains the Pidf document and tuple handles. */
    memset(&pidfAttrs, 0, sizeof(pidfAttrs));
    pidfAttrs.hPidf = hBuddyPidf;
    
    /* loop 1 - goes over documents in the Pidf body */
    rv = RvSimpleCltPidfGetDoc(hBuddyPidf, RVSIP_FIRST_ELEMENT, NULL, &pidfAttrs.hPidfDoc);
    while (rv == RV_OK && NULL != pidfAttrs.hPidfDoc  &&  RV_ERROR_NOT_FOUND != rv)
    {
        /* loop 2 - goes over the tuples in the document */
        rv = RvSimpleCltPidfDocGetTuple(RVSIMPLECLT_LIST_FIRST_ELEMENT,NULL, &pidfAttrs);
        if (RV_OK != rv  &&  RV_ERROR_NOT_FOUND != rv)
        {
            break;
        }
    
        while (NULL != pidfAttrs.hTuple  &&  RV_ERROR_NOT_FOUND != rv)
        {
            /* extract information for a single buddy: */
            /* buddy status */
            rv = RvSimpleCltPidfDocGetBasicStatus(&pidfAttrs, &eTupleStatus);
            if (rv == RV_OK)
            {
                OSPrintf("           tuple status = %s", AppGetWatcherBasicStatusName(eTupleStatus)); 
            }

            /* buddy Extended Status */
            memset(&tempString, 0, sizeof(tempString));
            getStrAttrs.givenStrLen = TEMP_PIDF_STRING_LEN;
            getStrAttrs.strCopy = tempString;
            rv = RvSimpleCltPidfDocGetExStatus(&pidfAttrs, 0, &getStrAttrs);
            if (RV_OK == rv)
            {
                OSPrintf("\n           tuple extended status = %s",getStrAttrs.strCopy); 
            }

            /* buddy Contact and priority */
            memset(&tempString, 0, sizeof(tempString));
            getStrAttrs.givenStrLen = TEMP_PIDF_STRING_LEN;
            getStrAttrs.strCopy = tempString;
            rv = RvSimpleCltPidfDocGetContact(&pidfAttrs, &getStrAttrs, &contactPriority);
            if (RV_OK == rv)
            {
                OSPrintf("\n           pidf contact = %s priority = %f",getStrAttrs.strCopy, contactPriority); 
            }

            /* buddy Note and language */
            memset(&tempString, 0, sizeof(tempString));
            getStrAttrs.givenStrLen = TEMP_PIDF_STRING_LEN;
            getStrAttrs.strCopy = tempString;
            memset(&tempString2, 0, sizeof(tempString2));
            getStrAttrs2.givenStrLen = TEMP_PIDF_STRING_LEN;
            getStrAttrs2.strCopy = tempString2;
            rv = RvSimpleCltPidfDocGetNote(&pidfAttrs, 0, &getStrAttrs, &getStrAttrs2);
            if (RV_OK == rv)
            {
                OSPrintf("\n           pidf note = %s lang = %s",getStrAttrs.strCopy, getStrAttrs2.strCopy); 
            }
            
            /* Get next tuple in loop 2*/
            rv = RvSimpleCltPidfDocGetTuple(RVSIMPLECLT_LIST_NEXT_ELEMENT, pidfAttrs.hTuple, &pidfAttrs);
            if (RV_OK != rv  &&  RV_ERROR_NOT_FOUND != rv)
            {
                break;
            }
        }/* loop 2 - tuples in the document */

        /* Get next document in loop 1*/
        rv = RvSimpleCltPidfGetDoc(hBuddyPidf, RVSIP_NEXT_ELEMENT, pidfAttrs.hPidfDoc, &pidfAttrs.hPidfDoc);
    }/* loop 1 - documents in the Pidf XML. */
   
    if (RV_OK != rv  &&  RV_ERROR_NOT_FOUND != rv)
    {
        AppExitOnError("Failed to extract watcher buddy information");
    }
    
}

/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

/***************************************************************************
 * AppGetPubStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetWatcherStateName (
                          IN  RvSimpleCltWatcherState  eState)
{

    switch(eState)
    {
    case RVSIMPLECLT_WATCHER_STATE_IDLE:
		return "Idle";
	case RVSIMPLECLT_WATCHER_STATE_TERMINATED:
		return "Terminated";
	case RVSIMPLECLT_WATCHER_STATE_SUBSCRIBING:
		return "Subscribing";
	case RVSIMPLECLT_WATCHER_STATE_REDIRECTED:
		return "Redirected";
	case RVSIMPLECLT_WATCHER_STATE_UNAUTHENTICATED:
		return "Unauthenticated";
	case RVSIMPLECLT_WATCHER_STATE_REFRESHING:
		return "Refreshing";
	case RVSIMPLECLT_WATCHER_STATE_UNSUBSCRIBING:
		return "Unsubscribing";
	case RVSIMPLECLT_WATCHER_STATE_PENDING:
		return "Pending";
	case RVSIMPLECLT_WATCHER_STATE_ACTIVE:
		return "Active";
	case RVSIMPLECLT_WATCHER_STATE_MSG_SEND_FAILURE:
		return "Msg Sent Failure";
    case RVSIMPLECLT_WATCHER_STATE_UNDEFINED:
	default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppGetWatcherBasicStatusName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given status
 * Return Value: The string with the status name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eStatus - The status as enum
 ***************************************************************************/
static const RvChar*  AppGetWatcherBasicStatusName (
                          IN  RvSimpleCltPidfTupleBasicStatus  eStatus)
{

    switch(eStatus)
    {
    case RVSIMPLECLT_PIDF_TUPLE_BASIC_STATUS_OPEN:
		return "Open";
	case RVSIMPLECLT_PIDF_TUPLE_BASIC_STATUS_CLOSED:
		return "Closed";
    case RVSIMPLECLT_PIDF_TUPLE_BASIC_STATUS_UNDEFINED:
	default:
        return "Undefined";
    }
}

// #endif /* RV_MTF_SIMPLE_ON */

