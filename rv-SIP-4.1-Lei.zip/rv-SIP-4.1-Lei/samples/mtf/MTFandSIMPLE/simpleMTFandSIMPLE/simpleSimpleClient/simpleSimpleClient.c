/*********************************************************************************
 *                              <simpleSimpleClient.c>
 *   This file gives a complete example of how to:
 *   (1) Initiate the RADVISION SIMPLE Client add-on (also referred as PUA=Presence
 *       User Agent) above the SIP stack.
 *       (File: simpleSimpleClient.c)
 *   (2) Initiate an outgoing Presentitiy object (event:presence.winfo).
 *       (File: simplePresentityClient.c)
 *   (3) Initiate an outgoing Watcher object (event:presence).
 *       (File: simpleWatcherClient.c)
 *   (4) Publish the client status using a Publisher object.
 *       (File: simplePublisherClient.c)
 *
 *
 *   ==============================================================================
 *   The sample should be run against the demo SIMPLE server, running on the same
 *   machine. In order to use remote machine you should change the PUBLISH_RESOURCE_URI
 *   address defined bellow.
 *   Notice that the application exits on errors.
 *
 * ------------------------------------------------------------------
 * Note: In order to run this sample under windows you must first
 *       Compile the stack, the SIMPLE client add-on and the event-dispatcher from
 *       the rvsip.dsw workspace with the following configurations:
 *       - Win32 Debug configuration for Debug execution
 *       - Win32 Release configuration for Release execution.
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                 Feb 2007
 *********************************************************************************/
// #ifdef RV_MTF_SIMPLE_ON

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "simpleSimpleClient.h"
#include <stdio.h>
#include <stdarg.h>
#include "RvSipMid.h"
#include "rvMtfHandles.h"
#include "rvMtfBaseApi.h"

#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif


#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
#include <vxWorks.h>
#include <taskLib.h>
#include <time.h>
#endif
#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif


/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static int mainFunc(void);
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
static void mainFuncForSymbian(void);
#endif

void AppSimpleClientInitialize(RvMtfHandle			g_hMtf);

void AppSetCallBackFunctions(void);

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the stack manager. This parameter is provided by MTF. You should supply this handle when using the stack
  manager API functions.*/
extern RvSipStackHandle	g_hSipStack;

/*Handle to the log-module. You can get this handle by calling
  RvSipStackGetLogHandle(). You need this value in order to construct the
  application memory pool.*/
static RV_LOG_Handle               g_hLog        = NULL;
/*Handle to the application memory pool. The application should construct
  its own memory using rpool API. The pool is needed for encoding messages
  or message parts. (See AppPrintMessage() )*/
static HRPOOL                      g_appPool     = NULL;

/*Handle to the pua (Presence User Agent) manager. This parameter is returned
  when calling RvSimpleCltPuaConstruct().
  You should supply this handle when using the pua manager API functions.*/
static RvSimpleCltPuaHandle        g_hPuaMgr     = NULL;

/*Handle to the presentity manager. This parameter is returned
  when calling RvSimpleCltPuaGetPresMgrHandle(). You should supply
  this handle when using the presentity manager API functions.*/
RvSimpleCltPresMgrHandle    g_hPresMgr    = NULL;
/*Handle to the publisher manager. This parameter is returned
  when calling RvSimpleCltPuaGetPublisherMgrHandle(). You should supply
  this handle when using the publisher manager API functions.*/
RvSimpleCltPubMgrHandle     g_hPublishMgr = NULL;
/*Handle to the watcher manager. This parameter is returned
  when calling RvSimpleCltPuaGetWatcherMgrHandle(). You should supply
  this handle when using the watcher manager API functions.*/
RvSimpleCltWatcherMgrHandle g_hWatcherMgr = NULL;

/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * main
 * ------------------------------------------------------------------------
 * General: In the main function we perform the following:
 *          1. Initialize the RADVISION SIMPLE client add-on above the SIP stack.
 *          2. Set the callback functions in the pua managers.
 *          3. Create a presentity subscription.
 *          4. Activates the RvSipStackProcessEvents() function that
 *             command the stack to process the event queue.
 ***************************************************************************/
#if 0
static int mainFunc(void)
{
    OSPrintf("Executing simpleSimpleClient\n");
    /*1. Initialize the RADVISION SIMPLE client add-on above the SIP stack.*/
    AppSimpleClientInitialize();
    /*2. Set the callback functions in the pua managers.*/
    AppSetCallBackFunctions();
    /*3. Create a presentity subscription.*/
    AppCreatePresentity();
    /*4. Activates the RvSipStackProcessEvents() function that
         commands the stack to process the event queue.*/
    RvSipStackProcessEvents();
    return 0;
}
#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) /* embedded start function */
int mainForEmbedded()
{
    mainFunc();
    return 0;
}
#elif (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) /* vxworks start function */
void startVx()
{
    taskSpawn("mainFunc", 100, 0, 0x30000, (FUNCPTR)mainFunc, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_PSOS) /* pSOS start function */
/* pSOS Shell entry point */
#include <psos.h>
#include <prepc.h>
void mainForEmbedded(int argc, char **argv, char **env, void *exit_param, const char *console_dev)
{
    mainFunc();
    psh_exit(exit_param);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_WINCE) /* WinCE start function */
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPWSTR lpCmdLine,
                   int nCmdShow)
{
    OSSetMainFuncCB(mainFunc);
    OSWinCEMain(hInstance,hPrevInstance,lpCmdLine,nCmdShow);
}
#else /* not embedded start function */
int main()
{
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    mainFuncForSymbian();
    return 0;
#else
    return mainFunc();
#endif
}
#endif

#endif /* if 0 */

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
/***************************************************************************
 * mainFuncForSymbian
 * ------------------------------------------------------------------------
 * General: Called from main(). creates heap and initiates thread. Starts
 *          the SIP sample.
 ***************************************************************************/
static void mainFuncForSymbian(void)
{
   /* Symbian stack and heap should be enlarged so we are */
    /* Construction SIP on new thread                      */
    SymbianCreateThread((void *)mainFunc);
    while(1)
    {
      SymbianSleep(1000);
    }
}
#endif


/***************************************************************************
 * AppSimpleClientInitialize
 * ------------------------------------------------------------------------
 * General: Initializing the pua and the stack and allocating the application memory pool.
 *          The initialization is done in several steps:
 *          (1) set the stack configuration struct to the default values.
 *          (2) set the pua configuration struct to the default values.
 *          (3) update the stack configuration struct with the pua needs.
 *          (4) change some of the configuration parameters.
 *          We then initialize the modules:
 *          (a) initialize the SIP Stack using RvSipStackConstruct()
 *          (b) initialize the SIMPLE add-on using RvSimpleCltPuaConstruct()
 *          (c) initialize the event dispatcher using RvEvDispatcherConstruct()
 *              (The event dispatcher is an external component, that is registered
 *               on the SIP stack callbacks, and on the callbacks calling, activate
 *               the suitable functions in the SIMPLE client add-on.
 *               The event dispatcher can be replaced with any other application
 *               dispatching implementation).
 ***************************************************************************/
void AppSimpleClientInitialize(RvMtfHandle			hMtf)
{
    RvStatus rv;
    RvSipStackCfg stackCfg;
	RvSimpleCltPuaCfg puaCfg;

//    RvSipMidInit();

    /*Initialize the SIP stack configuration structure with default values*/
//    RvSipStackInitCfg(sizeof(stackCfg),&stackCfg);
	/*Initialize the SIMPLE add-on configuration structure with default values*/
    RvSimpleCltPuaInitCfg(sizeof(puaCfg),&puaCfg);
	/*Update the SIP stack configuration structure with the SIMPLE add-on needs */
	RvSimpleCltPuaIncreaseSipCfg(sizeof(puaCfg),&puaCfg,sizeof(stackCfg),&stackCfg);

    /*change some of the default values*/
//     stackCfg.tcpEnabled = RV_TRUE;
// #if (RV_NET_TYPE & RV_NET_SCTP)
//     /* setting one SCTP address*/
//     stackCfg.numOfSctpAddresses = 1;
//     stackCfg.localSctpAddresses = RvSipMidMemAlloc(stackCfg.numOfSctpAddresses * sizeof(RvChar*));
//     memset(stackCfg.localSctpAddresses, 0, stackCfg.numOfSctpAddresses * sizeof(RvChar*));
//     stackCfg.localSctpPorts = RvSipMidMemAlloc(stackCfg.numOfSctpAddresses * sizeof(RvUint16));
//     memset(stackCfg.localSctpPorts, 0, stackCfg.numOfSctpAddresses * sizeof(RvUint16));
//     stackCfg.localSctpAddresses[0] ="127.0.0.1";
//     stackCfg.localSctpPorts[0] = 5066;
// #endif /* #if (RV_NET_TYPE & RV_NET_SCTP) */
//
// #if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) || (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || \
//     (RV_OS_TYPE == RV_OS_TYPE_PSOS) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
//     /* Disable most of log */
//     stackCfg.defaultLogFilters = RVSIP_LOG_ERROR_FILTER|RVSIP_LOG_EXCEP_FILTER;
// 	puaCfg.defaultLogFilters = RVSIP_LOG_ERROR_FILTER|RVSIP_LOG_EXCEP_FILTER;
// #endif


    /*Call the SIP stack initialization function*/
//     rv = RvSipStackConstruct(sizeof(stackCfg),&stackCfg,&g_hStackMgr);
//     if(rv != RV_OK)
//     {
//         AppExitOnError("Application failed to construct the stack\n");
//     }

	/*Call the SIMPLE add-on initialization function*/
	rv = RvSimpleCltPuaConstruct(g_hSipStack, sizeof(puaCfg),&puaCfg, &g_hPuaMgr);
	if(rv != RV_OK)
    {
        AppExitOnError("Application failed to construct the SIMPLE add-on\n");
    }


	/* Set the handle to PUA in MTF so it can be retrieved by MTF and passed to application
	   when SIP stack callbacks are called */
#ifdef RV_MTF_SIMPLE_ON
	rvMtfSetSimpleClientHandle(hMtf, g_hPuaMgr);
#else
		RV_UNUSED_ARG(hMtf);
#endif


	/*Call the event-dispatcher initialization function
	(the event dispatcher passes all callbacks from the SIP stack to the SIMPLE add-on)*/
// 	rv = RvEvDispatcherActivate(g_hStackMgr, g_hPuaMgr);
// 	if (RV_OK != rv)
//     {
//         AppExitOnError( "Application failed to construct the event dispatcher\n");
//     }

    /*getting handles for the internal modules*/
//	RvSipStackGetLogHandle(g_hStackMgr,&g_hLog);

	RvSimpleCltPuaGetPresMgrHandle(g_hPuaMgr, &g_hPresMgr);
	RvSimpleCltPuaGetPublisherMgrHandle(g_hPuaMgr, &g_hPublishMgr);
	RvSimpleCltPuaGetWatcherMgrHandle(g_hPuaMgr, &g_hWatcherMgr);


    OSPrintf("The RADVISION SIMPLE add-on was constructed successfully. Version %s (SIP version %s)\n",
               RvSimpleCltPuaGetVersion(), RvSipStackGetVersion());
    OSPrintf("===========================================================\n\n");


    /*Construct a pool of memory for the application*/
    g_appPool = RPOOL_Construct(1024,10,g_hLog,RV_FALSE,"ApplicationPool");

//    RvSipMidEnd();
}

/***************************************************************************
 * AppSetCallBackFunctions
 * ------------------------------------------------------------------------
 * General: Set application callback functions in the SIMPLE client add-on.
 ***************************************************************************/
void AppSetCallBackFunctions(void)
{
    RvStatus rv;
    RvSimpleCltPubEvHandlers appPublisherEvHandlers;
	RvSimpleCltWatcherEvHandlers appWatcherEvHandlers;
	RvSimpleCltPresEvHandlers appPresEvHandlers;

    /*Reset the appPublisherEvHandlers since not all callbacks are set by this sample*/
    memset(&appPublisherEvHandlers,0,sizeof(appPublisherEvHandlers));

    /*Set application publisher callbacks in the structure*/
    appPublisherEvHandlers.pfnMsgRcvdEvHandler     = AppSimplePublisherMsgRcvdEv;
    appPublisherEvHandlers.pfnMsgToSendEvHandler   = AppSimplePublisherMsgToSendEv;
    appPublisherEvHandlers.pfnStateChangedEvHandler= AppSimplePublisherStateChangedEv;
    appPublisherEvHandlers.pfnTimerExpiredEvHandler= AppSimplePublisherTimerExpiredEv;

    /*Set the structure in the publisher manager*/
    rv = RvSimpleCltPubMgrSetEvHandlers(g_hPublishMgr,
                                      &appPublisherEvHandlers,
                                      sizeof(appPublisherEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application publisher callbacks");
    }

	/*Reset the appWatcherEvHandlers since not all callbacks are set by this sample*/
    memset(&appWatcherEvHandlers,0,sizeof(appWatcherEvHandlers));

    /*Set application watcher callbacks in the structure*/
    appWatcherEvHandlers.pfnMsgRcvdEvHandler         = AppSimpleWatcherMsgRcvdEv;
    appWatcherEvHandlers.pfnMsgToSendEvHandler       = AppSimpleWatcherMsgToSendEv;
    appWatcherEvHandlers.pfnStateChangedEvHandler    = AppSimpleWatcherStateChangedEv;
    appWatcherEvHandlers.pfnNewUpdatesEvHandler      = AppSimpleWatcherNewUpdatesEv;

    /*Set the structure in the watcher manager*/
    rv = RvSimpleCltWatcherMgrSetEvHandlers(g_hWatcherMgr,
                                      &appWatcherEvHandlers,
                                      sizeof(appWatcherEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application watcher callbacks");
    }


	/*Reset the appPresEvHandlers since not all callbacks are set by this sample*/
    memset(&appPresEvHandlers,0,sizeof(appPresEvHandlers));

    /*Set application presentity callbacks in the structure*/
    appPresEvHandlers.pfnSubsMsgRcvdEvHandler        = AppSimplePresSubsMsgRcvdEv;
    appPresEvHandlers.pfnSubsMsgToSendEvHandler      = AppSimplePresSubsMsgToSendEv;
    appPresEvHandlers.pfnStateChangedEvHandler       = AppSimplePresStateChangedEv;
	appPresEvHandlers.pfnSubsStateChangedEvHandler   = AppSimplePresSubsStateChangedEv;
    appPresEvHandlers.pfnSubsWatcherNewUpdatesEvHandler = AppSimplePresWatcherNewUpdatesEv;

    /*Set the structure in the presentity manager*/
    rv = RvSimpleCltPresMgrSetEvHandlers(g_hPresMgr,
                                      &appPresEvHandlers,
                                      sizeof(appPresEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application presentity callbacks");
    }
}



/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
void AppPrintMessage(IN RvSipMsgHandle hMsg)
{
    RvStatus   rv;
    HPAGE       hPage;
    RvChar     *msgBuf;
    RvUint32   msgSize;

    /* getting the encoded message on an rpool page.*/
    rv = RvSipMsgEncode(hMsg, g_appPool, &hPage, &msgSize);
    if (rv != RV_OK)
    {
        OSPrintf("Message encoding failed");
        exit(1);
    }
    /*allocate a consecutive buffer - use UTILS since malloc doesn't work on all OS's */
    msgBuf = (RvChar *)RvSipMidMemAlloc(msgSize+1);

    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appPool,
                              hPage,
                              0,
                              (void*)msgBuf,
                              msgSize);
    /*terminate the buffer with null*/
    msgBuf[msgSize]   = '\0';
    if(rv != RV_OK)
    {
        OSPrintf("Message encoding failed");
        /*free the page the encode function allocated*/
        RPOOL_FreePage(g_appPool, hPage);
        RvSipMidMemFree(msgBuf);
        exit(1);
    }
    OSPrintf("%s \n",msgBuf);
    /*free the page the encode function allocated*/
    RPOOL_FreePage(g_appPool, hPage);
    RvSipMidMemFree(msgBuf);
}


/***************************************************************************
 * AppExitOnError
 * ------------------------------------------------------------------------
 * General: prints an error message and exits.
  ***************************************************************************/
void AppExitOnError(RvChar* str)
{
    OSPrintf("%s\n",str);
    exit(1);
}

/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Implementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameters according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
int OSPrintf(IN const char *format,... )
{
    int      charsNo;
    va_list  ap;

#if (RV_OS_TYPE == RV_OS_TYPE_WINCE)
    RvChar  cbuf[MAX_PRINT_LEN];

    /*************************************
     Print message to the buffer first
    **************************************/
    va_start(ap,format);
    charsNo = vsprintf (cbuf, format, ap);
    va_end(ap);

    /************************************************
     Using default output window for printing
    *************************************************/
    charsNo = OSWinCEPrintf(NULL,0,cbuf);
#else
    va_start(ap,format);
    charsNo = vprintf(format,ap);
    va_end(ap);

#endif

    return charsNo;
}


// #endif /* RV_MTF_SIMPLE_ON */



