

/*********************************************************************************
 *                              <simplePublisherClient.c>
 *   This file implements the publisher part in the simpleSimpleClient sample.
 *   The publisher object publishes its presence information.
 *   The publisher actions done in this sample:
 *   1) Initiate the publisher object.
 *   2) Handles the publisher event handlers.
 *   3) Build a Pidf document with the current resource status, and send it in a 
 *      PUBLISH request to the server.
 *   4) In this sample, when the publisher timer expires, change the status to 
 *      Closed, and send a PUBLISH request to the server.
 *********************************************************************************/

// #ifdef RV_MTF_SIMPLE_ON

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "simpleSimpleClient.h"
/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
extern RvSimpleCltPubMgrHandle     g_hPublishMgr;
/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static const RvChar*  AppGetPubStateName (IN  RvSimpleCltPubState  eState);

static void AppSetPublisherStatus(RvSimpleCltPubHandle            hPublisher,
                                  RvSimpleCltPidfTupleBasicStatus eStatus,
                                  RvChar*                         strNote);

/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * AppCreatePublisher
 * ------------------------------------------------------------------------
 * General: Creates a publisher object, and send PUBLISH.
 *          To publish the client status the application should:
 *          1. Create a new publisher using RvSimpleCltPubMgrCreatePublisher().
 *			2. Initialize the publisher object using RvSimpleCltPubSetInitParams().
 *          3. Set the body describing it's status to the publisher outbound message.
 *          4. Call RvSimpleCltPubPublish(). This will cause the PUBLISH message
 *             to be sent to the destination.
 ***************************************************************************/
void AppCreatePublisher(void)
{
	RvStatus              rv          = RV_OK;
    RvSimpleCltPubHandle hPublisher = NULL;
    RvSimpleCltCommonObjParamStrs initParams;
    RvSimpleCltCommonExpires expiresParam;

	/*--------------------------
      1. Create a new publisher
    ----------------------------*/
    OSPrintf("===========================================================\n");
    OSPrintf("Creating a new publisher for resource %s\n",PUBLISH_RESOURCE_URI);
    OSPrintf("===========================================================\n");
	
	rv = RvSimpleCltPubMgrCreatePublisher(
                g_hPublishMgr, (RvSimpleCltAppPubHandle )NULL, &hPublisher);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create new publisher");
    }

	/*---------------------------------------------
      2. Initialize the new publisher
    -----------------------------------------------*/
	memset((void*)&initParams, 0, sizeof(initParams));
	initParams.strFrom   = PUBLISH_FROM_URI;
	initParams.strReqUri = PUBLISH_RESOURCE_URI;
	initParams.strTo     = PUBLISH_RESOURCE_URI;
	rv = RvSimpleCltPubSetParamStrs(hPublisher, &initParams, sizeof(initParams));
	if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to initialise the new publisher");
    }
    /*--------------------------------
      Initialize the expires parameter
    ----------------------------------*/
	memset((void*)&expiresParam, 0, sizeof(expiresParam));
	expiresParam.bResides = RV_TRUE;
	expiresParam.value    = PUB_EXPIRES;
    RvSimpleCltPubSetExpiresVal(hPublisher,&expiresParam, sizeof(expiresParam));

    OSPrintf("\nPublisher %p was created\n",hPublisher);
    
    /*----------------------------------------------
      3. Build publisher Pidf status and set it to 
         the publisher outbound message body
    ------------------------------------------------*/
    AppSetPublisherStatus(hPublisher, RVSIMPLECLT_PIDF_TUPLE_BASIC_STATUS_OPEN, 
                          "I am back in my office");

	/*------------------------------------------------------------------------
      Call the publish function in order to publish the client status.
    --------------------------------------------------------------------------*/
    OSPrintf("\nPublishing from publisher: \n\t%s -> %s\n\n",PUBLISH_FROM_URI,PUBLISH_RESOURCE_URI);
	rv = RvSimpleCltPubPublish(hPublisher, RVSIMPLECLT_PUBLISHER_OPERATION_INITIAL);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to subscribe for publisher");
    }
}


/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/

/***************************************************************************
 * AppSimplePublisherStateChangedEv
 * ------------------------------------------------------------------------
 * General: Client handling of the PublisherStateChangedEvHandler.
 *          Here we only print the new state.
 * 
 * Arguments:
 * Input:   hPub      - A handle to SIMPLE client Publisher.
 *          hAppPub   - The application handle for this Publisher object.
 *          eNewState - The new state of the Publisher object.
 *          eReason   - The reason for the change in state.
 * Output:  pbDefBehavior - Indication if Publisher default behavior should
 *							take place (as defined above). 
 * Return Value: None.
 ***************************************************************************/
void RVCALLCONV AppSimplePublisherStateChangedEv(
                            IN  RvSimpleCltPubHandle            hPub,
                            IN  RvSimpleCltAppPubHandle         hAppPub,
                            IN  RvSimpleCltPubState				eNewState,
                            IN  RvSimpleCltPubStateReason		eReason,
							OUT RvBool                         *pbDefBehavior)
{
	/*print the new state on screen*/
    OSPrintf("\n publisher %p - State changed to %s\n\n",
             hPub, AppGetPubStateName(eNewState));

    if(eNewState == RVSIMPLECLT_PUBLISHER_STATE_PUBLISHED)
    {
        /* end of first messages cycle in this sample */
        OSPrintf("\n***************************************************************\n");
    }

	*pbDefBehavior = RV_TRUE;
    RV_UNUSED_ARG(hAppPub);
    RV_UNUSED_ARG(eReason);

}

/***************************************************************************
 * AppSimplePublisherTimerExpiredEv
 * ------------------------------------------------------------------------
 * General: Client handling of the PublisherTimerExpiresEvHandler.
 *          Here we refresh the publish client automatically.
 * 
 * Arguments:
 * Input:   hPub         - A handle to SIMPLE client Publisher.
 *          hAppPub      - The application handle for this Publisher object.
 *          eTimerType   - The type of the expired timer. 
 * Output:  pbHandleAuto - Indication 
 *
 * Return Value: None.
 ***************************************************************************/
void RVCALLCONV AppSimplePublisherTimerExpiredEv(
							IN  RvSimpleCltPubHandle         hPub,
							IN  RvSimpleCltAppPubHandle      hAppPub,
							OUT RvBool						*pbHandleAuto)
{
	OSPrintf("Publisher timer expired. change status to closed\n\n");
	
    /*----------------------------------------------
      Build a new Pidf close status and set it to 
      the publisher outbound message body
    ------------------------------------------------*/
    AppSetPublisherStatus(hPub, RVSIMPLECLT_PIDF_TUPLE_BASIC_STATUS_CLOSED, 
                          "time to go home");
    *pbHandleAuto = RV_TRUE;
	RV_UNUSED_ARG(hAppPub || hPub)
}
	

/***************************************************************************
* AppSimplePublisherMsgRcvdEv
* ------------------------------------------------------------------------
* General: Application implementation to the message received event handler.
*          Here we only print the message that was received.
*
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:   hPub          - A handle to SIMPLE client Publisher.
*          hAppPub       - The application handle for this Publisher object.
*		   hReceivedMsg  - The message that was received.
* Output:  None
***************************************************************************/
RvStatus RVCALLCONV AppSimplePublisherMsgRcvdEv(
					  IN  RvSimpleCltPubHandle         hPub,
					  IN  RvSimpleCltAppPubHandle      hAppPub,
					  IN  RvSipMsgHandle			   hReceivedMsg)
{
	
    OSPrintf("<-- Message Received (publisher %p)\n",hPub);
    AppPrintMessage(hReceivedMsg);
    RV_UNUSED_ARG(hAppPub);

    return RV_OK;
}

/***************************************************************************
* AppSimplePublisherMsgToSendEv
* ------------------------------------------------------------------------
* General: Application implementation to the message to send event handler.
*          Here we only print the message that is about to be sent.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:   hPub        - A handle to SIMPLE client Publisher.
*          hAppPub     - The application handle for this Publisher object.
*		   hMsgToSend  - The message that was received.
* Output:  None
***************************************************************************/
RvStatus RVCALLCONV AppSimplePublisherMsgToSendEv(
					  IN  RvSimpleCltPubHandle         hPub,
					  IN  RvSimpleCltAppPubHandle      hAppPub,
					  IN  RvSipMsgHandle			   hMsgToSend)
{
	OSPrintf("--> Message Sent (publisher %p)\n",hPub);
    AppPrintMessage(hMsgToSend);
    RV_UNUSED_ARG(hAppPub);
    
    
    return RV_OK;
}


/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

/***************************************************************************
 * AppSetPublisherStatus
 * ------------------------------------------------------------------------
 * General: Use the Pidf-XML API to create presence information, and 
 *          then push it to the publisher outbound message.
 *          Here we build a Pidf containing one document with one tuple.
 * Arguments:
 * Input:   hPublisher - The publisher object that publishes the new  
 *                       status information.
 *          eStatus    - the status of the client.
 *          strNote    - Note to set with the status.
 * Return Value: none
 ***************************************************************************/
static void AppSetPublisherStatus(RvSimpleCltPubHandle            hPublisher,
                                  RvSimpleCltPidfTupleBasicStatus eStatus,
                                  RvChar*                         strNote)
{
    RvStatus rv;
    RvSipMsgHandle hMsg;
    RvSimpleCltPidfAttrs pidfAttr;
    RvSimpleCltPidfSetAttrs pidfSetAttr;
    RvSipBodyHandle hBody;
    
    /* ----------------------------------------------------------- 
      1. Build the Pidf document and fill it with the client status 
       -----------------------------------------------------------*/
    rv = RvSimpleCltPubGetPidfHandle(hPublisher, &pidfAttr.hPidf);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to get a PIDF from publisher");
    }

    rv = RvSimpleCltPidfCreateDoc(pidfAttr.hPidf, &pidfAttr.hPidfDoc);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to create PIDF doc");
    }

    rv = RvSimpleCltPidfDocCreateTuple("sg89ae", &pidfAttr);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to set create PIDF tuple");
    }

    pidfSetAttr.bOverride = RV_FALSE;
    pidfSetAttr.index = 0;
    rv = RvSimpleCltPidfDocSetBasicStatus(&pidfAttr, eStatus, &pidfSetAttr);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to set PIDF basic status");
    }
    
    rv = RvSimpleCltPidfDocSetExStatus(&pidfAttr, strNote, &pidfSetAttr);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to set PIDF extended status");
    }

    rv = RvSimpleCltPidfDocSetContact(&pidfAttr, "Joe@office.com", 0.8, &pidfSetAttr);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to set PIDF contact ");
    }

    /* ----------------------------------------------------------- 
      2. Insert the PIDF body to the SIP message 
       -----------------------------------------------------------*/
    rv = RvSimpleCltPubGetOutboundMsg(hPublisher, &hMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to get outbound message from publisher");
    }
    rv = RvSipBodyConstructInMsg(hMsg, &hBody);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to set PIDF body to the publisher outbound message ");
    }

    rv = RvSimpleCltPidfDocEncode(&pidfAttr, hBody);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to set PIDF body to the publisher outbound message ");
    }    
    
}

/***************************************************************************
 * AppGetPubStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetPubStateName (
                          IN  RvSimpleCltPubState  eState)
{

    switch(eState)
    {
    case RVSIMPLECLT_PUBLISHER_STATE_IDLE:
		return "Idle";
	case RVSIMPLECLT_PUBLISHER_STATE_TERMINATED:
		return "Terminated";
	case RVSIMPLECLT_PUBLISHER_STATE_PUBLISHING:
		return "Publishing";
	case RVSIMPLECLT_PUBLISHER_STATE_REDIRECTED:
		return "Redirected";
	case RVSIMPLECLT_PUBLISHER_STATE_UNAUTHENTICATED:
		return "Unauthenticated";
	case RVSIMPLECLT_PUBLISHER_STATE_PUBLISHED:
		return "Published";
	case RVSIMPLECLT_PUBLISHER_STATE_REMOVING:
		return "Removing";
	case RVSIMPLECLT_PUBLISHER_STATE_REMOVED:
		return "Removed";
	case RVSIMPLECLT_PUBLISHER_STATE_FAILED:
		return "Failed";
	case RVSIMPLECLT_PUBLISHER_STATE_WAIT_FOR_RETRY_AFTER:
		return "Wait For Retry-After";
	case RVSIMPLECLT_PUBLISHER_STATE_MSG_SENT_FAILURE:
		return "Msg Sent Failure";
    case RVSIMPLECLT_PUBLISHER_STATE_UNDEFINED:
	default:
        return "Undefined";
    }
}

// #endif /*  RV_MTF_SIMPLE_ON */


