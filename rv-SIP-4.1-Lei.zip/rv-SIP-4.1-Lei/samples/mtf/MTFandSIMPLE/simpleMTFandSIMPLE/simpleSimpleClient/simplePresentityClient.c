

/*********************************************************************************
 *                              <simplePresentityClient.c>
 *   This file implements the presentity part in the simpleSimpleClient sample.
 *   The Presentity object subscribes to watcher information, and handles
 *   watcher info notifications from the server.
 *   The presentity actions done in this sample:
 *   1) Initiate the presentity object.
 *   2) Handles the presentity event handlers.
 *   3) When receiving Notification of a new watcher, extracts its parameters
 *      from the NOTIFY request, and display it on screen.
 *   After the presentity has an active watcher, publish the initial state
 *      of the client.
 *********************************************************************************/

// #ifdef RV_MTF_SIMPLE_ON

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "simpleSimpleClient.h"
/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
extern RvSimpleCltPresMgrHandle    g_hPresMgr;
/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static void RVCALLCONV AppExtractWatcherInformation(
                           IN  RvSimpleCltWinfoXMLHandle        hWinfoXML);
static const RvChar*  AppGetPresStateName (IN  RvSimpleCltPresState  eState);
static const RvChar*  AppGetSubsStateName (IN  RvSipSubsState  eState);
// static const RvChar*  AppGetWinfoXMLStateName(IN RvSimpleCltWinfoXMLState eXmlState);
static const RvChar*  AppGetWinfoXMLWatcherStatusName(
                       IN RvSimpleCltWinfoXMLWatcherStatus eXmlWatcherStatus);
/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppCreatePresentity
 * ------------------------------------------------------------------------
 * General: Creates a presentity object, and subscribe it.
 *          To subscribe a presentity the application should:
 *          1. create a new presentity using RvSimpleCltPresMgrCreatePresentity().
 *			2. initialize the presentity object using RvSimpleCltPresSetInitParams().
 *          3. call RvSimpleCltPresSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 ***************************************************************************/
void AppCreatePresentity(void)
{
	RvStatus              rv          = RV_OK;
    RvSimpleCltPresHandle hPresentity = NULL;
    RvSimpleCltCommonObjParamStrs initParams;
	RvSimpleCltCommonExpires expiresParam;
	
	/*--------------------------
      1. Create a new presentity
    ----------------------------*/
    OSPrintf("===========================================================\n");
    OSPrintf("Creating a new presentity for resource %s\n",PUBLISH_RESOURCE_URI);
    OSPrintf("===========================================================\n");

	rv = RvSimpleCltPresMgrCreatePresentity(
                g_hPresMgr, (RvSimpleCltAppPresHandle)NULL, &hPresentity);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create new presentity");
    }

	
	/*-----------------------------
      2. Initialize the new presentity
    -------------------------------*/
	memset((void*)&initParams, 0, sizeof(initParams));
	initParams.strFrom   = PUBLISH_FROM_URI;
	initParams.strReqUri = PUBLISH_RESOURCE_URI;
	initParams.strTo     = PUBLISH_RESOURCE_URI;
	rv = RvSimpleCltPresSetParamStrs(hPresentity, &initParams, sizeof(initParams));
	if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to initialise the new presentity");
    }

    OSPrintf("\nPresentity %p was created\n",hPresentity);
    
	/*--------------------------------
      Initialize the expires parameter
    ----------------------------------*/
	memset((void*)&expiresParam, 0, sizeof(expiresParam));
	expiresParam.bResides = RV_TRUE;
	expiresParam.value = SUBS_EXPIRES;

	OSPrintf("\nSubscribing from presentity: \n\t%s -> %s\n\n",PUBLISH_FROM_URI, PUBLISH_RESOURCE_URI);
	/*------------------------------------------------------------------------
      3. Call the subscribe function in order to establish the winfo subscription.
    --------------------------------------------------------------------------*/
    rv = RvSimpleCltPresSubscribe(hPresentity, NULL, &expiresParam, sizeof(expiresParam));
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to subscribe for presentity");
    }
}


/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/

/***************************************************************************
 * AppSimplePresStateChangedEv
 * ------------------------------------------------------------------------
 * General: Client handling of the PresentityStateChangedEvHandler.
 *          Here we only print the new state.
 *
 * Arguments:
 * Input:   hPres	   - The Presentity object whose state has changed
 *          hAppPres   - The application Presentity object
 *          eState     - The new Presentity state
 *          eReason    - The reason for the change in state
 *
 * Return Value: none
 ***************************************************************************/
void RVCALLCONV AppSimplePresStateChangedEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSimpleCltPresState             eState,
						   IN  RvSimpleCltPresStateChangeReason eReason)
{
    /*print the new state on screen*/
    OSPrintf("\n presentity %p - State changed to %s\n\n",
             hPres, AppGetPresStateName(eState));

	RV_UNUSED_ARG(hAppPres);
    RV_UNUSED_ARG(eReason);
}


/***************************************************************************
 * AppSimplePresSubsMsgRcvdEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Arguments:
 * Input:   hPres		- The Presentity object 
 *          hAppPres	- The application Presentity object
 *          hSubs       - The subscription receiving a message
 *          hMsg        - The received message
 * Return Value: none
 ***************************************************************************/
RvStatus RVCALLCONV AppSimplePresSubsMsgRcvdEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipMsgHandle                   hMsg)
{
	OSPrintf("<-- Message Received (presentity %p)\n",hPres);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppPres || hSubs);
    
    return RV_OK;
}

/***************************************************************************
 * AppSimplePresSubsMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 *
 * Arguments:
 * Input:   hPres		- The Presentity object 
 *          hAppPres	- The application Presentity object
 *          hSubs       - The subscription sending a message
 *          hMsg        - The message about to be sent
 * Return Value: none
 ***************************************************************************/
RvStatus RVCALLCONV AppSimplePresSubsMsgToSendEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipMsgHandle                   hMsg)
{
	OSPrintf("--> Message Sent (presentity %p)\n",hPres);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppPres || hSubs);
    
    return RV_OK;
}

/***************************************************************************
 * AppSimplePresSubsStateChangedEv
 * ------------------------------------------------------------------------
 * General: Application handling of the PresentitySubsStateChangedEvHandler.
 *          Here we print the new state.
 *          When the state is active, we initiate a watcher object.
 *
 * Arguments:
 * Input:   hPres			  - The Presentity object 
 *          hAppPres		  - The application Presentity object
 *          hSubs             - The subscription that changed its state
 *          eState            - The new subscription state
 *          eReason           - The reason for the change in state
 * Output:	pbDefaultBehavior - Indication whether the Presentity object should
 *                              apply the default behavior defined for this state. 
 *
 * Return Value: none
 ***************************************************************************/
void RVCALLCONV AppSimplePresSubsStateChangedEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipSubsState                   eState,
						   IN  RvSipSubsStateChangeReason       eReason,
                           OUT RvBool                          *pbDefaultBehavior)
{

	static RvBool bFirstActiveState = RV_TRUE;

	RV_UNUSED_ARG(hSubs);
	RV_UNUSED_ARG(pbDefaultBehavior);

	/*print the new state on screen*/
    OSPrintf("\n presentity %p - Subs state changed to %s\n\n",
             hPres, AppGetSubsStateName(eState));

    switch(eState)
    {
    case RVSIP_SUBS_STATE_ACTIVE:
        /* in case of ACTIVE after refreshing, we don't want to create another watcher */
        if(bFirstActiveState == RV_TRUE)
        {
            AppCreateWatcher();
            bFirstActiveState = RV_FALSE;
        }
    default:
        break;
    }
	RV_UNUSED_ARG(hAppPres);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppSimplePresWatcherNewUpdatesEv
 * ------------------------------------------------------------------------
 * General: Application handling of the PresentityWatcherNewUpdatesEvHandler.
 *			The callback indicates that new watcher information was received
 *          within a NOTIFY request from the server, and supplies a
 *          Winfo-XML object containing all the received information.
 *          Here we use the Winfo-XML API to observe this information, and 
 *          print it.
 *          In this sample, after receiving the first watcher information,
 *          we also publish the client status.
 * Arguments:
 * Input:   hPres		 	 - The Presentity object receiving a NOTIFY request
 *          hAppPres		 - The application Presentity object
 *          hSubs            - An inner subscription of the Presentity object that
 *                             is the specific subscription that received the NOTIFY request.
 *          hMsg             - The received NOTIFY request containing watcher XML
 *          hWinfoXML        - A Winfo-XML object containing all parsed watcher 
 *                             information received.
 * Return Value: none
 ***************************************************************************/
void RVCALLCONV AppSimplePresWatcherNewUpdatesEv(
                           IN  RvSimpleCltPresHandle            hPres,
                           IN  RvSimpleCltAppPresHandle         hAppPres,
						   IN  RvSipSubsHandle                  hSubs,
						   IN  RvSipMsgHandle                   hMsg,
						   IN  RvSimpleCltWinfoXMLHandle        hWinfoXML)
{
	RV_UNUSED_ARG(hAppPres);
	RV_UNUSED_ARG(hSubs);
	RV_UNUSED_ARG(hMsg);

    OSPrintf("===========================================================\n");
    OSPrintf(" presentity %p - new watcher information received \n",hPres);               
    AppExtractWatcherInformation(hWinfoXML);
    OSPrintf("\n===========================================================\n");
    
    /* the presentity is active. the watcher is active. time to publish the resource */
    AppCreatePublisher();
}


/***************************************************************************
 * AppExtractWatcherInformation
 * ------------------------------------------------------------------------
 * General: Use the Watcher-XML API to observe watcher information, and 
 *          print it.
 *          There may be several watcher lists in a Winfo XML document.
 *          Each watcher list contains watchers for a specific Resource (URI) 
 *          and Package (presence).
 *          Each watcher object encapsulates watcher information.
 * Arguments:
 * Input:   hWinfoXML      - A Winfo-XML object containing all parsed watcher 
 *                             information received.
 * Return Value: none
 ***************************************************************************/
static void RVCALLCONV AppExtractWatcherInformation(
                           IN  RvSimpleCltWinfoXMLHandle        hWinfoXML)
{
    RvStatus rv = RV_OK;
    RvSimpleCltWinfoXMLListHandle    hListOfWatchers;
    RvSimpleCltWinfoXMLWatcherHandle hWatcher;
    RvSimpleCltWinfoXMLWatcherStatus eStatus;
    RvSimpleCltWinfoXMLGetStrAttrs   attr;
#define TEMP_STRING_LEN 30
    RvChar  tempString[TEMP_STRING_LEN];

    /* loop 1 - goes over watchers lists in the winfo XML body */
    rv = RvSimpleCltWinfoXMLGetWatcherList(hWinfoXML, RVSIP_FIRST_ELEMENT, NULL, &hListOfWatchers);
    while (RV_OK == rv && NULL != hListOfWatchers  &&  RV_ERROR_NOT_FOUND != rv)
    {
        /* loop 2 - goes over the watchers in the list */
        rv = RvSimpleCltWinfoXMLListGetWatcher(hListOfWatchers, RVSIP_FIRST_ELEMENT, NULL, &hWatcher);
        if (RV_OK != rv)
            break;
        while (NULL != hWatcher  &&  RV_ERROR_NOT_FOUND != rv)
        {
            /* extract information for a single watcher: */
            /* watcher status */
            rv = RvSimpleCltWinfoXMLWatcherGetStatus(hWatcher,&eStatus);
            if (RV_OK == rv)
            {
                OSPrintf("           watcher status = %s", AppGetWinfoXMLWatcherStatusName(eStatus));
            }

            /* watcher ID */
            memset(&attr, 0, sizeof(attr));
            attr.strCopy = tempString;
            attr.givenStrLen = TEMP_STRING_LEN;
            rv = RvSimpleCltWinfoXMLWatcherGetId(hWatcher, &attr);
            if (RV_OK == rv)
            {
                OSPrintf("\n           watcher id = %s", attr.strCopy);
            }

            /* Contact */
            memset(&attr, 0, sizeof(attr));
            attr.strCopy = tempString;
            attr.givenStrLen = TEMP_STRING_LEN;
            rv = RvSimpleCltWinfoXMLWatcherGetURI(hWatcher, &attr);
            if (RV_OK == rv)
            {
                OSPrintf("\n           watcher uri = %s", attr.strCopy);
            }

             /* Get next watcher in loop 2*/
            rv = RvSimpleCltWinfoXMLListGetWatcher(hListOfWatchers, RVSIP_NEXT_ELEMENT, hWatcher, &hWatcher);
            if (RV_OK != rv  &&   RV_ERROR_NOT_FOUND != rv)
                break;
        }/* loop 2 - watchers in the list */

        /* Get next list in loop 1*/
        rv = RvSimpleCltWinfoXMLGetWatcherList(hWinfoXML, RVSIP_NEXT_ELEMENT, hListOfWatchers, &hListOfWatchers);
    }/* loop 1 - lists in the winfo XML. */
    
    if (RV_OK != rv  &&  RV_ERROR_NOT_FOUND != rv)
    {
        AppExitOnError("Failed to extract presentity watcher information");
    }
}


/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

/***************************************************************************
 * AppGetPresStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetPresStateName (
                          IN  RvSimpleCltPresState  eState)
{

    switch(eState)
    {
    case RVSIMPLECLT_PRES_STATE_IDLE:
		return "Idle";
	case RVSIMPLECLT_PRES_STATE_TERMINATED:
		return "Terminated";
	case RVSIMPLECLT_PRES_STATE_OPERATIVE:
		return "Operative";
    case RVSIMPLECLT_PRES_STATE_UNDEFINED:
	default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppGetSubsStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSubsStateName (
                          IN  RvSipSubsState  eState)
{

    switch(eState)
    {
    case RVSIP_SUBS_STATE_IDLE:
        return "Idle";
    case RVSIP_SUBS_STATE_SUBS_SENT:
        return "Subs Sent";
    case RVSIP_SUBS_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_SUBS_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_SUBS_STATE_NOTIFY_BEFORE_2XX_RCVD:
        return "Notify Before 2xx Rcvd";
    case RVSIP_SUBS_STATE_2XX_RCVD:
        return "2xx Rcvd";
    case RVSIP_SUBS_STATE_REFRESHING:
        return "Refreshing";
    case RVSIP_SUBS_STATE_REFRESH_RCVD:
        return "Refresh Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBING:
        return "Unsubscribing";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_RCVD:
        return "Unsubscribe Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_2XX_RCVD:
        return "Unsubscribe 2xx Rcvd";
    case RVSIP_SUBS_STATE_SUBS_RCVD:
        return "Subs Rcvd";
    case RVSIP_SUBS_STATE_ACTIVATED:
        return "Subs Activated";
    case RVSIP_SUBS_STATE_TERMINATING:
        return "Subs Terminating";
    case RVSIP_SUBS_STATE_PENDING:
        return "Subs Pending";
    case RVSIP_SUBS_STATE_ACTIVE:
        return "Subs Active";
    case RVSIP_SUBS_STATE_TERMINATED:
        return "Subs Terminated";
    default:
        return "Undefined";
    }
}

#if 0
/* This proc is currently unused */
/***************************************************************************
 * AppGetWinfoXMLStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given Winfo XML state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eXmlState - The state as enum
 ***************************************************************************/
static const RvChar* AppGetWinfoXMLStateName(IN RvSimpleCltWinfoXMLState eXmlState)
{
    switch(eXmlState)
    {
    case RVSIMPLECLT_WINFOXML_STATE_FULL:
        return "Full";
    case RVSIMPLECLT_WINFOXML_STATE_PARTIAL:
        return "Partial";
    default:
        return "Undefined";
    }
} 
#endif /* if 0 */
/***************************************************************************
 * AppGetWinfoXMLWatcherStatusName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given Winfo XML watcher status
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eXmlWatcherStatus - The state as enum
 ***************************************************************************/
static const RvChar* AppGetWinfoXMLWatcherStatusName(
                       IN RvSimpleCltWinfoXMLWatcherStatus eXmlWatcherStatus)
{
    switch(eXmlWatcherStatus)
    {
    case RVSIMPLECLT_WINFOXML_WATCHER_STATUS_PENDING:
        return "Pending";
    case RVSIMPLECLT_WINFOXML_WATCHER_STATUS_ACTIVE:
        return "Active";
    case RVSIMPLECLT_WINFOXML_WATCHER_STATUS_WAITING:
        return "Waiting";
    case RVSIMPLECLT_WINFOXML_WATCHER_STATUS_TERMINATED:
        return "Terminated";
    default:
        return "Undefined";
    }
} 


// #endif /* RV_MTF_SIMPLE_ON */




