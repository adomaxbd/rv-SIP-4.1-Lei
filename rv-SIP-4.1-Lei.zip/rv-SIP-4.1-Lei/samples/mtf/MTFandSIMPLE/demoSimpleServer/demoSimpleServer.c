/*********************************************************************************
 *                              <demoSimpleServer.c>
 *   This file demonstrates a SIMPLE server functionality:
 *   (1) Initiate the RADVISION SIP stack.
 *   (2) Accept incoming Presentitiy subscription (event:presence.winfo).
 *   (3) Accept an incoming Watcher subscription (event:presence) and if the resource
 *       is the same as the one of the presentity subscription, notifies the
 *       presentity subscription of the new watcher.
 *   (4) Accept Publish requests, and if the resource is the same as the one of the
 *       watcher subscription, notifies the watcher of the new client status.
 *
 *   Note - this is a demo application for the simpleSimpleClient sample.
 *          It is not an official sample, and must not be treated as such.
 *
 *   the demo message flow:
 *   =============================================================================
 *   CLIENT                                                 SERVER
 *      |                                                       |
 *   create presentity obj                                      |
 *      |                                                       |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |                  event:presence.winfo                 |
 *      |                                               Accept the subscription and send
 *      |                                               initial Notify request.
 *      |    <------------ 200 -----------------------          |
 *      |    <------------ NOTIFY (presentity) ----------       |
 *      |     ------------ 200 ----------------------->         |
 *   presentity subs is active.                                 |
 *      |                                                       |
 *   create watcher obj.                                        |
 *      |                                                       |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |                  event:presence                       |
 *      |                                               Accept the subscription and send
 *      |                                               initial Notify request.
 *      |    <------------ 200 -----------------------          |
 *      |    <------------ NOTIFY (watcher)--------------       |
 *      |     ------------ 200 ----------------------->         |
 *   watcher is active.                                         |
 *      |                                                       |
 *      |                                               Send Notify to the presentity
 *      |                                               informing the new watcher.
 *      |    <------------ NOTIFY (presentity)-----------       |
 *      |     ------------ 200 ----------------------->         |
 *      |                                                       |
 *   create publisher obj.                                      |
 *      |                                                       |
 *      |    ------------- PUBLISH ------------------->         |
 *      |                  event:presence                       |
 *      |                                               Accept the publish request.
 *      |    <------------ 200 -----------------------          |
 *      |                                               Send Notify to the watcher
 *      |                                               informing of the resource state.
 *      |    <------------ NOTIFY (watcher)--------------       |
 *      |     ------------ 200 ----------------------->         |
 *
 *   ==============================================================================
 *   The demo should be run against the simple SIMPLE client sample, running on the same
 *   machine.
 *   Notice that the application exits on errors.
 *
 * ------------------------------------------------------------------
 * Note: In order to run this demo under windows you must first
 *       Compile the stack, the SIMPLE client add-on and the event-dispatcher from
 *       the rvsip.dsw workspace with the following configurations:
 *       - Win32 Debug configuration for Debug execution
 *       - Win32 Release configuration for Release execution.
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                 Feb 2007
 *********************************************************************************/


/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"
#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdarg.h>
#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSipSubscriptionTypes.h"
#include "RvSipSubscription.h"
#include "RvSipSubscriptionStateHeader.h"
#include "RvSipMid.h"
#include "RvSipAddress.h"
#include "RvSipOtherHeader.h"

#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
#include <vxWorks.h>
#include <taskLib.h>
#include <time.h>
#endif
#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif

/*internal usage only*/
#ifdef USE_INTERNAL_SAMPLE_DEFS
#include "samplesInternalDefs.h"
#endif
/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*This identifier will be incremented for each response for PUBLISH request in order to set unique value
  for the SIP-ETag header*/
static RvInt32 uniqueId = 10;


/*Handle to the stack manager. This parameter is returned when calling
  RvSipStackConstruct. You should supply this handle when using the stack
  manager API functions.*/
static RvSipStackHandle      g_hStackMgr    = NULL;

/*Handle to the subscription manager. You can get this handle by calling
  RvSipStackGetSubsMgrHandle. You should supply this handle when
  using the subscription manager API functions.*/
static RvSipSubsMgrHandle    g_hSubsMgr  = NULL;

/*Handle to the transaction manager. This value is returned when calling
  RvSipStackGetTransactionMgrHandle. You should supply this handle when using
  the transaction manager API functions.*/
static RvSipTranscMgrHandle  g_hTranscMgr  = NULL;

/*Handle to the message manager. This value is returned when calling
  RvSipStackGetMsgMgrHandle. You should supply this handle when using
  the message manager API functions.*/
static RvSipMsgMgrHandle     g_hMsgMgr = NULL;

/*Handle to the log-module. You can get this handle by calling
  RvSipStackGetLogHandle. You need this value in order to construct the application
  memory pool.*/
static RV_LOG_Handle         g_hLog         = NULL;

/*Handle to the application memory pool. The application should construct its own
  memory using rpool API. The pool is needed for encoding messages or message
  parts. (See AppPrintMessage() )*/
static HRPOOL                g_appPool      = NULL;

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/
/* the presentity structure holds the parameters of a presentity subscription:*/
typedef struct
{
    RvSipSubsHandle hPresentitySubs;/*Handle to the stack subscription*/
    RvSipAddressHandle hResource;   /*The address defining the resource of this presentity.
                                      (The presentity subscription wants to receive notification
                                      about all watchers requesting to know the status of this
                                      specific resource.)*/
}presentity;

/* the watcher structure holds the parameters of a watcher subscription:*/
typedef struct
{
    RvSipSubsHandle hWatcherSubs;  /*Handle to the stack subscription*/
    RvSipAddressHandle hResource;  /*The address defining the resource of this watched by this watcher.*/
    RvSipAddressHandle hWatcher;   /*The address that identifies this watcher.*/
}watcher;

/* database - this demo supports only one watcher and one presentity subscriptions*/
presentity g_presentity;
watcher    g_watcher;

/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static int mainFunc(void);
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
static void mainFuncForSymbian(void);
#endif

static void AppStackInitialize(void);

static void AppSetCallBackFunctions(void);

static void AppPrintMessage(IN RvSipMsgHandle hMsg);


/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/
static void RVCALLCONV AppSubsCreatedEvHandler(
                                               IN  RvSipSubsHandle    hSubs,
                                               IN  RvSipCallLegHandle hCallLeg,
                                               IN  RvSipAppCallLegHandle hAppCallLeg,
                                               OUT RvSipAppSubsHandle *phAppSubs);

static void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason);


static RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                    IN  RvSipSubsHandle      hSubs,
                                    IN  RvSipAppSubsHandle   hAppSubs,
                                    IN  RvSipNotifyHandle    hNotify,
                                    IN  RvSipAppNotifyHandle hAppNotify,
                                    IN  RvSipMsgHandle       hMsg);

static RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                  IN  RvSipSubsHandle      hSubs,
                                  IN  RvSipAppSubsHandle   hAppSubs,
                                  IN  RvSipNotifyHandle    hNotify,
                                  IN  RvSipAppNotifyHandle hAppNotify,
                                  IN  RvSipMsgHandle       hMsg);

static void RVCALLCONV AppSubsSubscriptionExpiredEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs);

/*--------------------P R E S E N T I T Y   F U N C T I O N S -------------*/
static void RVCALLCONV AppHandlePresentityRequest(
                                    IN  RvSipSubsHandle            hSubs);

static void RVCALLCONV AppGeneratePresentityNotify(INOUT RvChar* strWinfoXml);

/*--------------------W A T C H E R   F U N C T I O N S -------------------*/
static void RVCALLCONV AppHandleWatcherRequest(
                                    IN  RvSipSubsHandle            hSubs);

static void RVCALLCONV AppWatcherSendStatus(RvSipMsgHandle hPublishRequestMsg);
/*--------------------T R A N S A C T I O N   F U N C T I O N S -----------*/
static void RVCALLCONV AppTranscCreatedEvHandler(
                           IN  RvSipTranscHandle            hTransc,
                           IN  void                         *context,
                           OUT RvSipTranscOwnerHandle       *phAppTransc,
                           OUT RvBool                      *b_handleTransc);

static void RVCALLCONV AppTranscStateChangedEvHandler(
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipTranscOwnerHandle            hAppTransc,
                                   IN  RvSipTransactionState             eState,
                                   IN  RvSipTransactionStateChangeReason eReason);

static RvStatus RVCALLCONV AppTranscMsgReceivedEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg);

static RvStatus RVCALLCONV AppTranscMsgToSendEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg);

static void RVCALLCONV AppHandlePublishTransc(IN  RvSipTranscHandle  hTransc);


/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

static void AppSendNotify(RvSipSubsHandle           hSubs,
                          RvSipSubscriptionSubstate eSubstate,
                          RvChar*                   pstrBody,
                          RvChar*                   pstrContentType);

static const RvChar*  AppGetSubsStateName (
                           IN  RvSipSubsState  eState);

static const RvChar*  AppGetTranscStateName (
                          IN  RvSipTransactionState  eState);

static void AppExitOnError(RvChar* str);


static int  OSPrintf(IN const char *format,... );

/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * main
 * ------------------------------------------------------------------------
 * General: In the main function we perform the following:
 *          1. Initialize the RADVISION SIP stack.
 *          2. Set the callback functions in the stack managers.
 *          3. Activates the RvSipStackProcessEvents() function that
 *             command the stack to process the event queue.
 ***************************************************************************/
static int mainFunc(void)
{
    OSPrintf("Executing demo of SIMPLE server\n");

    /*1. Initialize the RADVISION SIP stack.*/
    AppStackInitialize();

    /*2. Set the callback functions in the subscription manager.*/
    AppSetCallBackFunctions();

    /*3. Activates the RvSipStackProcessEvents() function that
         commands the stack to process the event queue.*/
    RvSipStackProcessEvents();
    return 0;
}
#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) /* embedded start function */
int mainForEmbedded()
{
    mainFunc();
    return 0;
}
#elif (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) /* vxworks start function */
void startVx()
{
    taskSpawn("mainFunc", 100, 0, 0x30000, (FUNCPTR)mainFunc, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_PSOS) /* pSOS start function */
/* pSOS Shell entry point */
#include <psos.h>
#include <prepc.h>
void mainForEmbedded(int argc, char **argv, char **env, void *exit_param, const char *console_dev)
{
    mainFunc();
    psh_exit(exit_param);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_WINCE) /* WinCE start function */
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPWSTR lpCmdLine,
                   int nCmdShow)
{
    OSSetMainFuncCB(mainFunc);
    OSWinCEMain(hInstance,hPrevInstance,lpCmdLine,nCmdShow);
}
#else /* not embedded start function */
int main()
{
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    mainFuncForSymbian();
    return 0;
#else
    return mainFunc();
#endif
}
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
/***************************************************************************
 * mainFuncForSymbian
 * ------------------------------------------------------------------------
 * General: Called from main(). Creats heap and initiates thread. Starts
 *          the SIP sample.
 ***************************************************************************/
static void mainFuncForSymbian(void)
{
   /* Symbian stack and heap should be enlarged so we are */
    /* Construction SIP on new thread                      */
    SymbianCreateThread((void *)mainFunc);
    while(1)
    {
      SymbianSleep(1000);
    }
}
#endif


/***************************************************************************
 * AppStackInitialize
 * ------------------------------------------------------------------------
 * General: Initializing the stack and allocating the application memory pool.
 *          When initializing we first set the configuration struct to the
 *          default values and then change some of the configuration parameters.
 *          We then use RvSipStackConstruct to initialize the stack.
 ***************************************************************************/
static void AppStackInitialize(void)
{
    RvStatus rv;
    RvSipStackCfg stackCfg;

    /*Initialize the configuration structure with default values*/
    RvSipStackInitCfg(sizeof(stackCfg),&stackCfg);

    /*change some of the default values*/
	stackCfg.localUdpPort = 6060;
	stackCfg.localTcpPort = 6060;
    stackCfg.maxSubscriptions = 10;
    stackCfg.tcpEnabled = RV_TRUE;
    stackCfg.maxConnections = 15;

#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) || (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || \
    (RV_OS_TYPE == RV_OS_TYPE_PSOS) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    /* Disable most of log */
    stackCfg.defaultLogFilters = RVSIP_LOG_ERROR_FILTER|RVSIP_LOG_EXCEP_FILTER;
#endif

    /*Call the stack initialization function*/
    rv = RvSipStackConstruct(sizeof(stackCfg),&stackCfg,&g_hStackMgr);
    if(rv != RV_OK)
    {
        AppExitOnError("Application failed to construct the stack\n");
    }


    /*getting handles for the internal modules*/
    RvSipStackGetSubsMgrHandle(g_hStackMgr, &g_hSubsMgr);
    RvSipStackGetMsgMgrHandle(g_hStackMgr, &g_hMsgMgr);
    RvSipStackGetLogHandle(g_hStackMgr,&g_hLog);
    RvSipStackGetTransactionMgrHandle(g_hStackMgr,&g_hTranscMgr);

    OSPrintf("The RADVISION SIP stack was constructed successfully. Version - %s\n",
                RvSipStackGetVersion());
    OSPrintf("===========================================================\n\n");
    /*Construct a pool of memory for the application*/
    g_appPool = RPOOL_Construct(1024,10,g_hLog,RV_FALSE,"ApplicationPool");

    /*Construct the server resources */
    {
        HPAGE hPage;
        rv = RPOOL_GetPage(g_appPool, 0, &hPage);
        if(rv != RV_OK)
        {
            AppExitOnError("Application failed to get application page\n");
        }
        rv = RvSipAddrConstruct(g_hMsgMgr, g_appPool, hPage, RVSIP_ADDRTYPE_URL, &g_presentity.hResource);
        if(rv != RV_OK)
        {
            AppExitOnError("Application failed construct presentity resource addr\n");
        }
        rv = RvSipAddrConstruct(g_hMsgMgr, g_appPool, hPage, RVSIP_ADDRTYPE_URL, &g_watcher.hResource);
        if(rv != RV_OK)
        {
            AppExitOnError("Application failed construct watcher resource addr\n");
        }
       rv = RvSipAddrConstruct(g_hMsgMgr, g_appPool, hPage, RVSIP_ADDRTYPE_URL, &g_watcher.hWatcher);
        if(rv != RV_OK)
        {
            AppExitOnError("Application failed construct watcher addr\n");
        }
    }
}

/***************************************************************************
 * AppSetCallBackFunctions
 * ------------------------------------------------------------------------
 * General: Set application call back functions in the subscription manager.
 ***************************************************************************/
static void AppSetCallBackFunctions(void)
{
    RvStatus rv;
    RvSipSubsEvHandlers appEvHandlers;
    RvSipTransactionEvHandlers   appTranscEvHandlers;

    /*Reset the appEvHandlers since not all callbacks are set by this sample*/
    memset(&appEvHandlers,0,sizeof(RvSipSubsEvHandlers));

    /*Set application callbacks in the structure*/
    appEvHandlers.pfnSubsCreatedEvHandler  = AppSubsCreatedEvHandler;
    appEvHandlers.pfnStateChangedEvHandler = AppSubsStateChangedEvHandler;
    appEvHandlers.pfnMsgReceivedEvHandler  = AppSubsMsgReceivedEvHandler;
    appEvHandlers.pfnMsgToSendEvHandler    = AppSubsMsgToSendEvHandler;
    appEvHandlers.pfnSubsExpiredEvHandler  = AppSubsSubscriptionExpiredEvHandler;


    /*Set the structure in the subscription manager*/
    rv = RvSipSubsMgrSetEvHandlers(g_hSubsMgr,
                                      &appEvHandlers,
                                      sizeof(RvSipSubsEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    /*Reset the appEvHandlers*/
    memset(&appTranscEvHandlers,0,sizeof(RvSipTransactionEvHandlers));

    appTranscEvHandlers.pfnEvTransactionCreated = AppTranscCreatedEvHandler;
    appTranscEvHandlers.pfnEvMsgReceived        = AppTranscMsgReceivedEvHandler;
    appTranscEvHandlers.pfnEvMsgToSend          = AppTranscMsgToSendEvHandler;
    appTranscEvHandlers.pfnEvStateChanged       = AppTranscStateChangedEvHandler;

    /*Set the structure in the transaction manager*/
    rv = RvSipTransactionMgrSetEvHandlers(g_hTranscMgr,
                                          NULL,
                                          &appTranscEvHandlers,
                                          sizeof(RvSipTransactionEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application transaction callbacks");
    }
}

/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/

/***************************************************************************
 * AppSubsCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new subscription was created.
 *           This application does not exchange handles with the subscription.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs - The new sip stack subscription handle
 * Output:  phAppSubs - The application handle for this subscription.
 ***************************************************************************/
static void RVCALLCONV AppSubsCreatedEvHandler(
                                               IN  RvSipSubsHandle    hSubs,
                                               IN  RvSipCallLegHandle hCallLeg,
                                               IN  RvSipAppCallLegHandle hAppCallLeg,
                                               OUT RvSipAppSubsHandle *phAppSubs)
{
    *phAppSubs = NULL;  /*the application handle is set to NULL*/
    RV_UNUSED_ARG(hCallLeg);
    RV_UNUSED_ARG(hAppCallLeg);
}


/***************************************************************************
 * AppSubsStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a subscription state change.
 *          This implementation handles only presence.winfo subscriptions
 *          (for presentity) and presence subscription (for watchers).
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          eState -      The new subscription state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason)
{
    RvStatus             rv;
    RvSipSubsEventPackageType eventType;

    /*print the new state on screen*/
    OSPrintf("\nsubscription %p - State changed to %s\n\n", hSubs, AppGetSubsStateName(eState));

    switch(eState)
    {
    /*-------------------------------------------------------------------
      Accept incoming subscription and send a notify (active) immediately
      -------------------------------------------------------------------*/
    case RVSIP_SUBS_STATE_SUBS_RCVD:
	{
        rv = RvSipSubsGetEventPackageType(hSubs, &eventType);
        if(eventType == RVSIP_SUBS_EVENT_PACKAGE_TYPE_PRESENCE)
        {
             /* handle a watcher request */
            AppHandleWatcherRequest(hSubs);
        }
        else if (eventType == RVSIP_SUBS_EVENT_PACKAGE_TYPE_PRESENCE_WINFO)
        {
            /* handle a presentity request */
            AppHandlePresentityRequest(hSubs);
        }
        else
        {
            OSPrintf("Reject the subscription with unknown event package\n\n");
            rv = RvSipSubsRespondReject(hSubs, 400, "Not Supported Event Package");
            if(rv != RV_OK)
            {
                AppExitOnError("Failed to reject the subscription\n");
            }
        }
    }
    default:
        break;
    }
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(eReason);
}


/***************************************************************************
* AppSubsSubscriptionExpiredEvHandler
* ------------------------------------------------------------------------
* General: Application implementation to the SubscriptionExpiredEv event
*          handler.
*          If this is a notifier expiration - send a notify (terminated)
*          request.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:    hSubs    - The sip stack subscription handle
*           hAppSubs - The application handle for this subscription.
***************************************************************************/
static void RVCALLCONV AppSubsSubscriptionExpiredEvHandler(
                                        IN  RvSipSubsHandle            hSubs,
                                        IN  RvSipAppSubsHandle         hAppSubs)
{
    RvSipSubscriptionType eType;

    OSPrintf("\nSubscription %p timeout!!! \n",hSubs);
    RvSipSubsGetSubsType(hSubs, &eType);

    if(eType == RVSIP_SUBS_TYPE_NOTIFIER)
    {
        /*send notify if the state it was not already sent*/
        RvSipSubsState eState;
        RvSipSubsGetCurrentState(hSubs,&eState);
        if(eState != RVSIP_SUBS_STATE_TERMINATING)
        {
            OSPrintf("\nSubscription %p send Notify(terminated) \n",hSubs);
            AppSendNotify(hSubs, RVSIP_SUBSCRIPTION_SUBSTATE_TERMINATED, NULL, NULL);
        }
    }
    RV_UNUSED_ARG(hAppSubs);
}


/***************************************************************************
 * AppSubsMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                        IN  RvSipSubsHandle      hSubs,
                                        IN  RvSipAppSubsHandle   hAppSubs,
                                        IN  RvSipNotifyHandle    hNotify,
                                        IN  RvSipAppNotifyHandle hAppNotify,
                                        IN  RvSipMsgHandle       hMsg)
{
    OSPrintf("\n<-- Message Received (subscription %p)\n",hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs || hAppNotify || hNotify)
    return RV_OK;
}

/***************************************************************************
 * AppSubsMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                          IN    RvSipSubsHandle      hSubs,
                                          IN    RvSipAppSubsHandle   hAppSubs,
                                          IN    RvSipNotifyHandle    hNotify,
                                          IN    RvSipAppNotifyHandle hAppNotify,
                                          IN    RvSipMsgHandle       hMsg)
{
    OSPrintf("--> Message Sent (subscription %p)\n",hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs || hAppNotify || hNotify)
    return RV_OK;
}


/*---- T R A N S C    E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/

/***************************************************************************
 * AppTranscCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new non call-leg related transaction was created
 *           This application does not exchange handles with the transaction.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc - The new sip stack transaction handle
 *          context - The application context given in the
 *                    RvSipTransactionMgrSetEvHandlers function. (In this
 *                    example it is null but applications can use this
 *                    parameters as reference to their database.
 * Output:  phAppTransc - The application handle for this call-leg.
 *          b_handleTransc - Indicates whether the application wishes to handle
 *                           this transaction. I False the transcation will
 *                           be a stand alone transaction.
 ***************************************************************************/
static void RVCALLCONV AppTranscCreatedEvHandler(
                           IN  RvSipTranscHandle            hTransc,
                           IN  void                         *context,
                           OUT RvSipTranscOwnerHandle       *phAppTransc,
                           OUT RvBool                      *b_handleTransc)
{
    RvChar strMethod[10];

    RvSipTransactionGetMethodStr(hTransc, 10, (RvChar*)strMethod);

    if(strcmp(strMethod, "PUBLISH") == 0)
    {
        OSPrintf("===========================================================\n");
        OSPrintf(" New PUBLISH transaction was created \n");
        OSPrintf("===========================================================\n\n");
    }
    *phAppTransc = NULL;  /*the application handle is set to NULL*/
    *b_handleTransc = RV_TRUE; /*the application wishes to handle the transaction*/
    RV_UNUSED_ARG(context);
}

/***************************************************************************
 * AppTranscStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a transaction state changed.
 *          In this implementation we want to handle only PUBLISH requests.
 *          other request are rejected with '501 not implemented'.
 *          Handling the PUBLISH request:
 *          1. Use the PUBLISH XML body, to notify the watcher of the new status.
 *          2. Push a 'SIP-ETag' header, and expires header to the response,
 *             and accept the PUBLISH request.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -     The sip stack transaction handle
 *          hAppTransc -  The application handle for this transaction
 *          eState -      The new transaction state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppTranscStateChangedEvHandler(
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipTranscOwnerHandle            hAppTransc,
                                   IN  RvSipTransactionState             eState,
                                   IN  RvSipTransactionStateChangeReason eReason)
{
    RvStatus             rv;

    /*print the new state on screen*/
    OSPrintf("\ntransc %p - State changed to %s\n\n", hTransc,AppGetTranscStateName(eState));

    switch(eState)
    {
    case RVSIP_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:
        {
            RvChar methodStr[20] = {0};
            RvSipTransactionGetMethodStr(hTransc,20,methodStr);

            /*respond with 200 only to PUBLISH*/
            if(strcmp(methodStr,"PUBLISH")==0)
            {
                AppHandlePublishTransc(hTransc);
            }
            else /*respond with 501 to any other transaction*/
            {
                rv = RvSipTransactionRespond(hTransc,501,NULL);
                if(rv != RV_OK)
                {
                    AppExitOnError("Failed to response to the request");
                }
            }
        }
        break;
    default:
        break;
    }
    RV_UNUSED_ARG(hAppTransc);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppTranscMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -    The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction.
 *          hMsg -        Handle to the incoming message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppTranscMsgReceivedEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg)
{
    OSPrintf("\n<-- Message Received (transaction %p)\n",hTransc);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppTransc);
    return RV_OK;
}

/***************************************************************************
 * RvSipTranscMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -    The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppTranscMsgToSendEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg)
{
    OSPrintf("\n--> Message Sent (transaction %p)\n",hTransc);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppTransc);
    return RV_OK;
}


/*-------------------- G E N E R A L   F U N C T I O N S -------------------*/

/*--------------------P U B L I S H    F U N C T I O N S -------------------*/
/***************************************************************************
 * AppHandlePublishTransc
 * ------------------------------------------------------------------------
 * General: Handling the PUBLISH request:
 *          1. Use the PUBLISH XML body, to notify the watcher of the new status.
 *          2. Push a 'SIP-ETag' header, and expires header to the response,
 *             and accept the PUBLISH request.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -     The sip stack transaction handle
 ***************************************************************************/
static void RVCALLCONV AppHandlePublishTransc(IN  RvSipTranscHandle  hTransc)
{
    RvStatus             rv;
    RvSipMsgHandle       hMsg, hOutboundMsg;
    RvSipOtherHeaderHandle hHeader;
    RvSipExpiresHeaderHandle hExpires;
    RvSipHeaderListElemHandle hElem = NULL, hElem2 = NULL;
	RvChar					  sipETagValue[50];
	RvInt32					  uId1,uId2,uId3;

	memset(sipETagValue, 0, 50);

    rv = RvSipTransactionGetReceivedMsg(hTransc, &hMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to get publish received message");
    }

    /*1. Use the PUBLISH XML body, to notify the watcher of the new status.*/
    AppWatcherSendStatus(hMsg);

    /*2. Prepare the 200 response for the PUBLISH request: */
    rv = RvSipTransactionGetOutboundMsg(hTransc, &hOutboundMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to get publish response outbound message");
    }

    /* Add SIP-ETag header to the message */
    rv = RvSipOtherHeaderConstructInMsg(hOutboundMsg, RV_TRUE, &hHeader);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to construct SIP-ETag header in the outbound message");
    }
    rv = RvSipOtherHeaderSetName(hHeader, "SIP-ETag");
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set SIP-ETag header name");
    }

	uId1 = uniqueId++;
	uId2 = uniqueId++;
	uId3 = uniqueId++;

	sprintf(sipETagValue, "%d%d%d", uId1, uId2, uId3);

    rv = RvSipOtherHeaderSetValue(hHeader, sipETagValue);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set SIP-ETag header value");;
    }

    /* Copy the Expires header from the request to the response */
    hExpires = (RvSipExpiresHeaderHandle)RvSipMsgGetHeaderByType(hMsg,
                RVSIP_HEADERTYPE_EXPIRES, RVSIP_FIRST_HEADER, &hElem);
    if(hExpires != NULL)
    {
        rv = RvSipMsgPushHeader(hOutboundMsg, RVSIP_FIRST_HEADER, (void*)hExpires,
                                RVSIP_HEADERTYPE_EXPIRES, &hElem2, (void**)&hExpires);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to push Expires header to the response message");
        }
    }

    /* Send the 200 response */
    rv = RvSipTransactionRespond(hTransc,200,NULL);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to response to the PUBLISH request");
    }

}
/*--------------------P R E S E N T I T Y   F U N C T I O N S -------------------*/

/***************************************************************************
 * AppHandlePresentityRequest
 * ------------------------------------------------------------------------
 * General: Handles the SUBSCRIBE request with "event:presence.winfo".
 *          1. Save the presentity parameters in the server database.
 *          2. Accept the subscription.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 ***************************************************************************/
static void RVCALLCONV AppHandlePresentityRequest(
                                    IN  RvSipSubsHandle            hSubs)
{
    RvStatus             rv;
    RvSipMsgHandle       hMsg;
    RvSipAddressHandle   hTempUri;

    /* 1. Save the presentity parameters in the server database:
          the request-uri is the presentity resource */
    g_presentity.hPresentitySubs = hSubs;

    rv = RvSipSubsGetReceivedMsg(hSubs, &hMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to get the received winfo message");
    }
    hTempUri = RvSipMsgGetRequestUri(hMsg);
    rv = RvSipAddrCopy(g_presentity.hResource, hTempUri); /* address was already constructed on initialization */
    if(rv != RV_OK || hTempUri == NULL)
    {
        AppExitOnError("Failed to copy the request-uri to the presentity resource.");
    }

    /* 2. Accept the subscription and send an activating notify*/
    OSPrintf("===========================================================\n");
    OSPrintf("Accept the presentity subscription\n");
    OSPrintf("===========================================================\n\n");
    rv = RvSipSubsRespondAccept(hSubs,UNDEFINED);
    if(rv != RV_OK)
    {
       AppExitOnError("Failed to accept the subscription\n");
    }
    AppSendNotify(hSubs, RVSIP_SUBSCRIPTION_SUBSTATE_ACTIVE, NULL, NULL);
}

/***************************************************************************
 * AppGeneratePresentityNotify
 * ------------------------------------------------------------------------
 * General: Build the winfo XML and set it as the body of the presentity
 *          NOTIFY request.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:
 ***************************************************************************/
static void RVCALLCONV AppGeneratePresentityNotify(INOUT RvChar* strWinfoXml)
{
    /* Build the winfo XML to set as the body of the presentity NOTIFY request. */
    RvChar strWatcher[50], strResource[50];
    HPAGE  tempPage = NULL;
    RvUint32 length = 0;
    RvStatus rv;

    /* build the watcher id string, by converting the address to string */
    rv = RvSipAddrEncode(g_watcher.hWatcher, g_appPool, &tempPage, &length);
    if(rv != RV_OK)
    {
       AppExitOnError("Failed to encode the watcher id\n");
    }
    rv = RPOOL_CopyToExternal(g_appPool, tempPage, 0, strWatcher, length);
    if(rv != RV_OK)
    {
       AppExitOnError("Failed to copy watcher to buffer\n");
    }
    strWatcher[length]='\0';
    RPOOL_FreePage(g_appPool, tempPage);

    /* build the resource string, by converting the address to string */
    length = 0;
    rv = RvSipAddrEncode(g_watcher.hResource, g_appPool, &tempPage, &length);
    if(rv != RV_OK)
    {
       AppExitOnError("Failed to encode the watcher id\n");
    }
    rv = RPOOL_CopyToExternal(g_appPool, tempPage, 0, strResource, length);
    if(rv != RV_OK)
    {
       AppExitOnError("Failed to copy watcher to buffer\n");
    }
    strResource[length]='\0';
    RPOOL_FreePage(g_appPool, tempPage);

    /* build the XML string */
    sprintf(strWinfoXml,
        "%s\n%s\n%s%s%s\n%s\n%s%s%s\n%s\n%s%c",
        "<?xml version=\"1.0\"?>",
        "<watcherinfo xmlns=\"urn:ietf:params:xml:ns:watcherinfo\" version=\"0\" state=\"full\">",
        "   <watcher-list resource=\"", strResource, "\" package=\"presence\">",
        "     <watcher id=\"7768a77s\" event=\"subscribe\"",
        "              status=\"active\">", strWatcher, "</watcher>",
        "   </watcher-list>",
        "</watcherinfo>",'\0');
}

/*--------------------W A T C H E R   F U N C T I O N S -------------------*/

/***************************************************************************
 * AppHandleWatcherRequest
 * ------------------------------------------------------------------------
 * General: Handles the SUBSCRIBE request with event:presence.
 *          1. Save the watcher parameters in server database.
 *          2. Accept the watcher subscription.
 *          3. Search for a Presentity object with the same resource,
 *             If exists, notify him of the new watcher.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 ***************************************************************************/
static void RVCALLCONV AppHandleWatcherRequest(
                                    IN  RvSipSubsHandle            hSubs)
{
    RvStatus             rv;
    RvSipMsgHandle       hMsg;
    RvSipAddressHandle   hTempUri;
    RvSipPartyHeaderHandle hFrom;

    /* 1. Save the watcher parameters in the server database:
          the request-uri is the watcher resource
          the uri in the From header is the watcher id*/
    g_watcher.hWatcherSubs = hSubs;

    rv = RvSipSubsGetReceivedMsg(hSubs, &hMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to get the received watcher message");
    }
    hTempUri = RvSipMsgGetRequestUri(hMsg);
    rv = RvSipAddrCopy(g_watcher.hResource, hTempUri); /* address was already constructed on initialization */
    if(rv != RV_OK || hTempUri == NULL)
    {
        AppExitOnError("Failed to copy the request-uri to the watcher resource.");
    }

    hFrom = RvSipMsgGetFromHeader(hMsg);
    hTempUri = RvSipPartyHeaderGetAddrSpec(hFrom);
    if(hFrom == NULL || hTempUri == NULL)
    {
        AppExitOnError("Failed to get watcher from uri.");
    }
    rv = RvSipAddrCopy(g_watcher.hWatcher, hTempUri);  /* address was already constructed on initialization */
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to copy the From uri to the watcher id.");
    }

    /* 2. Accept the subscription, and send an activating notify*/
    OSPrintf("===========================================================\n");
    OSPrintf("Accept the watcher subscription\n");
    OSPrintf("===========================================================\n\n");
    rv = RvSipSubsRespondAccept(hSubs,UNDEFINED);
    if(rv != RV_OK)
    {
       AppExitOnError("Failed to accept the subscription\n");
    }
    AppSendNotify(hSubs, RVSIP_SUBSCRIPTION_SUBSTATE_ACTIVE, NULL, NULL);

    /* 3. Search for a Presentity object with the same resource,
          If exists, notify him of the new watcher.*/
    /* in this demo, we have only one presentity, so the search is quite simple :-) */
    if(RvSipAddrUrlIsEqual(g_watcher.hResource, g_presentity.hResource) == RV_TRUE)
    {
        RvChar strWinfoXml[350];

        AppGeneratePresentityNotify(strWinfoXml);
        OSPrintf("===========================================================\n");
        OSPrintf(" Notify presentity subscriber %p of a new watcher\n",g_presentity.hPresentitySubs);
        OSPrintf("===========================================================\n\n");

        AppSendNotify(g_presentity.hPresentitySubs, RVSIP_SUBSCRIPTION_SUBSTATE_ACTIVE,
                      strWinfoXml, "application/watcherinfo+xml");
    }
}


/***************************************************************************
 * AppWatcherSendStatus
 * ------------------------------------------------------------------------
 * General: Creates and sends Notify request to the watcher subscription,
 *          containing the same Pidf body received in the PUBLISH request.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hPublishRequestMsg  - Handle to recevied PUBLISH message.
 ***************************************************************************/
static void RVCALLCONV AppWatcherSendStatus(RvSipMsgHandle hPublishRequestMsg)
{
    RvChar  strPublish[350];
    RvUint  actualLen;
    RvStatus rv;

    rv = RvSipMsgGetBody(hPublishRequestMsg, strPublish, 350, &actualLen);
    if(rv != RV_OK)
    {
       /*Since there is no body in the message this is probably a refresh reqeust.*/
		return;
    }

    /* send the same body in the NOTIFY of the watcher subscription */
	if (g_watcher.hWatcherSubs != NULL)
	{
		OSPrintf("===========================================================\n");
		OSPrintf(" Notify watcher subscriber %p of the new resource status\n",g_watcher.hWatcherSubs);
		OSPrintf("===========================================================\n\n");


		AppSendNotify(g_watcher.hWatcherSubs,
					  RVSIP_SUBSCRIPTION_SUBSTATE_ACTIVE,
					  strPublish,
					  "application/pidf+xml");
	}

}

/***************************************************************************
 * AppSendNotify
 * ------------------------------------------------------------------------
 * General: Creates and sends Notify requests.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs     - Handle to the subscription.
 *          eSubstate - Value to set in subscription-state header of notify
 *                      request.
 *          pstrBody  - Body sting to set in the NOTIFY request.
 *          pstrContentType - Content-type string to set in the NOTIFY request.
 ***************************************************************************/
static void AppSendNotify(RvSipSubsHandle           hSubs,
                          RvSipSubscriptionSubstate eSubstate,
                          RvChar*                   pstrBody,
                          RvChar*                   pstrContentType)
{
    RvSipNotifyHandle hNotify;
    RvSipMsgHandle    hMsg;
    RvStatus         rv;

    /*---------------------------
      Create a notify request.
      ---------------------------*/
    rv = RvSipSubsCreateNotify(hSubs, NULL, &hNotify);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create notification object\n");
        return;
    }

    /*-----------------------------------------------
      Set subscription-state header in notify message.
      -----------------------------------------------*/
    rv = RvSipNotifySetSubscriptionStateParams(hNotify, eSubstate, RVSIP_SUBSCRIPTION_REASON_UNDEFINED, UNDEFINED);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set Subscription-State\n");
        return;
    }


    /*-----------------------------------------------
      Set body and content-type in notify message.
      -----------------------------------------------*/
    if(pstrBody != NULL)
    {
        rv = RvSipNotifyGetOutboundMsg(hNotify, &hMsg);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to get notification outbound message\n");
            return;
        }
        rv = RvSipMsgSetBody(hMsg, pstrBody);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to set body in outbound message\n");
            return;
        }
        rv = RvSipMsgSetContentTypeHeader(hMsg, pstrContentType);
    }

    /*---------------------------
      Send the notify request.
      ---------------------------*/
    rv = RvSipNotifySend(hNotify);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to send Notify request\n");
        return;
    }
    /* after sending the notify request, we must not use the notify message handle again */
    hMsg = NULL;
}
/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/
/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
static void AppPrintMessage(IN RvSipMsgHandle hMsg)
{
    RvStatus   rv;
    HPAGE       hPage;
    RvChar     *msgBuf;
    RvUint32   msgSize;

    /* getting the encoded message on an rpool page.*/
    rv = RvSipMsgEncode(hMsg, g_appPool, &hPage, &msgSize);
    if (rv != RV_OK)
    {
        OSPrintf("Message encoding failed");
        exit(1);
    }
    /*allocate a consecutive buffer - use UTILS since malloc doesn't work on all OS's */
    msgBuf = (RvChar *)RvSipMidMemAlloc(msgSize+1);

    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appPool,
        hPage,
        0,
        (void*)msgBuf,
        msgSize);
    /*terminate the buffer with null*/
    msgBuf[msgSize] = '\0';
    if(rv != RV_OK)
    {
        OSPrintf("Message encoding failed");
        /*free the page the encode function allocated*/
        RPOOL_FreePage(g_appPool, hPage);
        RvSipMidMemFree(msgBuf);
        exit(1);
    }
    OSPrintf("%s \n",msgBuf);
    /*free the page the encode function allocated*/
    RPOOL_FreePage(g_appPool, hPage);
    RvSipMidMemFree(msgBuf);
}

/***************************************************************************
 * AppExitOnError
 * ------------------------------------------------------------------------
 * General: prints an error message and exits.
  ***************************************************************************/
static void AppExitOnError(RvChar* str)
{
    OSPrintf("%s\n",str);
    exit(1);
}


/***************************************************************************
 * AppGetSubsStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSubsStateName (
                          IN  RvSipSubsState  eState)
{

    switch(eState)
    {
    case RVSIP_SUBS_STATE_IDLE:
        return "Idle";
    case RVSIP_SUBS_STATE_SUBS_SENT:
        return "Subs Sent";
    case RVSIP_SUBS_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_SUBS_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_SUBS_STATE_NOTIFY_BEFORE_2XX_RCVD:
        return "Notify Before 2xx Rcvd";
    case RVSIP_SUBS_STATE_2XX_RCVD:
        return "2xx Rcvd";
    case RVSIP_SUBS_STATE_REFRESHING:
        return "Refreshing";
    case RVSIP_SUBS_STATE_REFRESH_RCVD:
        return "Refresh Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBING:
        return "Unsubscribing";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_RCVD:
        return "Unsubscribe Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_2XX_RCVD:
        return "Unsubscribe 2xx Rcvd";
    case RVSIP_SUBS_STATE_SUBS_RCVD:
        return "Subs Rcvd";
    case RVSIP_SUBS_STATE_ACTIVATED:
        return "Subs Activated";
    case RVSIP_SUBS_STATE_TERMINATING:
        return "Subs Terminating";
    case RVSIP_SUBS_STATE_PENDING:
        return "Subs Pending";
    case RVSIP_SUBS_STATE_ACTIVE:
        return "Subs Active";
    case RVSIP_SUBS_STATE_TERMINATED:
        return "Subs Terminated";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppGetTranscStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetTranscStateName (
                          IN  RvSipTransactionState  eState)
{

    switch(eState)
    {
    case RVSIP_TRANSC_STATE_UNDEFINED:
        return "Undefined";
    case RVSIP_TRANSC_STATE_IDLE:
        return "Idle";
    case RVSIP_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:
        return "General Request Received";
    case RVSIP_TRANSC_STATE_SERVER_GEN_FINAL_RESPONSE_SENT:
        return "General Final Response Sent";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_REQUEST_RCVD:
        return "Invite Request Received";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_FINAL_RESPONSE_SENT:
        return "Invite Final Response Sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_REQUEST_SENT:
        return "General Request Sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_PROCEEDING:
        return "General Proceeding";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_CALLING:
        return "Invite Calling";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_PROCEEDING:
        return "Invite Proceeding";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_FINAL_RESPONSE_RCVD:
        return "Invite Final Response Received";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_ACK_SENT:
        return "Invite Ack Sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_FINAL_RESPONSE_RCVD:
        return "General Final Response Received";
    case RVSIP_TRANSC_STATE_TERMINATED:
        return "Terminated";
    default:
        return "";
    }
}

/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Implementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameters according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
static int OSPrintf(IN const char *format,... )
{
    int      charsNo;
    va_list  ap;
#if (RV_OS_TYPE == RV_OS_TYPE_WINCE)
    RvChar  cbuf[MAX_PRINT_LEN];

    /*************************************
     Print message to the buffer first
    **************************************/
    va_start(ap,format);
    charsNo = vsprintf (cbuf, format, ap);
    va_end(ap);

    /************************************************
     Using default output window for printing
    *************************************************/
    charsNo = OSWinCEPrintf(NULL,0,cbuf);
#else
    va_start(ap,format);
    charsNo = vprintf(format,ap);
    va_end(ap);

#endif

    return charsNo;
}

