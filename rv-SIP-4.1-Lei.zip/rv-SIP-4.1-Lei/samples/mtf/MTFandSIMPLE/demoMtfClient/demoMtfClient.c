/******************************************************************************
Filename:    demoMtfClient.c
Description: This file demonstrates how MTF APIs can be used. The file includes
			 a the following functionality:
			 1. Initialization and shut down of MTF and sample application
			 2. Registration and un-registration of terminations
			 3. Sending events to MTF
			 4. Implementations of MTF signal callbacks
			 5. Implementations of MTF termination callbacks
			 6. Other APIs

			 Note:
			 For media integration see implementations of MTF media callbacks
			 in file rvMtfSampleMediaCallbacls.c.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include "ippthread.h"
#include "demoMtfClient.h"
#include "rvMtfBaseApi.h"
#include "rvMtfExtControlApi.h"
#include "rvMdmControlApi.h"
#include "rvstr.h"
#include "rvmtfalloc.h"

//#include "MfControl.h"


/*============================================================================================*/
/*=================================   G L O B A L S  =========================================*/
/*============================================================================================*/
#define		LOCAL_ADDRESS		"127.0.0.1"
#define		LOCAL_PORT			 5070
RvMtfHandle			g_hMtf;
RvSipStackHandle	g_hSipStack;

#if(RV_OS_TYPE == RV_OS_TYPE_WINCE)
#define MTF_LOG_PATH "\\Program Files\\MtfSipSample\\MtfLog.txt"
/* In WinCE the TLS certificate files should be placed in ROOT_DIR. In the config file
   only the file name should be provided e.g: privateKeyFileName=mycert.com.key-cert.pem.
   The reson is that while parsing the SIPPhone config file the white space in 'Program Files' causes
   partial parsing of the path  */
#define ROOT_DIR  "\\Program Files\\MtfSipSample\\"
#else
#define MTF_LOG_PATH "./MtfLog.txt"
#define ROOT_DIR ""
#endif

/*===============================================================================*/
/*================== M E D I A			C A L L B A C K	S	=====================*/
/*===============================================================================*/

/******************************************************************************
 * rvMtfSampleConnectMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfConnectMediaEv().
 *			This callback is called when application is required to connect either
 *			one of following:
 *				1.	An existing media stream (RTP session) with an audio/video device,
 *					to enable media flowing from both parties of the call.
 *				2.	An existing media stream with another existing media stream, to
 *					create mixing of media and enable Conference call to be established.
 *			This callback will usually be called when call is getting connected (remote
 *			party or local user answered the call), or during a Conference call.
 *			In this implementation we do first check which type of terminal should be connected,
 *			and send EPP message to GUI for connecting the stream. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTermSource			- Handle to source terminal, may be either RTP terminal or audio/video device.
 *			hAppTermSource		- Handle to application data associated with the source terminal.
 *			hTermTarget			- Handle to target terminal, always an RTP terminal.
 *			hAppTermTarget		- Handle to application data associated with the target terminal.
 *			termSourceType		- Type of the source terminal, indicating whether application should connect
 *								  RTP session to audio/video device, or RTP session to another RTP session.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleConnectMediaCB(
				RvIppTerminalHandle			hTermSource,
				RvMtfTerminalAppHandle		hAppTermSource,
				RvIppTerminalHandle			hTermTarget,
				RvMtfTerminalAppHandle		hAppTermTarget,
				RvMtfTerminalType			termType)
{
	
	RV_UNUSED_ARG(hTermSource);
	RV_UNUSED_ARG(hAppTermSource);
	RV_UNUSED_ARG(hTermTarget);
	RV_UNUSED_ARG(hAppTermTarget);
	RV_UNUSED_ARG(termType);

	return RV_OK;
}

/******************************************************************************
 * rvMtfSampleDisconnectMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaDisconnectEv().
 *			This callback is called when application is required to disconnect either
 *			one of following:
 *				1.	An existing media stream (RTP session) from an audio/video device,
 *					to stop media flowing from both parties of the call.
 *				2.	An existing media stream from another existing media stream, to
 *					stop mixing of media during Conference call.
 *			This callback will usually be called when basic call is disconnected (remote
 *			party or local user answered the call), or one of the participants left the
 *			Conference call.
 *			In this implementation we do first check which type of terminal should be disconnected,
 *			and send EPP message to GUI for disconnecting the stream. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTermSource			- Handle to source terminal, may be either RTP terminal or audio/video device.
 *			hAppTermSource		- Handle to application data associated with the source terminal.
 *			hTermTarget			- Handle to target terminal, always an RTP terminal.
 *			hAppTermTarget		- Handle to application data associated with the target terminal.
 *			termSourceType		- Type of the source terminal, indicating whether application should disconnect
 *								  RTP session from audio/video device, or RTP session from another RTP session.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDisconnectMediaCB(
               RvIppTerminalHandle			hTermSource,
			   RvMtfTerminalAppHandle		hAppTermSource,
               RvIppTerminalHandle			hTermTarget,
			   RvMtfTerminalAppHandle		hAppTermTarget,
			   RvMtfTerminalType			termType)
{
    RV_UNUSED_ARG(hTermSource);
	RV_UNUSED_ARG(hAppTermSource);
	RV_UNUSED_ARG(hTermTarget);
	RV_UNUSED_ARG(hAppTermTarget);
	RV_UNUSED_ARG(termType);

	return RV_OK;
}

/******************************************************************************
 * rvMtfSampleCreateMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaCreateStreamEv().
 *			This callback is called when application is required to create a new
 *			media stream (RTP session), with specific parameters provided in this
 *			callback (codec, etc). Application should return the ip address and port
 *			number of the new media stream. This callback will usually be called when
 *			new call is established.
 *			In this implementation we do the following:
 *				1. Check for currently available codecs (considering resources etc.)
 *				2. Media negotiation - find the common capabilities between us and remote party.
 *				3. Create a new RTP session according to common capabilities.
 *			We open the RTP stream by sending EPP message to GUI. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			params			- media parameters the new media stream should be created with.
 *
 * Output: params			- media parameters the new media stream was created with.
 *							  the localSdp should include the ip address and port number
 *							  of the new media stream. All the other fields should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleCreateMediaCB(
                RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
                RvMtfMediaParams*			params)
{
    RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(params);

	return RV_OK;
}

/******************************************************************************
 * rvMtfSampleModifyMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaModifyStreamEv().
 *			This callback is called when application is required to modify an existing
 *			media stream (RTP session), with specific parameters provided in this
 *			callback (codec, etc). Application should return the ip address and port
 *			number of the media stream. This callback will usually be called during
 *			a connected call.
 *			In this implementation we do the following:
 *				1. Check what kind of modifying should we operate on the stream, and
 *				   apply on the stream.
 *				2. If we are required to change parameters of existing stream -
 *						a. Check for currently available codecs (considering resources etc.)
 *						b. Media negotiation - find the common capabilities between us and remote party.
 *						c. Modify the RTP session according to the new parameters.
 *			We apply the modifications on the RTP stream by sending EPP message to GUI.
 *			Application should call its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			params			- media parameters the media stream should be modified with.
 *
 * Output: params			- media parameters the media stream was modified with.
 *							  the localSdp should include the ip address and port number
 *							  of the media stream. All the other fields should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleModifyMediaCB(
                RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
                RvMtfMediaParams*			params)
{
    RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(params);
	
	return RV_OK;
}


/******************************************************************************
 * rvMtfSampleDestroyMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaDestroyStreamEv().
 *			This callback is called when application is required to terminate an existing
 *			media stream (RTP session). This callback will usually be called when call
 *			disconnects.
 *			In this implementation we send EPP message to GUI for closing the RTP session.
 *			Application should call its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDestroyMediaCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm)
{
	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	
	return RV_OK;
}

/******************************************************************************
 * rvMtfSampleStartPhysicalDeviceCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaStartPhysicalDeviceEv().
 *			This callback is called when application is required to initialize an
 *			audio device (Handset, Speaker or headset). This callback will be called
 *			once, on the first call only.
 *			In this implementation we do first check which type of terminal should be started,
 *			and send EPP message to GUI for starting the device. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			termType		- Type of the terminal, indicating which device application
 *							  should start, audio or video device.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleStartPhysicalDeviceCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
				RvMtfTerminalType			termType)
{
	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(termType);
	
	return RV_OK;
}

/*@*****************************************************************************
 * rvMtfSampleStopPhysicalDeviceCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaStopPhysicalDeviceEv().
 *			This callback is called when application is required to stop an
 *			audio device (Handset, Speaker or headset). This callback is currently
 *			not called at all. Application should stop all audio devices after shutting
 *			down MTF.
 *			In this implementation we do first check which type of terminal should be stopped,
 *			and send EPP message to GUI for stopping the device. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			termType		- Type of the terminal, indicating which device application
 *							  should stop, audio or video device.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RvStatus RVCALLCONV rvMtfSampleStopPhysicalDeviceCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
				RvMtfTerminalType			termType)
{
    RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(termType);
	
	return RV_OK;
}

/*@*****************************************************************************
 * rvMtfSampleModifyMediaCompletedCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaModifyStreamDuringCallCompletedEv().
 *			This callback is called when a process of modifying media during a connected
 *			call is completed (dynamic media change). The process may be initiated by local party or remote party.
 *			The callback indicates the result of the process, whether it was succeeded or failed,
 *			and the reason for the failure.
 *			During a process of dynamic media change, application should keep both the old
 *			media stream and the new media stream open (meaning, listen on both sockets).
 *			If process was completed successfully, application should close the old media
 *			stream and leave the new one open. If process failed, application should close
 *			the new stream and leave the old one open.
 *			In this implementation we just print to log. Application may add here its own
 *			implementation.
 *
 * Arguments:
 *
 * Input:	hTerm				- Handle to terminal on which media was modified.
 *			hAppTermSource		- Handle to application data associated with the terminal.
 *			status				- Status of the process.
 *			sdpMsg				- SDP message containing the new media parameters.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
void RVCALLCONV rvMtfSampleModifyMediaCompletedCB(
					   RvIppTerminalHandle				hTerm,
					   RvMtfTerminalAppHandle			hAppTerm,
					   RvMtfDynamicModifyMediaStatus	status,
					   RvSdpMsg*						sdp)
{
	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(status);
	RV_UNUSED_ARG(sdp);
	
}


/*===============================================================================*/
/*=============    C A L L B A C K		I M P L M E N T A T I O N S  ============*/
/*===============================================================================*/

/* This function is an implementation of callback....
It checks if the dialed phone numbers is in the list of phone numbers */
RvStatus RVCALLCONV rvMtfSampleMapDialStringToAddressCB(
											 IN  RvIppTerminalHandle		hTerm,
											 IN  RvMtfTerminalAppHandle		hAppTerm,
											 IN  RvChar*					dialString,
											 OUT RvChar*					address)
{

	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(dialString);
	RV_UNUSED_ARG(address);

	return RV_ERROR_NOT_FOUND;
}

/******************************************************************************
*  rvMtfSampleStartSignalCB
* -----------------------------------------------------------------------------
*  General :    This is an implementation of callback RvMtfStartSignalEv().
*				This callback is called by MTF when application is required to
*				update terminal interface, by applying a tone or indicator.
*				For example: start playing dial tone, turn on/off Hold indicator,  etc.
*				Note:
*				Some signals are stopped by calling this callback and not by calling
*				RvMtfStopSignalEv, see signal state.
*				In this implementation we send EPP message to GUI for starting the signal.
*				Application should call directly its own system for starting the signal instead.
*
*  Arguments:
*  Input:          hTerm		- Handle to terminal
*                  signalType   - type of signal
*				   signalState	- state of signal
*				   signalParams	- signal parameters
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV rvMtfSampleStartSignalCB(
                RvIppTerminalHandle	    hTerm,
			    RvMtfTerminalAppHandle  hAppTerm,
                RvMtfSignalType		    signalType,
                RvMtfSignalState        signalState,
                RvMtfSignalParams*		signalParams)
{
	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(signalParams);
	RV_UNUSED_ARG(signalState);

	switch (signalType)
    {
		case RV_MTF_SIGNAL_DIALTONE:
		//	rvMtfGuiStartDialTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGBACK:
		//	rvMtfGuiStartRingbackTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGING:
	//		rvMtfGuiStartRingingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLER:
	//		rvMtfGuiStartCallWaitingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLEE:
	//		rvMtfGuiStartCallWaitingCalleeTone(ece);
			break;
		case RV_MTF_SIGNAL_BUSY:
	//		rvMtfGuiStartBusyTone(ece);
			break;
		case RV_MTF_SIGNAL_WARNING:
	//		rvMtfGuiStartWarningTone(ece);
			break;
        case RV_MTF_SIGNAL_DIGIT:
      //      rvMtfGuiStartDigitTone(ece, signalParams->digit);
            break;
        case RV_MTF_SIGNAL_IND_LINE:
      //      rvMtfGuiSetLineIndicator(ece, signalState, signalParams->lineId);
            break;
        case RV_MTF_SIGNAL_IND_HOLD:
        //    rvMtfGuiSetHoldIndicator(ece, signalState);
            break;
        case RV_MTF_SIGNAL_IND_MUTE:
          //  rvMtfGuiSetMuteIndicator(ece, signalState);
            break;
        case RV_MTF_SIGNAL_IND_HANDSFREE:
    //        rvMtfGuiSetSpeakerIndicator(ece, signalState);
            break;
        case RV_MTF_SIGNAL_IND_HEADSET:
     //       rvMtfGuiSetHeadsetIndicator(ece, signalState);
            break;
		default:
			IppLogMessage(RV_TRUE,"rvMtfSampleStartSignalCB() - unknown signal type = %d", signalType);
			break;
		}
}

/******************************************************************************
*  rvMtfSampleStopSignalCB
* -----------------------------------------------------------------------------
*  General :    This is an implementation of callback RvMtfStopSignalEv().
*				This callback is called by MTF when application is required to
*				update terminal interface, by stop playing a tone or indicator.
*				For example: stop playing dial tone,  etc.
*				In this implementation we send EPP message to GUI for stopping the signal.
*				Application should call directly its own system for stopping the signal instead.
*
*  Arguments:
*  Input:          hTerm		- Handle to terminal
*                  signalType   - type of signal
*				   signalState	- state of signal
*				   signalParams	- signal parameters
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV rvMtfSampleStopSignalCB(
					RvIppTerminalHandle		hTerm,
					RvMtfTerminalAppHandle  hAppTerm,
					RvMtfSignalType			signal)
{
	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);

	switch (signal)
    {
		case RV_MTF_SIGNAL_DIALTONE:
	//		rvMtfGuiStopDialTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGBACK:
	//		rvMtfGuiStopRingbackTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGING:
	//		rvMtfGuiStopRingingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLER:
	//		rvMtfGuiStopCallWaitingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLEE:
//			rvMtfGuiStopCallWaitingCalleeTone(ece);
			break;
		case RV_MTF_SIGNAL_BUSY:
//			rvMtfGuiStopBusyTone(ece);
			break;
		case RV_MTF_SIGNAL_WARNING:
	//		rvMtfGuiStopWarningTone(ece);
			break;
		default:
			IppLogMessage(RV_TRUE,"rvMtfSampleStopSignalCB() - unknown signal type = %d", signal);
		}
}

/****************************************************************************
*  rvMtfSamplePreProcessEventCB() 
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPreProcessEventEv().
* This implementation resets GUI interface when termination re-registers 
* (by processing GW_ACTIVE event).
* Also it demonstrates several new functionalities to be added by application 
* (some of the code is commented out).
*****************************************************************************/
void RVCALLCONV rvMtfSamplePreProcessEventCB(
											 IN     RvIppConnectionHandle   hConn,
											 IN		RvMtfConnAppHandle		hConnApp,
											 IN		RvMtfConnectionState	connState,
											 IN		RvMtfEvent				eventId,
											 OUT	RvMtfEvent*				newEventId,
											 INOUT  RvMtfReason*			reason)
{
	RV_UNUSED_ARG(hConn);
	RV_UNUSED_ARG(hConnApp);
	RV_UNUSED_ARG(connState);	
	RV_UNUSED_ARG(newEventId);
	RV_UNUSED_ARG(reason);

	switch (eventId)
    {
		
		  case RV_CCTERMEVENT_MAKECALL:
		
			printf("makecall\r\n");
// 		  *reason  = RV_CCCAUSE_CALL_CANCELLED;
// 		  *newEventId = RV_CCTERMEVENT_REJECTCALL;
// 		  return;
		  break;

		  default:
			  break;
    }
}

/****************************************************************************
*  rvMtfSamplePostProcessEventCB() 
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPostProcessEventEv().
* This implementation demonstrates several new functionalities to be added by  
* application (some of the code is commented out).
*****************************************************************************/
void RVCALLCONV rvMtfSamplePostProcessEventCB(
											  IN  RvIppConnectionHandle   hConn,
											  IN	RvMtfConnAppHandle		hConnApp,
											  IN	RvMtfConnectionState	connState,
											  IN  RvMtfEvent		        eventId,
											  IN  RvMtfReason				reason)
{
	RV_UNUSED_ARG(hConn);
	RV_UNUSED_ARG(hConnApp);
	RV_UNUSED_ARG(connState);
	RV_UNUSED_ARG(reason);

	switch (eventId)
    {
		  case RV_CCTERMEVENT_MAKECALL:
			  printf("makecall\r\n");
// 			  *reason  = RV_CCCAUSE_CALL_CANCELLED;
// 			  *newEventId = RV_CCTERMEVENT_REJECTCALL;
// 			  return;
			  break;

		  default:
			  break;
    }
}

/*===============================================================================*/
/*=============   S A M P L E	C O N S T R U C T / D E S T R U C T  ============*/
/*===============================================================================*/

RvStatus rvMtfSampleConstruct()
{
    IppLogSourceFilterElm   ippLogOptions[30];
    RvIppSipPhoneCfg        cfg;
    RvMtfMdmClbks	        mdmClbks;
    RvMtfMediaClbks         mediaClbks;
	RvMtfCallControlClbks	mdmExtClbks;
	RvSdpParseStatus		status;
	RvSdpMsg				sdpMsg;
    RvInt					sdpBufferLen = 0;	
    RvStatus                rv;
RvChar sdpBuffer[] = {
	"v=0\no=rtp/1 0 0 IN IP4 $\ns=- c=IN IP4 $t=0 0\nm=audio $ RTP/AVP 0\na=ptime:20\na=SilenceSupp:on\0"
	};

    /* ------------------ */
    /* Initialize Logger  */
    /* ------------------ */

    memset(ippLogOptions, 0, sizeof(ippLogOptions));

    /* Load logging configuration from buffer */
 //   rvMtfSampleUtilLoadMtfLogOptions(ippLogOptions, 30, configBuf);

    /* Initialize log before we do anything else*/
	rv = IppLogInit(ippLogOptions, MTF_LOG_PATH);
    if (rv != RV_OK)
	{
		printf("rvMtfSampleConstruct() - failed to initialize logger, status=%d\n", rv);
        return rv;
	}

    /* --------------------------------- */
    /* Load MF configuration parameters */
    /* --------------------------------- */
    /* Initialize Media configuration structure with default values*/
 //   rvMtfMediaInitConfig( &sampleParams->mediaParam);

    /* ---------------------- */
    /* Initialize MTF         */
    /* ---------------------- */

	rvMtfInitConfig(&cfg);

	cfg.localAddress = LOCAL_ADDRESS;
	cfg.stackUdpPort = LOCAL_PORT;
	cfg.stackTcpPort = LOCAL_PORT;
	cfg.userDomain = "bob";
	cfg.autoAnswer = RV_TRUE;

	rv = rvMtfSipConstruct(&g_hMtf, &cfg);
    if (rv != RV_OK)
    {
        printf("rvMtfSampleConstruct() - failed to construct MTF, status=%d\n", rv);
        return rv;
    }

	/* ----------------------- */
	/* Get handle to SIP stack */
	/* ----------------------- */
	rvMtfGetSipStackHandle(g_hMtf, &g_hSipStack);

    /* ----------------------- */
    /* Load Media Capabilities */
    /* ----------------------- */

	sdpBufferLen = strlen(sdpBuffer);

    /*Load media capabilities from configuration file*/
	rvSdpMsgConstructParse(&sdpMsg, sdpBuffer, &sdpBufferLen, &status);

    rv = rvMtfLoadMediaCapabilities(g_hMtf, &sdpMsg);
	if (rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "rvMtfSampleConstruct() - failed to load media capabilities to MTF, status=%d", rv);
        return rv;
    }

	/* ---------------------- */
    /* Register MDM callbacks */
	/* ---------------------- */

	memset(&mdmClbks, 0, sizeof(RvMtfMdmClbks));
    mdmClbks.startSignalCB = rvMtfSampleStartSignalCB;
    mdmClbks.stopSignalCB = rvMtfSampleStopSignalCB;
//    mdmClbks.mapDialStringToAddressCB = rvMtfSampleMapDialStringToAddressCB;
	mdmClbks.mapAddressToTerminationCB = NULL; /* We will use MTF default for this one. */

    rvMtfRegisterMdmCallbacks(g_hMtf, &mdmClbks);

	/* ------------------------ */
    /* Register media callbacks */
	/* ------------------------ */

	memset(&mediaClbks, 0, sizeof(RvMtfMediaClbks));
    mediaClbks.createMediaStreamCB = rvMtfSampleCreateMediaCB;
    mediaClbks.modifyMediaStreamCB = rvMtfSampleModifyMediaCB;
    mediaClbks.destroyMediaStreamCB = rvMtfSampleDestroyMediaCB;
    mediaClbks.connectMediaCB = rvMtfSampleConnectMediaCB;
    mediaClbks.disconnectMediaCB = rvMtfSampleDisconnectMediaCB;
    mediaClbks.modifyMediaCompletedCB = rvMtfSampleModifyMediaCompletedCB;
    mediaClbks.startPhysicalDeviceCB = rvMtfSampleStartPhysicalDeviceCB;
    mediaClbks.stopPhysicalDeviceCB = rvMtfSampleStopPhysicalDeviceCB;

    rvMtfRegisterMediaCallbacks(g_hMtf, &mediaClbks);

	/* ---------------------------------------- */
    /* Register MDM Extension Control callbacks */
	/* ---------------------------------------- */
	
	memset(&mdmExtClbks, 0, sizeof(RvMtfCallControlClbks));
    mdmExtClbks.preProcessEventCB = rvMtfSamplePreProcessEventCB;
    mdmExtClbks.postProcessEventCB = rvMtfSamplePostProcessEventCB;
	
    rvMtfRegisterMdmExtCallbacks(&mdmExtClbks);

return RV_OK;
}


void rvMtfSampleDestruct()
{

	/* Let current processing finish. */
    IppThreadSleep(1,0);

	/* Stop processing events. */
    rvMtfStop(g_hMtf);

	/* Release all resources. */
    rvMtfSipDestruct(g_hMtf);

}








