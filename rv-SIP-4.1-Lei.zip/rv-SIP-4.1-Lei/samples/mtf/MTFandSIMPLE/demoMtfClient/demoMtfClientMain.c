/******************************************************************************
Filename:    demoMtfClientMain.c
Description: This file contains the main() function for MTF sample application.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"
#include "ippthread.h"
#include "demoMtfClient.h"
#include "rvsdp.h"
#include "rvthread.h"
#include "rvmtfalloc.h"
#include "rvMtfHandles.h"
#include "rvMtfBaseTypes.h"
#include "rvMtfBaseApi.h"
#include "rvMdmControlApi.h"

/*============================================================================================*/
/*=================================   G L O B A L S  =========================================*/
/*============================================================================================*/

extern RvMtfHandle			g_hMtf;
extern RvSipStackHandle	g_hSipStack;

#define DESTINATION_ADDRESS		"sip:bob@127.0.0.1"


/*============================================================================================*/
/*=======================   S T A R T / E N D		F U N C T I O N S ========================*/
/*============================================================================================*/

RvStatus rvMtfSampleStart(void)
{
    RvStatus    rv;
	RvIppTerminalHandle			hTerm;

 	/* Initialize MTF and sample application */
	/* ------------------------------------ */
	printf("Initializing MTF...\r\n");
	rvMtfSystemInit();
    rv = rvMtfSampleConstruct();
	if (rv != RV_OK)
    {
        printf("rvMtfSampleStart() - ERROR: failed to initialize MTF, status = %d\n", rv);
        return rv;
    }
	
	/* Start MTF */
	/* --------- */
    rvMtfStart(g_hMtf);

	printf("MTF was initialized successfully!\r\n");


	/* Register terminations */
	/* --------------------- */
	rvMtfRegisterIPPhoneTerminations(g_hMtf, "bob", NULL, &hTerm);

	/* Set terminal configuration with default values */
//	rvMtfTerminationInitConfig(&termConfig);

//	rvMtfRegisterAnalogTermination(g_hMtf, "bob", &termConfig, NULL, &hTermDestination);

	/* Disconnect Call */
	/* --------------- */

//	rvMtfSendKeyEvent(hTermSource, RV_CCTERMEVENT_ONHOOK, NULL);

//	rvMtfUnegisterIPPhoneTerminations(hTermSource);
//	rvMtfUnregisterAnalogTermination(hTermDestination);

	getchar();

    return rv;
}

void rvMtfSampleEnd(void)
{
	/* Destruct MTF and sample application */
	/* ----------------------------------- */
    rvMtfSampleDestruct();
    rvIppSipSystemEnd();
}
/*============================================================================================*/
/*=======================   M A I N		F U N C T I O N  =====================================*/
/*============================================================================================*/

#if (RV_OS_TYPE != RV_OS_TYPE_WINCE)
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int MtfSipSample(int argc)
#else
int main(int argc, char **argv)
#endif
{
    RvStatus    status = RV_OK;
	RvTime st;
	
	RvTimeConstruct(10, 0, &st);

	RV_UNUSED_ARG(argc);

#if (RV_OS_TYPE != RV_OS_TYPE_VXWORKS)
	RV_UNUSED_ARG(argv);
#endif

    /* Run MTF for the first time */
    if ((status = rvMtfSampleStart()) != RV_OK)
    {
        printf("*******rvMtfSampleStart error = %d*******\n", status);
        return status;
    }

	while (1)
	{
		/* Sleep (10); */
		RvThreadSleep(&st, NULL); 
	}
	
    /* Shut down MTF*/
    rvMtfSampleEnd();

    return 0;
}
#endif
/*============================================================================================*/
/*=========================== V X W O R K S  =================================================*/
/*============================================================================================*/

/* In vxWorks we can either call vxMain() with no arguments for running application from seperated
   process (so we don't block the shell), or we can call MtfSipSample() directly
   (and block the shell) with one argument: number of warm restarts*/
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int vxMain()
{
    taskSpawn("User IPP",100,0,100000, MtfSipSample, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return 0;

}
#endif /*(RV_OS_TYPE_VXWORKS)*/

