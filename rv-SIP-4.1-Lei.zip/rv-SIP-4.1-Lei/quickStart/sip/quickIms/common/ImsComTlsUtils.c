/*********************************************************************************
 *                              <ImsUETls.c>
 * 
 *   This file implements functionality for enabling TLS connections
 *   and reacting to TLS events. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Dikla Dror Behr              July 2008
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON

#if (RV_TLS_TYPE != RV_TLS_NONE)
/* Please note: In this application we use openSSL functions to load certificates and keys to TLS engines.
   This is the reason than we include openSSL h file. The location of openSSL include directory and
   lib files should be predefined. Please also note that this application links with openSSL lib
   files libeay32.lib and ssleay32.lib */
#include <openssl/ssl.h>
#endif 

#include "ImsComTlsUtils.h"
#include "ImsComDefs.h"
#include "ImsComUtils.h"

/*-----------------------------------------------------------------------*/
/*                        STATIC VARIABLES                               */
/*-----------------------------------------------------------------------*/

/* Handle to the server TLS engine. that engine holds the key and will provide a
   matching certificate on demand */
static RvSipTransportTlsEngineHandle g_hTlsServerEngine;

/* Handle to the client TLS engine. that engine will be loaded with a certificate
   authority certificate and will be responsible to verify any incoming certificate */
static RvSipTransportTlsEngineHandle g_hTlsClientEngine;

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the transport manager. */
extern RvSipTransportMgrHandle g_hTransportMgr;


/*-----------------------------------------------------------------------*/
/*                          TLS CONTROL								     */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppInitTlsSecurity
 * ------------------------------------------------------------------------
 * General: Initializing Tls security: in this function we use openSSL to load
 * the certificates and key, there for the files are built in a format openSSL
 * recognizes. Keys and certificates can be read with different function
 * and than be passed to the engine configuration struct.
 * Constructs two TLS engines a client engine and a server engine.
 * The Server engine is the server that holds a private key and a matching certificate.
 * The client engine holds a certificate of a trusted entity (certificate authority).
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * 
 ***************************************************************************/
void RVCALLCONV AppInitTlsSecurity()
{
#if (RV_TLS_TYPE != RV_TLS_NONE)
    RvStatus                      rv                        = RV_OK;
    BIO                          *inKey                     = NULL;
    BIO                          *inCert                    = NULL;
    EVP_PKEY                     *pkey                      = NULL;
    X509                         *x509                      = NULL;
    RvSipTransportTlsEngineCfg    TlsEngineCfg;
    RvChar                        privKey[MAX_STRING_SIZE]  = {'\0'};
    unsigned char                *keyEnd                    = (unsigned char*)privKey;
    RvInt                         privKeyLen                = 0;
    RvChar                        cert[MAX_STRING_SIZE]     = {'\0'};
    unsigned char                *certEnd                   = (unsigned char*)cert;
    RvInt                         certLen                   = 0;

    memset(&TlsEngineCfg,0,sizeof(TlsEngineCfg));

    /* Loading the key for the server engine */
    inKey=BIO_new(BIO_s_file_internal());
    if (BIO_read_filename(inKey,SERVER_KEY_N_CERT_FILE) <= 0)
    {
        AppExitOnError("Can not load key");
    }

    pkey=PEM_read_bio_PrivateKey(inKey,NULL,NULL,NULL);

    privKeyLen = i2d_PrivateKey(pkey,NULL);
    privKeyLen = i2d_PrivateKey(pkey,&keyEnd);
    BIO_free(inKey);

    /* Loading the certificate for the server engine*/
    inCert=BIO_new(BIO_s_file_internal());
    if (BIO_read_filename(inCert,SERVER_KEY_N_CERT_FILE) <= 0)
    {
        AppExitOnError("Can not load certificate");
    }

    x509=PEM_read_bio_X509(inCert,NULL,NULL,NULL);

    certLen = i2d_X509(x509,NULL);
    certLen = i2d_X509(x509,&certEnd);
    BIO_free(inCert);

    /* Initializing the configuration struct for the server engine */
    TlsEngineCfg.eTlsMethod         = RVSIP_TRANSPORT_TLS_METHOD_TLS_V1;
    TlsEngineCfg.strCert            = cert;
    TlsEngineCfg.certLen            = certLen;
    TlsEngineCfg.strPrivateKey      = privKey;
    TlsEngineCfg.privateKeyLen      = privKeyLen;
    TlsEngineCfg.ePrivateKeyType    = RVSIP_TRANSPORT_PRIVATE_KEY_TYPE_RSA_KEY;
    TlsEngineCfg.certDepth          = 5;

    /* Using the initialized configuration to build the server TLS engine */
    rv = RvSipTransportTlsEngineConstruct(g_hTransportMgr,
                                          &TlsEngineCfg,
                                          sizeof(TlsEngineCfg),
                                          &g_hTlsServerEngine);
    if (RV_OK != rv)
    {
        AppExitOnError("failed to construct TLS server engine");
    }

    /* Making sure that the private key match the certificate we installed on the engine */
    rv = RvSipTransportTlsEngineCheckPrivateKey(g_hTransportMgr,g_hTlsServerEngine);
    if (RV_OK != rv)
    {
        AppExitOnError("Key and private certificate don't match");
    }

    /* constructing the client engine */
    memset(&TlsEngineCfg,0,sizeof(TlsEngineCfg));

    /* the client engine only verifies certificates so it only needs to load TLS
       methods and the depth of the certificate chain it will allow to certify */
    TlsEngineCfg.eTlsMethod         = RVSIP_TRANSPORT_TLS_METHOD_TLS_V1;
    TlsEngineCfg.certDepth          = 5;

    /* Using the initialized configuration to build the client TLS engine */
    rv = RvSipTransportTlsEngineConstruct(g_hTransportMgr,
                                          &TlsEngineCfg,
                                          sizeof(TlsEngineCfg),
                                          &g_hTlsClientEngine);
    if (RV_OK != rv)
    {
        AppExitOnError("failed to construct TLS client engine");
    }

    /* adding the approving CA to the list of certificates */
    certEnd        = (unsigned char*)cert;
    certLen        = 0;
    x509           = NULL;
    memset(cert,0,sizeof(cert));

    /* loading certificate */
    inCert=BIO_new(BIO_s_file_internal());
    if (BIO_read_filename(inCert,CA_CERT_FILE) <= 0)
    {
        AppExitOnError("Can not load CA certificate");
    }

    x509=PEM_read_bio_X509(inCert,NULL,NULL,NULL);

    certLen = i2d_X509(x509,NULL);
    certLen = i2d_X509(x509,&certEnd);
    BIO_free(inCert);

    /* Adding a trusted certificate to the engine.
       This should be the CA that signed the certificate for the server engine */
    rv = RvSipTransportTlsEngineAddTrustedCA(g_hTransportMgr,
                                             g_hTlsClientEngine,
                                             cert,
                                             certLen);
    if (RV_OK != rv)
    {
        AppExitOnError("Can not load add CA certificate to the client engine");
    }
#else /* #if (RV_TLS_TYPE != RV_TLS_NONE) */

    AppExitOnError("Cannot initialize TLS mechanism while RV_TLS_TYPE is RV_TLS_NONE");

#endif /* #if (RV_TLS_TYPE != RV_TLS_NONE) */ 
}

/*-----------------------------------------------------------------------*/
/*                          TLS CALLBACKS								 */
/*-----------------------------------------------------------------------*/


/***************************************************************************
* AppTransportConnectionTlsStateChanged
* ------------------------------------------------------------------------
* General:  This callback is used to notify the application on TLS
*           connection state changes. This callback is called only for
*           TLS state changes and not for connection state changes.
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:   hConnection  - The handle of the connection that changed TLS state
*          eState       - The connection state
*          eReason      - The reason for the state change
***************************************************************************/
RvStatus RVCALLCONV AppTransportConnectionTlsStateChanged(
                                     IN    RvSipTransportConnectionHandle             hConnection,
                                     IN    RvSipTransportConnectionAppHandle          hAppConnection,
                                     IN    RvSipTransportConnectionTlsState           eState,
                                     IN    RvSipTransportConnectionStateChangedReason eReason)
{
    RvStatus rv   = RV_OK;
    
    switch (eState)
    {
    case RVSIP_TRANSPORT_CONN_TLS_STATE_HANDSHAKE_READY:
        {
            OSPrintf("\nconnection %p - TLS State changed to handshake ready\n", hConnection);
            /* deciding what engine to use.
            1. for clients we use the client engine.
            2. for servers we use the server engine.
            */
            if (RVSIP_TRANSPORT_CONN_REASON_CLIENT_CONNECTED == eReason)
            {
            /* Starting the handshake. Since this is the client we associate the client
                engine to the connection and specify the default verification call back*/
                rv = RvSipTransportConnectionTlsHandshake(hConnection,
                    g_hTlsClientEngine,
                    RVSIP_TRANSPORT_TLS_HANDSHAKE_SIDE_DEFAULT,
                    NULL);
            }
            else
            {
            /* Starting the handshake. Since this is the server we associate the server
            engine to the connection and do not specify a certificate verification call
            back. another option is to specify a call back and than client certificate
                will be required*/
                rv = RvSipTransportConnectionTlsHandshake(hConnection,
                    g_hTlsServerEngine,
                    RVSIP_TRANSPORT_TLS_HANDSHAKE_SIDE_DEFAULT,
                    NULL);
            }
            
            
        }
        break;
    case RVSIP_TRANSPORT_CONN_TLS_STATE_CONNECTED:
        OSPrintf("\nconnection %p - TLS State changed to TLS Connected\n", hConnection);
        break;
    case RVSIP_TRANSPORT_CONN_TLS_STATE_HANDSHAKE_FAILED:
        OSPrintf("\nconnection %p - TLS State changed to handshake failed\n", hConnection);
        break;
    case RVSIP_TRANSPORT_CONN_TLS_STATE_TERMINATED:
        OSPrintf("\nconnection %p - TLS State changed to terminated\n", hConnection);
        break;
    default:
        break;
    }
    
    RV_UNUSED_ARG(hAppConnection);

    return rv;
}

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
/***************************************************************************
* AppTransportConnectionTlsPostConnectionAssertion
* ------------------------------------------------------------------------
* General:   This callback is used to override the default post connection
 *           assertion of the Stack. Once a connection has completed the handshake, it is
 *           necessary to make sure that the certificate presented was indeed issued
 *           for the address to which the connection was made. This assertion is
 *           automatically performed by the Stack. If, for some reason, the application wishes
 *           to override a failed assertion, it can implement this callback.
 *           For example, this callback can be used to compare the host name against
 *           a predefined list of outgoing proxies.
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hConnection    - The handle of the connection that changed TLS states.
 *          hAppConnection - The application handle for the connection.
 *          strHostName    - A NULL terminated string, indicating the host name
 *                          (IP/FQDN) to which the connection was meant to connect.
 *          hMsg           - The message if the connection was asserted against a message.
 * Output: pbAsserted      - RV_TRUE if the connection was asserted successfully.
 *                           RV_FALSE if the assertion failed. In this case, the connection
 *                           will be terminated automatically.
***************************************************************************/
void RVCALLCONV AppTransportConnectionTlsPostConnectionAssertion(
                         IN    RvSipTransportConnectionHandle             hConnection,
                         IN    RvSipTransportConnectionAppHandle          hAppConnection,
                         IN    RvChar*                                    strHostName,
                         IN    RvSipMsgHandle                             hMsg,
                         OUT   RvBool*                                    pbAsserted)
{
    *pbAsserted = RV_TRUE;
}
#endif /* #if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN) */ 

#endif /* #ifdef RV_SIP_IMS_ON */
