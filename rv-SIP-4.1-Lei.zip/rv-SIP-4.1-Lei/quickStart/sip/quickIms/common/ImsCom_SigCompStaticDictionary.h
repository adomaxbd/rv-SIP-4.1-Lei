/***********************************************************************
Filename   : SigCompStaticDictionary_RFC3485.h
Description: SIP and SDP Static Dictionary for SigComp (RFC 3485) header file

    Author                         Date
    ------                        ------
    Gil Keini                     20040307
************************************************************************
      Copyright (c) 2001,2002 RADVISION Inc. and RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Inc. and RADVISION Ltd.. No part of this document may be
reproduced in any form whatsoever without written prior approval by
RADVISION Inc. or RADVISION Ltd..

RADVISION Inc. and RADVISION Ltd. reserve the right to revise this
publication and make changes without obligation to notify any person of
such revisions or changes.

***********************************************************************/

#ifndef SIGCOMP_STATICDICTIONARY_RFC3485_H
#define SIGCOMP_STATICDICTIONARY_RFC3485_H

#ifdef __cplusplus
extern "C" {
#endif
    
/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"
#ifdef RV_SIGCOMP_ON 

#include "RvSigCompTypes.h"

/*-----------------------------------------------------------------------*/
/*                   Definitions & Constants                             */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                    Static Helper Functions                            */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                    Common Functions                                   */
/*-----------------------------------------------------------------------*/

/*************************************************************************
* SigCompStaticDictionary3485Init
* ------------------------------------------------------------------------
* General: Initialize the SigComp dictionary's structure,
*           for the Static SIP & SDP Dictionary, based on RFC-3485
*
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:    hSigCompMgr   - handle to the sigComp manager
*           dictStructSize - size of the structure containing information about the dictionary
*           *pAlgStruct - pointer a structure containing information about the dictionary
*
* Output:   *pAlgStruct - The same structure with info filled in
*************************************************************************/
    
RvStatus RVCALLCONV SigCompStaticDictionary3485Init(
                                 IN    RvSigCompMgrHandle  hSigCompMgr,
                                 IN    RvUint32            dictStructSize,
                                 INOUT RvSigCompDictionary *pDictStruct);

#endif /* #ifdef RV_SIGCOMP_ON  */ 

#ifdef __cplusplus
}
#endif


#endif /* end of: SIGCOMP_STATICDICTIONARY_RFC3485_H */
