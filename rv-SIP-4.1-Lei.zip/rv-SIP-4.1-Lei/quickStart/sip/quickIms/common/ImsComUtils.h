/*********************************************************************************
 *                              <ImsComUtils.h>
 * 
 *   This file defines general utility functions for the quickstart Ims application
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif

#ifndef IMSCOM_UTILS_H
#define IMSCOM_UTILS_H

#ifdef RV_SIP_IMS_ON
#include "RvSipMsg.h"


/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/
#define CLT_SIGCOMP_ID_STR "ims-quick-clt-sigcomp-id"

/*-----------------------------------------------------------------------*/
/*                       UTILITY FUNCTIONS                               */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
void AppPrintMessage(IN RvSipMsgHandle hMsg);

/***************************************************************************
 * AppExitOnError
 * ------------------------------------------------------------------------
 * General: prints an error message and exits.
  ***************************************************************************/
void AppExitOnError(RvChar* str);

#endif /* #ifdef RV_SIP_IMS_ON */

/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Implementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameters according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
int OSPrintf(IN const char *format,... );

#endif /* #ifndef IMSCOM_UTILS_H */

