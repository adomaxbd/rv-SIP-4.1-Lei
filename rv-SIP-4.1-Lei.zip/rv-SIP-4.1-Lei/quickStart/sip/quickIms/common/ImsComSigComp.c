/*********************************************************************************
 *                              <ImsComSigComp.c>
 * 
 *   This file implements SigComp utility functions to enable sigcomp
 *   compression in outgoing messages. SigComp is used by 3GPP to compress
 *   messages sent upon ipsec security-associations
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#ifdef RV_SIGCOMP_ON
#include "RvSigComp.h"
#include "ImsCom_SigCompAlgorithmNull.h"
#include "ImsCom_SigCompStaticDictionary.h"
#include "ImsComUtils.h"
#include "RvSipStack.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*Handle to the stack manager. */
extern RvSipStackHandle  g_hStackMgr;

/*Handle to the application log-module. */
extern RV_LOG_Handle         g_hLog;

/*-----------------------------------------------------------------------*/
/*                    STATIC FUNCTIONS PROTOTYPES                        */
/*-----------------------------------------------------------------------*/

static RvStatus AppInitSigCompNullAlgorithm(IN RvSigCompMgrHandle hSigCompMgr);

static RvStatus AppInitSigCompDictionary(IN RvSigCompMgrHandle hSigCompMgr);

/*-----------------------------------------------------------------------*/
/*                      SIGCOMP UTILITY FUNCTIONS                        */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppInitSigComp
 * ------------------------------------------------------------------------
 * General: Initializes the SigComp module, which is an external dll and
 *          enable the compression and decompression of SIP messages.
 * Return Value: RV_OK - if successful. error code o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 * Output:  (-)
 ***************************************************************************/
RvStatus AppInitSigComp(void)
{
    RvStatus             rv;
    RvSigCompCfg         sigCompCfg;
    RvSigCompMgrHandle   hSigCompMgr;

    memset(&sigCompCfg,0,sizeof(sigCompCfg));
    RvSigCompInitCfg(sizeof(sigCompCfg), &sigCompCfg);

    sigCompCfg.logHandle = g_hLog;
    rv = RvSigCompConstruct(sizeof(RvSigCompCfg),&sigCompCfg, &hSigCompMgr);
    if (rv != RV_OK)
    {
        OSPrintf("Failure in SigComp module construction\n");
        return rv;
    }

    /* NULL compression algorithm is used */
    rv = AppInitSigCompNullAlgorithm(hSigCompMgr);
    if (rv != RV_OK)
    {
        return rv;
    }

    rv = AppInitSigCompDictionary(hSigCompMgr);
    if (rv != RV_OK)
    {
        return rv;
    }

    /* Store the SigComp manager handle in the stack */
    rv = RvSipStackSetSigCompMgrHandle(g_hStackMgr,hSigCompMgr);
    if (rv != RV_OK)
    {
        OSPrintf("Failure in setting the SigComp mgr in Stack\n");
        return rv;
    }

    return rv;
}


/*-----------------------------------------------------------------------*/
/*                            STATIC  FUNCTIONS                          */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppInitSigCompNullAlgorithm
 * ------------------------------------------------------------------------
 * General: Initialize a NULL compression algorithm in the SigComp manager
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSigCompMgr - The initialized SigComp manager handle.
 * Output:  (-)
 ***************************************************************************/
static RvStatus AppInitSigCompNullAlgorithm(IN RvSigCompMgrHandle hSigCompMgr)
{
    RvStatus             rv;
    RvSigCompAlgorithm   sigCompAlg;

    rv = SigCompAlgNullInit(hSigCompMgr, sizeof(sigCompAlg), &sigCompAlg);
    if (rv != RV_OK)
    {
        OSPrintf("Failure during initialization of SigComp NULL Compression Algorithm\n");
        return rv;
    }
    /* Add the algorithm to the algorithms list */
    rv = RvSigCompAlgorithmAdd(hSigCompMgr, &sigCompAlg);
    if (rv != RV_OK)
    {
        OSPrintf("Failure during the addition of SigComp NULL Compression Algorithm\n");
        return rv;
    }

    return RV_OK;
}

/***************************************************************************
 * AppInitSigCompDictionary
 * ------------------------------------------------------------------------
 * General: Initialize a dictionary in the SigComp manager
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSigCompMgr - The initialized SigComp manager handle.
 * Output:  (-)
 ***************************************************************************/
static RvStatus AppInitSigCompDictionary(IN RvSigCompMgrHandle hSigCompMgr)
{
    RvStatus             rv;
    RvSigCompDictionary  staticDictStruct;

    rv = SigCompStaticDictionary3485Init(hSigCompMgr,
                                         sizeof(staticDictStruct),
                                         &staticDictStruct);
    if(rv != RV_OK)
    {
        OSPrintf("Failure during initialization of SigComp dictionary\n");
        return rv;
    }

    rv = RvSigCompDictionaryAdd(hSigCompMgr, &staticDictStruct);
    if(rv != RV_OK)
    {
        OSPrintf("Failure in RvSigCompDictionaryAdd()\n");
        return rv;
    }

    return RV_OK;
}

/***************************************************************************
 * AppGetMsgCompTypeName
 * ------------------------------------------------------------------------
 * General: Returns the message compression type as a string.
 * Return Value: The string which represents message compression type name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eMsgCompType - The message compression type as enum
 ***************************************************************************/
const RvChar* AppGetMsgCompTypeName(
                        IN RvSipTransmitterMsgCompType eMsgCompType)
{
    switch(eMsgCompType)
    {
    case RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNCOMPRESSED:
        return "Uncompressed Message";
    case RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED:
        return "SigComp Compressed Message";
    case RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED_INCLUDE_BYTECODE:
        return "SigComp Compressed Message including Bytecode";
    default:
        return "Undefined";
    }
}

#endif /* RV_SIGCOMP_ON */
#endif /* RV_SIP_IMS_ON */
