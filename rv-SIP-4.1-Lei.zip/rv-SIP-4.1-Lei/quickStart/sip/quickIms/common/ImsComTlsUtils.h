/*********************************************************************************
 *                              <ImsUETls.c>
 * 
 *   This file implements functionality for enabling TLS connections
 *   and reacting to TLS events. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Dikla Dror Behr              July 2008
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSCOM_TLS_H
#define IMSCOM_TLS_H

#ifdef RV_SIP_IMS_ON

#include "RvSipTransport.h"

/*-----------------------------------------------------------------------*/
/*                          TLS CONTROL								     */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppInitTlsSecurity
 * ------------------------------------------------------------------------
 * General: Initializing Tls security: in this function we use openSSL to load
 * the certificates and key, there for the files are built in a format openSSL
 * recognizes. Keys and certificates can be read with different function
 * and than be passed to the engine configuration struct.
 * Constructs two TLS engines a client engine and a server engine.
 * The Server engine is the server that holds a private key and a matching certificate.
 * The client engine holds a certificate of a trusted entity (certificate authority).
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * 
 ***************************************************************************/
void RVCALLCONV AppInitTlsSecurity(); 

/*-----------------------------------------------------------------------*/
/*                          TLS CALLBACKS								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
* AppTransportConnectionTlsStateChanged
* ------------------------------------------------------------------------
* General:  This callback is used to notify the application on TLS
*           connection state changes. This callback is called only for
*           TLS state changes and not for connection state changes.
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:   hConnection  - The handle of the connection that changed TLS state
*          eState       - The connection state
*          eReason      - The reason for the state change
***************************************************************************/
RvStatus RVCALLCONV AppTransportConnectionTlsStateChanged(
                                     IN    RvSipTransportConnectionHandle             hConnection,
                                     IN    RvSipTransportConnectionAppHandle          hAppConnection,
                                     IN    RvSipTransportConnectionTlsState           eState,
                                     IN    RvSipTransportConnectionStateChangedReason eReason); 

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
/***************************************************************************
* AppTransportConnectionTlsPostConnectionAssertion
* ------------------------------------------------------------------------
* General:   This callback is used to override the default post connection
 *           assertion of the Stack. Once a connection has completed the handshake, it is
 *           necessary to make sure that the certificate presented was indeed issued
 *           for the address to which the connection was made. This assertion is
 *           automatically performed by the Stack. If, for some reason, the application wishes
 *           to override a failed assertion, it can implement this callback.
 *           For example, this callback can be used to compare the host name against
 *           a predefined list of outgoing proxies.
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hConnection    - The handle of the connection that changed TLS states.
 *          hAppConnection - The application handle for the connection.
 *          strHostName    - A NULL terminated string, indicating the host name
 *                          (IP/FQDN) to which the connection was meant to connect.
 *          hMsg           - The message if the connection was asserted against a message.
 * Output: pbAsserted      - RV_TRUE if the connection was asserted successfully.
 *                           RV_FALSE if the assertion failed. In this case, the connection
 *                           will be terminated automatically.
***************************************************************************/
void RVCALLCONV AppTransportConnectionTlsPostConnectionAssertion(
                         IN    RvSipTransportConnectionHandle             hConnection,
                         IN    RvSipTransportConnectionAppHandle          hAppConnection,
                         IN    RvChar*                                    strHostName,
                         IN    RvSipMsgHandle                             hMsg,
                         OUT   RvBool*                                    pbAsserted)
{
    *pbAsserted = RV_TRUE;
}
#endif /* (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN) */ 

#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSCOM_TLS_H */

