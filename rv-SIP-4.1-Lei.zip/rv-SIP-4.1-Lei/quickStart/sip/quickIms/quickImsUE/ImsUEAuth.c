/*********************************************************************************
 *                              <ImsUEAuth.c>
 * 
 *   This file implements functionality for performing Aka authentication to the server,
 *   and reacting to authentication events. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                 June 2006
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#include "RvSipMid.h"
#include "RvSipAuthenticator.h"
#include "RvSipAuthenticationHeader.h"
#include "ImsUEAuth.h"
#include "ImsComDefs.h"
#include "ImsComUtils.h"
#include "ImsCom_md5c.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/*-----------------------------------------------------------------------*/
/*                          AUTH CONTROL								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************************
* AppClientGenerateClientAV
* -------------------------------------------------------------------------------------
* General:  This function generates the Authentication Vector for the client side.
*           1. Get the Authentication header from the given authentication object.
*           2. Extract the RAND and AUTN values from the nonce value in the Authentication
*              header.
*           3. Generate the Authentication Vector, using RAND and the shared secret USER_PW.
* Return Value: RvStatus.
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  hAuthObj - Handle to the authentication object.
**************************************************************************************/
RvStatus AppClientGenerateClientAV( IN RvSipAuthObjHandle hAuthObj)
{
    RvStatus rv;
    RvSipAuthenticationHeaderHandle hAuthHeader;
    RvBool  bValid;
    RvUint8 givenRAND[AKA_RAND_LEN+1]; /* +1 for null termination */
    RvUint8 givenAUTN[AKA_AUTN_LEN+1]; /* +1 for null termination */
    RvBool  bCorrectMacInAutn;
    RvUint8 Key[USER_KEY_LEN];
    
    /* Get the authentication header from the auth-object
       -------------------------------------------------- */
    rv = RvSipAuthObjGetAuthenticationHeader(hAuthObj, &hAuthHeader, &bValid);
    if(rv != RV_OK || RV_FALSE == bValid)
    {
        OSPrintf("\nFailed to get authentication header from authObj 0x%p bValid=%d\n", 
                    hAuthObj, bValid);
        return RV_ERROR_NOT_FOUND;
    }

    /* Extract the RAND and AUTN values from the header nonce value.
       ------------------------------------------------------------- */
    memset(givenAUTN, 0, sizeof(givenAUTN));
    memset(givenRAND, 0, sizeof(givenRAND));

    rv = AppClientGetRandAndAutnFromHeader(hAuthHeader, givenRAND, givenAUTN);
    if(rv != RV_OK)
    {
        OSPrintf("\nFailed to get RAND and AUTN from authObj 0x%p\n", hAuthObj);
        return RV_ERROR_NOT_FOUND;
    }

    /* Convert the saved password to Key (16 bytes buffer)
       --------------------------------------------------- */
    memset (Key, 0, USER_KEY_LEN);
    memcpy((void*)Key, (void*)USER1_PW, RvMin(strlen(USER1_PW), USER_KEY_LEN));

    /* Generate the AV 
       ------------------------------- */
    AkaCreateClientRES(givenRAND, Key, givenAUTN, &g_ImsUE.g_ClientAkaAV, &bCorrectMacInAutn);
    
    return RV_OK;
}

/***************************************************************************
 * AppClientGetRandAndAutnFromHeader
 * ------------------------------------------------------------------------
 * General:  Gets the nonce value from authentication header.
 *           Decode it base 64, and break it into AUTN and RAND strings.
 * Return Value: RV_OK - if successful. error code o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * input   : hAuthHeader - The Authentication header.
 * output  : pRAND - pointer to the RAND buffer.
 *           pAUTN - pointer to the AUTN buffer.
 ***************************************************************************/
RvStatus AppClientGetRandAndAutnFromHeader(IN  RvSipAuthenticationHeaderHandle hAuthHeader,
                                           OUT RvUint8 *pRAND,
                                           OUT RvUint8 *pAUTN)
{
    RvUint8 nonce[150];
    RvInt   len;
    RvStatus rv;
    RvUint8 nonceDecodeB64[AKA_RAND_LEN+AKA_AUTN_LEN];

    /* Get the nonce value from authentication header. */
    rv = RvSipAuthenticationHeaderGetNonce(hAuthHeader, (RvChar*)nonce, 150, (RvUint*)&len);
    if(rv != RV_OK)
    {
        OSPrintf("\nNo nonce in AppClientGetRandAndAutnFromHeader\n");
        return RV_ERROR_NOT_FOUND;
    }

    /* Give the decode function, the nonce string without the quotation marks:
       giving nonce+1 -> skip the first mark.
       giving len-2   -> don't reach the second mark. */
    len = RvSipMidDecodeB64(nonce+1, len-2, nonceDecodeB64, AKA_RAND_LEN+AKA_AUTN_LEN);

    /* Break the nonce string to RAND and AUTN */
    memcpy(pRAND, nonceDecodeB64, AKA_RAND_LEN);
    memcpy(pAUTN, nonceDecodeB64 + AKA_RAND_LEN, AKA_AUTN_LEN);
    return RV_OK;
}


/*-----------------------------------------------------------------------*/
/*                          AUTH CALLBACKS								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientAuthenticationGetSharedSecretEv
 * ------------------------------------------------------------------------
 * General: This callback function is called when the stack builds the 
 *          Authorization header, using the received WWW-Authenticate header.
 *          The client should supply the user-name and password.
 *          If the server required AKA authentication, the client should 
 *          supply the RES parameter from the Authentication-Vector, and not 
 *          its plain password.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator    - Handle to the authenticator object.
 *          hAppAuthenticator - Handle to the application authenticator handle.
 *          hObject           - handle to the Object, that is served
 *                              by the Authenticator (e.g. CallLeg, RegClient)
 *          peObjectType      - pointer to the variable, that stores type of
 *                              the Object. Use following code to get the type:
 *                              RvSipCommonStackObjectType eObjType = *peObjectType;
 *          pRpoolRealm       - the realm string in RPool_ptr format
 * Output:  pRpoolUserName    - the user-name string in RPool_ptr format
 *          pRpoolPassword    - the password string in RPool_ptr format
 ***************************************************************************/
void RVCALLCONV AppClientAuthenticationGetSharedSecretEv(
                                   IN  RvSipAuthenticatorHandle       hAuthenticator,
                                   IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                   IN  void*                          hObject,
                                   IN  void*                          peObjectType,
                                   IN  RPOOL_Ptr                     *pRpoolRealm,
                                   INOUT RPOOL_Ptr                   *pRpoolUserName,
                                   OUT RPOOL_Ptr                     *pRpoolPassword)
{
    /*copy the username + '\0' to the given page*/
    RPOOL_AppendFromExternalToPage(pRpoolUserName->hPool,
                                   pRpoolUserName->hPage,
                                   (void*)USER1_NAME,
                                   (RvInt)strlen(USER1_NAME) + 1,
                                   &(pRpoolUserName->offset));

    if (IS_IPSEC_GM_INTERFACE)
    {
        /*copy the RES + '\0' to the given page.
        (RES was generated in the Authentication Vector)*/
        RPOOL_AppendFromExternalToPage(pRpoolPassword->hPool,
                                   pRpoolPassword->hPage,
                                   (void*)g_ImsUE.g_ClientAkaAV.XRES,
                                   (RvInt)strlen((RvChar*)g_ImsUE.g_ClientAkaAV.XRES) + 1,
                                   &(pRpoolPassword->offset));
    }
    /* For Digest authentication the user's password is used as is */ 
    else  
    {
        RPOOL_AppendFromExternalToPage(pRpoolPassword->hPool,
                                       pRpoolPassword->hPage,
                                       (void*)USER1_PW,
                                       (RvInt)strlen(USER1_PW) + 1,
                                       &(pRpoolPassword->offset));

    }
    

    RV_UNUSED_ARG(hAppAuthenticator);
    RV_UNUSED_ARG(hAuthenticator);
    RV_UNUSED_ARG(hObject);
    RV_UNUSED_ARG(peObjectType);
    RV_UNUSED_ARG(pRpoolRealm);
}

/***************************************************************************
 * AppAuthenticationMD5Ev
 * ------------------------------------------------------------------------
 * General:  Notifies that there is a need to use the MD5 algorithm.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pRpoolMD5Input  - Rpool pointer to the MD5 input
 *          length          - the length of the string inside the page
 * Output:  pRpoolMD5Output - Rpool pointer to the MD5 output
 ***************************************************************************/
void RVCALLCONV AppAuthenticationMD5Ev(IN  RvSipAuthenticatorHandle       hAuthenticator,
                                       IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                       IN  RPOOL_Ptr                     *pRpoolMD5Input,
                                       IN  RvUint32                     length,
                                       OUT RPOOL_Ptr                     *pRpoolMD5Output)
{
    RvChar strDigest[1024];
    RvChar strResponse[33];
    RvUint8 digest[20];
    MD5_CTX mdc;

    /* The string for the md5 is on a page. first we copy it to
       a consecutive buffer.*/
    RPOOL_CopyToExternal(pRpoolMD5Input->hPool,
                         pRpoolMD5Input->hPage,
                         pRpoolMD5Input->offset,
                         (void*)strDigest,
                         length);

    /* implementation of the MD5 algorithm - we give the string to the MD5*/
    MD5Init(&mdc);
    MD5Update(&mdc, (RvUint8 *)strDigest,(unsigned int)strlen(strDigest));
    MD5Final(digest, &mdc);
    MD5toString(digest, strResponse);

    /*after we have a result we must copy it back to the page*/
    RPOOL_AppendFromExternalToPage(pRpoolMD5Output->hPool,
                                   pRpoolMD5Output->hPage,
                                   (void*)strResponse,
                                   (RvInt)strlen(strResponse) + 1,
                                   &(pRpoolMD5Output->offset));
    RV_UNUSED_ARG(hAuthenticator);
    RV_UNUSED_ARG(hAppAuthenticator);

}
#endif /* #ifdef RV_SIP_IMS_ON */
