/*********************************************************************************
 *                              <ImsUERegClient.h>
 * 
 *   This file defines register-client functionality for registering, authenticating
 *   and de-registering to the server, as well as reacting on register-client events.
 *   
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_REG_CLIENT_H
#define IMSUE_REG_CLIENT_H

#ifdef RV_SIP_IMS_ON
#include "RvSipRegClient.h"

/*-----------------------------------------------------------------------*/
/*                       REG-CLIENT CONTROL				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppRegClientMake
 * ------------------------------------------------------------------------
 * General: Invokes initial registration 
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSecAgree - The security-agreement to be set to the new register-client
 ***************************************************************************/
void AppRegClientMake(IN  RvSipSecAgreeHandle  hSecAgree);

/***************************************************************************
 * AppRegClientAuthenticate
 * ------------------------------------------------------------------------
 * General: Invokes registration authentication
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppRegClientAuthenticate();

/***************************************************************************
 * AppRegClientDeregister
 * ------------------------------------------------------------------------
 * General: Invokes de-registration 
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppRegClientDeregister();


/***************************************************************************************
 * AppRegClientInsertInitialAuthorizationToMessage
 * -------------------------------------------------------------------------------------
 * General:  Construct an initial authorization header in the reg-client object,
 *           and fill it with user name and realm information. All other parameters should 
 *           be empty.
 *           We use the initial authorization header to tell the private user identity to 
 *           the server. (The server will generate the Authentication Vector that matches
 *           the specific user).
 * Return Value: -
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:    hRegClient- Handle to the reg-client object.
 * Output:   none
 **************************************************************************************/
RvStatus AppRegClientInsertInitialAuthorizationToMessage(INOUT RvSipRegClientHandle hRegClient);


/***************************************************************************
 * AppRegClientSetExpires
 * ------------------------------------------------------------------------
 * General: Sets the given expires value to the outbound message of the reg-client
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
void AppRegClientSetExpires(IN  RvInt32  expires);

/***************************************************************************
 * AppRegClientGetExpires
 * ------------------------------------------------------------------------
 * General: Gets the expires value that was received in the response from
 *          the server
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
RvUint32 AppRegClientGetExpires();

/*-----------------------------------------------------------------------*/
/*                       REG-CLIENT CALLBACKS                            */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * RvSipRegClientStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a register-client state change.
 *          Prints the new state.
 *          If the new state is Unauthenticated:
 *              1. Get the authentication-object from the reg-client object.
 *              2. Use the Authentication header to generate the Authentication-Vector.
 *              3. Complete the security agreement activation, using the information
 *                 of the Authentication-Vector.
 *              4. Authenticate the request, using RvSipRegClientAuthenticate().
 *          If the new state is Failed, terminate the register-client.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          eState -        The new register-client state
 *          eReason -       The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppClientRegClientStateChangedEvHandler(
                                   IN  RvSipRegClientHandle            hRegClient,
                                   IN  RvSipAppRegClientHandle         hAppRegClient,
                                   IN  RvSipRegClientState             eState,
                                   IN  RvSipRegClientStateChangeReason eReason);

/***************************************************************************
 * AppClientRegClientMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *          hRegClient -  The application handle for this register-client.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppClientRegClientMsgReceivedEvHandler(
                                    IN  RvSipRegClientHandle          hRegClient,
                                    IN  RvSipAppRegClientHandle       hAppRegClient,
                                    IN  RvSipMsgHandle                hMsg);

/***************************************************************************
 * AppClientRegClientMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          hMsg -          Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppClientRegClientMsgToSendEvHandler(
                                    IN  RvSipRegClientHandle          hRegClient,
                                    IN  RvSipAppRegClientHandle       hAppRegClient,
                                    IN  RvSipMsgHandle                hMsg);

/***************************************************************************
 * AppRegClientFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
 *          Here we add comp=sigcomp to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hRegClient     - Handle to the register client.
 *            hAppRegClient  - The application handle for this register client.
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppRegClientFinalDestResolvedEvHandler(
                      IN  RvSipRegClientHandle    hRegClient,
                      IN  RvSipAppRegClientHandle hAppRegClient,
                      IN  RvSipTranscHandle       hTransc,
                      IN  RvSipMsgHandle          hMsgToSend);

/***************************************************************************
 * RvSipRegClientSigCompMsgNotRespondedEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the SigComp message not responded
 *          event handler. Here we decide if a retransmission will take
 *          place and if so, whether the next sent message is compressed
 *
 * Return Value: RV_OK 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hRegClient    - Handle to the register client.
 *            hAppRegClient - The application handle for this reg-client.
 *            hTransc       - The transaction handle.
 *            retransNo     - The number of retransmissions of the request
 *                            until now.
 *            ePrevMsgComp  - The type of the previous not responded request
 * Output:    peNextMsgComp - The type of the next request to retransmit (
 *                            RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNDEFINED means that the
 *                            application wishes to stop sending requests).
 ***************************************************************************/
RvStatus RVCALLCONV AppRegClientSigCompMsgNotRespondedEv(IN  RvSipRegClientHandle         hRegClient,
							 IN  RvSipAppRegClientHandle      hAppRegClient,
						 	 IN  RvSipTranscHandle            hTransc,
						  	 IN  RvInt32                      retransNo,
							 IN  RvSipTransmitterMsgCompType  ePrevMsgComp,
							 OUT RvSipTransmitterMsgCompType *peNextMsgComp);

#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_REG_CLIENT_H */
