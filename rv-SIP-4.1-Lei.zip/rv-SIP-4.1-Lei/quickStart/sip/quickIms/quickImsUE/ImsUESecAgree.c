/*********************************************************************************
 *                              <ImsUESecAgree.c>
 *
 *   This file implements sec-agree functionality for negotiating with the server
 *   and reacting on security-agreement events.
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#include "RvSipSecurityHeader.h"
#include "ImsUESecAgree.h"
#include "ImsUERegClient.h"
#include "ImsComUtils.h"
#include "ImsComDefs.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the security-agreement manager */
extern RvSipSecAgreeMgrHandle  g_hSecAgreeMgr;

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/* Global parameters for command line arguments */
extern RvChar g_pClientIP[MAX_STRING_SIZE];
extern RvChar g_pServerIP[MAX_STRING_SIZE];
extern RvUint16 g_clientPortTls;
extern RvUint16 g_serverPortTls;

/*-----------------------------------------------------------------------*/
/*                      STATIC FUNCTIONS PROTOTYPES					     */
/*-----------------------------------------------------------------------*/

static const RvChar*  AppGetSecAgreeStateName (IN  RvSipSecAgreeState  eState);

static void AppPrepareSecAgreeToIpsecChoice(RvSipSecAgreeHandle hSecAgree);

static void AppPrepareSecAgreeToTlsChoice(RvSipSecAgreeHandle hSecAgree);

/*-----------------------------------------------------------------------*/
/*                       SEC AGREE CONTROL								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientSecAgreeInitiate
 * ------------------------------------------------------------------------
 * General: Creates a secAgree object, fill it and use it in a REGISTER request:
 *          1. create the sec-agree object using RvSipSecAgreeMgrCreateSecAgree()
 *          2. Set its role (client) and its Security-Client header.
 *          3. Init the sec-agree using RvSipSecAgreeInit().
 *          4. Create reg-client object.
 *          5. Set the sec-agree object to the reg-client object.
 *             Set an initial Authorization header to the REGISTER outbound message.
 *          6. Send REGISTER.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
void AppClientSecAgreeInitiate (void)
{

    RvSipSecAgreeHandle       hSecAgree;       /* handle to the client security-agreement*/
    RvSipSecurityHeaderHandle hSecurityHeader; /* handle to the Security-Client header*/
    RvSipCommonListElemHandle hListElem;       /* handle to the Security-Client header list element*/
	RvStatus                  rv;

    /* =============================================
        Create and init a client sec-agree object
       ============================================= */
    /* Create a new security-agreement */
    rv = RvSipSecAgreeMgrCreateSecAgree(g_hSecAgreeMgr, (RvSipAppSecAgreeHandle)&g_ImsUE, &hSecAgree);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to create a new security-agreement");
    }

    /* Set the role of the security-agreement to client */
    rv = RvSipSecAgreeSetRole(hSecAgree, RVSIP_SEC_AGREE_ROLE_CLIENT);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set role to the security-agreement");
    }

	/* Set Special Standard support to the security-agreement object (3GPP, TISPAN,...) */
	rv = RvSipSecAgreeSetSpecialStandardFlag(hSecAgree, GM_INTERFACE_STANDARD);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to set GM_INTERFACE_STANDARD (special standard) to the security-agreement");
	}

    /* Create a new Security header */
    rv = RvSipSecAgreeGetNewMsgElementHandle(hSecAgree, RVSIP_HEADERTYPE_SECURITY, RVSIP_ADDRTYPE_UNDEFINED, (void**)&hSecurityHeader);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to create a new security header");
    }

    /* Parse Security-Client header */
    {
        /* Define the Security-Client header used for ipsec negotiation */
        RvChar * strSecurityClient = (IS_IPSEC_GM_INTERFACE) ?
                        "Security-Client: ipsec-3gpp;alg=hmac-md5-96;prot=esp;mod=trans;ealg=aes-cbc" :
                        "Security-Client: tls";
        rv = RvSipSecurityHeaderParse(hSecurityHeader, strSecurityClient);
        if (rv != RV_OK)
        {
            AppExitOnError("Failed to parse Security-Client header");
        }
    }

#if (defined RV_SIP_IPSEC_NEG_ONLY)
    if (IS_IPSEC_GM_INTERFACE)
    {
        /* Ipsec is not supported by the operating system, we shall be using the local
	   client ports */
        rv = RvSipSecurityHeaderSetPortC(hSecurityHeader, CLIENT_PORT);
        if (rv != RV_OK)
        {
            AppExitOnError("Failed to set port-c to security header");
        }
        rv = RvSipSecurityHeaderSetPortS(hSecurityHeader, CLIENT_PORT);
        if (rv != RV_OK)
        {
            AppExitOnError("Failed to set port-s to security header");
        }
    }
#endif /*  (defined RV_SIP_IPSEC_NEG_ONLY) */

    /* Push Security-Client header to local security list */
    rv = RvSipSecAgreePushLocalSecurityHeader(hSecAgree, hSecurityHeader,
                                                RVSIP_FIRST_ELEMENT, NULL, &hListElem);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to push Security-Client header to local security list");
    }

#ifdef RV_SIGCOMP_ON
	/* Enable sigcomp compression for 3GPP TS 24229 or Packet Cable 2.0 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		RvSipSecAgreeSendOptions  sendOptions;
		sendOptions.eMsgCompType = RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED;
        sendOptions.strSigcompId = CLT_SIGCOMP_ID_STR;
		rv = RvSipSecAgreeSetSendOptions(hSecAgree, &sendOptions, sizeof(RvSipSecAgreeSendOptions));
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to set sigcomp to the send options of the security-agreement");
		}
	}
#endif /* #ifdef RV_SIGCOMP_ON*/

    /* Init the client security-agreement */
    rv = RvSipSecAgreeInit(hSecAgree);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to init client security-agreement");
    }

	g_ImsUE.g_clientSecAgree = hSecAgree;

    OSPrintf("\nClient sec-agree %p was created\n\n",hSecAgree);

	/* Invoke initial registration to the server to begin the negotiation process */
	AppRegClientMake(hSecAgree);
}

/***************************************************************************
* AppClientSecAgreeChooseSecurity
* ----------------------------------
* General: Client choose the ip-sec security.
*          The function sets the keys values for ip-sec. (the keys were created
*          while generating the Authentication Vector).
*          The function choose the security using RvSipSecAgreeClientSetChosenSecurity().
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:  hSecAgree	- A handle to the security-agreement object.
**************************************************************************/
void AppClientSecAgreeChooseSecurity(RvSipSecAgreeHandle hSecAgree)
{
    RvStatus                    rv;
    RvSipSecurityHeaderHandle   hRemoteSecurity;
    RvSipSecurityHeaderHandle	hSecurityHeader;
	RvSipCommonListElemHandle   hListElem;
	/* Declare security mechanism initialized with UNDEFINED */
    RvSipSecurityMechanismType  eMechanism = RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED;
    /* Declare local security header to hold the local security header matching the chosen security mechanism */
    RvSipSecurityHeaderHandle   hLocalSecurity;
    /* Declare remote security header to hold the remote security header matching the chosen security mechanism */

    if (IS_IPSEC_GM_INTERFACE)
    {
        AppPrepareSecAgreeToIpsecChoice(hSecAgree);
    }
    else /* If the application is not configured for Ipsec then it's TLS-based for sure */
    {
        AppPrepareSecAgreeToTlsChoice(hSecAgree);
    }


    /* Initiate the client security-agreement */
    rv = RvSipSecAgreeClientSetChosenSecurity(hSecAgree, &eMechanism, &hLocalSecurity, &hRemoteSecurity);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to initiate client security-agreement");
    }

    OSPrintf("Client security was chosen\n\n");

    if (IS_IPSEC_GM_INTERFACE)
    {
	    /* Store the local ipsec server port in the local Contact headers  */
	    rv = RvSipSecAgreeGetLocalSecurityHeader(hSecAgree, RVSIP_FIRST_ELEMENT, NULL, &hSecurityHeader, &hListElem);
	    if (rv != RV_OK)
	    {
		    AppExitOnError("Failed get Security-Client header from security-agreement");
	    }
	    g_ImsUE.g_portS = RvSipSecurityHeaderGetPortS(hSecurityHeader);
    }

	/* Store comp=sigcomp in the UE to be used in further outgoing messages */
    if (IS_SIGCOMP_GM_INTERFACE)
    {
	    g_ImsUE.g_eCompType = RVSIP_COMP_SIGCOMP;
    }

}

/***************************************************************************
 * AppClientSecAgreeTerminate
 * ------------------------------------------------------------------------
 * General: Terminate the security-agreement
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
void AppClientSecAgreeTerminate (void)
{
	RvStatus   rv;

	OSPrintf("\nClient sec-agree %p - Terminate the sec-agree\n", g_ImsUE.g_clientSecAgree);
	rv = RvSipSecAgreeTerminate(g_ImsUE.g_clientSecAgree);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to terminate the security-agreement");
	}
	g_ImsUE.g_clientSecAgree = NULL;
}


/*-----------------------------------------------------------------------*/
/*                       SEC AGREE CALLBACKS							 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientSecAgreeStateChangedEvHandler
 * ----------------------------------
 * General: Client handling of the SecAgreeStateChangedEvHandler.
 *          In this sample code, when the client sec-agree object is active,
 *          we use it to connect a call.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 *         hAppSecAgree - The application handle for this security-agreement.
 *         eState		- The new security-agreement state.
 *         eReason		- The reason for the state change (if informative).
 **************************************************************************/
void RVCALLCONV AppClientSecAgreeStateChangedEvHandler(
                                                        IN  RvSipSecAgreeHandle       hSecAgree,
                                                        IN  RvSipAppSecAgreeHandle    hAppSecAgree,
                                                        IN  RvSipSecAgreeState        eState,
                                                        IN  RvSipSecAgreeReason       eReason)
{
	if (eState == RVSIP_SEC_AGREE_STATE_INVALID &&
		eReason == RVSIP_SEC_AGREE_REASON_SECURITY_OBJ_EXPIRED)
	{
		/* ----------------------------------------------------------
		   The security-agreement is invalidated due to connection
		   closing at the server. Terminate the security-agreement.
		   ---------------------------------------------------------- */
		OSPrintf("\nClient sec-agree %p - State changed to Invalid due to server closing the ipsec connection -> Terminate the security-agreement\n\n",
				 hSecAgree);
		AppClientSecAgreeTerminate();
	}
	else
	{
		/*print the new state on screen*/
		OSPrintf("\nClient sec-agree %p - State changed to %s\n\n",
				 hSecAgree,AppGetSecAgreeStateName(eState));
	}

	RV_UNUSED_ARG(hAppSecAgree)
}

/***************************************************************************
 * AppClientSecAgreeStatusEvHandler
 * ----------------------------------
 * General: Notifies the application of security-agreement statuses.
 *          Here we set the lifetime timer according to the security-association
 *          status
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 *         hAppSecAgree - The application handle for this security-agreement.
 *         eStatus      - The reported status of the security-agreement.
 *         pInfo        - Auxiliary information. Not in use.
 **************************************************************************/
void RVCALLCONV AppClientSecAgreeStatusEvHandler(
                                   IN  RvSipSecAgreeHandle        hSecAgree,
                                   IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                   IN  RvSipSecAgreeStatus        eStatus,
								   IN  void*					  pInfo)
{
	RvStatus                 rv;

	switch (eStatus)
	{
	case RVSIP_SEC_AGREE_STATUS_IPSEC_TEMPORARY_ASSOCIATION:
		OSPrintf("\nClient sec-agree %p - Security Association status is Temporary\n\n", hSecAgree);
		/* ===================================================
		   Start lifetime timer to reg-await-auth interval
		   =================================================== */
		OSPrintf("Client sec-agree %p - Starting lifetime timer to interval %d\n\n", hSecAgree, REG_AWAIT_AUTH);
		rv = RvSipSecAgreeStartIpsecLifetimeTimer(hSecAgree, REG_AWAIT_AUTH);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to start lifetime timer");
		}
		break;
	case RVSIP_SEC_AGREE_STATUS_IPSEC_ESTABLISHED_ASSOCIATION:
		OSPrintf("\nClient sec-agree %p - Security Association status is Established\n\n", hSecAgree);
		/* =============================================================
		   Start lifetime timer to registration interval plus 30 seconds
		   The registration interval of this reg-client is stored in the
		   application
		   ============================================================= */
		OSPrintf("Client sec-agree %p - Starting lifetime timer to interval %d\n\n", hSecAgree, g_ImsUE.g_clientExpires+30);
		rv = RvSipSecAgreeStartIpsecLifetimeTimer(hSecAgree, g_ImsUE.g_clientExpires+30);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to start lifetime timer");
		}
		break;
	case RVSIP_SEC_AGREE_STATUS_IPSEC_LIFETIME_EXPIRED:
		/* Handle lifetime expiration. This is out of scope of this sample application. */
		break;
	default:
		break;
	}

	RV_UNUSED_ARG(hAppSecAgree)
	RV_UNUSED_ARG(pInfo)
}

/*-----------------------------------------------------------------------*/
/*                          STATIC FUNCTIONS							 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppGetSecAgreeStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSecAgreeStateName (IN  RvSipSecAgreeState  eState)
{
    switch(eState)
    {
        case RVSIP_SEC_AGREE_STATE_IDLE:
            return "Idle";
        case RVSIP_SEC_AGREE_STATE_CLIENT_LOCAL_LIST_READY:
            return "Client Local List Ready";
        case RVSIP_SEC_AGREE_STATE_CLIENT_REMOTE_LIST_READY:
            return "Client Remote List Ready";
        case RVSIP_SEC_AGREE_STATE_CLIENT_HANDLING_INITIAL_MSG:
            return "Client Handling Initial Msg";
        case RVSIP_SEC_AGREE_STATE_CLIENT_LOCAL_LIST_SENT:
            return "Client Local List Sent";
        case RVSIP_SEC_AGREE_STATE_CLIENT_CHOOSE_SECURITY:
            return "Client Choose Security";
        case RVSIP_SEC_AGREE_STATE_SERVER_LOCAL_LIST_READY:
            return "Server Local List Ready";
        case RVSIP_SEC_AGREE_STATE_SERVER_REMOTE_LIST_READY:
            return "Server Remote List Ready";
        case RVSIP_SEC_AGREE_STATE_SERVER_READY:
            return "Server Ready";
        case RVSIP_SEC_AGREE_STATE_ACTIVE:
            return "Active";
        case RVSIP_SEC_AGREE_STATE_NO_AGREEMENT_REQUIRED:
            return "No Agreement Required";
        case RVSIP_SEC_AGREE_STATE_INVALID:
            return "Invalid";
        case RVSIP_SEC_AGREE_STATE_TERMINATED:
            return "Terminated";
        default:
            return "Undefined";

    }
}

/***************************************************************************
 * AppPrepareSecAgreeToIpsecChoice
 * ------------------------------------------------------------------------
 * General: Perform initial Security Agreement settings before choosing
 *          ipsec as it's security mechanism
 * Return Value: -
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object to be
 *                        prepared before choosing a security mechanism
 ***************************************************************************/
static void AppPrepareSecAgreeToIpsecChoice(RvSipSecAgreeHandle hSecAgree)
{
    RvSipSecAgreeIpsecInfo  ipsecInfo; /* structure for ip-sec-3gpp extra parameters*/
    RvStatus                rv;

    /* Reset ip-sec info structure */
    memset(&ipsecInfo, 0, sizeof(RvSipSecAgreeIpsecInfo));

    /* Set IK to the ip-sec info structure */
    memcpy(ipsecInfo.IK, g_ImsUE.g_ClientAkaAV.IK, 16);
    ipsecInfo.IKlen = 16*8;

    /* Set CK to the ip-sec info structure */
    memcpy(ipsecInfo.CK, g_ImsUE.g_ClientAkaAV.CK, 16);
    ipsecInfo.CKlen = 16*8;

    /* Set ip-sec info to the server security-agreement */
    rv = RvSipSecAgreeSetIpsecInfo (hSecAgree, &ipsecInfo, sizeof(RvSipSecAgreeIpsecInfo));
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set ip-sec info to client security-agreement");
    }
}

/***************************************************************************
 * AppPrepareSecAgreeToTlsChoice
 * ------------------------------------------------------------------------
 * General: Perform initial Security Agreement settings before choosing
 *          TLS as it's security mechanism
 * Return Value: -
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object to be
 *                        prepared before choosing a security mechanism
 ***************************************************************************/
static void AppPrepareSecAgreeToTlsChoice(RvSipSecAgreeHandle hSecAgree)
{
    /* Set the local and remote addresses in non-ipsec case */
    RvSipTransportAddr addr;
    RvStatus           rv;

    memset(&addr,0,sizeof(addr));
    addr.eTransportType = RVSIP_TRANSPORT_TLS;
    addr.eAddrType      = IS_IPV6_GM_INTERFACE(g_pClientIP) ?
                          RVSIP_TRANSPORT_ADDRESS_TYPE_IP6 : RVSIP_TRANSPORT_ADDRESS_TYPE_IP;

    /* Initializing the local address structure per the application configuration */
    addr.Ipv6Scope      = CLIENT_IPV6_SCOPE;
    addr.port           = g_clientPortTls;
    strncpy(addr.strIP,g_pClientIP,sizeof(addr.strIP));

    rv = RvSipSecAgreeSetLocalAddr(
            hSecAgree,RVSIP_SECURITY_MECHANISM_TYPE_TLS,&addr,sizeof(addr));
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set TLS local address to client security-agreement");
    }

    /* Initializing the remote address structure per the application configuration */
    addr.Ipv6Scope      = SERVER_IPV6_SCOPE;
    addr.port           = g_serverPortTls;
    strncpy(addr.strIP,g_pServerIP,sizeof(addr.strIP));

    rv = RvSipSecAgreeSetRemoteAddr(
        hSecAgree,RVSIP_SECURITY_MECHANISM_TYPE_TLS,&addr,sizeof(addr));
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set TLS remote address to client security-agreement");
    }
}

#endif /* RV_SIP_IMS_ON */
