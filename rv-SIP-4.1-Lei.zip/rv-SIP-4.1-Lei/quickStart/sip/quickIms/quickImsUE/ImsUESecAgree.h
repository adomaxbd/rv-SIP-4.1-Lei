/*********************************************************************************
 *                              <ImsUESecAgree.h>
 * 
 *   This file defines sec-agree functionality for negotiating with the server and
 *   reacting on security-agreement events. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_SEC_AGREE_H
#define IMSUE_SEC_AGREE_H

#ifdef RV_SIP_IMS_ON
#include "RvSipSecAgree.h"

/*-----------------------------------------------------------------------*/
/*                       SEC AGREE CONTROL								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientSecAgreeInitiate
 * ------------------------------------------------------------------------
 * General: Creates a secAgree object, fill it and use it in a REGISTER request:
 *          1. create the sec-agree object using RvSipSecAgreeMgrCreateSecAgree()
 *          2. Set its role (client) and its Security-Client header.
 *          3. Init the sec-agree using RvSipSecAgreeInit().
 *          4. Create reg-client object. 
 *          5. Set the sec-agree object to the reg-client object.
 *             Set an initial Authorization header to the REGISTER outbound message.
 *          6. Send REGISTER.          
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
void AppClientSecAgreeInitiate (void);

/***************************************************************************
* AppClientSecAgreeChooseSecurity
* ----------------------------------
* General: Client choose the ip-sec security.
*          The function sets the keys values for ip-sec. (the keys were created
*          while generating the Authentication Vector).
*          The function choose the security using RvSipSecAgreeClientSetChosenSecurity().
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:  hSecAgree	- A handle to the security-agreement object.
**************************************************************************/
void AppClientSecAgreeChooseSecurity(RvSipSecAgreeHandle hSecAgree);

/***************************************************************************
 * AppClientSecAgreeTerminate
 * ------------------------------------------------------------------------
 * General: Terminate the security-agreement          
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
void AppClientSecAgreeTerminate (void);

/*-----------------------------------------------------------------------*/
/*                       SEC AGREE CALLBACKS							 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientSecAgreeStateChangedEvHandler
 * ----------------------------------
 * General: Client handling of the SecAgreeStateChangedEvHandler.
 *          In this sample code, when the client sec-agree object is active,
 *          we use it to connect a call.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 *         hAppSecAgree - The application handle for this security-agreement.
 *         eState		- The new security-agreement state.
 *         eReason		- The reason for the state change (if informative).
 **************************************************************************/
void RVCALLCONV AppClientSecAgreeStateChangedEvHandler(
                                   IN  RvSipSecAgreeHandle       hSecAgree,
                                   IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                   IN  RvSipSecAgreeState         eState,
                                   IN  RvSipSecAgreeReason        eReason);

/***************************************************************************
 * AppClientSecAgreeStatusEvHandler
 * ----------------------------------
 * General: Notifies the application of security-agreement statuses.
 *          Here we set the lifetime timer according to the security-association
 *          status
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 *         hAppSecAgree - The application handle for this security-agreement.
 *         eStatus      - The reported status of the security-agreement.
 *         pInfo        - Auxiliary information. Not in use.
 **************************************************************************/
void RVCALLCONV AppClientSecAgreeStatusEvHandler(
                                   IN  RvSipSecAgreeHandle        hSecAgree,
                                   IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                   IN  RvSipSecAgreeStatus        eStatus,
								   IN  void*					  pInfo);

#endif /* RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_SEC_AGREE_H */

