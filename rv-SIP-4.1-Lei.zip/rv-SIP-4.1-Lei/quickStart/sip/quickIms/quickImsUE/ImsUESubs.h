/*********************************************************************************
 *                              <ImsUESubs.h>
 * 
 *   This file defines subscription functionality for subscribing to the
 *   registration-state event, reacting on subscription events, and processing
 *   incoming notification. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_SUBS_H
#define IMSUE_SUBS_H

#ifdef RV_SIP_IMS_ON
#ifdef RV_SIP_SUBS_ON
#include "RvSipSubscription.h"

/*-----------------------------------------------------------------------*/
/*                       SUBSCRIPTION CONTROL				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppSubscribe
 * ------------------------------------------------------------------------
 * General: Create a subscription.
 *          To Create a subscription the application should:
 *          1. create a new subscription using RvSipSubsMgrCreateSubscription().
 *          2. call RvSipSubsInitStr(), to set mandatory parameters.
 *          3. call RvSipSubsSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppSubscribe(void);

/***************************************************************************
 * AppSubsTerminate
 * ------------------------------------------------------------------------
 * General: Terminate the subscription object
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppSubsTerminate(void);

/*-----------------------------------------------------------------------*/
/*                       SUBSCRIPTION CALLBACKS				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppSubsMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                        IN  RvSipSubsHandle      hSubs,
                                        IN  RvSipAppSubsHandle   hAppSubs,
                                        IN  RvSipNotifyHandle    hNotify,
                                        IN  RvSipAppNotifyHandle hAppNotify,
                                        IN  RvSipMsgHandle       hMsg);

/***************************************************************************
 * AppSubsMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                          IN    RvSipSubsHandle      hSubs,
                                          IN    RvSipAppSubsHandle   hAppSubs,
                                          IN    RvSipNotifyHandle    hNotify,
                                          IN    RvSipAppNotifyHandle hAppNotify,
                                          IN    RvSipMsgHandle       hMsg);

/***************************************************************************
 * AppSubsFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
  *         Here we add comp=sigcomp to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs          - The sip stack subscription handle
 *            hAppSubs       - The application handle for this subscription.
 *            hNotify        - The notify object handle (relevant only for notify request or response)
 *            hAppNotify     - The application notify object handle (relevant only for notify request or response)
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsFinalDestResolvedEvHandler(
                      IN  RvSipSubsHandle           hSubs,
                      IN  RvSipAppSubsHandle        hAppSubs,
                      IN  RvSipNotifyHandle         hNotify,
                      IN  RvSipAppNotifyHandle      hAppNotify,
                      IN  RvSipTranscHandle         hTransc,
                      IN  RvSipMsgHandle            hMsgToSend);

/***************************************************************************
 * AppSubsStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a subscription state change.
 *          For all states indicating a new incoming requests (subs_rcvd,
 *          refresh_rcvd, ubsubscribe_rcvd) - accept the request, and send
 *          a notify request immediately.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          eState -      The new subscription state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason);

/***************************************************************************
 * AppSubsNotifyEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the SubsNotifyEv event handler.
 *          If the new status is request_rcvd - accept the notify request
 *          with RvSipNotifyAccept().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs         - The sip stack subscription handle
 *          hAppSubs      - The application handle for this subscription.
 *          hNotification - The new created notification object handle.
 *          hAppNotification - The application handle for this notification.
 *          eNotifyStatus - Status of the notification object.
 *          eNotifyReason - Reason to the indicated status.
 *          hNotifyMsg    - The received notify msg.
 ***************************************************************************/
void RVCALLCONV AppSubsNotifyEvHandler(
                                     IN  RvSipSubsHandle        hSubs,
                                     IN  RvSipAppSubsHandle     hAppSubs,
                                     IN  RvSipNotifyHandle      hNotification,
                                     IN  RvSipAppNotifyHandle   hAppNotification,
                                     IN  RvSipSubsNotifyStatus  eNotifyStatus,
                                     IN  RvSipSubsNotifyReason  eNotifyReason,
                                     IN  RvSipMsgHandle         hNotifyMsg);

#ifdef RV_SIGCOMP_ON
/***************************************************************************
 * RvSipSubsSigCompMsgNotRespondedEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the SigComp message not responded
 *          event handler. Here we decide if a retransmission will take
 *          place and if so, whether the next sent message is compressed
 *
 * Return Value: RV_OK 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs         - The sip stack subscription handle
 *            hAppSubs      - The application handle for this subscription.
 *            hNotify       - The notify object handle (relevant only for notify request or response)
 *            hAppNotify    - The application notify object handle (relevant only for notify request or response)
 *            hTransc       - The transaction handle.
 *            retransNo     - The number of retransmissions of the request
 *                            until now.
 *            ePrevMsgComp  - The type of the previous not responded request
 * Output:    peNextMsgComp - The type of the next request to retransmit (
 *                            RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNDEFINED means that the
 *                            application wishes to stop sending requests).
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsSigCompMsgNotRespondedEv(IN  RvSipSubsHandle              hSubs,
						    IN  RvSipAppSubsHandle           hAppSubs,
						    IN  RvSipNotifyHandle            hNotify,
						    IN  RvSipAppNotifyHandle         hAppNotify,
						    IN  RvSipTranscHandle            hTransc,
						    IN  RvInt32                      retransNo,
						    IN  RvSipTransmitterMsgCompType  ePrevMsgComp,
						    OUT RvSipTransmitterMsgCompType *peNextMsgComp);
#endif /* #ifdef RV_SIGCOMP_ON */

#endif /* #ifdef RV_SIP_SUBS_ON */
#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_SIG_SUBS_H */

