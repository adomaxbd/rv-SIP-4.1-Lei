/*********************************************************************************
 *                              <ImsUEServiceRoute.h>
 * 
 *   This file defines utility functions for Service-Route processing. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_SERVICE_ROUTE_H
#define IMSUE_SERVICE_ROUTE_H

#ifdef RV_SIP_IMS_ON
#include "RvSipMsg.h"
#include "RvSipRouteHopHeader.h"

/*-----------------------------------------------------------------------*/
/*                           TYPE DEFINITIONS                            */
/*-----------------------------------------------------------------------*/

/*define the size of the global array that keeps the service route list*/
#define MAX_NUM_OF_ROUTE_HEADER_LIST 10

/*defines a struct that contains all the data that is related to the routeList*/
typedef struct
{
   /*The page on which we save the service-route headers,in order to
     create later the Route header list from*/
    HPAGE                     serviceRouteListPage;

   /*routeHeader list (built from the serviceRoute list)*/
    RvSipRouteHopHeaderHandle routeHopHeaderList[MAX_NUM_OF_ROUTE_HEADER_LIST];

   /*counts how many service-route headers are in the list*/
    RvInt                     numOfRouteHopHeadersInList;

} RouteListData;

/*-----------------------------------------------------------------------*/
/*                         SERVICE ROUTE FUNCTIONS						 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppResetRouteHopHeaderList
 * ------------------------------------------------------------------------
 * General: Reset the global structure of service route information
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
void AppResetRouteHopHeaderList(void);

/***************************************************************************
 * AppRouteHopListInsertToMsg
 * ------------------------------------------------------------------------
 * General: Inserts the list of route hop headers into the given message
 * Return Value: A boolean indication to whether Route header were actually
 *               inserted to the message
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
RvBool AppRouteHopListInsertToMsg(IN RvSipMsgHandle  hOutboundMsg);

/***************************************************************************
 * AppServiceRouteListStore
 * ------------------------------------------------------------------------
 * General: Copy the service-route list received in the given message 
 *          to the global list of route hop header. The stored list will be 
 *          preloaded to outgoing request messages
 *
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg - The message from which to copy the Service-Route list
 *
 ***************************************************************************/
void  AppServiceRouteListStore(IN  RvSipMsgHandle   hMsg);

#endif /* RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_SERVICE_ROUTE_H */

