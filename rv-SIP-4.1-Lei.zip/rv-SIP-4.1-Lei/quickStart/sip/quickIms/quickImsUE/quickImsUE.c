

/*********************************************************************************
 *                              <quickImsUE.c>
 *   This file gives an example of the UE side in a Gm Interface flow.
 *   The UE can be configured to support either 3GPP TS-24.229, TISPAN ES-283.003
 *   or PKT-SP-24.229 by setting the relevant value to GM_INTERFACE_STANDARD in ImsComDefs.h.
 *   The 3GPP/TISPAN/PACKET_CABLE modes will affect message headers, message compression,
 *   security mechanisms, etc.
 *   The Gm Interface sample application includes:
 *   Initiate the RADVISION SIP stack.
 *   Register application callbacks.
 *   Implement application callbacks.
 *
 *   Here is further description of each of the Gm interface modes:
 *
 *   I. 3GPP/TISPAN Interface
 *   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   In this mode the UE initiates a security-agreement with ipsec-3gpp security
 *   using REGISTER request.
 *   UE and server maintain lifetime timer for the ipsec-3gpp security-associations
 *   according to the status of the registration flow.
 *   UE subscribes to registration-state info via reg event, using the security agreement and
 *   the established ipsec-3gpp connection.
 *   UE connects a call to UE2 via the server using the security agreement and the established
 *   ipsec-3gpp connection. Disconnect the call from UE2 side is simulated at the server.
 *   Upon server invoking notification on the upcoming termination of the UE registration,
 *   the UE de-registers to the server.
 *   Once the de-registration is complete the UE and server terminate the security-associations
 *   and the subscription objects.
 *
 *   The Gm Interface sample message flow is the following:
 *   =============================================================================
 *     UE                                                     SERVER
 *      |                                                       |
 *   create sec-agree                                           |
 *   with local security ip-sec                                 |
 *      |    ------------- REGISTER ----------------->          |
 *      |                                               create sec-agree with local
 *      |                                               security ip-sec.
 *      |                                               create AV (AKA Authentication Vector)
 *      |                                               for the user.
 *      |                                               fill the sec-agree with AV params.
 *      |                                               set the sec-agree to the transaction.
 *      |    <------------ 401 -----------------------          |
 *      |                                               sec-agree is active.
 *      |                                               security-association status is temporary
 *      |                                               start lifetime timer to reg-await-auth interval
 *   create AV using AKA                                        |
 *   params from Authentication                                 |
 *   header.                                                    |
 *   fill the sec-agree with AV params.                         |
 *   sec agree is active                                        |
 *   security-association status is temporary                   |
 *   start lifetime timer to reg-await-auth interval            |
 *	    |														|
 *      |    ------------- REGISTER ----------------->          |
 *      |    <------------ 200 -----------------------          |
 *      |                                               security-association status is established
 *      |                                               start  lifetime timer to registration interval
 *      |                                               plus 30 seconds
 *      |                                               Start timer for the registration period minus 5 seconds
 *      |														|
 *      |                                                       |
 *   security-association status is established                 |
 *   start lifetime timer to registration interval              |
 *   plus 30 seconds                                            |
 *      |                                                       |
 *      |                                                       |
 *   subscribe to reg event                                     |
 *   using the active sec-agree                                 |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |    <------------ 200 -----------------------          |
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently active
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *      |                                                       |
 *      |                                                       |
 *   connect a call to UE2 via the                              |
 *   server, using the active sec-agree                         |
 *      |    ------------- INVITE   ----------------->          |
 *      |                                               set the sec-agree to the
 *      |                                               new call-leg
 *      |                                               Invoke 200 response (simulating a response
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ 200 -----------------------          |
 *      |    ------------- ACK      ----------------->          |
 *      |                                               disconnect the call, using
 *      |                                               the active sec-agree (simulating a BYE request
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ BYE -----------------------          |
 *      |    ------------- 200      ----------------->          |
 *      |														|
 *      |														|
 *      |                                               Upon registration timer fires,
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently terminated
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *   Observe that the registration-state                        |
 *   is terminated. There's no need to de-register              |
 *      |														|
 *   terminate sec-agree                                terminate sec-agree
 *   terminate subscription object                      terminate subscription object
 *      |                                                       |
 *   ==============================================================================
 *
 *   II. PACKET CABLE Interface
 *   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   In this mode the UE initiates a security-agreement with TLS security
 *   using REGISTER request.
 *   UE and server maintain lifetime timer for the TLS session according to the status
 *   of the registration flow.
 *   UE subscribes to registration-state info via reg event, using the security agreement and
 *   the established TLS connection.
 *   UE connects a call to UE2 via the server using the security agreement and the established
 *   TLS connection. Disconnect the call from UE2 side is simulated at the server.
 *   Upon server invoking notification on the upcoming termination of the UE registration,
 *   the UE de-registers to the server.
 *   Once the de-registration is complete the UE and server terminate the TLS session
 *   and the subscription objects.
 *
 *   The Gm Interface sample message flow is the following:
 *   =============================================================================
 *     UE                                                     SERVER
 *      |                                                       |
 *   create sec-agree                                           |
 *   with local security TLS                                    |
 *      |    ------------- REGISTER ----------------->          |
 *      |                                               create sec-agree with local
 *      |                                               security TLS.
 *      |                                               fill the sec-agree with digest params.
 *      |                                               set the sec-agree to the transaction.
 *      |    <------------ 401 -----------------------          |
 *      |                                               sec-agree is active.
 *      |                                                       |
 *   calculate SIP digest-response                              |
 *   parameters as indicated in                                 |
 *   RFC 2617 from Authentication                               |
 *   header.                                                    |
 *   fill the sec-agree with these params.                      |
 *   sec agree is active                                        |
 *	    |														|
 *      |    ------------- REGISTER ----------------->          |
 *      |    <------------ 200 -----------------------          |
 *      |                                                       |
 *      |<-------------TLS connection is established----------->|
 *      |														|
 *      |                                                       |
 *      |                                                       |
 *      |                                                       |
 *   subscribe to reg event                                     |
 *   using the active sec-agree                                 |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |    <------------ 200 -----------------------          |
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently active
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *      |                                                       |
 *      |                                                       |
 *   connect a call to UE2 via the                              |
 *   server, using the active sec-agree                         |
 *      |    ------------- INVITE   ----------------->          |
 *      |                                               set the sec-agree to the
 *      |                                               new call-leg
 *      |                                               Invoke 200 response (simulating a response
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ 200 -----------------------          |
 *      |    ------------- ACK      ----------------->          |
 *      |                                               disconnect the call, using
 *      |                                               the active sec-agree (simulating a BYE request
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ BYE -----------------------          |
 *      |    ------------- 200      ----------------->          |
 *      |														|
 *      |														|
 *      |                                               Upon registration timer fires,
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently terminated
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *   Observe that the registration-state                        |
 *   is terminated. There's no need to de-register.             |
 *      |														|
 *   terminate sec-agree                                terminate sec-agree
 *   terminate subscription object                      terminate subscription object
 *      |                                                       |
 *   ==============================================================================
 *
 *   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *   You can run this application as is: An instance of quickImsUE (UE) versus an instance of
 *   demoImsServer (Server).
 *   Notice that the application exits on errors.
 * ------------------------------------------------------------------
 * Note:
 *       A. In order to run this sample you must compile the stack with IMS:
 *          you must set RV_SIP_IMS_ON in RvSipUserConfig.h
 *
 *       B. When configured in 3GPP/TISPAN modes this sample is
 *          designed to demonstrate ipsec usage, therefore
 *          it is recommended to run this sample on an OS that supports ipsec.
 *          To use ipsec you must compile with RV_IMS_IPSEC_ENABLED set to RV_YES
 *          in rvuserconfig.h. However, if you wish to run this sample without
 *          ipsec support, you must compile with RV_IMS_IPSEC_ENABLED set to RV_NO
 *          in rvuserconfig.h and set RV_SIP_IPSEC_NEG_ONLY in RvSipUserConfig.h.
 *          Before running the sample you must also set the correct addresses in
 *          file ImsComDefs.h
 *
 *       C. When configured in PACKET CABLE mode this sample is designed
 *          to demonstrate TLS+Digest usage. Therefore it is recommended
 *          to:
 *          I. Compile this sample (as well as the stack beneath)
 *          with RV_TLS_ON (or RV_CFLAG_TLS). For more infomration about
 *          this compilation flag, please apply the SIP Stack Prog Guide.
 *          II. Link this sample with ssl libraries. For instance, in case
 *          of compiling this sample over windows, you'll have to add
 *          the libraries libeay32.lib and ssleay32.lib to the list of
 *          linker's input libraries.
 *
 *       D. When running this sample with IPv6 addresses, you should
 *          compile this sample (as well as the stack beneath) with
 *          RV_NET_IPV6 (or RV_CFLAG_IPV6). For more infomration about
 *          this compilation flag, please apply the SIP Stack Prog Guide.
 *
 *       Under windows you must first compile the stack from the rvsip.dsw
 *       workspace with the following configurations:
 *       - Win32 Debug configuration for Debug execution
 *       - Win32 Release configuration for Release execution.
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                  June 2006
 *    Tamarb Barzuza                 Sep  2007
 *    Dikla Dror Behr                July 2008
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"


#include <stdio.h>
#include <stdarg.h>
#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif
#include "ImsComUtils.h"

#ifdef RV_SIP_IMS_ON
#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSipMid.h"

#include "ImsComDefs.h"
#include "ImsCom_md5c.h"
#include "ImsUECallLeg.h"
#include "ImsUERegClient.h"
#include "ImsUESubs.h"
#include "ImsComSigComp.h"
#include "ImsUESecAgree.h"
#include "ImsUEAuth.h"
#include "ImsComUtils.h"
#include "ImsComTlsUtils.h"
#include "ImsUEServiceRoute.h"
#include "quickImsUE.h"

#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
#include <vxWorks.h>
#include <taskLib.h>
#include <time.h>
#if (RV_IMS_IPSEC_ENABLED==RV_YES) && (RV_OS_VERSION == RV_OS_VXWORKS_3_1)
#include <wrn/ipsec/ipsec.h>
#endif
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif

/*internal usage only*/
#ifdef USE_INTERNAL_SAMPLE_DEFS
#include "samplesInternalDefs.h"
#endif
/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
/*Handle to the stack manager. This parameter is returned when calling
  RvSipStackConstruct. You should supply this handle when using the stack
  manager API functions.*/
RvSipStackHandle  g_hStackMgr    = NULL;

/* Handle to the stack transport manager. You can get this handle by calling
   RvSipStackGetTransportMgrHandle. This handle should be used when calling some
   of the connection function and TLS engine functions */
RvSipTransportMgrHandle g_hTransportMgr = NULL;

/*Handle to the security-agreement manager. This value is returned when calling
  RvSipStackGetSecAgreeMgrHandle after constructing the stack. You should
  supply this handle when using the sec-agree manager API functions.*/
RvSipSecAgreeMgrHandle  g_hSecAgreeMgr = NULL;

/*Handle to the register-client manager. This value is returned when calling
  RvSipStackGetRegClientMgrHandle after constructing the stack. You should
  supply this handle when using the register- client manager API functions.*/
RvSipRegClientMgrHandle g_hRegClientMgr  = NULL;

/*Handle to the call-leg manager. You can get this handle by calling
  RvSipStackGetCallLegMgrHandle. You should supply this handle when
  using the call-leg manager API functions.*/
RvSipCallLegMgrHandle g_hCallLegMgr  = NULL;

/*Handle to the Authenticator manager. This value is returned when calling
  RvSipStackGetAuthenticationHandle. You should supply this handle when using the
  Authenticator manager API functions.*/
RvSipAuthenticatorHandle g_hAuthenticatorMgr  = NULL;

/*Handle to the Subscription manager. This value is returned when calling
  RvSipStackGetSubsMgrHandle. You should supply this handle when using the
  Subscription manager API functions.*/
RvSipSubsMgrHandle g_hSubsMgr  = NULL;

/*Handle to the message manager. This value is returned when calling
  RvSipStackGetMsgMgrHandle. You should supply this handle when using
  the message manager API functions.*/
RvSipMsgMgrHandle       g_hMsgMgr  = NULL;

/*Handle to the log-module. You can get this handle by calling
  RvSipStackGetLogHandle. You need this value in order to construct the application
  memory pool.*/
RV_LOG_Handle         g_hLog         = NULL;

/*Handle to the application memory pool. The application should construct its own
  memory using rpool API. The pool is needed for encoding messages or message
  parts. (See AppPrintMessage() )*/
HRPOOL                g_appPool      = NULL;

/* Handle to the global Ims UE object. The Ims UE object contains the entire Ims
   UE application data */
ImsUE                 g_ImsUE;

/*The following variable saves the port to be used,
  that was given as input to the program */
RvUint16 g_clientPort    = CLIENT_PORT;
RvUint16 g_clientPortTls = CLIENT_TLS_PORT;
RvUint16 g_serverPort    = SERVER_PORT;
RvUint16 g_serverPortTls = SERVER_TLS_PORT;


/*The following variables save the command line parameters
  that were given as input to the program */
RvChar g_pClientIP[MAX_STRING_SIZE] = CLIENT_IP;
RvChar g_pServerIP[MAX_STRING_SIZE] = SERVER_IP;

#endif /*#ifdef RV_SIP_IMS_ON*/
/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static int mainFunc(int argc, char *argv[]);

#ifdef RV_SIP_IMS_ON
static void AppStackInitialize(void);

static void AppSetCallBackFunctions(void);

static void ImsUEInit(void);

static int AppAnalyzeCommandLineArguments(int argc, char *argv[]);

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
static void mainFuncForSymbian(void);
#endif

#endif /*#ifdef RV_SIP_IMS_ON*/

/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * main
 * ------------------------------------------------------------------------
 * General: In the main function we perform the following:
 *          1. Initialize the RADVISION SIP stack.
 *          2. Set the callback functions in the call-leg manager.
 *          3. Create a call-leg and connect a call. (The call will be disconnected
 *             after reaching the connected state. (Look at
 *             AppCallLegStateChangedEvHandler()).
 *          4. Activates the RvSipStackProcessEvents() function that
 *             command the stack to process the event queue.
 ***************************************************************************/
static int mainFunc(int argc, char *argv[])
{
#ifdef RV_SIP_IMS_ON
    int rc;
    
    OSPrintf("Executing quickImsUE\n");

    /* Analyze command line arguments */
    rc = AppAnalyzeCommandLineArguments(argc, argv);
    if (rc != 0)
        return rc;
    
    /*1. Initialize the RADVISION SIP stack.*/
    AppStackInitialize();
    /*2. Initializing the TLS engines only in non-ipsec mode */
    if (!IS_IPSEC_GM_INTERFACE)
    {
         AppInitTlsSecurity();
    }
    /*3. Set the callback functions in the call-leg manager.*/
    AppSetCallBackFunctions();
    /*4. Create a sec-agree, attach it to reg-client and register.*/
    AppClientSecAgreeInitiate();

    /*5. Activates the RvSipStackProcessEvents() function that
         commands the stack to process the event queue.*/
    RvSipStackProcessEvents();
    return 0;
#else /* #ifdef RV_SIP_IMS_ON */
	OSPrintf("\nThis Sample requires that flag RV_SIP_IMS_ON defined.\n Aborting.\n");
	return 1;
#endif /* #ifdef RV_SIP_IMS_ON */
}

#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) /* embedded start function */
int mainForEmbedded()
{
    mainFunc(0, NULL);
    return 0;
}
#elif (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) /* vxworks start function */
void startVx()
{
#if (RV_IMS_IPSEC_ENABLED==RV_YES)
    ipsecAttachIf(CLIENT_IP);
#endif
    taskSpawn("mainFunc", 100, 0, 0x30000, (FUNCPTR)mainFunc, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_PSOS) /* pSOS start function */

/* pSOS Shell entry point */
#include <psos.h>
#include <prepc.h>
void mainForEmbedded(int argc, char **argv, char **env, void *exit_param, const char *console_dev)
{
    mainFunc(argc, argv);
    psh_exit(exit_param);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_WINCE) /* WinCE start function */
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPWSTR lpCmdLine,
                   int nCmdShow)
{
    OSSetMainFuncCB(mainFunc);
    OSWinCEMain(hInstance,hPrevInstance,lpCmdLine,nCmdShow);
}
#else /* not embedded start function */
int main(int argc, char *argv[])
{
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    mainFuncForSymbian();
    return 0;
#else
    return mainFunc(argc, argv);
#endif
}
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
/***************************************************************************
 * mainFuncForSymbian
 * ------------------------------------------------------------------------
 * General: Called from main(). Creates heap and initiates thread. Starts
 *          the SIP sample.
 ***************************************************************************/
static void mainFuncForSymbian(void)
{
   /* Symbian stack and heap should be enlarged so we are */
    /* Construction SIP on new thread                      */
    SymbianCreateThread((void *)mainFunc);
    while(1)
    {
      SymbianSleep(1000);
    }
}
#endif

#ifdef RV_SIP_IMS_ON
/***************************************************************************
 * AppStackInitialize
 * ------------------------------------------------------------------------
 * General: Initializing the stack and allocating the application memory pool.
 *          When initializing we first set the configuration struct to the
 *          default values and then change some of the configuration parameters.
 *          We then use RvSipStackConstruct to initialize the stack.
 ***************************************************************************/
static void AppStackInitialize(void)
{
    RvStatus rv;
    RvSipStackCfg stackCfg;

    /* Define TLS variables */
    RvChar   *tlsAddr;
    RvUint16  tlsPort;

    RvSipMidInit();

    /*Initialize the configuration structure with default values*/
    RvSipStackInitCfg(sizeof(stackCfg),&stackCfg);

    /*change some of the default values*/
    stackCfg.maxCallLegs = 6;
    stackCfg.tcpEnabled = RV_TRUE;
    stackCfg.maxRegClients = 2;
    stackCfg.maxSecAgrees = 2;
    stackCfg.maxSecurityObjects = 2;
	stackCfg.maxSubscriptions = 2;

    /*setting the sec-agree extension in the supported list*/
    stackCfg.supportedExtensionList = "sec-agree";

    stackCfg.localUdpPort = g_clientPort;
    stackCfg.localTcpPort = g_clientPort;
    tlsPort               = g_clientPortTls;

    RvSipMidInit();  /* In order to enable memory allocation */ 
    if (IS_IPV6_GM_INTERFACE(g_pClientIP))
    {
        sprintf(stackCfg.localUdpAddress,"%s%%%d",g_pClientIP,CLIENT_IPV6_SCOPE);
        sprintf(stackCfg.localTcpAddress,"%s%%%d",g_pClientIP,CLIENT_IPV6_SCOPE);
        tlsAddr = RvSipMidMemAlloc(sizeof(g_pClientIP)+sizeof(CLIENT_IPV6_SCOPE)+2 /* 1 for the % and 1 for the '\0' */); 
        sprintf(tlsAddr,"%s%%%d",g_pClientIP,CLIENT_IPV6_SCOPE);
    }
    else
    {
        strcpy(stackCfg.localUdpAddress, g_pClientIP);
        strcpy(stackCfg.localTcpAddress,g_pClientIP);
        tlsAddr = RvSipMidMemAlloc(sizeof(g_pClientIP)+1 /* 1 for the '\0' */); 
        strcpy(tlsAddr,g_pClientIP);
    }

    if (!(IS_IPSEC_GM_INTERFACE))
    {
        /* Set resources specific to Packet Cable requirements (non ipsec mode), TLS is essential */
        stackCfg.numOfTlsAddresses = 1;
        stackCfg.localTlsAddresses = &tlsAddr;
        stackCfg.localTlsPorts     = &tlsPort;
        stackCfg.numOfTlsEngines   = 2;
    }

	if (strlen(OUTBOUND_PROXY_IP) > 0)
	{
		strcpy(stackCfg.outboundProxyIpAddress,OUTBOUND_PROXY_IP);
		stackCfg.outboundProxyPort = OUTBOUND_PROXY_PORT;
	}


#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) || (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || \
    (RV_OS_TYPE == RV_OS_TYPE_PSOS) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    /* Disable most of log */
    stackCfg.defaultLogFilters = RVSIP_LOG_ERROR_FILTER|RVSIP_LOG_EXCEP_FILTER;

#endif

    /*Call the stack initialization function*/
    rv = RvSipStackConstruct(sizeof(stackCfg),&stackCfg,&g_hStackMgr);
    if(rv != RV_OK)
    {
        AppExitOnError("Application failed to construct the stack\n");
    }

    /* Free the allocated memory, required for the stack construction */
    RvSipMidMemFree(tlsAddr);

    /*getting handles for the internal modules*/
    RvSipStackGetTransportMgrHandle(g_hStackMgr,&g_hTransportMgr);
    RvSipStackGetSecAgreeMgrHandle(g_hStackMgr, &g_hSecAgreeMgr);
    RvSipStackGetRegClientMgrHandle(g_hStackMgr,&g_hRegClientMgr);
    RvSipStackGetCallLegMgrHandle(g_hStackMgr,&g_hCallLegMgr);
	RvSipStackGetSubsMgrHandle(g_hStackMgr,&g_hSubsMgr);
    RvSipStackGetAuthenticatorHandle(g_hStackMgr, &g_hAuthenticatorMgr);
    RvSipStackGetMsgMgrHandle(g_hStackMgr,&g_hMsgMgr);
    RvSipStackGetLogHandle(g_hStackMgr,&g_hLog);

    OSPrintf("\nThe RADVISION SIP stack was constructed successfully. Version - %s\n",
                RvSipStackGetVersion());

    /*Construct a pool of memory for the application*/
    g_appPool = RPOOL_Construct(1024,10,g_hLog,RV_FALSE,"ApplicationPool");

#ifdef RV_SIGCOMP_ON
    /* Initialize the SigComp module if applying 3GPP TS 24.229 or Packet Cable 2.0 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		rv = AppInitSigComp();
		if(rv != RV_OK)
		{
			AppExitOnError("Application failed to construct the SigComp module\n");
		}
	}
#endif /* RV_SIGCOMP_ON */
	ImsUEInit();

    RvSipMidEnd();
}

/***************************************************************************
 * ImsUEInit
 * ------------------------------------------------------------------------
 * General: Init the structure of Ims UE by resetting all its fields.
 ***************************************************************************/
static void ImsUEInit(void)
{
	memset(&g_ImsUE, 0, sizeof(ImsUE));
	g_ImsUE.g_clientExpires		= UNDEFINED;
	g_ImsUE.g_portS				= UNDEFINED;
	g_ImsUE.g_eCompType			= RVSIP_COMP_UNDEFINED;
	AppResetRouteHopHeaderList();
}

/***************************************************************************
 * AppSetCallBackFunctions
 * ------------------------------------------------------------------------
 * General: Set application call back functions in the call-leg manager.
 ***************************************************************************/
static void AppSetCallBackFunctions(void)
{
    RvStatus                     rv;
    RvSipCallLegEvHandlers       appCallEvHandlers;
    RvSipRegClientEvHandlers     appRegEvHandlers;
	RvSipSubsEvHandlers          appSubsEvHandlers;
    RvSipSecAgreeEvHandlers      appSecAgreeEvHandlers;
    RvSipAuthenticatorEvHandlers authEvHandlers;

    /*Reset the appEvHandlers since not all callbacks are set by this sample*/
    memset(&appCallEvHandlers,0,sizeof(RvSipCallLegEvHandlers));
    memset(&appRegEvHandlers,0,sizeof(RvSipRegClientEvHandlers));
    memset(&appSubsEvHandlers,0,sizeof(RvSipSubsEvHandlers));
    memset(&appSecAgreeEvHandlers, 0, sizeof(RvSipSecAgreeEvHandlers));
    memset(&authEvHandlers,0,sizeof(RvSipAuthenticatorEvHandlers));

    /*Set application callbacks in the structure*/
    appCallEvHandlers.pfnStateChangedEvHandler			 = AppCallLegStateChangedEvHandler;
    appCallEvHandlers.pfnMsgReceivedEvHandler			 = AppCallLegMsgReceivedEvHandler;
    appCallEvHandlers.pfnMsgToSendEvHandler				 = AppCallLegMsgToSendEvHandler;
	appCallEvHandlers.pfnFinalDestResolvedEvHandler      = AppCallLegFinalDestResolvedEvHandler;
#ifdef RV_SIGCOMP_ON
	appCallEvHandlers.pfnSigCompMsgNotRespondedEvHandler = AppCallLegSigCompMsgNotRespondedEvHandler;
#endif /* RV_SIGCOMP_ON */

    /*Set the structure in the call-leg manager*/
    rv = RvSipCallLegMgrSetEvHandlers(g_hCallLegMgr,
                                      &appCallEvHandlers,
                                      sizeof(RvSipCallLegEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    /*Set application callbacks in the structure*/
    appRegEvHandlers.pfnStateChangedEvHandler			= AppClientRegClientStateChangedEvHandler;
    appRegEvHandlers.pfnMsgReceivedEvHandler			= AppClientRegClientMsgReceivedEvHandler;
    appRegEvHandlers.pfnMsgToSendEvHandler				= AppClientRegClientMsgToSendEvHandler;
	appRegEvHandlers.pfnFinalDestResolvedEvHandler      = AppRegClientFinalDestResolvedEvHandler;
#ifdef RV_SIGCOMP_ON
	appRegEvHandlers.pfnSigCompMsgNotRespondedEvHandler = AppRegClientSigCompMsgNotRespondedEv;
#endif /* RV_SIGCOMP_ON */

    /*Set the structure in the register-client manager*/
    rv = RvSipRegClientMgrSetEvHandlers(g_hRegClientMgr,
                                        &appRegEvHandlers,
                                        sizeof(RvSipRegClientEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

	/*Set application callbacks in the structure*/
	appSubsEvHandlers.pfnMsgReceivedEvHandler              = AppSubsMsgReceivedEvHandler;
	appSubsEvHandlers.pfnMsgToSendEvHandler                = AppSubsMsgToSendEvHandler;
	appSubsEvHandlers.pfnStateChangedEvHandler             = AppSubsStateChangedEvHandler;
	appSubsEvHandlers.pfnNotifyEvHandler                   = AppSubsNotifyEvHandler;
	appSubsEvHandlers.pfnFinalDestResolvedEvHandler        = AppSubsFinalDestResolvedEvHandler;
#ifdef RV_SIGCOMP_ON
    appSubsEvHandlers.pfnSigCompMsgNotRespondedEvHandler   = AppSubsSigCompMsgNotRespondedEv;
#endif /* RV_SIGCOMP_ON */

	/*Set the structure in the subscription manager*/
    rv = RvSipSubsMgrSetEvHandlers(g_hSubsMgr,
                                   &appSubsEvHandlers,
                                   sizeof(RvSipSubsEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    appSecAgreeEvHandlers.pfnSecAgreeStateChangedEvHandler = AppClientSecAgreeStateChangedEvHandler;
	appSecAgreeEvHandlers.pfnSecAgreeStatusEvHandler       = AppClientSecAgreeStatusEvHandler;
    rv = RvSipSecAgreeMgrSetSecAgreeEvHandlers(g_hSecAgreeMgr,
                                                  &appSecAgreeEvHandlers,
                                                  sizeof(RvSipSecAgreeEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    authEvHandlers.pfnMD5AuthenticationExHandler = AppAuthenticationMD5Ev;
    authEvHandlers.pfnGetSharedSecretAuthenticationHandler = AppClientAuthenticationGetSharedSecretEv;

    /*Set the structure in the call-leg manager*/
    rv = RvSipAuthenticatorSetEvHandlers(g_hAuthenticatorMgr,
                                         &authEvHandlers,
                                         sizeof(RvSipAuthenticatorEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks for authentication");
    }

    /* Set TLS callbacks only in non-ipsec mode */
    if (!IS_IPSEC_GM_INTERFACE)
    {
        RvSipTransportMgrEvHandlers     TransportMgrEvHandlers;

        /*Reset the appEvHandlers since not all callbacks are set by this sample*/
        memset(&TransportMgrEvHandlers,0,sizeof(RvSipTransportMgrEvHandlers));
        TransportMgrEvHandlers.pfnEvTlsStateChanged = AppTransportConnectionTlsStateChanged;
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
        TransportMgrEvHandlers.pfnEvTlsPostConnectionAssertion   = AppTransportConnectionTlsPostConnectionAssertion;
#endif
        /*Set the structure in the transport manager*/
        rv = RvSipTransportMgrSetEvHandlers(
                    g_hTransportMgr,NULL,&TransportMgrEvHandlers,sizeof(RvSipTransportMgrEvHandlers));
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to set application callbacks for transport (TLS)");
        }
    }
}

/***************************************************************************
 * AppAnalyzeCommandLineArguments
 * ------------------------------------------------------------------------
 * General: Analyzes the given Command Line Arguments
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   argc, argv
 ***************************************************************************/
static int AppAnalyzeCommandLineArguments(int argc, char *argv[])
{
    /* Analyze command line arguments and set global variables */
    if (argc < 2)
    {
        OSPrintf("Default Client UDP port %d will be used.\n", g_clientPort);
        OSPrintf("Default Client TLS port %d will be used.\n", g_clientPortTls);
        OSPrintf("Default Server UDP port %d will be used.\n", g_serverPort);
        OSPrintf("Default Server TLS port %d will be used.\n", g_serverPortTls);

    }
    else if (argc == 7)
    {
        g_clientPort    = (RvUint16)atoi(argv[1]);
        g_clientPortTls = (RvUint16)atoi(argv[2]);
        g_serverPort    = (RvUint16)atoi(argv[3]);
        g_serverPortTls = (RvUint16)atoi(argv[4]);
        sprintf(g_pClientIP,    "%s",    argv[5]);
        sprintf(g_pServerIP,    "%s",    argv[6]);

        OSPrintf("Given Client UDP port %d will be used.\n", g_clientPort);
        OSPrintf("Given Client TLS port %d will be used.\n", g_clientPortTls);
        OSPrintf("Given Server UDP port %d will be used.\n", g_serverPort);
        OSPrintf("Given Server TLS port %d will be used.\n", g_serverPortTls);
    }
    else
    {
        OSPrintf("Invalid arguments given!\n");
        OSPrintf("Usage:   quickImsUE <client udp port> <client tls port> <server port> <server tls port> <client ip> <server ip>\n\n");
        OSPrintf("Example: quickImsUE 6070 6071 6060 6061 [fe80::21c:23ff:fe03:1137] [fe80::21c:23ff:fe03:1137]\n");

        return 1;
    }

    return 0;
}

#endif /*#ifdef RV_SIP_IMS_ON*/






