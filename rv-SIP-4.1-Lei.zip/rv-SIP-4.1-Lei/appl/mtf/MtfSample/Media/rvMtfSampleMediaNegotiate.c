/******************************************************************************
Filename:    IppSampleMediaNegotiate.c
Description: This file contains the media negotiation of MTF sample application.
			 User application may use this file as an example and make the necessary
			 changes to adjust it to application's needs.
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include <stdlib.h>
#include <ctype.h>
#include "ipp_inc_std.h"
#include "rvtimestamp.h"
#include "rvsdpenc.h"
#include "rvsdpcodecs.h"
#include "ippmisc.h"
#include "ippcodec.h"
#include "rvMtfSample.h"
#include "rvstr.h"
#include "rvcctext.h"
#include "ippcodec_h263.h"
#include "ippcodec_h261.h"

#define RV_IPP_FIRST_DYNAMIC_PAYLOAD	96	/* according to standard: payloads lower than 96 are static, higher are dynamic. */

typedef enum
{
    POLICY_NONE,
    POLICY_ADD,
    POLICY_REMOVE,
    POLICY_MODIFY
}CHANGE_POLICY;

typedef enum RvIppCodingId_
{
	IPP_CODING_G711_MU		= 0x00,							/* 8 bit A-law PCM					*/
	IPP_CODING_G711_A		= 0x08,							/* 8 bit mu-law PCM					*/
	IPP_CODING_G711			= IPP_CODING_G711_MU,			/* 8 bit A-law PCM					*/

	IPP_CODING_G723_5_3K	= 0x04,							/* G.723 at 5.3 kbits/second		*/
	IPP_CODING_G723_6_3K	= IPP_CODING_G723_5_3K,			/* G.723 at 6.3 kbits/second		*/

	IPP_CODING_G726_16K		= 0x62,							/* 2 bits/sample ADPCM (G.726)		*/
	IPP_CODING_G726_24K		= IPP_CODING_G726_16K,			/* 3 bits/sample ADPCM (G.726)		*/
	IPP_CODING_G726_32K		= IPP_CODING_G726_16K,			/* 4 bits/sample ADPCM (G.726)		*/
	IPP_CODING_G726_40K		= IPP_CODING_G726_16K,			/* 5 bits/sample ADPCM (G.726)		*/

	IPP_CODING_G727_16K		= 0x63,							/* (2,2) embedded ADPCM (G.727)		*/
	IPP_CODING_G727_24K		= IPP_CODING_G727_16K,			/* (3,2) embedded ADPCM (G.727)		*/
	IPP_CODING_EADPCM_24K	= IPP_CODING_G727_16K,
	IPP_CODING_G727_32K		= IPP_CODING_G727_16K,			/* (4,2) embedded ADPCM (G.727)		*/
	IPP_CODING_EADPCM_32K	= IPP_CODING_G727_16K,
	IPP_CODING_G727_40K		= IPP_CODING_G727_16K,			/* (5,2) embedded ADPCM (G.727)		*/
	IPP_CODING_EADPCM_40K	= IPP_CODING_G727_16K,

	IPP_CODING_G728_16K		= 0x0F,							/* LD-CELP 16K (G.728)				*/
	IPP_CODING_LDCELP_16K	= IPP_CODING_G728_16K,

	IPP_CODING_G729			= 0x12,							/* CS-ACELP 8K (G.729)				*/
	IPP_CODING_G729A		= IPP_CODING_G729,				/* CS-ACELP 8K (G.729A)				*/
	IPP_CODING_G729B		= IPP_CODING_G729,				/* CS-ACELP 8K internal VAD (G.729B)*/
	IPP_CODING_G729AB		= IPP_CODING_G729,				/* CS-ACELP internal VAD (G.729AB)	*/
	IPP_CODING_G729E		= IPP_CODING_G729,				/* CS-ACELP 8K (G.729E)				*/
	IPP_CODING_GSM_EFR		= IPP_CODING_G729,				/* GSM_EFR codec					*/
	IPP_CODING_GSM_FR		= IPP_CODING_G729,				/* GSM_FR codec						*/


	/* Wide-band definitions */
	IPP_CODING_G722_64K		= 0x09,							/* G.722 at 64 kbits/second			*/
	IPP_CODING_G722_56K		= IPP_CODING_G722_64K,			/* G.722 at 56 kbits/second			*/
	IPP_CODING_G722_48K		= IPP_CODING_G722_64K,			/* G.722 at 48 kbits/second			*/

	IPP_CODING_FAX			= 0x64,							/* FAX								*/
	IPP_CODING_T38_FAX		= IPP_CODING_FAX,				/* T38 FAX							*/
	IPP_FAKE_CODING_T38_RTP_FAX = IPP_CODING_FAX,			/* T38 FAX with forced RTP encapsulation   */
	IPP_FAKE_CODING_T38_UDP_FAX = IPP_CODING_FAX,			/* T38 FAX with forced UDP encapsulation   */
	IPP_CODING_CLEAR_CHAN	= IPP_CODING_FAX,				/* Clear Channel - Transparent data */

	IPP_FAKE_CODING_RTP_DTMF_RELAY = 0xa0,					/* 'fake' coding so that we retrieve
																rtp payload type for rtp dtmf relay */

    IPP_CODING_MODEM_V90    = 0x65,							/* V.90 & V.34 modem termination	*/
    IPP_CODING_MODEM_V32    = IPP_CODING_MODEM_V90,         /* V32 down to V.21 modem termination */
	IPP_CODING_MODEM_RELAY	= IPP_CODING_MODEM_V90,			/* V.21 & V.22 MODEM RELAY			*/
    IPP_CODING_MODEM_KFLEX  = IPP_CODING_MODEM_V90,         /* K56flex modem termination		*/
    IPP_CODING_FAX_TERM     = IPP_CODING_MODEM_V90,         /* fax termination					*/
    IPP_CODING_DATA_TERM    = IPP_CODING_MODEM_V90,         /* data termination					*/
    IPP_CODING_SIG_ONLY     = IPP_CODING_MODEM_V90,         /* signaling only					*/
    IPP_CODING_MODEM_V92    = IPP_CODING_MODEM_V90,         /* V.92 modem termination			*/

	IPP_CODING_MODEM_HI		= IPP_CODING_MODEM_V90,
	IPP_CODING_MODEM_LOW	= IPP_CODING_MODEM_V90,

	/* The following def. are added for AAL2 and RTP profiles */
	IPP_CODING_GEN_SID		= 0xE0,

	IPP_CODING_INVALID      = 0xff

} RvIppCodingId;

typedef RvStatus    (*AttrValueNegotiateCB)(
                                            IN const char* valueLocal,  /*NULL if not exist*/
                                            IN const char* valueRemote,  /*NULL if not exist*/
                                            OUT CHANGE_POLICY*     changeLocal,
                                            OUT char* valueLocalNegotiated,/*buffer for valueLocalNegotiated must be provided*/
                                            IN int bufzise
                                            );/*buffer for valueLocalNegotiated must be provided*/


/*==================================================================================
======================= P R I V A T E		F U N C T I O N S ======================
===================================================================================*/

/***********************************************************
 Function:    strcmpIgnoreCase ()

 Description: Perform case sensitive comparison
 Arguments:

 Returns:     0 if strings are equal, negative if str1 < str2,
			  positive if str1 > str2
***********************************************************/

static int strcmpIgnoreCase(const char *str1, const char *str2) {

	while (*str1 && *str2) {
		int diff = tolower(*str1) - tolower(*str2);
		if(diff)
			return diff;
		str1++;
		str2++;
	}

	return *str1 ? 1 : *str2 ? -1 : 0;
}

/***********************************************************
 Function:    isStaticCodecAvailable ()

 Description:	Check if a codec is supported by the engine.
 Arguments:		IN	payload codec
				 OUT *idxMediaDescr	| position of this codec
				 OUT *idxPayload	| in SdpMsgList stored by gateway
 Returns:    rvFalse if codec not supported.
***********************************************************/
static RvBool isStaticCodecAvailable( IN RvSdpMsg* msg, IN RvIppCodingId codec, OUT RvSdpMediaDescr **matchDescr)
{
	RvSize_t i;

	RvSdpMediaDescr*	descr;

	for(i=0; i<rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		RvSize_t	payloadNum;
		RvSize_t	payloadIndex;

		descr = rvSdpMsgGetMediaDescr(msg, i);
		payloadNum = rvSdpMediaDescrGetNumOfPayloads( descr);

		for( payloadIndex=0; payloadIndex < payloadNum; payloadIndex++)
		{
			int payload = rvSdpMediaDescrGetPayloadNumber(descr, (int)payloadIndex);

			if (payload == (int)codec)
			{
				/* return a pointer to the media descriptor with matching codec */

				*matchDescr = descr;

				return RV_TRUE;
			}
		}
	}
	return RV_FALSE;
}
/***********************************************************
 Function:    isDynamicCodecAvailable ()

 Description: Check if a codec is supported by the gateway
 Arguments:		IN	char* codecName
				 OUT *idxMediaDescr	| position of this codec
				 OUT *idxPayload	| in SdpMsgList stored by gateway
 Returns:    rvFalse if codec not supported.
***********************************************************/
static RvBool isDynamicCodecAvailable(IN RvSdpMsg* msg, IN const char* codec, OUT RvSdpMediaDescr **matchDescr)
{
	RvSize_t i;

	RvSdpMediaDescr*	descr;

	for (i=0; i<rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		RvSize_t	payloadNum;
		RvSize_t	payloadIndex;

		descr = rvSdpMsgGetMediaDescr(msg, i);
		payloadNum = rvSdpMediaDescrGetNumOfPayloads( descr);

		for( payloadIndex=0; payloadIndex < payloadNum; payloadIndex++)
		{
			int         payload = rvSdpMediaDescrGetPayloadNumber(descr, (int)payloadIndex);
			RvSize_t	rtpmapNum = rvSdpMediaDescrGetNumOfRtpMap(descr);
			RvSize_t	rtpmapIndex;

			for (rtpmapIndex=0; rtpmapIndex < rtpmapNum; rtpmapIndex++)
			{
				RvSdpRtpMap* rtpmap = rvSdpMediaDescrGetRtpMap(descr, rtpmapIndex);
				if (rvSdpRtpMapGetPayload(rtpmap) == (int)payload)
				{
					if (strcmpIgnoreCase(rvSdpRtpMapGetEncodingName(rtpmap), codec) ==0)
					{
						*matchDescr = descr;
						return RV_TRUE;
					}
				}
			}
		}
	}

	return RV_FALSE;
}


/*
* AttrValueNegotiateCB functions for different attributes
*/
/*============================================================*/
static RvStatus AttrValueNegotiateCB_min_int(
    IN  const char*     valueLocal,  /*NULL if not exist*/
    IN  const char*     valueRemote,  /*NULL if not exist*/
    OUT CHANGE_POLICY*  changeLocal,
    OUT char*           valueLocalNegotiated,/*buffer for valueLocalNegotiated must be provided*/
    IN  int             bufSize)
{
    *changeLocal = POLICY_NONE;

    if (valueLocal && valueRemote)
    {
        if (atoi(valueLocal) > atoi(valueRemote))
        {
            *changeLocal = POLICY_MODIFY;
            strncpy(valueLocalNegotiated, valueRemote, (RvSize_t)(bufSize-1));
            valueLocalNegotiated[bufSize-1]= '\0';
        }
    }

    return RV_OK;
}

/*
* "no" has privilege upon other values
*/
static RvStatus AttrValueNegotiateCB_yes_no(
    IN  const char*     valueLocal,  /*NULL if not exist*/
    IN  const char*     valueRemote,  /*NULL if not exist*/
    OUT CHANGE_POLICY*  changeLocal,
    OUT char*           valueLocalNegotiated,/*buffer for valueLocalNegotiated must be provided*/
    IN  int             bufSize)
{
    *changeLocal = POLICY_NONE;

    if ((valueLocal && strcmp("no", valueLocal) !=0) &&
        (!valueRemote || strcmp("no", valueRemote) ==0))
    {
        *changeLocal = POLICY_MODIFY;
        strncpy(valueLocalNegotiated, "no", (RvSize_t)(bufSize-1));
        valueLocalNegotiated[bufSize-1]= '\0';
    }
    return RV_OK;
}

static int getMaxValue(int val1, int val2)
{
	return ((val1 > val2)? val1 : val2);
}

static int getMinValue(int val1, int val2)
{
	return ((val1 < val2)? val1 : val2);
}

/******************************************************************************
*  symmetrizeCodecH261
*  -------------------
*  General :       Symmetrize two media descriptors. The result is written to
*                  changingMedia descriptor. The media parameters are symmetric
*                  if they appear in both descriptors.  
*
*  Return Value:   RV_OK - all the parameters symmetrized successfully
*                  RV_ERROR_UNKNOWN - otherwise
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          
*                  changingMedia - media descriptor whose data is compared to the other descr
*                                  and overridden with the result media
*                  baseMedia - a media to compare to. It is not changed. 
*                  payload - of the codec.
*				   localANdRemote - notifies whether the medias in comparison are 
*                                   local media to remote media (TRUE) or local/remote compared
*                                   with the media capabilities (FALSE) 
*
*  Output:         none.
******************************************************************************/
static void symmetrizeCodecH261( INOUT RvSdpMediaDescr **changingMedia,IN RvSdpMediaDescr *baseMedia, 
								 IN RvInt payload, IN RV_BOOL localAndRemote)
{
	CodecData_h261 changingData, baseData, resultData;
	RV_BOOL xCifFound = RV_FALSE;

	memset( &resultData,0, sizeof(resultData));

	CodecData_h261_Construct( &changingData, *changingMedia, payload);
	CodecData_h261_Construct( &baseData, baseMedia, payload);

	/* If both medias posses xCIF parameter, set result's xCIF value to the higher value */

	if ((changingData.qcifMPI !=0) && (baseData.qcifMPI !=0))
	{
		resultData.qcifMPI = getMaxValue(changingData.qcifMPI, baseData.qcifMPI);
		xCifFound = RV_TRUE;
	}

	if ((changingData.cifMPI !=0) && (baseData.cifMPI !=0))
	{
		resultData.cifMPI = getMaxValue(changingData.cifMPI, baseData.cifMPI);
		xCifFound = RV_TRUE;
	}

	if (xCifFound)
	{
		/* set the order privilege (i.e which xCIP should be listed first) */
		/* There could be a case where baseData.order_privilege is a xCIF which is not common
		   in both descriptors thus will not appear in result data. In this case the common
		   xCIFs will be listed in any order, depending on the data-to-media proc */
		/* If we compare local media with remote media the order privilege is determined 
		   according to the remote media (in baseMedia).
		   If we compare local/remote with the media capabilities the order privilege is 
		   determined according to local/remote (in changingMedia) */
		if (localAndRemote)
			resultData.order_privilege = baseData.order_privilege;
		else
			resultData.order_privilege = changingData.order_privilege;
	}
	else
	{
		/* if no matching xCIF parameters were found add a default QCIF parameter */
		resultData.qcifMPI =2;
        resultData.order_privilege = MF_RESOLUTION_QCIF;
	}

	if ((changingData.maxBitRate != 0) && (baseData.maxBitRate != 0))
	{
		resultData.maxBitRate = getMinValue(changingData.maxBitRate, baseData.maxBitRate);
	}

	resultData.unrestrictedVector = (changingData.unrestrictedVector && baseData.unrestrictedVector);

	/* update the changingMedia according to the resultData */
	CodecData_h261_to_mediaDsecr(&resultData, *changingMedia, payload, localAndRemote);

	/* Currently there is nothing really to destruct. The code is left here to avoid potential leaks */
	CodecData_h261_Destruct(&resultData);
	CodecData_h261_Destruct(&changingData);
	CodecData_h261_Destruct(&baseData);
}

/******************************************************************************
*  symmetrizeCodecH263
*  -------------------
*  General :       Symmetrize two media descriptors. The result is written to
*                  changingMedia descriptor. The media parameters are symmetric
*                  if they appear in both descriptors.  
*
*  Return Value:   RV_OK - all the parameters symmetrized successfully
*                  RV_ERROR_UNKNOWN - otherwise
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          
*                  changingMedia - media descriptor whose data is compared to the other descr
*                                  and overridden with the result media
*                  baseMedia - a media to compare to. It is not changed. 
*                  payload - of the codec.
*				   localANdRemote - notifies whether the medias in comparison are 
*                                   local media to remote media (TRUE) or local/remote compared
*                                   with the media capabilities (FALSE) 
*
*  Output:         none.
******************************************************************************/

static void symmetrizeCodecH263( INOUT RvSdpMediaDescr **changingMedia,IN RvSdpMediaDescr *baseMedia, 
								IN RvInt payload, IN RV_BOOL localAndRemote)
{
	CodecData_h263 changingData, baseData, resultData;
	RV_BOOL        xCifFound = RV_FALSE;

	memset( &resultData,0, sizeof(resultData));

	CodecData_h263_Construct( &changingData, *changingMedia, payload);
	CodecData_h263_Construct( &baseData, baseMedia, payload);

	/* If both medias posses xCIF parameter, set result's xCIF value to the higher value */

	if ((changingData.sqcifMPI !=0) && (baseData.sqcifMPI !=0))
	{
		resultData.sqcifMPI = getMaxValue(changingData.sqcifMPI, baseData.sqcifMPI);
		xCifFound = RV_TRUE;
	}

	if ((changingData.qcifMPI !=0) && (baseData.qcifMPI !=0))
	{
		resultData.qcifMPI = getMaxValue(changingData.qcifMPI, baseData.qcifMPI);
		xCifFound = RV_TRUE;
	}

	if ((changingData.cifMPI !=0) && (baseData.cifMPI !=0))
	{
		resultData.cifMPI = getMaxValue(changingData.cifMPI, baseData.cifMPI);
		xCifFound = RV_TRUE;
	}

	if ((changingData.cif4MPI !=0) && (baseData.cif4MPI !=0))
	{
		resultData.cif4MPI = getMaxValue(changingData.cif4MPI, baseData.cif4MPI);
		xCifFound = RV_TRUE;
	}

	if ((changingData.cif16MPI !=0) && (baseData.cif16MPI !=0))
	{
		resultData.cif16MPI = getMaxValue(changingData.cif4MPI, baseData.cif4MPI);
		xCifFound = RV_TRUE;
	}

	/* set the order privilege (i.e which xCIP should be listed first) */
	if (xCifFound)
	{
		/* found at least one xCIF parameter                               */
		/* set the order privilege (i.e which xCIP should be listed first) */
		/* There could be a case where baseData.order_privilege is a xCIF which is not common
		   in both descriptors thus will not appear in result data. In this case the common
		   xCIFs will be listed in any order, depending on the data-to-media proc */

		/* If we compare local media with remote media the order privilege is determined 
		   according to the remote media (in baseMedia).
		   If we compare local/remote with the media capabilities the order privilege is 
		   determined according to local/remote (in changingMedia) */

		if (localAndRemote)
			resultData.order_privilege = baseData.order_privilege;
		else
			resultData.order_privilege = changingData.order_privilege;
	}
	else
	{
		/* if no matching xCIF parameters were found add a default QCIF parameter */
		resultData.qcifMPI =2;
        resultData.order_privilege = MF_RESOLUTION_QCIF;
	}

	if ((changingData.maxBitRate != 0) && (baseData.maxBitRate != 0))
	{
		resultData.maxBitRate = getMinValue(changingData.maxBitRate, baseData.maxBitRate);
	}

	resultData.unrestrictedVector = (changingData.unrestrictedVector && baseData.unrestrictedVector);

	resultData.arithmeticCoding = (changingData.arithmeticCoding && baseData.arithmeticCoding);

	resultData.advancedPrediction = (changingData.advancedPrediction && baseData.advancedPrediction);

	resultData.pbFrames = (changingData.pbFrames && baseData.pbFrames);

	if ((changingData.hrdB != 0) && (baseData.hrdB != 0))
	{
		resultData.hrdB = getMinValue(changingData.hrdB, baseData.hrdB);
	}

	if ((changingData.bppMaxKb != 0) && (baseData.bppMaxKb != 0))
	{
		resultData.bppMaxKb = getMinValue(changingData.bppMaxKb, baseData.bppMaxKb);
	}


	/* update the changingMedia according to the resultData */
	/* The localAndRemote bool is used by the codec_to_media proc to determine how many 
	   xCIF options should be listed in the resulting media descr */
	CodecData_h263_to_mediaDsecr(&resultData, *changingMedia, payload, localAndRemote);

	/* Currently there is nothing really to destruct. The code is left here to avoid potential leaks */
	CodecData_h263_Destruct(&resultData);
	CodecData_h263_Destruct(&changingData);
	CodecData_h263_Destruct(&baseData);

}

/***********************************************************
 Function:    SymmetrizeAttribute ()

 Description:

 Arguments:

 Returns:     None.
***********************************************************/
static void SymmetrizeAttribute(IN const char* attrName,
                                IN AttrValueNegotiateCB negotiateCB,
                                IN RvSdpMediaDescr *mediaRemote,
                                INOUT RvSdpMediaDescr *mediaLocal)
{
	RvSdpAttribute* attr;
	RvSize_t	iRemote, ilocal;
    char		value[256] = {0};
	CHANGE_POLICY		changeLocal =POLICY_NONE;
    const char  *attrNameLocal, *attrNameRemote;
    const char  *attrValueLocal =NULL, *attrValueRemote =NULL;

	/* look for a Remote packeting attribute, if there is any... */
	for (iRemote =0 ; iRemote < rvSdpMediaDescrGetNumOfAttr2(mediaRemote); ++iRemote)
	{
		attr = rvSdpMediaDescrGetAttribute2(mediaRemote, iRemote);
        attrNameRemote = rvSdpAttributeGetName(attr);
		if (!strcmp( attrNameRemote, attrName))
		{
            attrValueRemote = rvSdpAttributeGetValue(attr);
            break;
		}
	}

	/* look for a Remote packeting attribute, if there is any... */
	for (ilocal =0 ; ilocal < rvSdpMediaDescrGetNumOfAttr2(mediaLocal); ++ilocal)
	{
		attr = rvSdpMediaDescrGetAttribute2(mediaLocal, ilocal);
        attrNameLocal = rvSdpAttributeGetName(attr);
		if (!strcmp( attrNameLocal, attrName))
		{
            attrValueLocal = rvSdpAttributeGetValue(attr);
            break;
		}
	}

    if (attrValueLocal || attrValueRemote)
    {
        if (negotiateCB( attrValueLocal, attrValueRemote, &changeLocal, value, sizeof(value)) !=RV_OK)
            goto err_exit;
    }

    if (changeLocal == POLICY_ADD)
    {
        rvSdpMediaDescrAddAttr(mediaLocal, attrName, value);
    }
    else if(changeLocal == POLICY_REMOVE)
    {
        if(attrValueLocal)
    		rvSdpMediaDescrRemoveAttribute2( mediaLocal, ilocal);
    }
    else if(changeLocal == POLICY_MODIFY)
    {
        if(attrValueLocal)
    		rvSdpMediaDescrRemoveAttribute2( mediaLocal, ilocal);

        rvSdpMediaDescrAddAttr( mediaLocal, attrName, value);
    }

    return;
err_exit:
	IppLogMessage(RV_TRUE,  "SymmetrizeAttribute() failed");
    return;
}


/***********************************************************
 Function:    symmetrizeByCodec ()

 Description: Make codecs symmetric.

 Arguments:

 Returns:     None.
***********************************************************/
static void symmetrizeByCodec(INOUT RvSdpMediaDescr**		changingMedia,
							  IN RvSdpMediaDescr*			baseMedia,
							  IN RvInt						payload, 
							  IN enMFRtpPayloadCodecType_t	codecEn,
							  IN RV_BOOL					localAndRemote)
{

	switch (codecEn)
	{
		case eMFG711UPayloadCodecType:
		case eMFG711APayloadCodecType:

		case eMFG722PayloadCodecType:

		case eMFG723PayloadCodecType:


		case eMFG729PayloadCodecType:
		case eMFG729ABPayloadCodecType:

		SymmetrizeAttribute("SilenceSupp", AttrValueNegotiateCB_yes_no, baseMedia,  *changingMedia);
		SymmetrizeAttribute("ptime", AttrValueNegotiateCB_min_int, baseMedia,  *changingMedia);
#ifdef MTF_SUPPORT_G711_ANNEX2
		if(payload == PAYLOAD_PCMU || payload == PAYLOAD_PCMA)
		{
			SymmetrizeAttribute("annex2", AttrValueNegotiateCB_yes_no, baseMedia,  *changingMedia);
		}
#endif
		break;


		case eMFH261PayloadCodecType:

			symmetrizeCodecH261(changingMedia, baseMedia, payload, localAndRemote);
			break;


		case eMFH263_2190_PayloadCodecType:

			symmetrizeCodecH263(changingMedia, baseMedia, payload, localAndRemote);
			break;

	default:
		;

	}

}


/***********************************************************
 Function:    SymmetrizeBandwith ()

 Description: analyze just first Bandwidth line

 Arguments:

 Returns:     None.
***********************************************************/
void  SymmetrizeBandwith( IN RvSdpMediaDescr *descrRemote,  INOUT RvSdpMediaDescr *descrLocal)
{
    RvSdpBandwidth* bandLocal;
    RvSdpBandwidth* bandRemote;

    if(rvSdpMediaDescrGetNumOfBandwidth( descrLocal) ==0 || rvSdpMediaDescrGetNumOfBandwidth( descrRemote) ==0 )
        return;
    bandLocal = rvSdpMediaDescrGetBandwidth( descrLocal);
    bandRemote = rvSdpMediaDescrGetBandwidth( descrRemote);

    if(bandLocal->iBWType == bandRemote->iBWType)
    {
        if(bandLocal->iBWValue > bandRemote->iBWValue)
        {
            rvSdpMediaDescrRemoveBandwidth(descrLocal ,0);
            rvSdpMediaDescrAddBandwidth(descrLocal, "TIAS", (int)bandRemote->iBWValue);
        }
    }
}



/***********************************************************
 Function:    SymmetrizeStaticCodec ()

 Description:	Add all codecs existing in descrRemote to msgLocal.
				It's OK because this function is called when descrRemote contain only codes supported by application
 Arguments:	IN	*descrRemote
			IN	payloadRemote 	|
			INOUT *msgLocal	|
 Returns:    rvFalse if fails.
***********************************************************/
static RvBool SymmetrizeStaticCodec( IN RvSdpMediaDescr	*descrRemote, IN int payloadRemote, 
									 IN OUT RvSdpMsg* msgLocal, IN RV_BOOL localAndRemote)
{
	RvSize_t	        i;
	int					payloadLocal;
	RvSdpMediaDescr*	descrLocal;

#ifdef MTF_SUPPORT_G711_ANNEX2
    enum
    {
        PAYLOAD_PCMU  = 0,
        PAYLOAD_PCMA  = 8,
        PAYLOAD_CN    = 13		/* RFC 3551: Comfort noise Audio Clock Rate:8,000 Hz 1 channel */
    };
#endif



    for (i=0; i<rvSdpMsgGetNumOfMediaDescr(msgLocal); ++i)
	{
		RvSize_t	payloadNum;
		RvSize_t	payloadIndex;

		descrLocal = rvSdpMsgGetMediaDescr(msgLocal, i);
		payloadNum = rvSdpMediaDescrGetNumOfPayloads(descrLocal);

		for (payloadIndex=0; payloadIndex < payloadNum; payloadIndex++)
		{
			payloadLocal = rvSdpMediaDescrGetPayloadNumber(descrLocal, (int)payloadIndex);

			if (payloadLocal == payloadRemote)
			{
				/*
				 *	TBD. Different handling for different payload.
				 *  Meanwhile we do default handling on RvSdpMediaDescr level
				 */
				enMFRtpPayloadCodecType_t codecEn = IppCodecGetEnum( descrRemote,  payloadRemote);

				symmetrizeByCodec(&descrLocal, descrRemote, payloadRemote, codecEn, localAndRemote);

				return RV_TRUE;
			}
		}
	}
	return RV_FALSE;
}
/***********************************************************
 Function:    SymmetrizeDynamicCodec ()

 Description: Check if a codec is supported by the gateway
 Arguments:		IN	char* codecName
				 OUT *idxMediaDescr	| position of this codec
				 OUT *idxPayload	| in SdpMsgList stored by gateway
 Returns:    rvFalse if codec not supported.
***********************************************************/
static RvBool SymmetrizeDynamicCodec(IN RvSize_t payloadRemote, IN RvSdpMediaDescr	*descrRemote, 
									 IN OUT RvSdpMsg* msgLocal, IN RV_BOOL localAndRemote)
{
	RvSize_t i;

	RvSdpMediaDescr*	descrLocal;
    RvUint32            payloadLocal;
    enMFRtpPayloadCodecType_t codecEn, codecEnRemote;

    codecEnRemote = IppCodecGetEnum(descrRemote, (int)payloadRemote);

    for (i=0; i < rvSdpMsgGetNumOfMediaDescr( msgLocal); ++i)
	{
		RvSize_t	payloadNum;
		RvSize_t	payloadIndex;

		descrLocal = rvSdpMsgGetMediaDescr( msgLocal, i);
		payloadNum = rvSdpMediaDescrGetNumOfPayloads( descrLocal);

		for( payloadIndex=0; payloadIndex < payloadNum; payloadIndex++)
        {
            payloadLocal = (RvUint32)rvSdpMediaDescrGetPayloadNumber(descrLocal, (int)payloadIndex);
            codecEn = IppCodecGetEnum(descrLocal, (int)payloadLocal);

            if( codecEnRemote == codecEn)
            {

				symmetrizeByCodec(&descrLocal, descrRemote, payloadLocal, codecEn, localAndRemote);
            }

        }
	}

    return rvTrue;
}


/***********************************************************
 Function:    removeIgnoredConnections ()

 Description:	This function checks for connections with port=0,
				and removes them from the list. If these connections
				are open, they should be closed.
***********************************************************/
static void removeIgnoredConnections( RvSdpMsg *msg)
{
	RvSdpMediaDescr *media;
	int rtpPort;
	RvSize_t j;

	for(j=0; j<rvSdpMsgGetNumOfMediaDescr(msg); ++j)
	{
		media = rvSdpMsgGetMediaDescr(msg, j);
		rtpPort=rvSdpMediaDescrGetPort(media);
		if (rtpPort == 0)
		{
			rvSdpMsgRemoveMediaDescr(msg,j);
			continue;
		}
	}
}


RvBool	symmetrizeLocalWithRemote( IN OUT RvSdpMsg *msgLocal, IN RvSdpMsg *msg/*Remote*/)
{
    RvSdpMsg            *msgRemote = msg;
	RvSdpMediaDescr		*media, *dummyPtr=NULL;

	size_t				i, idxPayload, idxRtpMap;
	RvBool				bPayloadSupported;
	int					payload;


	for(i=0; i < rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		media = rvSdpMsgGetMediaDescr(msg, i);


		/*Go through list of codecs*/
        idxPayload=0;
		while( idxPayload < rvSdpMediaDescrGetNumOfPayloads(media))
		{
			idxRtpMap = (size_t)(-1);
			bPayloadSupported = rvTrue;
			payload = rvSdpMediaDescrGetPayloadNumber(media, (int)idxPayload);


			/* Attributes of different codecs may be different. switch over payloads should be here. */

			/* Static payloads */
			/* --------------- */
			if (payload < RV_IPP_FIRST_DYNAMIC_PAYLOAD)
			{

				if(!SymmetrizeStaticCodec( media, payload, msgLocal, RV_TRUE))
				{
					bPayloadSupported = rvFalse;
				}
			}
			/* Dynamic payloads */
			/* ---------------- */
			else
			{
				if (!SymmetrizeDynamicCodec((RvSize_t)payload, media, msgLocal, RV_TRUE))
				{
					bPayloadSupported = rvFalse;
				}

			}

			/* Payload not supported */
			/* --------------------- */
			if(!bPayloadSupported)
			{
				rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
				if(	idxRtpMap != (size_t)(-1))
				{
					rvSdpMediaDescrRemoveRtpMap( media, idxRtpMap);
				}
			}
            else
			{
                ++idxPayload;
			}
		}
	}

	/* Remove media with all payloads removed above, (!) starting from the last.  */

	for(i= rvSdpMsgGetNumOfMediaDescr(msg) -1; (int)i >=0 ; i--)
	{
		media = rvSdpMsgGetMediaDescr(msg, i);


		if( !rvSdpMediaDescrGetNumOfPayloads(media))
			rvSdpMsgRemoveMediaDescr( msg, i);
	}



	/* We remove media from local that doesn't exist in remote. */

	while( i < rvSdpMsgGetNumOfMediaDescr(msgLocal))
	{
		media = rvSdpMsgGetMediaDescr(msgLocal, i);


		/*Go through list of codecs*/
		for(idxPayload=0; idxPayload < rvSdpMediaDescrGetNumOfPayloads(media); ++idxPayload)
		{
			idxRtpMap = (size_t)(-1);
			bPayloadSupported = rvTrue;
			payload = rvSdpMediaDescrGetPayloadNumber(media, (int)idxPayload);


			/* Attributes of different codecs may be different. Switch over payloads should be here.	*/

			/* Static payloads */
			/* --------------- */
			if (payload < RV_IPP_FIRST_DYNAMIC_PAYLOAD)
			{

				if (!isStaticCodecAvailable(msg, (RvIppCodingId)payload, &dummyPtr))
				{
					bPayloadSupported = rvFalse;
				}
			}
			/* Dynamic payloads */
			/* ---------------- */
			else
			{
				RvSdpRtpMap*	rtpMap = NULL;
				int				element;

				/* find the rtp map of this payload type */
				for(idxRtpMap=0; idxRtpMap< rvSdpMediaDescrGetNumOfRtpMap(media); ++idxRtpMap)
				{
					rtpMap = rvSdpMediaDescrGetRtpMap(media, idxRtpMap);
					element = rvSdpRtpMapGetPayload(rtpMap);
					/*Look for the rtp map that matches this payload*/
					if (element == payload)
						break;

				}

				if(rtpMap)
				{

					if(!isDynamicCodecAvailable( msg, rvSdpRtpMapGetEncodingName(rtpMap), &dummyPtr))
					{
						bPayloadSupported = rvFalse;
					}
				}
			}

			/* Payload not supported */
			/* --------------------- */
			if(!bPayloadSupported)
			{
				rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
				if(	idxRtpMap != (size_t)(-1))
				{
					rvSdpMediaDescrRemoveRtpMap( media, idxRtpMap);
				}

                if( !rvSdpMediaDescrGetNumOfPayloads(media))
				{
                    i++;
				}
			}
            else
            {
                ++i;
            }
		}
	}

	/* Remove media with all payloads removed above, (!) starting from the last. */

	for(i= rvSdpMsgGetNumOfMediaDescr(msgLocal) -1; (int)i >=0 ; i--)
	{
		media = rvSdpMsgGetMediaDescr(msgLocal, i);


		if( !rvSdpMediaDescrGetNumOfPayloads(media))
			rvSdpMsgRemoveMediaDescr( msgLocal, i);
	}

	/* Leave only one audio and video payload in local and remote descriptors. */
    {
        RvBool  bFoundAudio = rvFalse;
        RvBool  bFoundVideo = rvFalse;
        int payloadAudio =0, payloadAudioTmp;
        int payloadVideo =0, payloadVideoTmp;

        i =0;
	    while( i < rvSdpMsgGetNumOfMediaDescr(msgRemote))
	    {
            RvSdpMediaType  mediaType;

            media = rvSdpMsgGetMediaDescr( msgRemote, i);
            mediaType = rvSdpMediaDescrGetMediaType( media);

			/* Handle Audio codecs */
			/* ------------------- */
            if (mediaType == RV_SDPMEDIATYPE_AUDIO && !bFoundAudio)
            {
                bFoundAudio = rvTrue;

		        /*Go through list of codecs*/
		        payloadAudio = rvSdpMediaDescrGetPayloadNumber( media, 0);
                /* remove all others*/
		        for(idxPayload = rvSdpMediaDescrGetNumOfPayloads(media) -1; idxPayload >0; --idxPayload)
		        {
			        rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
                }
                i++;
                continue;
            }
			/* Handle Video codecs */
			/* ------------------- */
            else if(mediaType == RV_SDPMEDIATYPE_VIDEO && !bFoundVideo)
            {
                bFoundVideo = rvTrue;
		        /*Go through list of codecs*/
		        payloadVideo = rvSdpMediaDescrGetPayloadNumber( media, 0);
                /* remove all others*/
		        for(idxPayload = rvSdpMediaDescrGetNumOfPayloads(media) -1; idxPayload >0; --idxPayload)
		        {
			        rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
                }
                i++;
                continue;
            }
            else
            {
   			    rvSdpMsgRemoveMediaDescr( msgRemote, i);
            }
	    }

        bFoundAudio = rvFalse;
        bFoundVideo = rvFalse;
        i =0;
	    while( i < rvSdpMsgGetNumOfMediaDescr( msgLocal))
	    {
            RvSdpMediaType  mediaType;

            media = rvSdpMsgGetMediaDescr( msgLocal, i);
            mediaType = rvSdpMediaDescrGetMediaType( media);

			/* Handle Audio codecs */
			/* ------------------- */
            if (mediaType == RV_SDPMEDIATYPE_AUDIO && !bFoundAudio)
            {
		        /*Go through list of codecs*/
		        for(idxPayload = 0; idxPayload < rvSdpMediaDescrGetNumOfPayloads(media);  )
		        {
    		        payloadAudioTmp = rvSdpMediaDescrGetPayloadNumber(media, (int)idxPayload);
                    if (payloadAudio != payloadAudioTmp)
                    {
			            rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
                    }
                    else
                    {
                        ++idxPayload;
                        bFoundAudio = rvTrue;
                    }
                }
                if(bFoundAudio)
                {
                    i++;
                    continue;
                }
                else
       			    rvSdpMsgRemoveMediaDescr( msgLocal, i);
            }
			/* Handle Video codecs */
			/* ------------------- */
            else if(mediaType == RV_SDPMEDIATYPE_VIDEO && !bFoundVideo)
            {
		        /*Go through list of codecs*/
		        for(idxPayload = 0; idxPayload < rvSdpMediaDescrGetNumOfPayloads(media); )
		        {
    		        payloadVideoTmp = rvSdpMediaDescrGetPayloadNumber(media, (int)idxPayload);
                    if( payloadVideo != payloadVideoTmp)
                    {
			            rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
                    }
                    else
                    {
                        ++idxPayload;
                        bFoundVideo = rvTrue;
                    }
                }
                if(bFoundVideo)
                {
                    i++;
                    continue;
                }
                else
       			    rvSdpMsgRemoveMediaDescr( msgLocal, i);
            }
            else
            {
   			    rvSdpMsgRemoveMediaDescr( msgLocal, i);
            }
	    }

    }

	return rvTrue;
}


/***********************************************************
 Function:    processLocalSdp ()

 Description: Goes through local sdp list to find sdp we support.
			  Once sdp was found, we set the connection and make sure
			  the list will contain only the parameters we chose.
			  In the current sample sdp will be always found. But real application
			  may consult if media, found below, is supported in current run-time context.

 Arguments:

 Returns:     True - success, False - no supported parameters were found

 Notes:		  For now assume only one stream.
			  
***********************************************************/

static RvBool processLocalSdp( INOUT RvSdpMsg *msg, IN RvSdpMsg *msgAvailable)
{
	RvSdpMediaDescr		*media;
	RvSize_t			i,idxPayload, idxRtpMap;
	RvBool				bPayloadSupported;
	int					payload;
	RvSdpMediaDescr *matchDescr = NULL;
	RvBool			    supportedCodecWasFound = rvFalse;	

	for(i=0; i < rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		media = rvSdpMsgGetMediaDescr(msg, i);

		/*Go through list of codecs*/
		for(idxPayload=0; idxPayload < rvSdpMediaDescrGetNumOfPayloads(media); ++idxPayload)
		{
			idxRtpMap = (size_t)(-1);
			bPayloadSupported = rvTrue;
			payload = rvSdpMediaDescrGetPayloadNumber(media, (int)idxPayload);


			/*
			*	Attributes of different codecs may be different.
			*  switch over payloads should be here
			*/
			if (payload < RV_IPP_FIRST_DYNAMIC_PAYLOAD)
			{/* static payload*/


				if (!isStaticCodecAvailable(msgAvailable, (RvIppCodingId)payload, &matchDescr))
				{
					bPayloadSupported = rvFalse;
				}
				else
				{
					enMFRtpPayloadCodecType_t codecEn = IppCodecGetEnum( media,  payload);
					/* found a matching descriptor with the same payload. Symmetrize the codec attributes */
					symmetrizeByCodec(&media, matchDescr, payload, codecEn, RV_FALSE);

					/* this is case when the sdp paylod doesn't have attributes --> invalid SDP message */
					if (codecEn == eMFNullPayloadCodecType)  
					{
						bPayloadSupported = rvFalse;
					}
					else
					{
						supportedCodecWasFound =  rvTrue;
					}
				}
			}
			else
			{/* dynamic payload*/
				RvSdpRtpMap*	rtpMap = NULL;
				int				element;

				/* find the rtp map of this payload type */
				for(idxRtpMap=0; idxRtpMap< rvSdpMediaDescrGetNumOfRtpMap(media); ++idxRtpMap)
				{
					rtpMap = rvSdpMediaDescrGetRtpMap(media, idxRtpMap);
					element = rvSdpRtpMapGetPayload(rtpMap);
					/*Look for the rtp map that matches this payload*/
					if (element == payload)
						break;
				}

				if(rtpMap)
				{

					if(!isDynamicCodecAvailable( msgAvailable, rvSdpRtpMapGetEncodingName(rtpMap), &matchDescr))
					{
						bPayloadSupported = rvFalse;
					}
					else
					{
						enMFRtpPayloadCodecType_t codecEn = IppCodecGetEnum( matchDescr,  payload);
						/* found a matching descriptor with the same payload. Symmetrize the codec attributes */
						symmetrizeByCodec(&media, matchDescr, payload, codecEn, RV_FALSE);
					}
				}
			}

			if(!bPayloadSupported)
			{
				rvSdpMediaDescrRemovePayloadNumber( media, idxPayload);
				if(idxRtpMap != (size_t)(-1))
					rvSdpMediaDescrRemoveRtpMap( media, idxRtpMap);
			}
		}
	}

	/*
	 *	remove media with all payloads removed above, (!) starting from the last
	 */

	for(i= rvSdpMsgGetNumOfMediaDescr(msg) -1; (int)i >=0 ; i--)
	{
		media = rvSdpMsgGetMediaDescr(msg, i);

		if( !rvSdpMediaDescrGetNumOfPayloads(media))
			rvSdpMsgRemoveMediaDescr( msg, i);
	}

	removeIgnoredConnections( msg);

	if (supportedCodecWasFound)
	{
		return rvTrue;
	}
	else
	{
		return rvFalse;
	}
}

/***********************************************************
 Function:    processRemoteSdp ()

 Description: Goes through remote sdp list to find sdp we support.
			  Once sdp was found, we set the connection and make sure
			  the list will contain only the parameters we chose.
			  Update rtp media parameters.

 Arguments:

 Returns:     True - success, False - no supported parameters were found

 Notes:		  For now assume only one stream.
			  
***********************************************************/
static RvBool processRemoteSdp( INOUT RvSdpMsg *msg, IN RvSdpMsg *msgAvailable)
{
	RvSdpMediaDescr		*newMedia; /* Eventually will contain only supported codecs*/
	RvSdpMediaDescr		origMedia; /* Original list to go through, will not be changed */
	size_t				i, idxPayload, idxRtpMap, numRemovedPayloads, numRemovedRtpmaps;
	int					payload =-1;
    RvBool              retval = rvFalse;

	/* Construct with meaningless values*/
	rvSdpMediaDescrConstructA(&origMedia, RV_SDPMEDIATYPE_NOTSET, 0, RV_SDPPROTOCOL_NOTSET, userDefaultAlloc);

	for(i=0; i < rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		/* Original list is copied from remote list*/
		rvSdpMediaDescrCopy(&origMedia, rvSdpMsgGetMediaDescr(msg, i));
		/* Changes in new list will be made in remote list*/
		newMedia = rvSdpMsgGetMediaDescr(msg, i);
		numRemovedPayloads = 0;
		numRemovedRtpmaps = 0;

		/*Go through list of codecs in origMedia, and find the supported ones.
		  A non supported codec will be removed from newMedia. */
		for(idxPayload=0; idxPayload < rvSdpMediaDescrGetNumOfPayloads(&origMedia); ++idxPayload)
		{
    	    RvBool				bPayloadSupported = rvTrue;
			idxRtpMap = (size_t)(-1);
			payload = rvSdpMediaDescrGetPayloadNumber(&origMedia, (int)idxPayload);

			/*
			*	Attributes of different codecs may be different.
			*  switch over payloads should be here
			*/
			if (payload < RV_IPP_FIRST_DYNAMIC_PAYLOAD)
			{/* static payload*/
				RvSdpMediaDescr *matchDescr = NULL;

				if (!isStaticCodecAvailable(msgAvailable, (RvIppCodingId)payload, &matchDescr))
				{
					bPayloadSupported = rvFalse;
				}
				else
				{
					enMFRtpPayloadCodecType_t codecEn = IppCodecGetEnum( newMedia,  payload);
					/* found a matching descriptor with the same payload. Symmetrize the codec attributes */
					symmetrizeByCodec(&newMedia, matchDescr, payload, codecEn, RV_FALSE);
				}
			}
			else
			{/* dynamic payload*/
				RvSdpRtpMap*	rtpMap = NULL;
				int				element;

				/* find the rtp map of this payload type */
				for(idxRtpMap=0; idxRtpMap< rvSdpMediaDescrGetNumOfRtpMap(&origMedia); ++idxRtpMap)
				{
					rtpMap = rvSdpMediaDescrGetRtpMap(&origMedia, idxRtpMap);
					element = rvSdpRtpMapGetPayload(rtpMap);
					/*Look for the rtp map that matches this payload*/
					if (element == payload)
						break;

				}

				if(rtpMap)
				{
					RvSdpMediaDescr *matchDescr = NULL;

					if(!isDynamicCodecAvailable( msgAvailable, rvSdpRtpMapGetEncodingName(rtpMap), &matchDescr))
					{
						bPayloadSupported = rvFalse;
					}
					else
					{
						enMFRtpPayloadCodecType_t codecEn = IppCodecGetEnum( newMedia,  payload);
						/* found a matching descriptor with the same payload. Symmetrize the codec attributes */
						symmetrizeByCodec(&newMedia, matchDescr, payload, codecEn, RV_FALSE);
					}
				}
			}

			/* A non supported codec will be removed with its rtp map (if one exists)*/
			if(!bPayloadSupported)
			{
				/* Since items are removed from newMedia, index of payload and rtpmap
				   in newMedia is not the same as in origMedia*/
				numRemovedPayloads++;
				rvSdpMediaDescrRemovePayloadNumber( newMedia, idxPayload + 1 - numRemovedPayloads);
				if(idxRtpMap != (size_t)(-1)) {
					numRemovedRtpmaps++;
					rvSdpMediaDescrRemoveRtpMap( newMedia, idxRtpMap + 1 - numRemovedRtpmaps);
				}
			}
            else
            {
                retval = rvTrue;
            }
		}

	}

	/*
	 *	remove empty media descriptors, (!) starting from the last
	 */

	for(i= rvSdpMsgGetNumOfMediaDescr(msg) -1; (int)i >=0 ; i--)
	{
		newMedia = rvSdpMsgGetMediaDescr(msg, i);

		if( !rvSdpMediaDescrGetNumOfPayloads(newMedia))
			rvSdpMsgRemoveMediaDescr( msg, i);
	}

	rvSdpMediaDescrDestruct(&origMedia);
	removeIgnoredConnections( msg);
	return retval;
}

/*===============================================================================*/
/*=======  M E D I A   N E G O T I A T I O N   C A L L B A C K		 ============*/
/*===============================================================================*/


/******************************************************************************
*  IppSampleMediaNegotiateCB
*  ----------------------------
*  General :    This is a sample code for performing media negotiation during a call.
*				In this implementation we do the following:
*				1. Go through local list and choose the one codec we want to offer to 
*				   remote party. We also compare codec attributes.
*				2. Go through remote list and choose the one codec we both support. 
*				   We also compare codec attributes.
*				3. Symmetrizing local and remote codecs in case they different. This is done for convenience only. 
*				4. print results to log.
*				Application may change this implementation to fit its requirements.
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*		msgLocal		- local media capabilities for sending to remote party
*		msgRemote		- remote media capabilities as were received from remote party 
*		msgAvailable	- currently available media in our system.	
*
******************************************************************************/
RvBool rvMtfSampleMediaNegotiate(   
				INOUT RvSdpMsg*			msgLocal,
				INOUT RvSdpMsg*			msgRemote,
				IN RvSdpMsg*			msgAvailable)
{
	RvBool			retval			= rvTrue;

	IppLogMessage(RV_FALSE, "rvMtfSampleMediaNegotiate() - starting media negotiation...");

	/* Process local SDP */
	/* ----------------- */

	if( msgLocal)
    {
		/*  Choose the local capabilities which we want to offer to remote party. When this function returns,
			localSdp will include only the codec we want to offer. */
        retval = processLocalSdp( msgLocal, msgAvailable);

	    if( !msgLocal || !retval)
	    {
		    IppLogMessage(RV_TRUE, "rvMtfSampleMediaNegotiate() - No supported codecs were found in local list");
		    return  RV_FALSE;
	    }
    }

    /* Process remote SDP */
	/* ------------------ */

	/*  Go through local and remote and choose the common capabilities. When this function returns, localSdp
		will include the one codec we chose. */
	if (msgRemote && (retval = processRemoteSdp( msgRemote, msgAvailable)))
	{
		if(!retval)
		{
			IppLogMessage(RV_TRUE, "rvMtfSampleMediaNegotiate() - No supported codecs were found in Remote list");
			return  RV_FALSE;
		}
	}

	if(!msgLocal || !retval)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleMediaNegotiate() - failed to find common capabilities");
		return  RV_FALSE;
	}

	/* Symmetric local and remote */
	/* -------------------------- */
	/* If remote codec is different than local one, set them to the same value.  */
	if(msgRemote)
	{
		symmetrizeLocalWithRemote( msgLocal, msgRemote);
	}

	/* Check if local and remote are not empty */
	/* --------------------------------------- */
	/* Check if both msgLocal and msgRemote still contain at least one media descriptor ("m=" line). */
	
	/*
	if( msgLocal && rvSdpMsgGetNumOfMediaDescr( msgLocal) ==0)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleMediaNegotiate() - local list is empty");
		return  RV_FALSE;
	}
	if( msgRemote && rvSdpMsgGetNumOfMediaDescr( msgRemote) ==0)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleMediaNegotiate() - remote list is empty");
		return  RV_FALSE;
	}
	*/


	/* Print to log */
	/* ------------- */
	if( msgLocal)
	{
		IppPrintSdp( msgLocal, "rvMtfSampleMediaNegotiate():\n ********* Local SDP *********");
	}

	if( msgRemote)
	{
		IppPrintSdp( msgRemote, "rvMtfSampleMediaNegotiate():\n ********* Remote SDP *********");
	}

	IppLogMessage(RV_FALSE, "rvMtfSampleMediaNegotiate() - media negotiation is done.");

	return RV_TRUE;

}


