/******************************************************************************
Filename:    rvMtfMediaCallbacks.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

  RADVISION LTD. reserves the right to revise this publication and make
  changes without obligation to notify any person of such revisions or
  changes.
******************************************************************************/
#ifndef RV_MEDIACB_H
#define RV_MEDIACB_H

#include "MfControl.h"
#include "rvMtfBaseApi.h"


/*===============================================================================*/
/*================== M E D I A			C A L L B A C K	S	=====================*/
/*===============================================================================*/

/***************************************************************************
 * rvMtfSampleConnectMediaCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleConnectMediaCB(
				RvIppTerminalHandle			hTermSource,
				RvMtfTerminalAppHandle		hAppTermSource,
				RvIppTerminalHandle			hTermTarget,
				RvMtfTerminalAppHandle		hAppTermTarget,
				RvMtfTerminalType			termType);

/***************************************************************************
 * rvMtfSampleDisconnectMediaCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDisconnectMediaCB(
               RvIppTerminalHandle			hTermSource,
			   RvMtfTerminalAppHandle		hAppTermSource,
               RvIppTerminalHandle			hTermTarget,
			   RvMtfTerminalAppHandle		hAppTermTarget,
			   RvMtfTerminalType			termType);

/***************************************************************************
 * rvMtfSampleCreateMediaCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleCreateMediaCB(
                RvIppConnectionHandle       hConn,
                RvMtfConnAppHandle          hAppConn,
                RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
                RvMtfMediaParams*			params);

/***************************************************************************
 * rvMtfSampleModifyMediaCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleModifyMediaCB(
                RvIppConnectionHandle       hConn,
                RvMtfConnAppHandle          hAppConn,
                RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
                RvMtfMediaParams*			params);

/***************************************************************************
 * rvMtfSampleDestroyMediaCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDestroyMediaCB( 
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm);

/***************************************************************************
 * rvMtfSampleStartPhysicalDeviceCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleStartPhysicalDeviceCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
				RvMtfTerminalType			termType);

/***************************************************************************
 * rvMtfSampleStopPhysicalDeviceCB
 ***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleStopPhysicalDeviceCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
				RvMtfTerminalType			termType);

/***************************************************************************
 * rvMtfSampleModifyMediaCompletedCB
 ***************************************************************************/
void RVCALLCONV rvMtfSampleModifyMediaCompletedCB(
			   RvIppTerminalHandle				hTerm,
			   RvMtfTerminalAppHandle			hAppTerm,
			   RvMtfDynamicModifyMediaStatus	status,
			   RvSdpMsg*						sdp);       

/***************************************************************************
* rvMtfSampleConnModifySpecificMediaStreamCB       
***************************************************************************/
RvStatus RVCALLCONV rvMtfSampleConnModifySpecificMediaStreamCB(
	IN      RvIppConnectionHandle           hConn,
	IN      RvMtfConnAppHandle              hAppConn,
	IN		RvIppTerminalHandle				hTerm,		
	IN		RvMtfTerminalAppHandle			hAppTerm,
	IN      RvMtfMediaStreamHandle			hStream,
	INOUT	RvMtfMediaStreamAppHandle*		hAppStream,
	INOUT	RvMtfMediaStreamParams*			params);

#ifdef RV_MTF_SECOND_VIDEO
/***************************************************************************
* rvMtfSamplePresentationTokenMsgReceivedCB 
***************************************************************************/
RvStatus RVCALLCONV rvMtfSamplePresentationTokenMsgReceivedCB(
	IN		RvIppConnectionHandle				hConn,
	IN		RvMtfConnAppHandle					hAppConn,
	IN		RvIppTerminalHandle					hTerm,
	IN		RvMtfTerminalAppHandle				hAppTerm,
	IN		RvMtfMediaStreamHandle				hStream,
	INOUT	RvMtfMediaStreamAppHandle*			hAppStream,
	IN      RvMtfPresentationTokenMsgParams*	msgParams,
	IN      RvMtfMediaStreamParams*				mediaStreamParams);
#endif

/******************************************************************************
*  RvMtfCreateMediaNegotiateCB
*  ----------------------------
*  General :     user CB to negotiate media.
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:        
*               
******************************************************************************/
typedef RvBool (*RvMtfMediaNegotiateCB)( INOUT RvSdpMsg* msgLocal, 
                                         INOUT RvSdpMsg* msgRemote, 
                                         IN RvSdpMsg*    msgAvailable);

typedef struct
{
    RvMtfHandle 	        mtfHandle;  
	RvMtfMediaNegotiateCB   mediaNegotiate;/* negotiation policy. called in media CB implementations*/
    /*MfControl parameters to initialize Media library*/
    RvBool                      bDisableMedia; /* if false the following mfControlParams is irrelevant*/
    RvMfControlConstructParam   mfControlParams;
    RvSdpMsg*               sdpFullCaps;
	RvSdpMsg*               sdpForInvite;
}RvMtfMediaConstructParam;


/*====================================================================================*/
/*=====  I N T E R N A L	M E D I A	M O D U L E		F U N C T I O N S   ==========*/
/*====================================================================================*/

/******************************************************************************
*  rvMtfMediaInitConfig
*  ----------------------------
*  General :        Set default values for parameters which may be used in rvMtfMediaInit
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInitConfig( INOUT RvMtfMediaConstructParam* p);

/******************************************************************************
*  rvMtfMediaInit
*  ----------------------------
*  General :        Register Media CB for TK etc. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInit( IN RvMtfMediaConstructParam* p);

/******************************************************************************
*  rvMtfMediaEnd
*  ----------------------------
*  General :        Unregister Media CB for TK. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaEnd();

/******************************************************************************
*  rvMtfMediaStart
*  ----------------------------
*  General :        Start internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
RvStatus rvMtfMediaStart( void* context);

/******************************************************************************
*  rvMtfMediaStop
*  ----------------------------
*  General :        Stop internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaStop( void* context);

#ifdef RV_MTF_N_LINES

RvStatus RVCALLCONV rvMtfSampleConnectMultiStreams(
												   IN RvPtrList		hTermsList);
RvStatus RVCALLCONV rvMtfSampleDisconnectMultiStreams(
													  IN RvPtrList		hTermsList);

#endif /*RV_MTF_N_LINES */


#endif /*RV_MEDIACB_H*/

