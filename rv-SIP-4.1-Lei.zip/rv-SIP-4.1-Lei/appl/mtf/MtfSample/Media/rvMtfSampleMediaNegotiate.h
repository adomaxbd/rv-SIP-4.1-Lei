/******************************************************************************
Filename:    rvMtfSampleMediaNegotiate.h
Description: This file contains the Call Forward implementation of MTF sample application.
			 User application may use this file as an example and make the necessary
			 changes to adjust it to application's needs.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_MEDIA_NEGOTIATE_H
#define RV_MEDIA_NEGOTIATE_H


/******************************************************************************
*  rvMtfSampleMediaNegotiate
*  ----------------------------
*  General :     user CB to negotiate media.
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
******************************************************************************/
RvBool rvMtfSampleMediaNegotiate(
						INOUT RvSdpMsg* msgLocal,
						INOUT RvSdpMsg* msgRemote,
						IN RvSdpMsg*    msgAvailable);

#endif /*RV_MEDIA_NEGOTIATE_H */



