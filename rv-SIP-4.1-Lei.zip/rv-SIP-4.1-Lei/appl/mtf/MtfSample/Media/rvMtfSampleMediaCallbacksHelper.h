/******************************************************************************
Filename:    MtfMediaCallbacksHelper.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#ifndef RV_MC_HELPER_H
#define RV_MC_HELPER_H


#if defined(__cplusplus)
extern "C" {
#endif

#include "rvMtfExtControlApi.h"
#include "MfControl.h"

typedef enum 
{
    RVIPP_MEDIA_DEV_MIN             =-1,
    RVIPP_MEDIA_DEV_MIC             =0,
    RVIPP_MEDIA_DEV_SPEAKER,
    RVIPP_MEDIA_DEV_DISPLAY_WINDOW,
    RVIPP_MEDIA_DEV_CAMERA,
    RVIPP_MEDIA_DEV_MAX
}RvIppMediaDevice;

/***************************************************************************************
 * mcHelperCreateLocalRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.   
 *			At this point  local<-->remote negotiation ended. 	
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec. 	
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify 	
 *			appropriate rtp sessions.	
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.	
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgLocal: list of incoming media
 *				
 * Output:   
 *			RvSdpMsg*		- msgLocal: list of incoming media. media RTP/RTCP addresses should be initialized.
 *				
 **************************************************************************************/
RvStatus mcHelperCreateRtpLocal(  IN void* context, 
                                 IN RvUint32        connectionId, 
                                 IN const char*     termId, 
                                 INOUT RvSdpMsg *msgLocal);
/***************************************************************************************
 * mcHelperModifyRtpLocalBySdp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.   
 *			At this point  local<-->remote negotiation ended. 	
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec. 	
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify 	
 *			appropriate rtp sessions.	
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.	
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgLocal: list of incoming media
 *				
 * Output:   
 *			None
 *				
 **************************************************************************************/
RvStatus mcHelperModifyRtpLocalBySdp( IN void* context,  
                                 IN RvUint32        connectionId, 
                                 IN const char*     termId, 
                                 IN RvSdpMsg*         msgLocal);

/***************************************************************************************
 * mcHelperModifyRtpLocalByMode
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.   
 *			At this point  local<-->remote negotiation ended. 	
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec. 	
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify 	
 *			appropriate rtp sessions.	
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.	
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgLocal: list of incoming media
 *				
 *			RvMdmTermConnState	- state: defined by user ( say, mute implementation)
 *				
 * Output:   
 *			None
 *				
 **************************************************************************************/
RvStatus mcHelperModifyRtpLocal(  IN void*			context, 
                               IN RvUint32			connectionId, 
                               IN const char*		termId, 
                               IN RvSdpMsg*         msgLocal,
                               IN RvMtfMediaAction  cmd);

/***************************************************************************************
 * mcHelperModifyRtpRemoteBySdp
 * -------------------------------------------------------------------------------------
 * General: to create or modify appropriate rtp sessions.
 *          Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.   
 *			At this point  local<-->remote negotiation ended. 	
 *			msgRemote contains not more than 1 audio codec and 1 video codec. 	
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify 	
 *			appropriate rtp sessions.	
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgRemote: list of outgoing media
 *				
 * Output:   
 *			None
 *				
 **************************************************************************************/
RvStatus mcHelperModifyRtpRemoteBySdp(  IN void* context, 
                                 IN RvUint32        connectionId, 
                                 IN const char*     termId, 
                                 IN RvSdpMsg *msgRemote);

/***************************************************************************************
 * mcHelperModifyRtpLocalByMode
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.   
 *			At this point  local<-->remote negotiation ended. 	
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec. 	
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify 	
 *			appropriate rtp sessions.	
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.	
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgRemote: list of outgoing media
 *				
 *			RvMdmTermConnState	- state: defined by user ( say, mute implementation)
 *				
 * Output:   
 *			None
 *				
 **************************************************************************************/
RvStatus mcHelperModifyRtpRemote( IN void* context, 
                                 IN RvUint32        connectionId, 
                                 IN const char*     termId, 
                                 IN RvSdpMsg*       msgRemote,
                                 IN RvMtfMediaAction  cmd);

/***************************************************************************************
 * mcHelperDestroyRtpId
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to destroy rtp sessions.
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			const char*		- rtpId: name Link object
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperDestroyLink( IN void* context, const char* szId);

/***************************************************************************************
 * mcHelperDestroyRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to destroy rtp media.    
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperDestroyRtp( IN void* context, const char* termId);



/***************************************************************************************
 * mcHelperConnectRtpToDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to connect rtp session to device. Invoke RvIppMediaControlInterface.   
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			const char*		- termIdDev: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperConnectRtpToDev( IN void* context,
								   RvIppMediaDevice devId, 
								   const char* termId);

/***************************************************************************************
 * mcHelperDisconnectRtpFromDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to disconnect rtp session from device. Invoke RvIppMediaControlInterface.   
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			const char*		- termIdDev: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperDisconnectRtpFromDev( IN void* context,
									IN RvIppMediaDevice devId, 
									IN const char* termId);


/***************************************************************************************
 * mcHelperOpenDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open a device. Invoke RvIppMediaControlInterface.   
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			RvIppMediaDevice		- devId
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperOpenDev( IN void* context, RvIppMediaDevice devId);


/***************************************************************************************
 * mcHelperCloseDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to close a device. Invoke RvIppMediaControlInterface.   
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			RvIppMediaDevice		- devId
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperCloseDev( IN void* context,  RvIppMediaDevice devId);

/***************************************************************************************
 * mcHelperConnectRtpToRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to connect rtp session to another rtp session (used to join calls). Invoke RvIppMediaControlInterface.   
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			const char*		- termIdDev: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperConnectRtpToRtp( IN void* context,
										   const char* termIdSrc, 
										   const char* termId);

/***************************************************************************************
 * mcHelperDisconnectRtpFromRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to disconnect rtp session from device. Invoke RvIppMediaControlInterface.   
 *				
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 
 *			const char*		- termIdSrc: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *				
 * Output:  None 
 *				
 **************************************************************************************/
RvStatus mcHelperDisconnectRtpFromRtp( IN void* context,
												IN const char* termIdSrc, 
												IN const char* termId);
												


/*====================================================*/
/*= split between media and no_media options =========*/
/* we use wrapper containing logics of splitting MfControl and MediaControl libraries */
/*----------------------------------------------------------------------------------------------------------*/
HLinkDB  wrapDbLinkFindByName( IN void* context, IN const char* linkName);
/*----------------------------------------------------------------------------------------------------------*/
HOperDB  wrapDbOperFindByName( IN void* context, IN const char* opName);
/*----------------------------------------------------------------------------------------------------------*/
HOperDB  wrapDbGetOperElmIn( IN void* context, IN HLinkDB hLinkElm);
/*----------------------------------------------------------------------------------------------------------*/
HOperDB  wrapDbGetOperElmOut( IN void* context, IN HLinkDB hLinkElm);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapControlInit( IN void* context, IN RvMfControlConstructParam* param);
/*----------------------------------------------------------------------------------------------------------*/
void     wrapControlEnd( IN void* context);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkNew(  IN void* context, OUT HLinkDB *hLink,INOUT RvMfCLinkParamBase* param);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkDelete( IN void* context, IN HLinkDB hLink);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkStart  ( IN void* context, IN HLinkDB hLink);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkStop ( IN void* context, IN HLinkDB hLink);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkModify ( IN void* context, IN HLinkDB hLink, IN RvMfCLinkModifyParam* param);
/*----------------------------------------------------------------------------------------------------------*/
RvBool   wrapLinkIsStarted ( IN void* context, IN HLinkDB hLink);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapOperatorNew(  IN void* context, OUT HOperDB *hOperator, IN const char* opName, IN RvMfCOprBaseParam* param);
/*----------------------------------------------------------------------------------------------------------*/
void     wrapOperatorDelete( IN void* context, IN HOperDB hOperator);
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapOperatorCmd( IN void* context, IN RvMfCOpCmd cmd, IN RvMfCOpCmdParam* param);
/*----------------------------------------------------------------------------------------------------------*/



#if defined(__cplusplus)
}
#endif

#endif
