/******************************************************************************
Filename:    rvMtfMediaCallbacks.c
Description: This file includes implementations for MTF media callbacks.
			 This implementation is using the media engine in the GUI application,
			 by sending EPP messages over UDP.
			 User application should replace the EPP messages with calling directly
			 to application media engine.
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

  RADVISION LTD. reserves the right to revise this publication and make
  changes without obligation to notify any person of such revisions or
  changes.
******************************************************************************/

#include "ipp_inc_std.h"
#include "rvMtfSample.h"
#include "rvMtfSampleMediaCallbacks.h"
#include "rvMtfSampleMediaCallbacksHelper.h"
#include "rvMtfSampleMediaNegotiate.h"
#include "rvMtfExtControlApi.h"
#include "rvMdmControlApi.h"
#include "rvcctext.h"

/*===============================================================================*/
/*==========================    G L O B A L S   =================================*/
/*===============================================================================*/
RvMtfMediaConstructParam  g_param;


/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

/******************************************************************************
*  printSdp
*  ----------------------------
*  General :   This function prints SDP message to log with a title.
*
*  Return Value:	None.
*
*  Arguments:
*  Input:
*					sdp		-	pointer to SDP message to print.
*					title	-	title to be printed before the SDP message.
*
*  Output:			None.
******************************************************************************/
static void printSdp( RvSdpMsg *sdp, const char* title)
{
    char	buf[1024];
    int		len = sizeof(buf) -1;
    RvSdpStatus  stat;

    rvSdpMsgEncodeToBuf( sdp, buf, len, &stat);

    if (stat != RV_SDPSTATUS_OK)
    {
        IppLogMessage(rvTrue,"%s printSdp() failed", title);
        return;
    }

    IppLogMessage(RV_FALSE,"%s\n%s\n", title, buf);

}

/******************************************************************************
*  printMediaStreamDescr
*  ----------------------------
*  General :   This function prints media stream descriptor message to log with 
*  a title.
*
*  Return Value:	None.
*
*  Arguments:
*  Input:
*					streamDescr - pointer to media descriptor to print.
*					headline	- title to be printed before the SDP message.
*
*  Output:			None.
******************************************************************************/
static void printMediaStreamDescr( RvSdpMediaDescr*	streamDescr, char* headline)
{
	char            buf[2048];

	if (IppSerializeSdpDescrTo( buf, 2048, streamDescr) != RV_OK)
	{
		IppLogMessage(rvTrue,"%s printMediaStreamDescr() failed", headline);
		return;
	}

	IppLogMessage(RV_FALSE,"%s\n%s\n", headline, buf);

}

/******************************************************************************
*  getDefaultAvailableMedia
*  ----------------------------
*  General :   This function returns the media capabilities that are currently available
*			   in the application, considering resources, etc.
*			   In this default implementation we return the full media capabilities
*			   that were loaded during initialization. Applications may replace this
*			   implementation with their own, by checking which codecs are currently
*			   available in their system.
*
*  Return Value:	None.
*
*  Arguments:
*  Input:
*					None.
*
*  Output:			msgAvailable - SDP containing media capabilities currently available .
******************************************************************************/
static void getDefaultAvailableMedia(OUT RvSdpMsg*   msgAvailable)

{
    rvSdpMsgCopy( msgAvailable, g_param.sdpFullCaps);
}

/******************************************************************************
*  mediaEnableDev
*  ----------------------------
*  General :     This function starts or stops an audio or video device.
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*			context			-	key for finding the device.
*			devId           -   device id.
*			bEnable         -   RV_TRUE  - start the device.
*								RV_FALSE - stop the device.
*
*  Output:		None.
*
******************************************************************************/
static RvStatus mediaEnableDev( void* context, RvIppMediaDevice devId, RvBool bEnable)
{

	IppLogMessage(RV_FALSE,"mediaEnableDev(devId=%d, bEnable=%d)", devId, bEnable);

    if (devId <= RVIPP_MEDIA_DEV_MIN && devId >= RVIPP_MEDIA_DEV_MAX)
    {
        IppLogMessage(rvTrue,"mediaEnableDev(devId=%d, bEnable=%d) failed. devId out of range", devId, bEnable);
        return RV_ERROR_UNKNOWN;
    }

	if (bEnable)
    {
        return mcHelperOpenDev(context, devId);
    }
	else
    {
        return mcHelperCloseDev( context, devId);
    }
	IppLogMessage(RV_FALSE,"mediaEnableDev()=0");

    return RV_OK;
}

/***************************************************************************
 * copySdpPort
 * ------------------------------------------------------------------------
 * General: This function copies port numbers of Audio and Video stream from
 *          source SDP to destination SDP.
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   sdpSource       -   pointer to SDP message to copy port number from
 *          sdpDestination  -   pointer to SDP message to copy port number to
 * Output: None
 ***************************************************************************/
void copySdpPort(
                RvSdpMsg*           sdpSource,
                RvSdpMsg*           sdpDestination)
{

    RvSize_t n, i;
    RvSdpMediaDescr*    descr;
    static RvUint16     portAudio =10000, portVideo = 20000;

    /* get the audio and video ports from the current media */
    n = rvSdpMsgGetNumOfMediaDescr( sdpSource);
    for(i=0; i < n; ++i)
    {
        descr = rvSdpMsgGetMediaDescr( sdpSource, i);
        if( rvSdpMediaDescrGetMediaType( descr) == RV_SDPMEDIATYPE_AUDIO)
        {
            portAudio = (RvUint16)rvSdpMediaDescrGetPort( descr);
        }

        if( rvSdpMediaDescrGetMediaType( descr) == RV_SDPMEDIATYPE_VIDEO)
        {
            portVideo = (RvUint16)rvSdpMediaDescrGetPort( descr);
        }
    }

    /* copy the audio and video ports into the modified media */
    n = rvSdpMsgGetNumOfMediaDescr( sdpDestination);

    for(i=0; i < n; ++i)
    {
        descr = rvSdpMsgGetMediaDescr( sdpDestination, i);

        if( rvSdpMediaDescrGetMediaType( descr) == RV_SDPMEDIATYPE_AUDIO)
        {
            rvSdpMediaDescrSetPort( descr, portAudio);
        }

        if( rvSdpMediaDescrGetMediaType( descr) == RV_SDPMEDIATYPE_VIDEO)
        {
            rvSdpMediaDescrSetPort( descr, portVideo);
        }
    }

}

/*===============================================================================*/
/*================== M E D I A			C A L L B A C K	S	=====================*/
/*===============================================================================*/

/******************************************************************************
 * rvMtfSampleConnectMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfConnectMediaEv().
 *			This callback is called when application is required to connect either
 *			one of following:
 *				1.	An existing media stream (RTP session) with an audio/video device,
 *					to enable media flowing from both parties of the call.
 *				2.	An existing media stream with another existing media stream, to
 *					create mixing of media and enable Conference call to be established.
 *			This callback will usually be called when call is getting connected (remote
 *			party or local user answered the call), or during a Conference call.
 *			In this implementation we do first check which type of terminal should be connected,
 *			and send EPP message to GUI for connecting the stream. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTermSource			- Handle to source terminal, may be either RTP terminal or audio/video device.
 *			hAppTermSource		- Handle to application data associated with the source terminal.
 *			hTermTarget			- Handle to target terminal, always an RTP terminal.
 *			hAppTermTarget		- Handle to application data associated with the target terminal.
 *			termSourceType		- Type of the source terminal, indicating whether application should connect
 *								  RTP session to audio/video device, or RTP session to another RTP session.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleConnectMediaCB(
				RvIppTerminalHandle			hTermSource,
				RvMtfTerminalAppHandle		hAppTermSource,
				RvIppTerminalHandle			hTermTarget,
				RvMtfTerminalAppHandle		hAppTermTarget,
				RvMtfTerminalType			termType)
{
	RvStatus		    rc = RV_ERROR_UNKNOWN;
	char		        termIdSrc[256];
	char		        termIdTarget[256];
    void*               context = (void*)hAppTermTarget;

	RV_UNUSED_ARG(hAppTermSource);

    rvMtfTerminationGetId(hTermSource, termIdSrc, sizeof(termIdSrc));
    rvMtfTerminationGetId(hTermTarget, termIdTarget, sizeof(termIdTarget));

	if (g_param.bDisableMedia == RV_TRUE)
	{
		IppLogMessage(RV_FALSE,"rvMtfSampleConnectMediaCB() - media is disabled! (disableGuiMedia=1), term = %s", termIdSrc);
		return RV_OK;
	}

	IppLogMessage(RV_FALSE,"rvMtfSampleConnectMediaCB() - connecting media between: source=%s and target=%s",
		termIdSrc, termIdTarget);

	/* As this function is called either to connect rtp session to device or connect rtp session
	 * to another rtp session, we must separate these two cases. */
    switch(termType)
    {
		/* Connect Audio */
		/* ------------- */
		case RV_CCTERMINALTYPE_AT:
		case RV_CCTERMINALTYPE_ANALOG:

				rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_MIC, termIdTarget);
				if (rc == RV_OK)
				{
					rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_SPEAKER, termIdTarget);
				}

			break;

		/* Connect Video */
		/* ------------- */
#ifdef RV_MTF_VIDEO
		case RV_CCTERMINALTYPE_VT:

				rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_CAMERA, termIdTarget);
				if (rc == RV_OK)
				{
					rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, termIdTarget);
				}
			break;
#endif

		/* Mixing for Conference */
		/* --------------------- */
		case RV_CCTERMINALTYPE_EPHEMERAL:
			rc = mcHelperConnectRtpToRtp( context, termIdSrc, termIdTarget);
			break;

		case RV_CCTERMINALTYPE_UI:
		case RV_CCTERMINALTYPE_UNKNOWN:
			break;

		default:
			IppLogMessage(RV_TRUE, "rvMtfSampleConnectMediaCB() - unknown terminal type: %d", termType);
    }

	if (rc == RV_OK)
	{
		IppLogMessage(RV_FALSE,"rvMtfSampleConnectMediaCB() - media was successfully connected between: source=%s and target=%s",
					termIdSrc, termIdTarget);
	}
	else
	{
		IppLogMessage(RV_TRUE,"rvMtfSampleConnectMediaCB() - failed to connect media between: source=%s and target=%s",
			termIdSrc, termIdTarget);
	}

	return rc;
}

/******************************************************************************
 * rvMtfSampleDisconnectMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaDisconnectEv().
 *			This callback is called when application is required to disconnect either
 *			one of following:
 *				1.	An existing media stream (RTP session) from an audio/video device,
 *					to stop media flowing from both parties of the call.
 *				2.	An existing media stream from another existing media stream, to
 *					stop mixing of media during Conference call.
 *			This callback will usually be called when basic call is disconnected (remote
 *			party or local user answered the call), or one of the participants left the
 *			Conference call.
 *			In this implementation we do first check which type of terminal should be disconnected,
 *			and send EPP message to GUI for disconnecting the stream. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTermSource			- Handle to source terminal, may be either RTP terminal or audio/video device.
 *			hAppTermSource		- Handle to application data associated with the source terminal.
 *			hTermTarget			- Handle to target terminal, always an RTP terminal.
 *			hAppTermTarget		- Handle to application data associated with the target terminal.
 *			termSourceType		- Type of the source terminal, indicating whether application should disconnect
 *								  RTP session from audio/video device, or RTP session from another RTP session.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDisconnectMediaCB(
               RvIppTerminalHandle			hTermSource,
			   RvMtfTerminalAppHandle		hAppTermSource,
               RvIppTerminalHandle			hTermTarget,
			   RvMtfTerminalAppHandle		hAppTermTarget,
			   RvMtfTerminalType			termType)
{
    RvStatus		    rc = RV_ERROR_UNKNOWN;
    char		        termIdSrc[256];
    char		        termIdTarget[256];
    void*               context = (void*)hAppTermTarget;

	RV_UNUSED_ARG(hAppTermSource);

    rvMtfTerminationGetId(hTermSource, termIdSrc, sizeof(termIdSrc));
    rvMtfTerminationGetId(hTermTarget, termIdTarget, sizeof(termIdTarget));

	if (g_param.bDisableMedia  == RV_TRUE)
    {
		IppLogMessage(RV_FALSE,"rvMtfSampleDisconnectMediaCB() - media is disabled! (disableGuiMedia=1), term = %s", termIdSrc);
        return RV_OK;
    }

	IppLogMessage(RV_FALSE,"rvMtfSampleDisconnectMediaCB() - disconnecting media between: source=%s and target=%s",
		termIdSrc, termIdTarget);

    switch(termType)
    {
		/* Disconnect Audio */
		/* ---------------- */
		case RV_CCTERMINALTYPE_AT:
		case RV_CCTERMINALTYPE_ANALOG:
			/* Disconnect microphone from RTP session*/
    	    rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_MIC, termIdTarget);
            if (rc == RV_OK)
			{
				/* Disconnect speaker from RTP session*/
    			rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_SPEAKER, termIdTarget);
			}
		break;

		/* Disconnect Video */
		/* ---------------- */
#ifdef RV_MTF_VIDEO
		case RV_CCTERMINALTYPE_VT:
			/* Disconnect camera from RTP session*/
       		rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_CAMERA, termIdTarget);
			if (rc == RV_OK)
			{
				/* Disconnect screen from RTP session*/
    			rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, termIdTarget);
			}
		break;
#endif

		/* Stop mixing for Conference */
		/* -------------------------- */
		case RV_CCTERMINALTYPE_EPHEMERAL:
			/* Disconnect two RTP sessions and stop the mixing.*/
			rc = mcHelperDisconnectRtpFromRtp( context, termIdSrc, termIdTarget);
        break;

		case RV_CCTERMINALTYPE_UNKNOWN:
			IppLogMessage(RV_TRUE, "rvMtfSampleDisconnectMediaCB() - unknown terminal type: %d", termType);
        break;
		default:
		break;
    }

	if (rc == RV_OK)
	{
		IppLogMessage(RV_FALSE,"rvMtfSampleDisconnectMediaCB() - media was successfully disconnected between: source=%s and target=%s",
			termIdSrc, termIdTarget);
	}
	else
	{
		IppLogMessage(RV_TRUE,"rvMtfSampleDisconnectMediaCB() - failed to disconnect media between: source=%s and target=%s",
			termIdSrc, termIdTarget);
	}

	return rc;
}

#ifdef RV_MTF_N_LINES

/******************************************************************************
 * rvMtfSampleConnectMultiStreams
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaConnectMultiStreamsEv().
 *			This callback is called when application is required to connect multiple
 *			media streams (RTP sessions), to add a new call to a Conference. 
 *			The first termination in the list is the latest session that is added to the conference.
 *
 * Arguments:
 *
 * Input:	hTermsList			- List of handles to RTP sessions that should be connected.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleConnectMultiStreams(
							IN RvPtrList		hTermsList)
{
	RvBool			rc = rvFalse;
	unsigned int	index;
	const char*		termIdSrc; 
	const char*		termIdTarget;	
	RvMdmTermType	srcType;
	RvPtrListIter	i;
	RvMdmTerm		*rtpTermSrc, *rtpTermTarget;
	
	/* Index 0 of the list relates to the new connection */	
	i=rvListBegin(&hTermsList);	
	rtpTermSrc = (RvMdmTerm *)RvPtrListIterData(i);
	termIdSrc = rvMdmTermGetId(rtpTermSrc);
	srcType = rvMdmTermGetType(rtpTermSrc);
	if(	srcType != RV_MDMTERMTYPE_EPHEMERAL) /* Not a conference case... */
	{
		/* Error case */
		IppLogMessage(RV_TRUE, "rvIppSampleGatewayConnectMultiple:srcType is not ephemeral");
		return (rc);
	}
	
	i=rvListIterNext(i);
	
	for (index = 1; index < rvListSize(&hTermsList); index++)
	{
		rtpTermTarget = (RvMdmTerm *)RvPtrListIterData(i);
		termIdTarget = rvMdmTermGetId(rtpTermTarget);
		/* Connect rtp to rtp. For now, we assume the direction is always BOTHWAYS... */
	//	rc = mcHelperConnectRtpToRtp( termIdSrc, termIdTarget, IPPMEDIACONTROL_DIR_BOTHWAYS);
		i=rvListIterNext(i);
	} 
	
	return RV_OK;
}


/******************************************************************************
 * rvMtfSampleMediaDisconnectMultiStreams
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaConnectMultiStreamsEv().
 *			This callback is called when application is required to disconnect multiple
 *			media streams (RTP sessions), to disconnect a Conference call. 
 *
 * Arguments:
 *
 * Input:	hTermsList			- List of handles to RTP sessions that should be disconnected.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDisconnectMultiStreams(
							IN RvPtrList		hTermsList)
{
	
	RvBool			rc = rvFalse;
	unsigned int	index;
	const char*		termIdSrc; 
	const char*		termIdTarget;
	RvMdmTermType	srcType;
	RvPtrListIter	i;
	RvMdmTerm		*rtpTermSrc, *rtpTermTarget;
	
	
	/* Index 0 of the list relates to the new connection */

	i=rvListBegin(&hTermsList);		
	rtpTermSrc = (RvMdmTerm *)RvPtrListIterData(i);
	termIdSrc = rvMdmTermGetId(rtpTermSrc);
	srcType = rvMdmTermGetType(rtpTermSrc);
	if(	srcType != RV_MDMTERMTYPE_EPHEMERAL) /* Not a conference case... */
	{
		/* Error case */
		IppLogMessage(RV_TRUE, "rvIppSampleGatewayDisconnectMultiple:srcType is not ephemeral");
		return (rc);
	}
	
	i=rvListIterNext(i);
	
	for (index = 1; index < rvListSize(&hTermsList); index++)	
	{
		rtpTermTarget = (RvMdmTerm *)RvPtrListIterData(i);
		termIdTarget = rvMdmTermGetId( rtpTermTarget);
		/* Disconnect rtp from rtp. the direction is always BOTHWAYS... */
	//	rc = mcHelperDisconnectRtpFromRtp( termIdSrc, termIdTarget, IPPMEDIACONTROL_DIR_BOTHWAYS);
		i=rvListIterNext(i);
	}
	
	return (rc == RV_OK);
}


#endif /* RV_MTF_N_LINES */

/******************************************************************************
 * rvMtfSampleCreateMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaCreateStreamEv().
 *			This callback is called when application is required to create a new
 *			media stream (RTP session), with specific parameters provided in this
 *			callback (codec, etc). Application should return the ip address and port
 *			number of the new media stream. This callback will usually be called when
 *			new call is established.
 *			In this implementation we do the following:
 *				1. Check for currently available codecs (considering resources etc.)
 *				2. Media negotiation - find the common capabilities between us and remote party.
 *				3. Create a new RTP session according to common capabilities.
 *			We open the RTP stream by sending EPP message to GUI. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			params			- media parameters the new media stream should be created with.
 *
 * Output: params			- media parameters the new media stream was created with.
 *							  the localSdp should include the ip address and port number
 *							  of the new media stream. All the other fields should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleCreateMediaCB(
                RvIppConnectionHandle       hConn,
                RvMtfConnAppHandle          hAppConn,
                RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
                RvMtfMediaParams*			params)
{
    RvSdpMsg    msgAvailable;
	RvSdpMsg	*msgLocal		= params->localSdp;
	RvSdpMsg	*msgRemote		= params->remoteSdp;
    RvChar		termId[256];
    void*       context = (void*)hAppTerm;
	RvChar		str[256];

	RV_UNUSED_ARG(hAppConn);

	rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	/* Print to log */
	/* ------------ */
	sprintf(str, "rvMtfSampleCreateMediaCB() - create media for term=%s, with Local SDP:", termId);

    printSdp( msgLocal, str);

    if (msgRemote != NULL)
    {
		sprintf(str, "rvMtfSampleCreateMediaCB() - create media for term=%s, with Remote SDP:", termId);

        printSdp( msgRemote, str);
    }
    else
    {
        IppLogMessage(RV_FALSE, "rvMtfSampleCreateMediaCB() - create media for term=%s, with Remote SDP: <empty>", termId);
    }

	/* Get available media */
	/* ------------------- */
    rvSdpMsgConstruct( &msgAvailable);
    getDefaultAvailableMedia( &msgAvailable);


	/* Choose local media for this call */
	/* -------------------------------- */
	if ((msgRemote == NULL) && (rvMtfConnectionGetProtocolId(hConn) != RV_MTF_PROTOCOL_H323))
	{
		/* If remote SDP is empty, then this is an outgoing invite. We change localMedia, which is currently
		   equal to the full media capabilities, so it contains only the media we want to send in outgoing Invite. */

		RvSize_t		i;
		RvSdpMediaDescr	*descrOfInvite;
		RvSdpMsg        *sdpOfInvite;

		/* Clear local media. */
		rvSdpMsgClearMediaDescr(msgLocal);
		sdpOfInvite =  g_param.sdpForInvite;

		/* Here we copy all the media descriptors from our SDP we previously configured for outgoing Invites,
		   to the msgLocal. Application may change this implementation to fit its requirements. */
		for(i=0; i < rvSdpMsgGetNumOfMediaDescr( sdpOfInvite); ++i)
		{
			descrOfInvite = rvSdpMsgGetMediaDescr( sdpOfInvite, i);
			rvSdpMsgInsertMediaDescr ( msgLocal, descrOfInvite);
		}
	}

	/* Negotiate media in SIP calls only. In H323 calls negotiation is done by Mtf and not by application*/
	if (rvMtfConnectionGetProtocolId(hConn) != RV_MTF_PROTOCOL_H323)
	{
		/* Media negotiation */
		/* ----------------- */
		/* In our implementation for media negotiation, we find the common capabilities between the currently
		available media and local and remote. After calling this function, msgLocal and msgRemote will
		include one codec each. Application may change this implementation to fit its requirements.*/

		if (!g_param.mediaNegotiate( msgLocal, msgRemote, &msgAvailable))
		{
			IppLogMessage(RV_TRUE, "rvMtfSampleCreateMediaCB() - media negotiation failed, term=%s", termId);
			rvSdpMsgDestruct( &msgAvailable);
			return RV_ERROR_UNKNOWN;
		}
	}

    /* Create RTP session for local (in) */
	/* --------------------------------- */
    if (msgLocal)
    {
		/* Check if local SDP message has any media descriptors in it. */
        if(rvSdpMsgGetNumOfMediaDescr (msgLocal))
        {
            if (g_param.bDisableMedia == RV_FALSE)
            {
				/*	This will send EPP message to our GUI for creating a new RTP session with the
					parameters in msgLocal. Application should call its own media engine instead.
					Before calling this function, msgLocal includes $ instead of port number:
						o=rtp/1 0 0 IN IP4 $
						s=-
						t=0 0
						m=audio $ RTP/AVP 0 4.
					When this function returns, the $ will be replaced with the actual port number of
				    the media stream, which will be sent to remote party.*/
				RvStatus rc;
                CHECK_FUNC( mcHelperCreateRtpLocal(context, (RvUint32)hTerm, termId, msgLocal));
            }
			else
			{
				IppLogMessage(RV_FALSE,"rvMtfSampleCreateMediaCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
			}
        }
        else
		{
			/* Local SDP message is empty. */
            IppLogMessage(RV_TRUE, "rvMtfSampleCreateMediaCB() - local media is empty, term=%s", termId);
			rvSdpMsgDestruct( &msgAvailable);
			return RV_ERROR_UNKNOWN;
		}
    }

	/* Create/modify RTP session for remote (out) */
	/* ------------------------------------------ */
    if (msgRemote)
    {
		/* Check if remote SDP message has any media descriptors in it. */
        if(rvSdpMsgGetNumOfMediaDescr (msgRemote))
        {
            if(g_param.bDisableMedia == RV_FALSE)
            {
				/* This will send EPP message to our GUI for modify the RTP session we just opened with the
				   parameters in msgRemote. Application should call its own media engine instead.*/
				  RvStatus rc;
				  CHECK_FUNC( mcHelperModifyRtpRemoteBySdp( context, (RvUint32)hTerm, termId, msgRemote));
            }
			else
			{
				IppLogMessage(RV_FALSE,"rvMtfSampleCreateMediaCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
			}
        }
        else
		{
			/* Remote SDP message is empty. */
            IppLogMessage(RV_TRUE, "rvMtfSampleCreateMediaCB() - remote media is empty, term=%s", termId);
			rvSdpMsgDestruct( &msgAvailable);
			return RV_ERROR_UNKNOWN;
		}
    }

    rvSdpMsgDestruct( &msgAvailable);

    return RV_OK;
err_exit:
    rvSdpMsgDestruct( &msgAvailable);
	IppLogMessage(RV_TRUE,"rvMtfSampleCreateMediaCB() - failed to create media for term=%s", termId);
    return RV_ERROR_UNKNOWN;
}

/******************************************************************************
 * rvMtfSampleModifyMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaModifyStreamEv().
 *			This callback is called when application is required to modify an existing
 *			media stream (RTP session), with specific parameters provided in this
 *			callback (codec, etc). Application should return the ip address and port
 *			number of the media stream. This callback will usually be called during
 *			a connected call.
 *			In this implementation we do the following:
 *				1. Check what kind of modifying should we operate on the stream, and
 *				   apply on the stream.
 *				2. If we are required to change parameters of existing stream -
 *						a. Check for currently available codecs (considering resources etc.)
 *						b. Media negotiation - find the common capabilities between us and remote party.
 *						c. Modify the RTP session according to the new parameters.
 *			We apply the modifications on the RTP stream by sending EPP message to GUI.
 *			Application should call its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			params			- media parameters the media stream should be modified with.
 *
 * Output: params			- media parameters the media stream was modified with.
 *							  the localSdp should include the ip address and port number
 *							  of the media stream. All the other fields should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleModifyMediaCB(
				RvIppConnectionHandle       hConn,
				RvMtfConnAppHandle          hAppConn,
                RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
                RvMtfMediaParams*			params)
{
    RvStatus    rc = RV_OK;
	RvSdpMsg	*msgLocal		= params->localSdp;
	RvSdpMsg	*msgRemote		= params->remoteSdp;
	RvSdpMsg	*currentSdp     = NULL;
    void*       context = (void*)hAppTerm;
    char		termId[256];
	RvChar		str[256];

	RV_UNUSED_ARG(hAppConn);

    rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	currentSdp = rvMtfMediaGetCurrentMedia(hTerm);
	/* Use the port of the current media for the modified local media as well */
	if (currentSdp != NULL)
	{
		copySdpPort(currentSdp, msgLocal);
	}

	/* Print to log */
	/* ------------ */
	sprintf(str, "rvMtfSampleModifyMediaCB() - modify media for term=%s, with Local SDP:", termId);

    printSdp( msgLocal, str);

    if (msgRemote != NULL)
    {
		sprintf(str, "rvMtfSampleModifyMediaCB() - modify media for term=%s, with Remote SDP:", termId);

        printSdp( msgRemote, str);
    }
    else
    {
        IppLogMessage(RV_FALSE, "rvMtfSampleModifyMediaCB() - modify media for term=%s, with Remote SDP: <empty>", termId);
    }

	if (g_param.bDisableMedia == RV_TRUE)
	{
		IppLogMessage(RV_FALSE,"rvMtfSampleModifyMediaCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
	}

	/* TODO: check for streams with port=0, if these streams are open, they need to be closed (according to RFC 3264). */

    switch( params->action)
    {
		/* Mute/Unmute */
		/* ----------- */
		case RVMTF_MEDIA_MUTE:
		case RVMTF_MEDIA_UNMUTE:
			if (g_param.bDisableMedia == RV_FALSE)
			{
				/* Send an EPP message to our GUI to mute/unmute the media stream. */
				rc = mcHelperModifyRtpRemote( context, (RvUint32)hTerm, termId, params->remoteSdp, params->action);
			}

			break;

		/* Remote Hold/Unhold */
		/* ------------------ */
		case RVMTF_MEDIA_HOLD_REMOTE:
		case RVMTF_MEDIA_UNHOLD_REMOTE:
			if (g_param.bDisableMedia == RV_FALSE)
			{
				/* Send an EPP message to our GUI to put the media stream on hold/unhold (by remote party). */
				rc = mcHelperModifyRtpRemote( context, (RvUint32)hTerm, termId, params->remoteSdp, params->action);
			}
			break;

		/* Local Hold/Unhold */
		/* ----------------- */
		case RVMTF_MEDIA_HOLD_LOCAL:
		case RVMTF_MEDIA_UNHOLD_LOCAL:
			if (g_param.bDisableMedia == RV_FALSE)
			{
				/* Send an EPP message to our GUI to put the media stream on hold/unhold (by local party). */
				rc = mcHelperModifyRtpLocal( context, (RvUint32)hTerm, termId, params->localSdp, params->action);
			}

			break;

		/*  Unhold in a double side held call (hold on hold) */
		/* ------------------------------------------------- */
		case RVMTF_MEDIA_UNHOLD_INACTIVE_TO_REMOTE:
		case RVMTF_MEDIA_UNHOLD_INACTIVE_TO_LOCAL:
			/* Nothing is done in this case. The call was held by both parties, now it is
			   on hold by one of the parties. Media remains disabled. */
			break;

		/* Modify media parameters */
		/* ----------------------- */
		case RVMTF_MEDIA_MODIFY_SESSION:
			{
				RvSdpMsg    msgAvailable;

				/* In H323 negotiation is done inside MTF. It could also be done by application, so that application
				   will know what media streams to open. Our IPPhone GUI supports only voice, so calling 
				   here mediaNegotiate will remove all video codecs from sdp, although they were declared in TCS.
				   Due to this fact mediaNegotiate in our implementation is not called here for H323 calls. Application could
				   change this to fit its requirements.*/
				if (rvMtfConnectionGetProtocolId(hConn) != RV_MTF_PROTOCOL_H323)
				{
					/* Get available media */
					/* ------------------- */
					rvSdpMsgConstruct( &msgAvailable);
					getDefaultAvailableMedia( &msgAvailable);

					/* Media negotiation */
					/* ----------------- */
					/* In our implementation for media negotiation, we find the common capabilities between the currently
					  available media and local and remote. After calling this function, msgLocal and msgRemote will
					  include one codec each. Application may change this implementation to fit its requirements.*/
				
					if (g_param.mediaNegotiate( msgLocal, msgRemote, &msgAvailable) == RV_FALSE)
					{
						IppLogMessage(RV_TRUE, "rvMtfSampleModifyMediaCB() - media negotiation failed, term=%s", termId);
						rvSdpMsgDestruct( &msgAvailable);
						rc = RV_ERROR_UNKNOWN;
						break;
					}
					else
					{
						rvSdpMsgDestruct( &msgAvailable);
					}
				}
				if (g_param.bDisableMedia == RV_FALSE)
				{
					/* Send an EPP message to our GUI to change the parameters of media stream according to
					   remote SDP and local SDP.
					   When this function returns, localSdp should include the actual port number of
				       the media stream, which will be sent to remote party.*/
					rc = mcHelperModifyRtpLocalBySdp( context, (RvUint32)hTerm, termId, params->localSdp);
					if(rc == RV_OK)
					{
						rc = mcHelperModifyRtpRemoteBySdp( context, (RvUint32)hTerm, termId, params->remoteSdp);
					}

				}
			}
			break;

		case RVMTF_MEDIA_NEW:
		case RVMTF_MEDIA_UNKNOWN:
		default:
			rc = RV_ERROR_UNKNOWN;
	}

    return rc;
}


/******************************************************************************
 * rvMtfSampleDestroyMediaCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaDestroyStreamEv().
 *			This callback is called when application is required to terminate an existing
 *			media stream (RTP session). This callback will usually be called when call
 *			disconnects.
 *			In this implementation we send EPP message to GUI for closing the RTP session.
 *			Application should call its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleDestroyMediaCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm)
{
	RvStatus		rc = RV_OK;
    void*           context = (void*)hAppTerm;
    char		    termId[256];

    rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	IppLogMessage(RV_FALSE, "rvMtfSampleDestroyMediaCB() - destroy media for term=%s", termId);

    if (g_param.bDisableMedia == RV_FALSE)
	{
		rc = mcHelperDestroyRtp( context, termId);
	}
	else
	{
		IppLogMessage(RV_FALSE,"rvMtfSampleDestroyMediaCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
	}

	return rc;
}

/******************************************************************************
 * rvMtfSampleStartPhysicalDeviceCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaStartPhysicalDeviceEv().
 *			This callback is called when application is required to initialize an
 *			audio device (Handset, Speaker or headset). This callback will be called
 *			once, on the first call only.
 *			In this implementation we do first check which type of terminal should be started,
 *			and send EPP message to GUI for starting the device. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			termType		- Type of the terminal, indicating which device application
 *							  should start, audio or video device.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 *****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleStartPhysicalDeviceCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
				RvMtfTerminalType			termType)
{
	void*		context = (void*)hAppTerm;
	char		termId[256];

	rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	IppLogMessage(RV_FALSE,"rvMtfSampleStartPhysicalDeviceCB() - Start physical device, term = %s", termId);

    if (g_param.bDisableMedia == RV_TRUE)
    {
		IppLogMessage(RV_FALSE,"rvMtfSampleStartPhysicalDeviceCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
		return RV_OK;
    }

	switch(termType)
    {
		/* Start Audio devices */
		/* ------------------- */
		case RV_CCTERMINALTYPE_AT:
		case RV_CCTERMINALTYPE_ANALOG:
			mediaEnableDev( context, RVIPP_MEDIA_DEV_MIC, RV_TRUE);
			mediaEnableDev( context, RVIPP_MEDIA_DEV_SPEAKER, RV_TRUE);
			break;

#ifdef RV_MTF_VIDEO
		/* Start Video devices */
		/* ------------------- */
		case RV_CCTERMINALTYPE_VT:
			mediaEnableDev( context, RVIPP_MEDIA_DEV_CAMERA, RV_TRUE);
			mediaEnableDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, RV_TRUE);
			break;
#endif /* RV_MTF_VIDEO */
		default:
			break;
	}

	return RV_OK;
}

/*@*****************************************************************************
 * rvMtfSampleStopPhysicalDeviceCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaStopPhysicalDeviceEv().
 *			This callback is called when application is required to stop an
 *			audio device (Handset, Speaker or headset). This callback is currently
 *			not called at all. Application should stop all audio devices after shutting
 *			down MTF.
 *			In this implementation we do first check which type of terminal should be stopped,
 *			and send EPP message to GUI for stopping the device. Application should call
 *			its media engine directly instead.
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to terminal.
 *			hAppTerm		- Handle to application data associated with the terminal.
 *			termType		- Type of the terminal, indicating which device application
 *							  should stop, audio or video device.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RvStatus RVCALLCONV rvMtfSampleStopPhysicalDeviceCB(
				RvIppTerminalHandle			hTerm,
				RvMtfTerminalAppHandle		hAppTerm,
				RvMtfTerminalType			termType)
{
    void*		context = (void*)hAppTerm;
    char		termId[256];

    rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	IppLogMessage(RV_FALSE,"rvMtfSampleStopPhysicalDeviceCB() - Stop physical device, term = %s", termId);

    if (g_param.bDisableMedia == RV_TRUE)
    {
		IppLogMessage(RV_FALSE,"rvMtfSampleStopPhysicalDeviceCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
		return RV_OK;
    }

	switch(termType)
    {
		/* Stop Audio devices */
		/* ------------------ */
	case RV_CCTERMINALTYPE_AT:
	case RV_CCTERMINALTYPE_ANALOG:
		mediaEnableDev( context, RVIPP_MEDIA_DEV_MIC, RV_FALSE);
        mediaEnableDev( context, RVIPP_MEDIA_DEV_SPEAKER, RV_FALSE);
		break;

#ifdef RV_MTF_VIDEO
		/* Stop Video devices */
		/* ------------------ */
	case RV_CCTERMINALTYPE_VT:
		mediaEnableDev( context, RVIPP_MEDIA_DEV_CAMERA, RV_FALSE);
        mediaEnableDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, RV_FALSE);
		break;
#endif /* RV_MTF_VIDEO */
	default:
		break;
	}

	return RV_OK;
}

/*@*****************************************************************************
 * rvMtfSampleModifyMediaCompletedCB
 * -----------------------------------------------------------------------------
 * General:
 *			This is an implementation of media callback RvMtfMediaModifyStreamDuringCallCompletedEv().
 *			This callback is called when a process of modifying media during a connected
 *			call is completed (dynamic media change). The process may be initiated by local party or remote party.
 *			The callback indicates the result of the process, whether it was succeeded or failed,
 *			and the reason for the failure.
 *			During a process of dynamic media change, application should keep both the old
 *			media stream and the new media stream open (meaning, listen on both sockets).
 *			If process was completed successfully, application should close the old media
 *			stream and leave the new one open. If process failed, application should close
 *			the new stream and leave the old one open.
 *			In this implementation we just print to log. Application may add here its own
 *			implementation.
 *
 * Arguments:
 *
 * Input:	hTerm				- Handle to terminal on which media was modified.
 *			hAppTermSource		- Handle to application data associated with the terminal.
 *			status				- Status of the process.
 *			sdpMsg				- SDP message containing the new media parameters.
 *
 * Output: None.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
void RVCALLCONV rvMtfSampleModifyMediaCompletedCB(
					   RvIppTerminalHandle				hTerm,
					   RvMtfTerminalAppHandle			hAppTerm,
					   RvMtfDynamicModifyMediaStatus	status,
					   RvSdpMsg*						sdp)
{
	char		termId[256];

	RV_UNUSED_ARG(sdp);
    RV_UNUSED_ARG(hAppTerm);

    rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	IppLogMessage(RV_FALSE,"rvMtfSampleModifyMediaCompletedCB() - modify media is completed for term=%s, status=%d", termId, status);

}

/******************************************************************************
* rvMtfSampleConnModifySpecificMediaStreamCB  
* -----------------------------------------------------------------------------
* General:
*			This is an implementation of media callback connModifySpecificMediaStreamCB().
*			This callback is called when application is required to open/close a
*			media stream (RTP session), with specific parameters provided in this
*			callback (codec, etc). Application should return the ip address and port
*			number of the media stream.
*			In this implementation we do the following:
*				Print to the log file parameters received to open the stream
*
*
* Arguments:
*
* Input:    hConn       - Handle to the connection.
*           hAppConn    - Handle to the application data associated with the
*                         connection.
*           hTerm       - Handle to the terminal.
*           hAppTerm    - Handle to the application data associated with the
*                         terminal.
*           hStream     - Handle to the media stream.
*           hAppStream  - Pointer to handle to the application data associated 
*                         with the media stream.
*           mediaStreamParams  - Media parameters of the media stream to be 
*                         modified. 
*
* Output:   
*           hAppStream  - Pointer to handle to the application data associated 
*                         with the terminal. Application should set the handle 
*                         and return it to MTF for consequent references to the
*                         media stream.
*			mediaStreamParams - Media parameters with which the media stream was
*                         modified. When mediaStreamParams.streamDirection is 
*                         RVMTF_MEDIA_STREAM_RECEIVE, mediaStreamParams.streamDescriptor
*                         should include the IP address and port number of the media stream. 
*                         All other fields should remain the same.
*
* Return Value: RV_OK if successful, other if not.
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleConnModifySpecificMediaStreamCB(
	IN      RvIppConnectionHandle           hConn,
	IN      RvMtfConnAppHandle              hAppConn,
	IN		RvIppTerminalHandle				hTerm,		
	IN		RvMtfTerminalAppHandle			hAppTerm,
	IN      RvMtfMediaStreamHandle			hStream,
	INOUT	RvMtfMediaStreamAppHandle*		hAppStream,
	INOUT   RvMtfMediaStreamParams*			mediaStreamParams)
{
	RvStatus    rc = RV_OK;
	char		termId[256];
	RvChar		str[256];

	RV_UNUSED_ARG(hConn);
	RV_UNUSED_ARG(hAppConn);
	RV_UNUSED_ARG(hAppTerm);
	rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	/* Print to log */
	/* ------------ */

	IppLogMessage(RV_FALSE, "rvMtfSampleConnModifySpecificMediaStreamCB() - action=%d direction =%d on media for term=%s hStream=0x%p hAppStream=0x%p", 
		                         mediaStreamParams->action, mediaStreamParams->streamDirection, termId, hStream, *hAppStream);

	if (mediaStreamParams->action == RVMTF_MEDIA_STREAM_OPEN)
	{
		*hAppStream = (RvMtfMediaStreamAppHandle)hStream;
		if (mediaStreamParams->streamDirection == RVMTF_MEDIA_STREAM_SEND)
		{
			sprintf(str, "rvMtfSampleConnModifySpecificMediaStreamCB() Term=%s hStream=0x%p hAppStream=0x%p Open transmitter for media stream:", termId, hStream, *hAppStream);
			printMediaStreamDescr(mediaStreamParams->streamDescriptor, str);
		}
		else
		{
			/* video stream is not supported in MTF application. So just to check that
			   parameters are passed correctly between application and MTF, set here port number
			   to some value
			   */
			rvSdpMediaDescrSetPort(mediaStreamParams->streamDescriptor,2005);
			sprintf(str, "rvMtfSampleConnModifySpecificMediaStreamCB() Term=%s  hStream=0x%p hAppStream=0x%p Open receiver for media stream:", termId, hStream, *hAppStream);
			printMediaStreamDescr(mediaStreamParams->streamDescriptor, str);
		}
	}

	if (mediaStreamParams->action == RVMTF_MEDIA_STREAM_CLOSE)
	{
		*hAppStream = NULL;
		if (mediaStreamParams->streamDirection == RVMTF_MEDIA_STREAM_SEND)
		{
			sprintf(str, "rvMtfSampleConnModifySpecificMediaStreamCB() Term=%s hStream=0x%p hAppStream=0x%p Close transmitter for media stream:", termId, hStream, *hAppStream);
			printMediaStreamDescr(mediaStreamParams->streamDescriptor, str);
		}
		else
		{
			sprintf(str, "rvMtfSampleConnModifySpecificMediaStreamCB() Term=%s Close receiver for media stream:", termId);
			printMediaStreamDescr(mediaStreamParams->streamDescriptor, str);
		}
	}

	if (g_param.bDisableMedia == RV_TRUE)
	{
		IppLogMessage(RV_FALSE,"rvMtfSampleConnModifySpecificMediaStreamCB() - media is disabled! (disableGuiMedia=1), term = %s", termId);
	}
	
	return rc;
}

#ifdef RV_MTF_SECOND_VIDEO
RvStatus RVCALLCONV rvMtfSamplePresentationTokenMsgReceivedCB(
	IN		RvIppConnectionHandle				hConn,
	IN		RvMtfConnAppHandle					hAppConn,
	IN		RvIppTerminalHandle					hTerm,
	IN		RvMtfTerminalAppHandle				hAppTerm,
	IN		RvMtfMediaStreamHandle				hStream,
	INOUT	RvMtfMediaStreamAppHandle*			hAppStream,
	IN      RvMtfPresentationTokenMsgParams*	msgParams,
	IN      RvMtfMediaStreamParams*				mediaStreamParams)
{
	RvStatus    rc = RV_OK;
	char		termId[256];

	RV_UNUSED_ARG(hConn);
	RV_UNUSED_ARG(hAppConn);
	RV_UNUSED_ARG(hAppTerm);
	RV_UNUSED_ARG(mediaStreamParams);

	rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	switch (msgParams->msgType)
	{
	case RVMTF_MSG_PRESENTATION_TOKEN_REQUEST:
		{
		RvMtfPresentationTokenMsgParams msg;

		IppLogMessage(RV_FALSE, "rvMtfSamplePresentationTokenMsgReceivedCB() - Token Request received with terminalLabel =%d on media for term=%s, hStream=0x%p, hAppStream=0x%p", 
			msgParams->terminalLabel, termId, hStream, *hAppStream);
		/* token request is received. Send back token response message */

		msg.msgType = RVMTF_MSG_PRESENTATION_TOKEN_RESPONSE;
		msg.requestStatus = RVMTF_PRESENTATION_TOKEN_REQUEST_CONFIRM;
		msg.terminalLabel = msgParams->terminalLabel;
		rvMtfPresentationTokenMsgSend(hTerm, NULL, &msg);
		break;
		}
	case RVMTF_MSG_PRESENTATION_TOKEN_RESPONSE:
		*hAppStream = (RvMtfMediaStreamAppHandle)hStream;  // just for test
		IppLogMessage(RV_FALSE, "rvMtfSamplePresentationTokenMsgReceivedCB() - Token Response received with terminalLabel =%d on media for term=%s, hStream=0x%p, hAppStream=0x%p", 
			msgParams->terminalLabel, termId, hStream, *hAppStream);
		break;

	case RVMTF_MSG_PRESENTATION_TOKEN_RELEASE:
		IppLogMessage(RV_FALSE, "rvMtfSamplePresentationTokenMsgReceivedCB() - Token Release received with terminalLabel =%d on media for term=%s, hStream=0x%p, hAppStream=0x%p", 
			msgParams->terminalLabel, termId, hStream, *hAppStream);
		break;

	case RVMTF_MSG_PRESENTATION_TOKEN_INDICATE_OWNER:
		IppLogMessage(RV_FALSE, "rvMtfSamplePresentationTokenMsgReceivedCB() - Indicate Owner received with terminalLabel =%d on media for term=%s, hStream=0x%p, hAppStream=0x%p", 
			msgParams->terminalLabel, termId, hStream, *hAppStream);
		break;
	default:
		IppLogMessage(RV_FALSE, "rvMtfSamplePresentationTokenMsgReceivedCB() - msgType=%d terminalLabel =%d on media for term=%s, hStream=0x%p, hAppStream=0x%p", 
			msgParams->msgType, msgParams->terminalLabel, termId, hStream, *hAppStream);
	}
	return rc;
}
#endif
	
/*====================================================================================*/
/*=====  I N T E R N A L	M E D I A	M O D U L E		F U N C T I O N S   ==========*/
/*====================================================================================*/

/******************************************************************************
*  rvMtfMediaInitConfig
*  ----------------------------
*  General :        Set default values for parameters which may be used in rvMtfMediaInit
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInitConfig( INOUT RvMtfMediaConstructParam* p)
{
    RvMfControlConstructParam*  mfcParam = &p->mfControlParams;
    void*                       logMgr = rvMtfGetLogMgr();

    memset( p, 0, sizeof(RvMtfMediaConstructParam));
    p->bDisableMedia = RV_FALSE;
    p->mediaNegotiate = rvMtfSampleMediaNegotiate;

    RvMfControlSetDefaultConfig( mfcParam, logMgr);
}

/******************************************************************************
*  rvMtfMediaInit
*  ----------------------------
*  General :        Register Media CB for TK etc. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInit( IN RvMtfMediaConstructParam* p)
{
    g_param = *p;

    /* Initialize codec analyze utility*/
    IppCodecInitialize(IppLogMgr());

}


/******************************************************************************
*  rvMtfMediaEnd
*  ----------------------------
*  General :        Unregister Media CB for TK. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaEnd()
{
    /* End codec analyze utility*/
    IppCodecEnd();
}

/******************************************************************************
*  rvMtfMediaStart
*  ----------------------------
*  General :        Start internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
RvStatus rvMtfMediaStart( void* context)
{
    if(!g_param.bDisableMedia)
    {
        RvStatus    rc = wrapControlInit( context, &g_param.mfControlParams);
        if(RV_OK != rc)
		{
            IppLogMessage(rvTrue,"wrapControlInit Failed");
		}
        return rc;
    }
    else
	{
        return RV_OK;
	}
}

/******************************************************************************
*  rvMtfMediaStop
*  ----------------------------
*  General :        Stop internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaStop( void* context)
{
    if(!g_param.bDisableMedia)
	{
        wrapControlEnd( context);
	}
}
