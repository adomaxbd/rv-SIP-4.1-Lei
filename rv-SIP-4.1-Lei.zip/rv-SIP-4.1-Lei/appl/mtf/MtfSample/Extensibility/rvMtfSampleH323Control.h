/******************************************************************************
Filename:    rvMtfSampleH323Control.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef USER_H323_CLBKS_H
#define USER_H323_CLBKS_H

/****************************************************************************
*  rvMtfSampleH323ExtRegEvent()
*****************************************************************************/
RvBool RVCALLCONV rvMtfSampleH323ExtRegEvent(
	    IN      RvMtfHandle		         hMtf,
		IN      cmRegState               regState,
        IN      cmRegEvent               regEvent,
		IN      int                      regEventHandle);

/****************************************************************************
*  rvMtfSampleH323ExtFlowControl
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleH323ExtFlowControl( 
	IN		RvIppConnectionHandle			hConn,
	IN		RvMtfConnAppHandle				hAppConn,
	IN		RvIppTerminalHandle				hTerm,
	IN		RvMtfTerminalAppHandle			hAppTerm,
	IN		RvMtfMediaStreamHandle			hStream,
	IN		RvMtfMediaStreamAppHandle		hAppStream,
	IN		RvMtfMediaType					mediaType,
	INOUT   RvMtfH323FlowControlMsgParams*	msgParams);

#endif /*USER_H323_CLBKS_H*/

