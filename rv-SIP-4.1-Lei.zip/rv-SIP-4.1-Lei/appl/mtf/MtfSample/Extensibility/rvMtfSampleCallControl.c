/******************************************************************************
Filename:    rvMtfSampleCallControl.c
Description: This file contains implementations of Call Control Extensibility callbacks
			 of MTF sample application.
			 User application may use this file as an example and make the necessary
			 changes to adjust it to application's needs.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include "rvMtfExtControlApi.h"
#include "rvMtfSample.h"
#include "ippthread.h"
#ifdef RV_MTF_VIDEO
#include "rvMdmControlVideoApi.h"
#endif

#define USER_CCTERMEVENT_BACKSPACE      (RV_CCTERMEVENT_USER + 1)
#define USER_CCTERMEVENT_FLASH          (RV_CCTERMEVENT_USER + 2)

#define DISPLAY_BUFFER_SIZE         64

char g_displayRegisterStatus[RV_MEDIUM_STR_SZ] = "Register: <Not Defined>";
char emptyLine[50] = {"                                        "};

extern RvMtfSampleParams	g_sampleParams;


/*===============================================================================*/
/*==========        P R I V A T E           F U N C T I O N S       =============*/
/*===============================================================================*/

static RvIppDisplayRawsOrder mapLineIdToRaw(int lineId)
{
    if (lineId == 1)
        return RVIPP_RAW_LINE1_STATUS;
    else
        return RVIPP_RAW_LINE2_STATUS;
}

static void clearLineStatus(RvEppClientEndpoint* ece, int raw)
{
    rvMtfGuiSetTextDisplay(ece, emptyLine, raw, RVIPP_DISPLAY_COLUMN_LINE);
    rvMtfGuiSetTextDisplay(ece, emptyLine, raw+1, RVIPP_DISPLAY_COLUMN_LINE);
}

static void userDisplayCallerId(RvIppConnectionHandle       connHndl,
                                RvIppTerminalHandle         hTerm,
                                char*                       prefix,
                                int                         raw,
                                int                         column)
{
	RvEppClientEndpoint* ece = NULL;
    RvChar callerId[256];

	rvMtfTerminationGetAppHandle (hTerm, (RvMtfTerminalAppHandle*)&ece);

    if ((rvMtfConnectionGetCallerName(connHndl, callerId, sizeof(callerId))) != RV_OK)
    {
        strcpy(callerId, "Anonymous");
    }

    clearLineStatus(ece, raw);
    rvMtfGuiSetTextDisplay(ece, prefix, raw, column);
    rvMtfGuiSetTextDisplay(ece, callerId, raw+1, column);
}


/*===============================================================================*/
/*=======  M D M    C A L L B A C K     I M P L E M E N T A T I O N S   =========*/
/*===============================================================================*/

/****************************************************************************
*  rvMtfSampleSetDisplayCB()
* ---------------------------------------------------------------------------
* This is an implementation of MTF callback RvMtfUpdateTextDisplayEv().
* This implementation updates text display according to states and events.
* The text changes in GUI by sending EPP messages.
*****************************************************************************/
void RVCALLCONV rvMtfSampleSetDisplayCB(
					IN RvIppConnectionHandle    hConn,
					IN RvMtfConnAppHandle		hConnApp,
					IN RvMtfConnectionState		connState,
					IN RvIppTerminalHandle      hTerm,
					IN RvMtfEvent		        eventId,
					IN RvMtfReason				reason)
{
	RvEppClientEndpoint* ece = NULL;
    char buf[DISPLAY_BUFFER_SIZE];
    char dialString[128];
    RvBool keepDisplay = rvFalse;
    char userDisplay[136] = "";
/*  RvIppConnectionHandle activeConn = rvMtfTerminationGetActiveConnection(hTerm);*/
    int lineId;

	RV_UNUSED_ARG(hConnApp);

	rvMtfConnectionGetLineId(hConn, &lineId);

	rvMtfTerminationGetAppHandle (hTerm, (RvMtfTerminalAppHandle*)&ece);

    switch (eventId)
    {
    case RV_CCTERMEVENT_OFFHOOK:

        break;

        case RV_CCTERMEVENT_HOLD:
            if (connState == RV_CCCONNSTATE_CONNECTED)
            {
#ifdef RV_MTF_N_LINES
				rvMtfGuiSetTextNLineStatus(ece,lineId,"On Hold");
#endif /* RV_MTF_N_LINES */
                rvMtfGuiSetTextDisplay(ece, emptyLine, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                userDisplayCallerId(hConn, hTerm, "On Hold", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);

            }
            break;
        case RV_CCTERMEVENT_UNHOLD:
        /* No break*/
        case RV_CCTERMEVENT_CALLANSWERED:
#ifdef RV_MTF_N_LINES
			if ((connState == RV_CCCONNSTATE_CONNECTED) || (connState == RV_CCTERMCONSTATE_REMOTE_HELD))
				/* Means in the middle of conference or transfer process */
			{
				rvMtfTerminationGetLastDialString(hTerm, hConn, dialString, sizeof(dialString));
				sprintf(userDisplay, "Talking:%s", dialString);
				rvMtfGuiSetTextNLineStatus(ece,lineId,userDisplay);
				rvMtfGuiSetTextDisplay(ece, userDisplay, mapLineIdToRaw(lineId), RVIPP_DISPLAY_COLUMN_LINE);
				userDisplayCallerId(hConn, hTerm, "Talking:", mapLineIdToRaw(lineId), RVIPP_DISPLAY_COLUMN_LINE);
			}
			else
#endif /* RV_MTF_N_LINES */
			{
            if (connState == RV_CCCONNSTATE_CONNECTED)
            {
                rvMtfGuiSetTextDisplay(ece, emptyLine, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
				rvMtfTerminationGetLastDialString(hTerm, hConn, dialString, sizeof(dialString));

                sprintf(userDisplay, "Talking:%s", dialString);
#ifdef RV_MTF_N_LINES
				rvMtfGuiSetTextNLineStatus(ece,lineId,userDisplay);
#endif /* RV_MTF_N_LINES */
                rvMtfGuiSetTextDisplay(ece, userDisplay, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);

            //  userDisplayCallerId(connHndl, hTerm, "Connected:", mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
			}
            break;

        case RV_CCTERMEVENT_RINGING:
            if (connState == RV_CCCONNSTATE_ALERTING)
            {
#ifdef RV_MTF_N_LINES
				rvMtfGuiSetTextNLineStatus(ece,lineId,"Call From:");
#endif /* RV_MTF_N_LINES */
                userDisplayCallerId(hConn, hTerm, "Call From:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                keepDisplay = rvTrue;
            }
            break;
        case RV_CCTERMEVENT_RINGBACK:
            if (connState == RV_CCCONNSTATE_CALL_DELIVERED)
            {
#ifdef RV_MTF_N_LINES
				rvMtfGuiSetTextNLineStatus(ece,lineId,"Calling:");
#endif /* RV_MTF_N_LINES */
                userDisplayCallerId(hConn, hTerm, "Calling:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_DIGITS:
            if (connState == RV_CCCONNSTATE_DIALING)
            {
                RvSize_t dialStringLength;
                rvMtfTerminationGetLastDialString(hTerm, hConn, dialString, sizeof(dialString));
                dialStringLength = strlen(dialString);
                /* First digit */
                if (dialStringLength == 1)
                {
                    //  rvMtfGuiClearTextDisplay(ece);
                    rvMtfGuiSetTextDisplay(ece, emptyLine, (int)mapLineIdToRaw(lineId), (int)strlen("Dial:")+(int)RVIPP_DISPLAY_COLUMN_LINE+2);
                }
                if (dialStringLength > 0)
                {
                    /* Echo digit */
                    buf[0] = dialString[dialStringLength - 1];
                    buf[1] = '\0';
                    rvMtfGuiSetTextDisplay(ece, buf, (int)mapLineIdToRaw(lineId), (int)strlen(dialString)+(int)strlen("Dial:")+(int)RVIPP_DISPLAY_COLUMN_LINE+2);
                }
            }
            break;
        case RV_CCTERMEVENT_DIALTONE:
            if (connState == RV_CCCONNSTATE_DIALING)
            {
				RvMtfTerminationState terminalState;

				rvMtfTerminationGetState(hTerm, &terminalState);

                if (terminalState == RV_CCTERMINAL_CFW_ACTIVATING_STATE)
                {
                    rvMtfGuiSetTextDisplay(ece, emptyLine, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                /*  rvMtfGuiSetTextDisplay(ece, "CFW", (int)RVIPP_RAW_CFW, 0);*/
                    rvMtfGuiSetTextDisplay(ece, "CFW:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                }
                else
                {
#ifdef RV_MTF_N_LINES
					rvMtfGuiSetTextNLineStatus(ece,lineId,"Dial:");
#endif /* RV_MTF_N_LINES */
                    rvMtfGuiSetTextDisplay(ece, "Dial:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                }
            }
            break;
        case RV_CCTERMEVENT_DIALCOMPLETED:
            if (connState == RV_CCCONNSTATE_ADDRESS_ANALYZE)
            {
                clearLineStatus(ece, (int)mapLineIdToRaw(lineId));

				rvMtfTerminationGetLastDialString(hTerm, hConn, dialString, sizeof(dialString));

                sprintf(userDisplay, "Calling %s", dialString);
#ifdef RV_MTF_N_LINES
				rvMtfGuiSetTextNLineStatus(ece,lineId,userDisplay);
#endif /* RV_MTF_N_LINES */
                rvMtfGuiSetTextDisplay(ece, userDisplay, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            //  userDisplayCallerId(hConn, hTerm, "Trying:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            else if ((connState == RV_CCCONNSTATE_FAILED) && (reason == RV_CCCAUSE_NOT_FOUND))
            {
                rvMtfGuiSetTextDisplay(ece, "Not Found", (int)mapLineIdToRaw(lineId)+1, (int)RVIPP_DISPLAY_COLUMN_LINE);
            }

            break;
        case RV_CCTERMEVENT_MEDIAFAIL:
            if (connState == RV_CCCONNSTATE_FAILED)
            {
                clearLineStatus(ece, (int)mapLineIdToRaw(lineId));
                rvMtfGuiSetTextDisplay(ece, "Media Failed!", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_DISCONNECTING:
            if (connState == RV_CCCONNSTATE_DISCONNECTED)
            {
                clearLineStatus(ece, (int)mapLineIdToRaw(lineId));
#ifdef RV_MTF_N_LINES
				rvMtfGuiSetTextNLineStatus(ece,lineId,"Idle");
#endif /* RV_MTF_N_LINES */
                rvMtfGuiSetTextDisplay(ece, "Idle", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_REMOTE_DISCONNECTED:
            if (connState == RV_CCCONNSTATE_DISCONNECTED)
            {
                clearLineStatus(ece, (int)mapLineIdToRaw(lineId));
                if (reason == RV_CCCAUSE_BUSY)
				{
                    userDisplayCallerId(hConn, hTerm, "Busy", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
				}
                else
				{
                    userDisplayCallerId(hConn, hTerm, "Disconnected", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
				}
            }
#ifdef RV_MTF_N_LINES
			else if (connState == RV_CCCONNSTATE_IDLE)
			{
				clearLineStatus(ece, (int)mapLineIdToRaw(lineId));
				rvMtfGuiSetTextNLineStatus(ece,lineId,"Idle");
				rvMtfGuiSetTextDisplay(ece, "Idle", mapLineIdToRaw(lineId), RVIPP_DISPLAY_COLUMN_LINE);
			}
#endif
            break;
        case RV_CCTERMEVENT_ONHOOK:
            clearLineStatus(ece, (int)mapLineIdToRaw(lineId));
#ifdef RV_MTF_N_LINES
			rvMtfGuiSetTextNLineStatus(ece,lineId,"Idle");
#endif /* RV_MTF_N_LINES */
            rvMtfGuiSetTextDisplay(ece, "Idle", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            break;
        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }
}

/****************************************************************************
*  rvMtfSamplePreProcessEventCB()
* ---------------------------------------------------------------------------
* This is an implementation of MTF callback RvMtfPreProcessEventEv().
* This implementation resets GUI interface when termination re-registers
* (by processing GW_ACTIVE event).
* Also it demonstrates several new functionalities to be added by application
* (some of the code is commented out).
*****************************************************************************/
void RVCALLCONV rvMtfSamplePreProcessEventCB(
				IN      RvIppConnectionHandle   hConn,
				IN		RvMtfConnAppHandle		hConnApp,
				IN		RvMtfConnectionState	connState,
				IN		RvMtfEvent				eventId,
				OUT		RvMtfEvent*				newEventId,
				INOUT   RvMtfReason*			reason)
{
    RvIppTerminalHandle hTerm;
	RvEppClientEndpoint* ece = NULL;
    RvCCTermConnState termState;

	RV_UNUSED_ARG(hConnApp);
	RV_UNUSED_ARG(reason);

	rvMtfConnectionGetTerminal(hConn, &hTerm);

	rvMtfTerminationGetAppHandle(hTerm, (RvMtfTerminalAppHandle*)&ece);

	rvMtfConnectionGetTermConnState(hConn, &termState);

	IppLogMessage(RV_FALSE, "userCBPreProcessEvent: event=%d, termState=%d, connState=%d",
				eventId, termState, connState);

    switch (eventId)
    {

    /*-----------------------------------------*/
    /*----- Reset Terminal---------------------*/
    /*-----------------------------------------*/
        case RV_CCTERMEVENT_GW_ACTIVE:
        {
            /* Reset signals and indicators*/
            rvMtfTerminationStopAllActiveSignals(hTerm);
            rvMtfGuiStopRingingTone(ece);
            rvMtfGuiSetHoldIndicator(ece, RV_MTF_SIGNAL_STATE_OFF);
            rvMtfGuiSetLineIndicator(ece, RV_MTF_SIGNAL_STATE_OFF, 1);
            rvMtfGuiSetLineIndicator(ece, RV_MTF_SIGNAL_STATE_OFF, 1);
            rvMtfGuiClearTextDisplay(ece);

            /* Display logo*/
            /* Display Lines states*/
#ifdef RV_MTF_MEDIA
            rvMtfGuiSetTextDisplay(ece, "Media", 1, 27);
#else
            rvMtfGuiSetTextDisplay(ece, "NoMedia", 1, 27);
#endif
            rvMtfGuiSetTextDisplay(ece, "...................", (int)RVIPP_RAW_LOGO_SEPERATOR1, 0);
            rvMtfGuiSetTextDisplay(ece, "1>> Idle", (int)RVIPP_RAW_LINE1_STATUS, 0);
            rvMtfGuiSetTextDisplay(ece, "2>> Idle", (int)RVIPP_RAW_LINE2_STATUS, 0);
            rvMtfGuiSetTextDisplay(ece, "...................", (int)RVIPP_RAW_LINE2_CALLER+1, 0);

            /* Registration status was stored previously by SIP user callback (userSipPreRegClientStateChanged)
               in a global string (g_displayRegisterStatus), since we don't have access
               to SIP data from this Common adapter*/
            rvMtfGuiSetTextDisplay(ece, g_displayRegisterStatus, (int)RVIPP_RAW_REGISTER_STATUS, 0);
        }

        break;

    /*-----------------------------------------*/
    /*----- Reject a Call ---------------------*/
    /*-----------------------------------------*/
    /*  case RV_CCTERMEVENT_MAKECALL:

            *reason  = RV_CCCAUSE_CALL_CANCELLED;
            *newEventId = RV_CCTERMEVENT_REJECTCALL;
			return;
        break;
    */
    /*-----------------------------------------*/
    /*----- Backspace -------------------------*/
    /*-----------------------------------------*/

    /*  case USER_CCTERMEVENT_BACKSPACE:
        {
            char dialString[128];

            rvMtfTerminationGetLastDialString(t, hConn, dialString, 128);

			*newEventId = RV_CCTERMEVENT_NONE;
			return;

        }
        break;
    */
    /*-----------------------------------------*/
    /*----- Disable Call Waiting --------------*/
    /*-----------------------------------------*/

    /*  case RV_CCTERMEVENT_RINGING:
        {
            if (termState == RV_CCTERMCONSTATE_BRIDGED)
            {
                *reason = RV_CCCAUSE_BUSY;

                //Stop Call Waiting tone...

				*newEventId = RV_CCTERMEVENT_REJECTCALL;
				return;
            }
        }
        break;
    */

    /*-----------------------------------------*/
    /*----- Ignore Hold in Conference----------*/
    /*-----------------------------------------*/

/*      case RV_CCTERMEVENT_HOLD:
        {
            RvMtfCallType callState;

			rvMtfConnectionGetCallType(connHndl, &callState);
            if (callState == RV_CCCALLSTATE_CONFERENCE_COMPLETED)
			{
				*newEventId = RV_CCTERMEVENT_NONE;
				return;
        }
        break;
*/
    /*-----------------------------------------*/
    /*----- Handle Flash event-----------------*/
    /*-----------------------------------------*/

/*      case USER_CCTERMEVENT_FLASH:
        {

        }
        break;
*/

    default:
        *newEventId = eventId;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    *newEventId = eventId;

}

/****************************************************************************
*  rvMtfSamplePostProcessEventCB()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPostProcessEventEv().
* This implementation demonstrates several new functionalities to be added by
* application (some of the code is commented out).
*****************************************************************************/
void RVCALLCONV rvMtfSamplePostProcessEventCB(
					IN  RvIppConnectionHandle   hConn,
					IN	RvMtfConnAppHandle		hConnApp,
					IN	RvMtfConnectionState	connState,
					IN  RvMtfEvent		        eventId,
					IN  RvMtfReason				reason)
{
    RvIppTerminalHandle hTerm;
	RvEppClientEndpoint* ece = NULL;

    RV_UNUSED_ARG(reason);
	RV_UNUSED_ARG(connState);
	RV_UNUSED_ARG(hConnApp);

	rvMtfConnectionGetTerminal(hConn, &hTerm);

	rvMtfTerminationGetAppHandle(hTerm, (RvMtfTerminalAppHandle*)&ece);

    switch (eventId)
    {


		/*-----------------------------------------*/
        /*-------  Line on Hold alert      --------*/
        /*-----------------------------------------*/
/*  case RV_CCTERMEVENT_ONHOOK: */

        /* The following code causes a terminal to ring if one call was disconnected
           and another call is on hold. It alerts the user that another call
           is on hold.
           The terminal will not ring if a call is on hold because of transfer or
           conference activation  */

    /*  RvIppConnectionHandle heldConn;
		rvMtfTerminationGetOtherConnectionOnHold(hTerm, hConn, &heldConn);
	    if (heldConn != NULL)
        {
            RvMtfCallType  callState;
			RvInt32         lineId;

            callState = rvMtfConnectionGetCallType(heldConn, &callState);
            if (callState == RV_CCCALLSTATE_NORMAL)
			{
                rvMtfGuiStartRingingTone(ece);
			}
        }

        break;*/

        /*-----------------------------------------*/
        /*-------  Line on Hold alert      --------*/
        /*-----------------------------------------*/

/*    case RV_CCTERMEVENT_UNHOLD:*/
        /* In case the Line on Hold alert was uncommented in the RV_CCTERMEVENT_ONHOOK
           case above, open the comment here as well. This code stops the ringing that was
           started when a line was in hold while the active call was disconnected.
           Note: Some user applications may need to set a flag when starting ringing
           and check it here before stopping the signal to avoid cases when a signal is
           stopped without being activated.*/
    /*		rvMtfGuiStopRingingTone(ece);

        break;*/

        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }
}

/****************************************************************************
*  rvMtfSampleConnStateChangedCB()
* ---------------------------------------------------------------------------
* This is an implementation of MTF callback RvMtfConnStateChangedEv().
* This implementation demonstrates several new functionalities to be added by
* application.
*****************************************************************************/
void RVCALLCONV rvMtfSampleConnStateChangedCB(
					IN  RvIppConnectionHandle   hConn,
					IN	RvMtfConnAppHandle		hConnApp,
					IN	RvMtfConnectionState	connState,
				    IN  RvMtfCallStateReason    reason)
{
	RV_UNUSED_ARGS(hConn);
	RV_UNUSED_ARGS(hConnApp);
	RV_UNUSED_ARGS(connState);
	RV_UNUSED_ARGS(reason);

	IppLogMessage(RV_FALSE, "rvMtfSampleConnStateChangedCB: hConn= %p, hConnApp=%d, connState=%d, reason=%d",
				hConn, hConnApp, connState, reason);
}

void RVCALLCONV rvMtfSampleTermRegistrationStateChangedCB(
							IN RvIppTerminalHandle              hTerminal,
							IN RvMtfTerminalAppHandle           hAppTerminal,
							IN RvMtfRegisterReportType          reportType,
							IN RvMtfTermRegistrationStatus*     pData)
{
	IppLogMessage(RV_FALSE,"rvMtfSampleTermRegistrationStateChangedCB() invoked ");
	RV_UNUSED_ARG(hTerminal);
	RV_UNUSED_ARG(hAppTerminal);
	RV_UNUSED_ARG(reportType);
	RV_UNUSED_ARG(pData);

}
