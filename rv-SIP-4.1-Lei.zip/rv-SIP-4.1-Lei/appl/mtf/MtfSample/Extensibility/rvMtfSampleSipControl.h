/******************************************************************************
Filename:    rvMtfSampleSipControl.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef USER_CLBKS_H
#define USER_CLBKS_H

#include "rvMtfExtControlApi.h"
#include "RvSipTransportTypes.h"

/****************************************************************************
*  rvMtfSampleSipStackConfig()
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipStackConfig(RvSipStackCfg* stackCfg);

/****************************************************************************
*  rvMtfSampleRegisterSipStackEvents()
*****************************************************************************/
void RVCALLCONV rvMtfSampleRegisterSipStackEvents(
					IN RvSipStackHandle				hSipStack,
					IN RvIppSipStackCallbacks*		sipStackClbks);

/****************************************************************************
*  rvMtfSamplePreCallLegCreatedIncoming()
*****************************************************************************/
RvMtfMsgProcessType	RVCALLCONV rvMtfSamplePreCallLegCreatedIncoming(
				IN  RvSipCallLegHandle      hCallLeg,
				IN  RvMtfAppHandle			hAppMtf);

/****************************************************************************
*  rvMtfSamplePostCallLegCreatedIncoming()
*****************************************************************************/
void RVCALLCONV rvMtfSamplePostCallLegCreatedIncoming(
			IN RvSipCallLegHandle			hCallLeg,
			OUT RvMtfConnAppHandle*			hConnApp);

/****************************************************************************
*  rvMtfSampleSipPreCallLegCreatedOutgoing()
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPreCallLegCreatedOutgoing(
			IN RvSipCallLegHandle			hCallLeg,
			IN RvIppConnectionHandle		hConn,
			INOUT RvChar*					to,
			INOUT RvChar*					from,
			OUT RvMtfConnAppHandle*			hConnApp);

/****************************************************************************
*  rvMtfSampleSipPostCallLegCreatedOutgoing()
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPostCallLegCreatedOutgoing(
				IN RvSipCallLegHandle       hCallLeg,
				IN RvIppConnectionHandle    hConn,
				IN RvMtfConnAppHandle       hConnApp);

/****************************************************************************
*  rvMtfSampleSipPreStateChanged()
*****************************************************************************/
RvMtfMsgProcessType RVCALLCONV rvMtfSampleSipPreStateChanged(
    IN RvSipCallLegHandle               hCallLeg,
    IN RvIppConnectionHandle            hConn,
    IN RvMtfConnAppHandle				hConnApp,
    IN RvSipCallLegState                eState,
    IN RvSipCallLegStateChangeReason    eReason);

/****************************************************************************
*  rvMtfSampleSipPostStateChanged()
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPostStateChanged(
					IN RvSipCallLegHandle               hCallLeg,
					IN RvIppConnectionHandle            hConn,
					IN RvMtfConnAppHandle				hConnApp,
					IN RvSipCallLegState                eState,
					IN RvSipCallLegStateChangeReason    eReason);

/****************************************************************************
*  rvMtfSampleSipMsgToSend()
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipMsgToSend(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg);

/****************************************************************************
*  rvMtfSampleSipPreMsgReceived()
*****************************************************************************/
RvMtfMsgProcessType RVCALLCONV rvMtfSampleSipPreMsgReceived(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg);

/****************************************************************************
*  rvMtfSampleSipPostMsgReceived()
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPostMsgReceived(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg);

/****************************************************************************
*  rvMtfSampleSipRegClientStateChanged()
*****************************************************************************/
RvMtfMsgProcessType RVCALLCONV rvMtfSampleSipRegClientStateChanged(
			IN RvSipRegClientHandle             hRegClient,
			IN RvIppTerminalHandle              hTerminal,
			IN RvMtfTerminalAppHandle           hAppTerminal,
			IN RvSipRegClientState              eState,
			IN RvSipRegClientStateChangeReason  eReason);

/****************************************************************************
*  rvMtfSampleSipRegClientCreated()
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipRegClientCreated(
			IN RvSipRegClientHandle             hRegClient);

/****************************************************************************
* rvMtfSampleSipExtRegClientMsgToSend
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipExtRegClientMsgToSend(
	IN RvSipRegClientHandle				hRegClient,
	IN RvIppTerminalHandle				hTerminal,
	IN RvMtfTerminalAppHandle			hAppTerminal,
	IN RvSipMsgHandle					hMsg);

/****************************************************************************
* rvMtfSampleSipExtRegClientMsgReceived
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipExtRegClientMsgReceived(
	IN RvSipRegClientHandle				hRegClient,
	IN RvIppTerminalHandle				hTerminal,
	IN RvMtfTerminalAppHandle			hAppTerminal,
	IN RvSipMsgHandle					hMsg);

/****************************************************************************
*  rvMtfSampleSipExtRegExpResolutionNeeded()
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipExtRegExpResolutionNeeded(
                IN  RvSipTransmitterMgrHandle                   hTrxMgr,
				IN  RvSipTransmitterHandle                      hTrx,
				INOUT RvSipTransmitterRegExpResolutionParams*   pRegExpParams);


#endif /*USER_CLBKS_H*/

