/******************************************************************************
Filename:    rvMtfSampleStunRvClient.c
Description: This file contains integration of Radvision STUN client with MTF. 
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"

#ifdef RV_MTF_STUN

#include "inc.h"
#include "rvtimestamp.h"

#include "rvMtfExtControlApi.h"

#include "RvSipResolver.h"
#include "RvSipTransmitter.h"
#include "RvStun.h"

#include "rvSipStunApi.h"
#include "rvMtfSampleStunRvClient.h"



extern RvMtfSampleParams    g_sampleParams;

RvStunStackHandle           g_stunStackHndl;
RvSipTransmitterMgrHandle   g_hTrxMgr;
RvSipTransportAddr          g_stunSrvSipAddr;




static RvStatus RVCALLCONV stunClientReplyReceived(
    IN  RvAddress*                          addr,
    IN  RvChar*                             buf,
    IN  RvSize_t                            size,
	OUT RvBool*                             bDiscardMsg)
{
    RvStunProcessInputStatus    status;

    status = RvStunRequestProcessInput(g_stunStackHndl, NULL, buf, size, addr, RV_FALSE, NULL);

    /* Well, if this is a STUN response, we will simply need to let the MTF know
       it needs to discard this message, as we'll be the ones handling it. */
    *bDiscardMsg = (status == rvStunIsStunMsg);

    return RV_OK;
}

static RvStatus RVCALLCONV stunClientSendRequest(IN RvIppStunAddrData* addrData)
{
    RvStunRequestHandle stunReq;
    RvStatus            status;

    /* Create a STUN request transaction. We don't really need the addrData
       up until the moment we find the resulting public address... */
    stunReq = RvStunRequestConstruct(g_stunStackHndl, NULL, rvStunMsgBindingReq,
        RV_FALSE, RV_FALSE, 0);
    if (stunReq == NULL)
    {
        RvIppStunAddressResolveComplete(addrData, RV_FALSE);
        return RV_ERROR_UNKNOWN;
    }

    /* Set the context to fit what we like best */
    RvStunRequestSetRequestCompleteCbCtx(stunReq, addrData);
	RvStunRequestSetTransmitCbCtx(stunReq, addrData);

    /* Start the darn request. AppSendBufferFunc() will be used to actually
       send it out. */
    status = RvStunRequestStart(stunReq);
    if (status != RV_OK)
    {
        RvStunRequestDestroy(stunReq, RV_TRUE);
        RvIppStunAddressResolveComplete(addrData, RV_FALSE);
        return status;
    }

	return RV_OK;
}


static RvBool RVCALLCONV stunIsAddressResolveNeededCB(IN RvAddress* addrDest)
{
    /* We check here if the destination address is inside the private network.
       We do that by checking the given address against an address mask, which
       is basically a string, with the possible 'x' character at its end,
       denoting a matching mask. */
    RvChar  szDest[64];
    RvChar* ptrDest;
    RvChar* ptrMask;

    /* Convert to a string and start running on our strings */
    RvAddressGetString(addrDest, sizeof(szDest), szDest);
    ptrDest = szDest;
    ptrMask = g_sampleParams.stunNeedMask;

    while ((*ptrDest != '\0') && (*ptrMask != '\0'))
    {
        if (*ptrMask == 'x')
        {
            /* They are identical in the masked part */
            return RV_FALSE;
        }
        else if (*ptrDest != *ptrMask)
        {
            /* We've got a mismatch in a character... */
            return RV_TRUE;
        }

        /* Next character please */
        ptrDest++;
        ptrMask++;
    }

    if (*ptrDest != *ptrMask)
    {
        /* One of the strings ended while the other didn't */
        return RV_TRUE;
    }

    /* They are identical if we got here */
    return RV_FALSE;
}


/***************************************************************************
 * AppTrxStateChangedEv
 * ------------------------------------------------------------------------
 * General: Transmitter events callback.
 * Needed to notify STUN about completion of transmit operation.
 ***************************************************************************/
static void RVCALLCONV AppTrxStateChangedEv(
                        IN  RvSipTransmitterHandle          hTrx,
                        IN  RvSipAppTransmitterHandle       hAppTrx,
                        IN  RvSipTransmitterState           eState,
                        IN  RvSipTransmitterReason          eReason,
                        IN  RvSipMsgHandle                  hMsg,
                        IN  void*                           pExtraInfo)
{
    RvStunRequestHandle stunReq = (RvStunRequestHandle)hAppTrx;

    RV_UNUSED_ARG(eReason);
    RV_UNUSED_ARG(hMsg);
    RV_UNUSED_ARG(pExtraInfo);

    switch (eState)
    {
    case RVSIP_TRANSMITTER_STATE_MSG_SENT:
        RvSipTransmitterTerminate(hTrx);
        /* notify STUN the send operation was completed */
        RvStunRequestSendCompletion(stunReq);
        break;

    case RVSIP_TRANSMITTER_STATE_MSG_SEND_FAILURE:
        RvSipTransmitterTerminate(hTrx);
        /* we may destroy STUN request here */
        RvStunRequestDestroy(stunReq, RV_TRUE);
        break;

    default:
        break;
    }
}

static void transmitStunReqOverSip(						
								   IN RvChar*              msg,
								   IN RvInt                msgSz,
								   IN const RvAddress*     pAddr,
								   IN RvStunRequestHandle  req)
{
	RvSipTransmitterEvHandlers  trxEvHandlers;        
    RvSipTransmitterHandle      hTrx = NULL;
    RvStatus                    status;
	RvSipTransportAddr          stunSrvSipAddr;
	RvChar addr[RV_ADDRESS_MAXSTRINGSIZE];
	
	
	memset(&trxEvHandlers, 0, sizeof(RvSipTransmitterEvHandlers));
	trxEvHandlers.pfnStateChangedEvHandler = AppTrxStateChangedEv;
	
	/* create the Transmitter */
	status = RvSipTransmitterMgrCreateTransmitter(g_hTrxMgr, (RvSipAppTransmitterHandle)req,
		&trxEvHandlers, sizeof(trxEvHandlers), &hTrx);
		
	/* Get the STUN server address from the pAddr proc parameter	 */
	/* The pAddr parameter is mostly usefull when the STUN server is configured using its domain name.
	 * In this case the pAddr contains the server's IP address and port after the stun client has 
	 * discovered it*/
    RvAddressGetString(pAddr, sizeof(addr), addr);

	strcpy(stunSrvSipAddr.strIP, addr);        
	stunSrvSipAddr.port = RvAddressGetIpPort(pAddr);
	stunSrvSipAddr.eAddrType = RVSIP_TRANSPORT_ADDRESS_TYPE_IP;
	stunSrvSipAddr.eTransportType = RVSIP_TRANSPORT_UDP;

	
	/* set the transmitter address as the address of STUN server */
	status = RvSipTransmitterSetDestAddress(hTrx, &stunSrvSipAddr,
		sizeof(stunSrvSipAddr), NULL, 0);
	
	/* perform the send */
	status = RvSipTransmitterSendBuffer(hTrx, msg, msgSz);
}
/***************************************************************************
 * transmitStunReqOverRtp
 * ------------------------------------------------------------------------
 * This proc should be implemented by the user application. It receives a msg
 * supplied by the STUN client and sends it over RTP port to the STUN server.
 * The STUN server reply will be handled by the MTF STUN application which
 * will update the SDP relevant fields.
 * The code below demonstrates how the RTP port and the STUN server address
 * can be retreived from the proc arguments. This data should be used by the
 * user's RTP application when sending the msg out.
 * NOTE: the TODO line must be replaced by an RTP send data proc.
 *
 *  This proc may reside in a more suitable file e.g. in the user's RTP application
 * 
 *  
 ***************************************************************************/
static void transmitStunReqOverRtp(
							  IN void*                ctx,
							  IN RvChar*              msg,
							  IN RvInt                msgSz,
							  IN const RvAddress*     pAddr,
							  IN RvStunRequestHandle  req)
{
	RvUint16    rtpPort, stunSrvPort;
	RvIppStunAddrData*  addrData = (RvIppStunAddrData *)ctx;
	RvChar stunSrvaddr[RV_ADDRESS_MAXSTRINGSIZE];

	RV_UNUSED_ARG(ctx);
	RV_UNUSED_ARG(msg);
	RV_UNUSED_ARG(msgSz);
	RV_UNUSED_ARG(pAddr);
	RV_UNUSED_ARG(req);
	
	/* get the requested RTP port from ctx which contains data from the SDP m= line */
	rtpPort = RvAddressGetIpPort(&addrData->inAddr);

	/* Get the STUN server address from the pAddr proc parameter	 */
	/* The pAddr parameter is mostly usefull when the STUN server is configured using its domain name.
	 * In this case the pAddr contains the server's IP address and port after the stun client has 
	 * discovered it */
    RvAddressGetString(pAddr, sizeof(stunSrvaddr), stunSrvaddr);
	stunSrvPort = RvAddressGetIpPort(pAddr);
	
	/* TODO: send 'msg' with 'msgSz' over RTP 'rtpPort' to 'stunSrvaddr':'stunSrvPort' */ 
	/* In the meantime the Sip transmit proc is called otherwise the stun process gets stuck */

	transmitStunReqOverSip(msg,msgSz, pAddr, req);
}

/***************************************************************************
 * transmitStunReqOverRtcp
 * ------------------------------------------------------------------------
 * This proc should be implemented by the user application. It receives a msg
 * supplied by the STUN client and sends it over RTCP port to the STUN server.
 * The STUN server reply will be handled by the MTF STUN application which
 * will update the SDP relevant fields.
 * The code below demonstrates how the RCTP port and the STUN server address
 * can be retreived from the proc arguments. This data should be used by the
 * user's RTP application when sending the msg out.
 * NOTE: the TODO line must be replaced by an RTCP send data proc.
 *
 *  This proc may reside in a more suitable file e.g. in the user's RTP application
 * 
 *  
 ***************************************************************************/
static void transmitStunReqOverRtcp(
								   IN void*                ctx,
								   IN RvChar*              msg,
								   IN RvInt                msgSz,
								   IN const RvAddress*     pAddr,
								   IN RvStunRequestHandle  req)
{
	RvUint16    rtcpPort, stunSrvPort;
	RvIppStunAddrData*  addrData = (RvIppStunAddrData *)ctx;
	RvChar stunSrvaddr[RV_ADDRESS_MAXSTRINGSIZE];

	RV_UNUSED_ARG(ctx);
	RV_UNUSED_ARG(msg);
	RV_UNUSED_ARG(msgSz);
	RV_UNUSED_ARG(pAddr);
	RV_UNUSED_ARG(req);
	
	/* get the requested RTP port from ctx which contains data from the SDP m= line */
	rtcpPort = RvAddressGetIpPort(&addrData->inAddr);

	/* Get the STUN server address from the pAddr proc parameter	 */
	/* The pAddr parameter is mostly usefull when the STUN server is configured using its domain name.
	 * In this case the pAddr contains the server's IP address and port after the stun client has 
	 * discovered it */
    RvAddressGetString(pAddr, sizeof(stunSrvaddr), stunSrvaddr);
	stunSrvPort = RvAddressGetIpPort(pAddr);
	
	/* TODO: send 'msg' with 'msgSz' over RTP 'rtcpPort' to 'stunSrvaddr':'stunSrvPort' */ 
	/* In the meantime the Sip transmit proc is called otherwise the stun process gets stuck */

	transmitStunReqOverSip(msg,msgSz, pAddr, req);
}

/***************************************************************************
 * AppSendBufferFunc
 * ------------------------------------------------------------------------
 * This function is given to STUN request as transmit function. That is STUN 
 * will use this function when it needs to send something to the STUN server.
 * The same function is used by all three STUN requests engaged (SIP,RTP and
 * RTCP). 
 ***************************************************************************/
static void AppSendBufferFunc(
    IN void*                ctx,
    IN RvChar*              msg,
    IN RvInt                msgSz,
    IN const RvAddress*     pAddr,
    IN RvStunRequestHandle  req)
{
	RvIppStunAddrData*  addrData = (RvIppStunAddrData *)ctx;

    RV_UNUSED_ARG(pAddr);
    // TODO: handle status...

	switch (addrData->type)
	{
		case RVIPP_SIP_VIA_FIELD:
		case RVIPP_SIP_CONTACT_FIELD:
		case RVIPP_SDP_ORIGIN_FIELD:
			transmitStunReqOverSip(msg,msgSz, pAddr, req);
			break;

		case RVIPP_SDP_MEDIA_CONN_FIELD:
		case RVIPP_SDP_MEDIA_FIELD:			
		case RVIPP_SDP_MEDIA_CLOSE_FIELD:
		case RVIPP_SDP_MEDIA_CONN_CLOSE_FIELD:
			transmitStunReqOverRtp(ctx,msg,msgSz,pAddr, req);
			break;

		case RVIPP_SDP_ATTRIBUTE_FIELD:
			transmitStunReqOverRtcp(ctx,msg,msgSz,pAddr, req);
			break;

		default:
			IppLogMessage(RV_TRUE, "AppSendBufferFunc:: unexpected address type %d", addrData->type);
	}
}

/***************************************************************************
 * AppStunResponseCB
 * ------------------------------------------------------------------------
 * General: 
 * This function is given to STUN request as completion callback. This function 
 * will be called by STUN manager when it completes the request execution. 
 * The same function is used for all three STUN requests engaged (SIP, RTP and RTCP)
 ***************************************************************************/
static void AppStunResponseCB(
    IN void*                    ctx, 
    IN RvStunRequestHandle      reqH,
    IN RvStunTransactionError   errNo)
{
    RvStatus            status = RV_ERROR_UNKNOWN;
    RvIppStunAddrData*  addrData = (RvIppStunAddrData *)ctx;
    RvStunMessageType   respType;

    /* Check for errors */
    if (errNo == RV_STUN_ERRCODE_OK)
    {
        /* All is well */
        respType = RvStunRequestGetRespType(reqH);
        if (respType != rvStunMsgBindingErrorResp)
        {
            /* Get the public address */
            status = RvStunRequestGetMappedAddr(reqH, &addrData->outAddr);
            if (status != RV_OK)
            {
                IppLogMessage(RV_TRUE, "No mapped address set in STUN response");
            }

            // TODO: TSAHI to remove!!!
            //RvAddressSetString("127.0.0.1", &addrData->outAddr);
        }
        else
        {
            RvChar* errPhrase = (RvChar *)"";
            RvInt errCode = 0, errPhraseLen = 0;
            RvStunRequestGetErrorCodePhrase(reqH, &errCode, &errPhrase, &errPhraseLen);
            IppLogMessage(RV_TRUE, "Stun request finished with error %d(%s)", errCode, errPhrase);
        }
    }
    else
    {
        /* We have a problem with the response */
        const RvChar *errTxt = RvStunError2Txt(errNo);
        IppLogMessage(RV_TRUE, "Stun request failed, error: %s (%d)", errTxt, errNo);
    }

    /* destroy the request that has completed */
    RvStunRequestDestroy(reqH, RV_TRUE);
    RvIppStunAddressResolveComplete(addrData, (status == RV_OK));
}


/*-----------------------------------------------*/
/*-----------------------------------------------*/
/*-----------------------------------------------*/
RvStatus stunClientInit(IN RvMtfSampleParams* gw)
{
    RvStatus status;

	RV_UNUSED_ARG(gw);

    if (g_sampleParams.stunClientResponsePort == 0)
        g_sampleParams.stunClientResponsePort = 3474;

    if ((g_sampleParams.stunServerAddress[0] != '\0') && (g_sampleParams.stunServerPort !=0))
    {
        /* Initialize the STUN client in the MTF. We mainly need to feed it with
           some callbacks... */
        RvIppStunMgrParam param;

        param.isAddressResolveNeededCB = stunIsAddressResolveNeededCB;
        param.addressResolveReplyCB = stunClientReplyReceived;
        param.addressResolveStartCB = stunClientSendRequest;

        g_sampleParams.stunMgrHndl = RvIppStunMgrCreate(&param);
    }

    /* Initialize STUN Stack */
    {
        void*                   pLog;
        RvStunStackCfg          stunStackCfg;
        RvStunRequestCfg        stunReqCfg;
        RvSipResolverMgrHandle  sipDnsResolver;
        void*                   dnsResolver;

        RvSipStackGetTransmitterMgrHandle(g_sampleParams.sipStackHandle, &g_hTrxMgr);

        RvStunGetDefaultStackCfg(&stunStackCfg);
        stunStackCfg.bStrict3489Behavior = RV_TRUE;
        stunStackCfg.pfnHMAC_SHA1Func = NULL;
        stunStackCfg.pfnMD5Func = NULL;
        
#if (RV_LOGMASK != RV_LOGLEVEL_NONE)
		RvSipStackGetLogHandle(g_sampleParams.sipStackHandle, (RV_LOG_Handle*)&pLog);
        stunStackCfg.pLogManager = (void*)pLog;
#endif
        
        if (RvSipStackGetResolverMgrHandle(g_sampleParams.sipStackHandle,&sipDnsResolver) == RV_OK &&
            RvSipResolverMgrGetDnsEngine(sipDnsResolver,&dnsResolver) == RV_OK)
            stunStackCfg.dnsResolver = dnsResolver;

        status = RvStunStackConstruct(&stunStackCfg, &g_stunStackHndl);

        RvStunGetDefaultRequestCfg(&stunReqCfg);
        stunReqCfg.pfnAppTransmitFunc = AppSendBufferFunc;
        stunReqCfg.pfnRequestCompleteCB = AppStunResponseCB;

        memset(&g_stunSrvSipAddr, 0, sizeof(g_stunSrvSipAddr));
		if (IppUtilIsIpV4(g_sampleParams.stunServerAddress))
		{
			strcpy(g_stunSrvSipAddr.strIP, g_sampleParams.stunServerAddress);        
			g_stunSrvSipAddr.port = g_sampleParams.stunServerPort;
			g_stunSrvSipAddr.eAddrType = RVSIP_TRANSPORT_ADDRESS_TYPE_IP;
			g_stunSrvSipAddr.eTransportType = RVSIP_TRANSPORT_UDP;
			RvSipTransportConvertTransportAddr2RvAddress(&g_stunSrvSipAddr, &stunReqCfg.serverAddress);
		}
		else
			strcpy(stunReqCfg.strServerDomain, g_sampleParams.stunServerAddress);


        RvStunStackSetRequestCfg(g_stunStackHndl, &stunReqCfg);
    }

	return RV_OK;
}


RvStatus stunClientEnd(void)
{
    RvStunStackDestruct(g_stunStackHndl);

    RvIppStunMgrDelete(g_sampleParams.stunMgrHndl);

	return RV_OK;
}


#endif /* RV_MTF_STUN */

