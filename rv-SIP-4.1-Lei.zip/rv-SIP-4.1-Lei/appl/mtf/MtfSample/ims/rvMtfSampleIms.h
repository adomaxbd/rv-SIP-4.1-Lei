/******************************************************************************
Filename:    rvMtfSampleIms.h
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef MTF_SAMPLE_IMS_H
#define MTF_SAMPLE_IMS_H

#ifdef RV_SIP_IMS_ON

#include "rvtypes.h"

#if defined(__cplusplus)
extern "C" {
#endif

/* IMS fields under RvMtfSampleParams */
typedef struct 
{
	RvBool						disableAkaAuthentication;
	RvBool				        isAkaAuthOpConfigured;
	RvUint8                     akaAuth_op[AKA_OP_ARRAY_SIZE];
	RvBool						disableSecAgree;
	RvChar                      PAccessNetworkInfo[RV_SHORT_STR_SZ];
	RvUint32					ipsecPortC;
	RvUint32					ipsecPortS;
    RvUint32					ipsecSpiRangeStart;
    RvUint32					ipsecSpiRangeEnd;
} RvImsMtfSampleParams;	

/******************************************************************************
* RvMtfHandleSecAgreeNegCompletedEv
* -----------------------------------------------------------------------------
* General:
*			This is an implementation of ims callback secAgreeNegCompletedEv().
*			This callback is called when the security agreement negotiation
*			phase is completed, and notifies the application about the results
*			of this phase.
*
*  Arguments:
*  Input:			hTerm			- Handle to the terminal.
*				    hAppTerm		- Handle to the application data associated
*									  with the terminal.
*					success			- indication if selection was successful.
*					reason			- reason of outcome.
*					chosenSecurity  - security mechanism chosen.
*
*  Return Value:    None.
*******************************************************************************/
void RVCALLCONV RvMtfHandleSecAgreeNegCompletedEv (IN RvIppTerminalHandle			hTerm,
												   IN RvMtfTerminalAppHandle		hAppTerm,
												   IN RvBool						success,
												   IN RvMtfSecAgreeReason			reason,
												   IN RvSipSecurityMechanismType	chosenSecurity);

#if defined(__cplusplus)
extern "C" }
#endif
	
#endif /* RV_SIP_IMS_ON */

#endif /*MTF_SAMPLE_IMS_H */
