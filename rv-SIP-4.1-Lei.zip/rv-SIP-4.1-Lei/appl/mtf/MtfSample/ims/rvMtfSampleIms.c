/******************************************************************************
Filename:    rvMtfSampleIms.c
Description: This file includes utility functions for MTF sample application.
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifdef RV_SIP_IMS_ON
#include "IppStdInc.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "rvMtfSampleUtils.h"
#include "rvMtfSampleCfw.h"
#include "rvhost.h"
#include "rvstr.h"
#include "rvlog.h"
#include "rvloglistener.h"

extern RvMtfSampleParams			g_sampleParams;

#define LOGSRC	LOGSRC_BASE
static RvChar* ConvertEnumToStrSecMechanism(IN RvSipSecurityMechanismType eSecMech);

/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

/******************************************************************************
 * ConvertEnumToStrSecMechanism
 * ----------------------------------------------------------------------------
 * General: returns string, representing name of the Security Mechanism.
 *
 * Return Value: security mechanism name
 * ----------------------------------------------------------------------------
 * Arguments:
 * Input:     eSecMech - mechanism to be converted
 *****************************************************************************/
static  RvChar* ConvertEnumToStrSecMechanism(IN RvSipSecurityMechanismType eSecMech)
{
    switch(eSecMech)
    {
        case RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED:   return "UNDEFINED";
        case RVSIP_SECURITY_MECHANISM_TYPE_DIGEST:      return "Digest";
        case RVSIP_SECURITY_MECHANISM_TYPE_TLS:         return "TLS";
        case RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_IKE:   return "IPSEC-IKE";
        case RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_MAN:   return "IPSEC-MAN";
        case RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_3GPP:  return "IPSEC-3GPP";
        case RVSIP_SECURITY_MECHANISM_TYPE_OTHER:       return "Other";
    }
    return "";
}

/*===============================================================================*/
/*=============      C A L L B A C K	   F U N C T I O N S   ==================*/
/*===============================================================================*/

/******************************************************************************
* RvMtfHandleSecAgreeNegCompletedEv
* -----------------------------------------------------------------------------
* General:
*			This is an implementation of ims callback secAgreeNegCompletedEv().
*			This callback is called when the security agreement negotiation
*			phase is completed, and notifies the application about the results
*			of this phase.
*
*  Arguments:
*  Input:			hTerm			- Handle to the terminal.
*				    hAppTerm		- Handle to the application data associated
*									  with the terminal.
*					success			- indication if selection was successful.
*					reason			- reason of outcome.
*					chosenSecurity  - security mechanism chosen.
*
*  Return Value:    None.
*******************************************************************************/
void RVCALLCONV RvMtfHandleSecAgreeNegCompletedEv (IN RvIppTerminalHandle		hTerm,
												  IN RvMtfTerminalAppHandle		hAppTerm,
												  IN RvBool						success,
												  IN RvMtfSecAgreeReason		reason,
												  IN RvSipSecurityMechanismType	chosenSecurity)
{
	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);
	IppLogMessage(RV_FALSE,"RvMtfHandleSecAgreeNegCompletedEv(success=%d, reason=%d, chosenSecurity=%s)",
												  success, reason, ConvertEnumToStrSecMechanism(chosenSecurity));
}


#endif /* RV_SIP_IMS_ON */
