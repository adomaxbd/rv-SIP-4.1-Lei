/******************************************************************************
Filename:    rvMtfSampleInit.h
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#ifndef RV_MTFSAMPLE_H
#define RV_MTFSAMPLE_H

#include "rvstring.h"
#include "rvMtfSample.h"
#include "rvMtfSampleEpp.h"
#include "rvMtfSampleMediaCallbacks.h"
#include "RvSipStackTypes.h"
#include "RvSipMsgTypes.h"
#include "rvMtfExtControlApi.h"
#include "AppRegExpMgr.h"
#ifdef RV_MTF_H323
#include "rvH323ControlApi.h"
#endif /* RV_MTF_H323 */
#ifdef RV_CFLAG_TLS
#include "rvSipTlsApi.h"
#include "rvMtfSampleTls.h"
#endif

#ifdef RV_MTF_STUN
#include "rvSipStunApi.h"
#endif

#ifdef RV_SIP_IMS_ON
#include "rvMtfSampleIms.h"
#endif

#if defined(__cplusplus)
extern "C" {
#endif

/*===============================================================================*/
/*=============  G L O B A L		D E F I N I T I O N S =======================*/
/*===============================================================================*/
#if(RV_OS_TYPE == RV_OS_TYPE_WINCE)
#define PHONE_CONFIGURATION_PATH "\\Program Files\\MtfSipSample\\SIPPhone.cfg"
#define MTF_LOG_PATH "\\Program Files\\MtfSipSample\\MtfLog.txt"
/* In WinCE the TLS certificate files should be placed in ROOT_DIR. In the config file
   only the file name should be provided e.g: privateKeyFileName=mycert.com.key-cert.pem.
   The reson is that while parsing the SIPPhone config file the white space in 'Program Files' causes
   partial parsing of the path  */
#define ROOT_DIR  "\\Program Files\\MtfSipSample\\"
#else
#define PHONE_CONFIGURATION_PATH "./SIPPhone.cfg"
#define MTF_LOG_PATH "./MtfLog.txt"
#define ROOT_DIR ""
#endif

#define PHONE_CONFIGURATION_FILE_SIZE 16000

rvDeclareMap(RvString, RvString);

/*===============================================================================*/
/*=====================  G L O B A L		T Y P E S ===========================*/
/*===============================================================================*/

typedef enum
{
	SIP_API_TYPE,
	IPP_API_TYPE
}APITYPE;

#define RVIPP_DISPLAY_COLUMN_LINE	4
#define RVIPP_DISPLAY_REG_PREFIX    "Register:"

typedef enum RvIppDisplayRawsOrder_
{
	RVIPP_RAW_LOGO				= 0, /* Lines 0 and 1 are unused by MTF, reserved for GUI*/
		RVIPP_RAW_LOGO_SEPERATOR1	= 2,
		RVIPP_RAW_LINE1_STATUS		= 3,
		RVIPP_RAW_LINE1_CALLER		= 4,
		RVIPP_RAW_LINE2_STATUS		= 6,
		RVIPP_RAW_LINE2_CALLER		= 7,
		RVIPP_RAW_LOGO_SEPERATOR2	= 8,
		RVIPP_RAW_CFWU				= 9,
		RVIPP_RAW_CFWB				= 10,
		RVIPP_RAW_CFWNR				= 11,
		RVIPP_RAW_REGISTER_STATUS	= 12,
} RvIppDisplayRawsOrder;

typedef enum
{
    RV_IPP_DTMF_RELAY_OFF = 0,     /* DTMF tones passed as voice */
    RV_IPP_DTMF_RELAY_INBAND = 1,  /* DTMF tones passed as RFC2833 packets */
    RV_IPP_DTMF_RELAY_OOB = 2      /* DTMF tones sent as out-of-band protocol
                                   specific packets */

} RvRtpDtmfRelay;

/*===============================================================================*/
/*===============  S A M P L E		P A R A M E R E R S =========================*/
/*===============================================================================*/

typedef struct
{
	/* ========= General MTF parameters ======================*/
	/* =======================================================*/
	RvMtfHandle 	        mtfHandle;
		/* Handle to MTF */

	RvSipStackHandle		sipStackHandle;
		/* Handle to SIP stack */
	RvChar					localAddress[64];
		/* Local address for listening for SIP messages */

	unsigned int        	numberOfLines;
		/* Number of lines */

	RvSipTransport			transportType;
		/* Transport type for sending SIP messages */

	RvUint16				stackTcpPort;
		/* TCP port number for listening for SIP messages */

	RvUint16				stackUdpPort;
		/* UDP port number for listening for SIP messages */

	RvString				userDomain;
		/* This parameter is relevant when SIP Registrar is not configured */

	RvIppSipLogOptions		logOptions;
		/* log filters for SIP stack */

	unsigned int			dialToneDuration;
		/*Timeout of dial tone signal, when going off-hook, in milliseconds*/

	int						maxCallLegs;
	RvSdpMsg				*sdpForInitialInvite;
		/* This SDP will be sent when initiating a call */

	RvSdpMsg				*sdpOfFullCaps;
		/* This SDP includes the full MTF capabilities   */

	RvRtpDtmfRelay			dtmfRelay;
	RvBool                  enableSdpLogs;
		/*When set to true, SDP logging will be generated to log file */

	RvString					termId;
		/* This parameter will be used as termination id when UI termination is registered */

    int							maxRegClients;
	RvInt32						referTimeout;
	RvInt32						outgoingRequestNoResponseTimeout;
	RvInt32						outgoingCallNoAnswerTimeout;
    RvBool						tcpEnabled;
	RvCallWaitingReply			callWaitingReply;
		/* Indicates the reply for call waiting - 180(Ringing) or 182(Queued) */
	RvBool                      disableCallWaiting;
	RvBool                      persistentRegisterEnabled;
	RvInt32                     persistentRegisterRetryInterval;
	RvInt32                     registerCompleteTimeout;
	    /* When set to True, a waiting call will be rejected */
	RvUint32					watchdogTimeout;
		/* Timeout for printing MTF and SIP resources periodically*/

    RvBool                      connectMediaOn180;
		/* When set to True, media will be connected both in 180, 183 and 200,
           when set to False, media will be connect in 183 and 200 only*/

	RvBool                      addUserAgentHeader; 
	/* When set to True, User-Agent header will be added to SIP messages  */

	RvChar                      manufacturerId[64];
	RvChar                      productId[64];
	RvChar                      productVersion[64];

	RvBool                      sessionTimerRefreshByUpdate;
		/* send session timer refresh messages by INVITE (0) or by UPDATE (1) */
	RvUint16                    sessionTimerMinimumAllowed;
	    /* set a minimum session expire interval for session timer */ 
	
	RvUint16                    sessionTimerSessionExpires;
	    /* set the session timer expiration interval */

	RvBool                      sendOldHoldFormat;
	     /* send Hold requests in old format: c=IN IP4 0.0.0.0 instead of a=sendonly */
	
	RvBool                      addUpdateSupport;
		/* Enables/disable support for Update messages.*/

	RvUint8                     updateRetryAfterTimeout;

	RvUint16                    callerUpdateResendTimeout;

	RvUint16                    calleeUpdateResendTimeout;

	RvBool                      autoAnswer;
		/* When set to True, incoming calls will be automatically answered,
           when set to False, call be answered when user goes off hook.*/

	RvBool                      autoDisconnect;
		/* When set to True, line will be automatically disconnected after remote party disconnected the call.
           when set to False, user will need to go on hook after remote party disconnected the call, before he
		   can use the line for another call.*/
	RvInt						defaultProtocolType;
	RvBool						acceptCallWhenUserNotFound;
	/* When set to True, incoming calls will be answered even if user name is not found, 
	   meaning there is no termination id that matches the username in To header. 
	   When set to False, they'll be rejected. */

	/* ========= Sample internal parameters ==================*/
	/* =======================================================*/
	RvMtfSampleEpp			mtfSampleEpp;
	RvMap(RvString,			RvString)	addressList;
		/* List of phone numbers and addresses (as loaded from under [PhoneNumbers] section in configuration file) */

    RvChar                  displayName[256];
    RvBool					bConfigTCP;
	char					eppIp[80];
	RvUint16				eppPort;
    char					localIpPrefix[128];
    char					localIpMask[128];

	/* ========= Call Forward parameters =====================*/
	/* =======================================================*/
	RvBool						callForwardTypeIsActive[RV_IPP_CFW_MAX_NUMBER_OF_TYPES];
		/* For Call Forward feature:
			1st press on cfwTypeX button, its "typeXIsActive parameter will be switch from off to be on.
			2nd press on cfwTypeX button, its "typeXIsActive parameter will be switch from on to off...
			Every press on cfwTypeX will be switch the value of its "IsActive" parameter. */
	RvUint						callForwardNoReplyTimeout;
		/* For Call Forward feature:
			This parameter is relevant for CFW No Reply type only.
			Its value will be used when a request to activate cfnr is required.
			This value is set in configuration time and can not be set dynamically */
	RvIppCfwCfg					cfwCallCfg;

    RvMtfMediaConstructParam    mediaParam;

	/* ========= SIP Servers parameters =======================*/
	/* ========================================================*/

	RvString					registrarAddress;
	RvUint16					registrarPort;
	RvString					outboundProxyAddress;
	RvUint16					outboundProxyPort;
	RvString					username;
		/* Username for Authentication*/
	RvString					password;
		/* Password for Authentication*/
	RvBool						autoRegister;
    RvInt32						registrationExpire;
    RvInt32						unregistrationExpire;
	RvInt32                     maxAuthenticateRetries; /* how many times we should respond to consequent 401/407 msgs */
	RvBool                      removeOldAuthHeaders;

	/* ========= Digit Map parameters ========================*/
	/* =======================================================*/
    RvChar                      digitMapPatterns[RV_SHORT_STR_SZ];
	/* ========= STUN parameters =============================*/
	/* =======================================================*/
#ifdef RV_MTF_STUN
	RvString					stunNeedMask;
	RvChar                      stunServerAddress[64];
		/* Address of the STUN server */
	RvUint16					stunServerPort;
		/* Port of the STUN server */
	RvUint16					stunClientResponsePort;
		/* Port receiving STUN response messages */
	RvIppStunMgrHandle			stunMgrHndl;
		/* MTF STUN object to use */
#endif


    /* ========= AKA parameters ==============================*/
	/* =======================================================*/
#ifdef RV_SIP_IMS_ON
	RvImsMtfSampleParams		imsSampleParams;
#endif

	/* ========= ENUM/Tel-URI parameters======================*/
	/* =======================================================*/
	/* Pointer to an applicative regular expression resolver manager.
       we use this manager when we want to resolve a regular expression. */
    RegExpMgr*                  regExpMgr;

	/* ==== Message Waiting Indication (MWI) parameters ======*/
	/* =======================================================*/
#ifdef SAMPLE_MWI
	RvString					subsServerName;
#endif

	/* ========= TLS parameters ==============================*/
	/* =======================================================*/
#ifdef RV_CFLAG_TLS
	RvIppTransportTlsCfg		transportTlsCfg;
	RvIppKeyTlsCfg				keyTlsCfg;
#endif
	/* ========= H.323 parameters ============================*/
	/* =======================================================*/
#ifdef RV_MTF_H323
	RvString					localH323Address;
	int							h323MaxCalls;
	RvString					gkAddress;
    int							gkPort;
	int							debugLevel;
	RvBool						fastStart;
	RvString					h323TermId;
	RvMtfH323E164List			e164PhoneList; 
	int							q931SignalingPort;
	int 						h323OutgoingRequestNoResponseTimeout;
	int    					    h323OutgoingCallNoAnswerTimeout;
	RvIppH323LogOptions			h323LogOptions;
#endif /* RV_MTF_H323 */

} RvMtfSampleParams;


/*===============================================================================*/
/*===============  S A M P L E		A P I S  ====================================*/
/*===============================================================================*/

RV_Status rvMtfSampleConstruct(OUT RvMtfSampleParams *sampleParams, IN char* configBuf);

void rvMtfSampleDestruct(IN RvMtfSampleParams *sampleParams);

void rvMtfSampleRegisterIPPhone(
						IN RvChar*						termId,
						IN void*						userData,
						OUT RvIppTerminalHandle*		termination);

void rvMtfSampleUnregisterIPPhone(
						IN RvIppTerminalHandle		termination);


#ifdef RV_MTF_VIDEO
void rvMtfSampleRegisterVideo(IN void*	userData);
void rvMtfSampleUnregisterVideo(void);

#endif /* RV_MTF_VIDEO */

void rvMtfSampleRegisterAnalog(
				IN RvChar*					termId,
				IN RvChar*					strParams,
				IN void*					userData,
				OUT RvIppTerminalHandle*	termination);

void rvMtfSampleUnregisterAnalog(
						IN RvIppTerminalHandle		termination);

void rvMtfSampleOnHookEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleOffHookEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleHoldEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleConferenceEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleTransferEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleBlindTransferEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleMuteEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleSpeakerEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleHeadesetEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleRedialEvent(
						IN RvIppTerminalHandle     hTerm);

void rvMtfSampleLineEvent(
						 IN RvIppTerminalHandle     hTerm,
						 IN RvUint32				lineId);

void rvMtfSampleCallForwardEvent(
						 IN RvIppTerminalHandle		hTerm,
						 IN RvIppCfwType			cfwType);
void rvMtfSampleDialCompletedEvent(
						 IN RvIppTerminalHandle     hTerm);

void rvMtfSampleDigitDownEvent(
						 IN RvIppTerminalHandle      hTerm,
						 IN RvChar					digit);

void rvMtfSampleDigitUpEvent(
						 IN RvIppTerminalHandle      hTerm,
						 IN RvChar					digit);

void rvMtfSampleRejectCallEvent(
						IN RvIppTerminalHandle		hTerm,
						IN RvUint32					lineId);

/* Dynamic media change - send Re-Invite*/
void rvMtfSampleModifyMediaByReInvite(
						IN RvIppTerminalHandle		hTerm,
						IN RvChar*					sdpBuffer,
					 	 IN RvInt					sdpBufferLen);

/* Dynamic media change - send Update*/
void rvMtfSampleModifyMediaByUpdate(
						IN RvIppTerminalHandle		hTerm,
						IN RvChar*					sdpBuffer,
					 	 IN RvInt					sdpBufferLen);

void rvMtfSampleMakeCall(
						IN RvIppTerminalHandle		hTerm,
						IN RvChar*					destination);

#if defined(__cplusplus)
}
#endif

#endif /*RV_SIPGATEWAY_H*/
