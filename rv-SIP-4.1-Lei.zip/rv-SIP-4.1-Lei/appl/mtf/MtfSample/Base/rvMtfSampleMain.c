/******************************************************************************
Filename:    MtfSampleMain.c
Description: This file contains the main() function for MTF sample application.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"
#include "ippthread.h"
#include "rvMtfSample.h"
#include "rvsdp.h"
#include "rvthread.h"
#include "rvmtfalloc.h"
#include "rvMtfSampleUtils.h"


#if defined(RV_OS_NUCLEUS)
#include <plus\nucleus.h>
#endif
#if defined(RV_MEMTRACE_ON)
#include "rvmem.h"
#endif

/*============================================================================================*/
/*=================================   G L O B A L S  =========================================*/
/*============================================================================================*/

RvAlloc*        userDefaultAlloc = NULL;

RvMtfSampleParams		g_sampleParams;
RV_BOOL                 startWarmRestart;
RV_BOOL                 startShutdown;

/*============================================================================================*/
/*=======================   S T A R T / E N D		F U N C T I O N S ========================*/
/*============================================================================================*/

RvStatus rvMtfSampleStart(void)
{
    RvChar      *configBuf;
    RvStatus    status;

    /* Load configuration file */
	/* ----------------------- */
    configBuf = (RvChar *)malloc(PHONE_CONFIGURATION_FILE_SIZE);

    status = rvMtfSampleUtilLoadFile(configBuf, PHONE_CONFIGURATION_FILE_SIZE, PHONE_CONFIGURATION_PATH);
    if (status != RV_OK)
    {
        free(configBuf);
        printf("rvMtfSampleStart() - ERROR: failed to read file: %s\n", PHONE_CONFIGURATION_PATH);
        return status;
    }

    /* Initialize the MTF core */
	/* ----------------------- */
    rvIppSipSystemInit();

    userDefaultAlloc = rvAllocGetDefaultAllocator();

	/* Construct MTF and sample application */
	/* ------------------------------------ */
    status = rvMtfSampleConstruct(&g_sampleParams, (char *)configBuf);
	if (status != RV_OK)
    {
        free(configBuf);
        printf("rvMtfSampleStart() - ERROR: failed to initialize MTF, status = %d\n", status);
        return status;
    }

	/* Start MTF */
	/* --------- */
    rvMtfStart(g_sampleParams.mtfHandle);

    free(configBuf);

    return status;
}

void rvMtfSampleEnd(void)
{
	/* Destruct MTF and sample application */
	/* ----------------------------------- */
    rvMtfSampleDestruct(&g_sampleParams);
    rvIppSipSystemEnd();
}
/*============================================================================================*/
/*=======================   M A I N		F U N C T I O N  =====================================*/
/*============================================================================================*/

#if (RV_OS_TYPE != RV_OS_TYPE_WINCE)
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int MtfSipSample(int argc)
#else
int Sample_main(int argc, char **argv)
#endif
{
    RvStatus    status = RV_OK;
    int         i, numOfWarmRestarts = 0;

#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
    /*There is no argc and argv in vxWorks, so we have one argument only*/
    numOfWarmRestarts = argc;
#else
    /* Get number of warm restarts from command line */
    if (argc == 2)
        numOfWarmRestarts = atoi( argv[argc-1]);
#endif

    /* Run MTF for the first time */
    if ((status = rvMtfSampleStart()) != RV_OK)
    {
        printf("*******rvMtfSampleStart error = %d*******\n", status);
        return status;
    }

    /* Loop through Warm Restarts for the fun of it*/
    for (i=0 ; i < numOfWarmRestarts ; ++i)
    {

        /* Shut down MTF*/
        rvMtfSampleEnd();

        printf("******* Shut Down is Completed! (number=%d) *******\n", i);

		/* Restart MTF*/
        if (rvMtfSampleStart() != RV_OK)
		{
        	printf("******* Startup failed!!! (number=%d)*******\n", i);
			break;
		}

        printf("******* Startup is Completed (number=%d)*******\n", i);
    }

    startWarmRestart = RV_FALSE;
    startShutdown = RV_FALSE;

    while (startShutdown == RV_FALSE)
    {
        /* This boolean will be changed only by EPP thread to notify us the
           user wants to perform Restart or Shutdown*/
        while ((startWarmRestart == RV_FALSE) && (startShutdown == RV_FALSE))
        {
            IppThreadSleep(2, 0);
        }

        /* Shut down MTF*/
        rvMtfSampleEnd();

        if (startWarmRestart == RV_TRUE)
        {
            /* Restart MTF if needed*/
            rvMtfSampleStart();
        }

        startWarmRestart = RV_FALSE;
    }

#if defined(RV_MEMTRACE_ON)
    rvMemTraceDestruct();
#endif

    return 0;
}

/*============================================================================================*/
/*=========================== V X W O R K S  =================================================*/
/*============================================================================================*/

/* In vxWorks we can either call vxMain() with no arguments for running application from seperated
   process (so we don't block the shell), or we can call MtfSipSample() directly
   (and block the shell) with one argument: number of warm restarts*/
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int vxMain()
{
    taskSpawn("User IPP",100,0,100000, MtfSipSample, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return 0;

}
#endif /*(RV_OS_TYPE_VXWORKS)*/

/*============================================================================================*/
/*=================   W I N D O W S		M O B I L E  =========================================*/
/*============================================================================================*/

#else /*if !defined(RV_OS_WINCE)*/

#include "resource.h"

/* Global variables*/
HWND        g_hWnd=0;
HINSTANCE   g_hInst=NULL;
HWND        g_hDlg = NULL;

/* Function prototypes*/
RvBool InitApplication(HANDLE hInstance);
RvBool InitInstance(HANDLE hInstance, int nCmdShow);
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam);
RvBool    CALLBACK IppSipDialogBox(HWND hDlg, WORD wMsg, WORD wParam, LONG lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPWSTR lpCmdLine, int nCmdShow)
{

    g_hInst = hInstance;

    if (!hPrevInstance)
    {
        if (!InitApplication(hInstance))
            if (!InitInstance(hInstance, nCmdShow))
                return (FALSE);
    }

    DialogBox(g_hInst, MAKEINTRESOURCE(IDD_FORM_CLIENT), g_hWnd,
        (DLGPROC)IppSipDialogBox);

    /*Note: to load configuration from files, we should give the full path
      (\\Windows\Start Menu....), and give the file name in wide chars
      (use macro TEXT("\\Windows\RvIpp\SipPhone.cfg"))*/

    return (RV_TRUE);
}
RvBool InitApplication(HANDLE hInstance)
{
    WNDCLASS  wc;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = 0;
    wc.hCursor = 0;
    wc.hbrBackground = GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = TEXT("RADVISION IPP SIP Application");

    return (RegisterClass(&wc));
}

RvBool InitInstance(HANDLE hInstance, int nCmdShow)
{
    g_hInst = hInstance;

    g_hWnd = CreateWindow(
        TEXT("RADVISION IPP SIP Application"),
        TEXT("RADVISION IPP SIP Application"),
        0,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
        );
    if (!g_hWnd)
        return (FALSE);
    return (RV_TRUE);
}


/* Function: MainWndProc
//
// Description:
//    Main window callback.
*/
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam)
{
    switch (message)
    {
    case WM_CREATE:
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    case WM_CLOSE:
        return 0;
    default:
        return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return 0;
}



// Function: IppSipDialogBox (hDlg, wMsg, wParam, lParam)
//
// This is the callback function for messages for the dialog.
// It contains the code to handle window events as well as user
// input such as button clicks.
//
RvBool CALLBACK IppSipDialogBox(HWND hDlg, WORD wMsg, WORD wParam, LONG lParam)
{
    if (!g_hDlg)               // Assign global Dialog handle value if it was empty. Necessary only for
        g_hDlg = hDlg;         // the convenience of the wce_printf() function

    switch(wMsg)
    {
    case WM_INITDIALOG:
        {
            RvStatus status;
            status = rvMtfSampleStart();
            if (status != RV_OK)
            {
                return FALSE;
            }
            ShowWindow(hDlg, SW_SHOW);

            return RV_TRUE;
        }
    case WM_COMMAND:
        {
            switch(wParam)
            {
            case IDC_EXIT:
                rvMtfSampleEnd();
                // Exit the app
                EndDialog(hDlg, IDC_EXIT);
                break;
            }
            return RV_TRUE;
        }
    }
    return FALSE;
}


#endif /*RV_OS_WINCE*/























