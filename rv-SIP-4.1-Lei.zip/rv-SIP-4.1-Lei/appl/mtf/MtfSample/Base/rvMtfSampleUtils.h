/******************************************************************************
Filename:    rvMtfSampleUtils.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef IPP_SIP_UTIL_H
#define IPP_SIP_UTIL_H

#include "RvSipStackTypes.h"
#include "rvMtfSample.h"
//#include "rvMtfExtControlApi.h"
#include "rvtypes.h"

void rvMtfSampleUtilLoadMtfLogOptions(
    OUT IppLogSourceFilterElm*  logOptions,
    IN  RvSize_t                numLogOptions,
    IN  RvChar*                 configBuf);

RvStatus rvMtfSampleUtilLoadFile(
    IN RvChar*          buf,
    IN RvSize_t         bufsize,
    IN const RvChar*    fileName);

RvChar* rvMtfSampleUtilGetNextLine(IN RvChar* buf, OUT RvChar** p);

RvBool rvMtfSampleUtilLoadMediaParams(IN const char* buffer, OUT RvMtfSampleParams* sampleParams);

void rvMtfSampleUtilCleanParam(INOUT RvChar* str);

void rvMtfSampleUtilPrintConfigParams(IN RvMtfSampleParams *sampleParams);

void rvMtfSampleUtilLoadConfigParams(
						OUT RvMtfSampleParams*	sampleParams,
						IN RvChar*              configBuf);

RvMtfDigit rvMtfSampleUtilDigitToEnum(RvChar digit);

void rvMtfSampleUtilParseRegisterParams(
										IN RvChar*					regParams, 
										OUT RvMtfTerminationConfig*	termConfig);

void rvMtfSampleUtilBuildDigitMap( 
								  INOUT RvMdmDigitMap*	    digitMap, 
			                      IN    char*				digitMapString );

#endif /*IPP_SIP_UTIL_H */
