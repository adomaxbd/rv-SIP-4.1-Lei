/******************************************************************************
Filename:    rvMtfSampleEpp.h
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#ifndef RV_MTF_SAMPLE_EPP_H
#define RV_MTF_SAMPLE_EPP_H

#include "rveppclient.h"
#include "rvMtfBaseApi.h"
//#include "rvMdmControlApi.h"

#if defined(__cplusplus)
extern "C" {
#endif

/*===============================================================================*/
/*=============  G L O B A L		D E F I N I T I O N S =======================*/
/*===============================================================================*/

typedef struct
{
//	RvMtfHandle     mtfHandle;
	RvEppClient*    eppClient;
} RvMtfSampleEpp;


/*===============================================================================*/
/*=================  E P P			F N U C T I O N S	 ========================*/
/*===============================================================================*/

RvStatus rvMtfSampleEppConstruct(
							 IN RvMtfSampleEpp*     mgr,
							 IN RvMtfHandle			mtfHandle,
							 IN RvBool				bConfigTCP,
							 IN const RvChar*		eppClientIp,
							 IN RvUint16			eppPort);

void rvMtfSampleEppDestruct(RvMtfSampleEpp *mgr);

void rvMtfGuiStartDialTone(RvEppClientEndpoint*		ece);

void rvMtfGuiStartRingbackTone(
							   RvEppClientEndpoint*		ece, 
							   char*                    signalInfo);

void rvMtfGuiStartRingingTone(
							  RvEppClientEndpoint*		ece, 
							  char*                     signalInfo);

void rvMtfGuiStartCallWaitingTone(RvEppClientEndpoint*		ece);

void rvMtfGuiStartCallWaitingCalleeTone(RvEppClientEndpoint*		ece);

void rvMtfGuiStartBusyTone(RvEppClientEndpoint*		ece);

void rvMtfGuiStartWarningTone(RvEppClientEndpoint*		ece);

void rvMtfGuiStartDigitTone(
						RvEppClientEndpoint*	ece,
						RvMtfDigit				digit);

void rvMtfGuiSetLineIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState,
						RvUint32				lineId);

void rvMtfGuiSetHoldIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState);

void rvMtfGuiSetMuteIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState);

void rvMtfGuiSetSpeakerIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState);

void rvMtfGuiSetHeadsetIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState);

void rvMtfGuiStopDialTone(
						 RvEppClientEndpoint*	ece);

void rvMtfGuiStopRingbackTone(
							  RvEppClientEndpoint*	ece);

void rvMtfGuiStopRingingTone(
							  RvEppClientEndpoint*	ece);

void rvMtfGuiStopCallWaitingTone(
							  RvEppClientEndpoint*	ece);

void rvMtfGuiStopCallWaitingCalleeTone(
							  RvEppClientEndpoint*	ece);

void rvMtfGuiStopBusyTone(
							  RvEppClientEndpoint*	ece);

void rvMtfGuiStopWarningTone(
							  RvEppClientEndpoint*	ece);

void rvMtfGuiSetTextDisplay(
							RvEppClientEndpoint*	ece,
							RvChar* 				text, 
							RvUint 					column, 
							RvUint 					row);

void rvMtfGuiClearTextDisplay(RvEppClientEndpoint*	ece);

void rvMtfGuiSetMwiIndicator(
							 RvEppClientEndpoint*		ece,
							 RvMtfSignalState			signalState);

void rvMtfGuiStartMwiTone(RvEppClientEndpoint*	ece);

/*===============================================================================*/
/*=================  E P P			 C A L L B A C K S	 ========================*/
/*===============================================================================*/

void rvMtfSampleEppOnEvent(
						   RvEppClient*            ec, 
						   RvEppClientEndpoint*    ece, 
						   const RvChar*           eventName,
						   RvChar*                 eventParams, 
						   void*                   data);

RvBool rvMtfSampleEppOnRegister(
							RvEppClientEndpoint*	ece, 
							void*					params);

void rvMtfSampleEppOnUnregister(
							RvEppClient*				ec,
							RvEppClientEndpoint*		ece,
							void*						data,
							RvChar*						params);

#ifdef RV_MTF_N_LINES
void rvMtfGuiSetTextNLineStatus(
								RvEppClientEndpoint*	ece,							
								RvUint 					lineID,
								RvChar* 				text
								);
#endif


#if defined(__cplusplus)
}
#endif

#endif /*RV_MTF_SAMPLE_EPP_H*/
