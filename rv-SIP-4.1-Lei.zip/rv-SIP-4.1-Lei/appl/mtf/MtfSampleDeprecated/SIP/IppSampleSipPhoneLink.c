/******************************************************************************
Filename:    IppSampleSipPhoneLink.c
Description: Phone Link functions for SIP Phone
*******************************************************************************
                Copyright (c) 2004 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"

#include "IppSampleSipGateway.h"
#include "IppSamplePhoneLink.h"
#include "IppSampleSipUserClbks.h"
#include "MtfMediaCallbacks.h"
#include "MfControl.h"
#include "rvstr.h"

#ifdef SAMPLE_MWI
#include "IppSampleSipMWI.h"
#endif

extern RvIppSampleGateway		gw;

/*--------------------------------------------------------------------------------*/
static RvMap(RvString, RvString)* getAddressList()
{
	return &gw.gatewayBase.addressList;
}

/*--------------------------------------------------------------------------------*/
RvBool rvPhoneMgrMapDialStringToAddressCB(
    IN  RvMdmTerm*      term,
    IN  const RvChar*   dialString,
    OUT RvChar*         address)
{
    /* TODO: Change implementation so it doesn't use RvMap and it is easy to read...*/
    /* TODO: Comment while at it...*/

	/*	RvMap(RvString, RvString)* getAddressList();*/
	RvMap(RvString, RvString)* addressList=getAddressList();
	RvMapIter(RvString, RvString) iter = rvMapBegin(RvString, RvString)(addressList);
	int i;
	int j;

	RV_UNUSED_ARG(term);

	while(iter)
	{
		const char* key = rvStringGetData(rvMapIterGetKey(RvString, RvString)(iter));

		for (i=0;key[i];i++)
		{
			switch(key[i])
			{
			case '0':case '1':case '2':case '3':case '4':
			case '5':case '6':case '7':case '8':case '9':
			case '*':case '#':
				if (dialString[i]==key[i])
					continue;
				break;
			case '.':
				continue;
            default:
                break;
			}
			break;
		}
		if (!key[i])
		{/*key found*/
			const char* value = rvStringGetData(rvMapIterGetValue(RvString, RvString)(iter));
			for (i=0,j=0;key[i];i++)
			{
				if (key[i]=='.')
					for (;value[j];j++)
					{
						if (value[j]=='\\')
						{
							address[j++]=dialString[i];
							break;
						}
						else
							address[j]=value[j];
					}
			}
			for (;value[j];j++)
			{
				if (value[j]=='\\')
				{
					address[j]='.';
					break;
				}
				else
					address[j]=value[j];
			}
			address[j]='\0';
            RvAssert(j < 64); /* If this isn't true, we have a buffer overrun... */
			return RV_TRUE;
		}
		iter = rvMapIterNext(iter);
	}

	/* didn't find a matching mapping in the dial map, check if this is an analog line
	   in call simulation. If so generate address of type dialString@destIpAddress */
	{

		if ((gw.gatewayBase.numOfAnalogLines > 0 ) && (strcmp (gw.gatewayBase.analogDestAddress, "")))
		{
			sprintf(address, "%s@%s", dialString, gw.gatewayBase.analogDestAddress);
			return RV_TRUE;
		}
	}
	return RV_FALSE;
}

/***************************************************************************************
* parseRegParams
* -------------------------------------------------------------------------------------
* General:  This function gets a string with terminal data sent by the terminal at
*           registration time, parses it and converts it into char* or int format.
*           An example for terminal data string:
*           register <term id> analog <GUI address> <GUI port>,RegistrarAddress=172.0.0.0,
*            RegistrarPort=9999,OutboundProxyAddress=172.0.0.0,OutboundProxyPort=8888,
*			 Username=ymoran,Password=radvision,RegisterExpires=3600
*
*           The input string may contain one or more of the data items.
* Return Value: - None
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  regParams - a string with terminal data
*         termProperties - A data structure the stores the data after parsing
* Output:   none
**************************************************************************************/
static void parseRegParams(RvChar* regParams, RvMdmTermDefaultProperties*	termProperties)
{
	char* token;
	RvStrTok commaTokenizer;

	if (regParams == NULL)
	{
		IppLogMessage(RV_FALSE, "parseRegData:: No Registration parameters supplied");
		return;
	}

    rvStrTokConstruct(&commaTokenizer, ",", regParams);
	while ((token = rvStrTokGetToken(&commaTokenizer)) != NULL)
	{
	   RvStrTok equalTokenizer;
	   char* name;
	   char* value;
	   RvUint32  tempVal;
	   rvStrTokConstruct(&equalTokenizer, "=", token);
	   name = rvStrTokGetToken(&equalTokenizer);
	   value = rvStrTokGetToken(&equalTokenizer);
	   if (rvStrIcmp(name, "username") == 0)
	   {
		    rvMdmTermDefaultPropertiesSetUsername(termProperties, value);
	   }
	   else if (rvStrIcmp(name, "password") == 0)
	   {
		   	rvMdmTermDefaultPropertiesSetPassword(termProperties, value);
	   }
	   else if (rvStrIcmp(name, "registrarAddress") == 0)
	   {
		   rvMdmTermDefaultPropertiesSetRegistrarAddress(termProperties, value);
	   }
	   else if (rvStrIcmp(name, "registrarPort") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of registrarPort field = uint16. sscanf'ing right to
		      termProperties->registrarPort will cause memory overrun. */
			sscanf(value,"%d",&tempVal);
		   	rvMdmTermDefaultPropertiesSetRegistrarPort(termProperties, (RvUint16)tempVal);
	   }
	   else if (rvStrIcmp(name, "outBoundProxyAddress") == 0)
	   {
		  rvMdmTermDefaultPropertiesSetOutboundProxyAddress(termProperties, value);
	   }
	   else if (rvStrIcmp(name, "outBoundProxyPort") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of outboundProxyPort field = uint16. sscanf'ing right to
		      termProperties->outboundProxyPort will cause memory overrun. */
		   sscanf(value,"%d",&tempVal);
		   rvMdmTermDefaultPropertiesSetOutboundProxyPort(termProperties, (RvUint16)tempVal);
	   }
	   else if (rvStrIcmp(name, "registerExpires") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of outboundProxyPort field = uint16. sscanf'ing right to
		      termProperties->outboundProxyPort will cause memory overrun. */
		   sscanf(value,"%d",&tempVal);
		   rvMdmTermDefaultPropertiesSetRegisterExpires(termProperties, (RvUint16)tempVal);
	   }
	   else if (rvStrIcmp(name, "TransportTcp") == 0)
	   {
		   sscanf(value,"%d",&tempVal);
		   rvMdmTermDefaultPropertiesSetTransportType(termProperties, (RvUint)tempVal);
		   if (!gw.tcpEnabled && (tempVal != 1))
		   {
			   IppLogMessage(RV_TRUE, "parseRegParams() Terminal transport is TCP while TCP is not enabled", name);
		   }
	   }
	   else
	   {
		   IppLogMessage(RV_TRUE, "parseRegParams: Unknown registration parameter %s", name);
	   }
	   rvStrTokDestruct(&equalTokenizer);
	}

    rvStrTokDestruct(&commaTokenizer);

}

/*--------------------------------------------------------------------------------*/
RvBool rvPhoneMgrOnRegister(RvEppClientEndpoint *ece, void *params)
{
    RvIppSampleGateway*			pgw = &gw;
    RvIppSampleGatewayBase*     gwb = &gw.gatewayBase;
    RvMdmTermDefaultProperties	termProperties;
    RvMdmTerm					*termination = NULL;
//MARKA    RvPhoneLink					*phoneLink = NULL;
    int							profile			= rvEppClientEndpointGetProfile(ece);
    const char*					termId			= rvEppClientEndpointGetName(ece);
    RvBool						rc				= RV_TRUE;

    IppLogMessage(RV_FALSE, "<-- rvPhoneMgrOnRegister(ece:%p, params:%p)", ece, params);

//MARKA    rvMtfAllocatorAlloc(sizeof(RvPhoneLink), (void**)&phoneLink);
//MARKA    rvPhoneLinkConstruct(phoneLink, ece);

    rvMdmTermDefaultPropertiesConstruct(&termProperties);

    rvMdmTermPropertiesSetPresentationInfo(&termProperties, &pgw->gatewayBase.presentationInfo);

    if (profile == EP_PROFILE_IPPHONE)
    {
		/* Register UI termination */
		/* ----------------------- */
        if (!strcmp(termId, "ui"))
        {
			termination = rvMdmTermMgrRegisterPhysicalTerminationAsync(
                            &gwb->termMgr,
							gwb->uiClass,
                            rvStringGetData(&pgw->uiAlias),
                            &termProperties,
//MARKA                             phoneLink);
                            ece);

			if (termination != NULL)
			{
#ifdef SAMPLE_MWI
				rvIppSampleSipMwiRegisterMdmTerm( termination);
#endif
			}
        }
		/* Register Audio termination */
		/* -------------------------- */
        else if ( strstr( termId,"at/"))
        {
			termination = rvMdmTermMgrRegisterPhysicalTerminationAsync(&gwb->termMgr,
//MARKA										gwb->atClass, termId, &termProperties, phoneLink);
										gwb->atClass, termId, &termProperties, ece);
        }
		/* Register Video termination */
		/* -------------------------- */
        else if ( strstr( termId,"vt/"))
        {
			termination = rvMdmTermMgrRegisterPhysicalTerminationAsync(&gwb->termMgr,
//MARKA								gwb->atClass, termId, &termProperties, phoneLink);
								gwb->atClass, termId, &termProperties, ece);
        }
        else
        {
            rc = rvFalse;
        }

    }
	/* Register Analog termination */
	/* --------------------------- */
    else if (profile == EP_PROFILE_ANALOG)
    {
		parseRegParams(params, &termProperties);

		termination = rvMdmTermMgrRegisterPhysicalTerminationAsync(&gwb->termMgr,
//MARKA			gwb->phoneClass, termId, &termProperties, phoneLink);
			gwb->phoneClass, termId, &termProperties, ece);
    }
	/* Illegal profile */
    else
    {
        IppLogMessage(RV_TRUE, "rvPhoneMgrOnRegister: illegal termination profile");
        rc = RV_FALSE;
    }

	/* Registration failed */
	/* ------------------- */
	if (termination == NULL)
	{
		rc = RV_FALSE;
		IppLogMessage(RV_TRUE, "rvPhoneMgrOnRegister::Register Termination Failed (termId=%s)", termId);
	}
	/* Registration succeeded */
	/* ---------------------- */
    else
    {
        IppLogMessage(RV_FALSE, "rvPhoneMgrOnRegister::termination=%p)", termination);
    }

	rvMdmTermDefaultPropertiesDestruct(&termProperties);

    return rc;
}

