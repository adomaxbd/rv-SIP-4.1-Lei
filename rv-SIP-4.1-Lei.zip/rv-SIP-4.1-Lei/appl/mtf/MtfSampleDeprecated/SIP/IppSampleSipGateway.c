/******************************************************************************
Filename:    IppSampleSipGateway.c
Description: Sample gateway for SIP Phone
*******************************************************************************
                Copyright (c) 2001 RADVision Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD.

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include "ippthread.h"
#include "IppSamplePhoneLink.h"
#include "IppSampleSipGateway.h"
#include "IppSampleSipUserClbks.h"
#ifdef RV_CFLAG_TLS
#include "IppSampleSipTlsClbks.h"
#endif
#include "IppSampleSipUtils.h"
#include "IppSampleRtpLink.h"
#include "rvhost.h"
#include "rvstr.h"
#include "rvmtfalloc.h"

#ifdef SAMPLE_MWI
#include "IppSampleSipMWI.h"
#endif

#ifdef RV_MTF_STUN
#include "rvSipStunApi.h"
#include "IppStunClient.h"
#endif

#include "IppSampleMediaNegotiate.h"
#include "MtfMediaCallbacks.h"

#include "MfControl.h"
#ifndef RV_MTF_MEDIA
#include "mediaControl.h"
#endif

/*Globals*/

RvIppSampleGateway g_gw;/*used by STUN*/

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/
/************************************************************************************
 * IppUtilGetDefaultHost
 * ----------------------------------------------------------------------------------
 * General: Get ip address of the default local host as received from the operating
 *          system. The default host will be chosen from the list of local hosts
 *          according to parameters localIpPrefix & localIpMask.
 *          If no address that matches localIpPrefix & localIpMask was found, the
 *          chosen address will be the first one on the list.
 *          Opening a socket with ip 0 will cause listening to all local IP addresses,
 *          including the one returned here.
 * Return Value: RvStatus - RvStatus
 *                           RV_ERROR_UNKNOWN
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   pTransportMgr - pointer to transport instance
 *          eAddressType - indicates the class of address we want to get ipv4/ipv6
 *          localIpPrefix - prefix of the desired local ip address to be chosen
 *                          from the list of local addresses
 *          localIpMask - mask of the desired local ip address
 *
 * Output:  pAddr - The default local address
 ***********************************************************************************/
static RvStatus IppUtilGetDefaultHost(
                                        IN    RvLogMgr*     pLogMgr,
                                        IN    RvInt         eAddressType,
                                        IN    char*         localIpPrefix,
                                        IN    char*         localIpMask,
                                        INOUT RvAddress*    pAddr)
{

    RvStatus      crv         = RV_OK;
    RvUint32      numofAddresses = 10;
    RvUint        i              = 0;
    RvAddress     addresses[RV_HOST_MAX_ADDRS];
    RvAddress     maskAddr, netAddr;
    RV_BOOL       localIpPrefixFound = RV_FALSE;

#if(RV_NET_TYPE & RV_NET_IPV6)
    if (RV_ADDRESS_TYPE_IPV6 == eAddressType)
        numofAddresses = RV_HOST_MAX_ADDRS;
#endif /*(RV_NET_TYPE & RV_NET_IPV6)*/

    crv = RvHostLocalGetAddress(pLogMgr,&numofAddresses,addresses);
    if (RV_OK != crv)
    {
        IppLogMessage(RV_TRUE, "TransportMgrGetDefaultHost - Failed to get default address");
        return crv;
    }

    RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &maskAddr);
    RvAddressSetString(localIpMask, &maskAddr);

    RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &netAddr);
    RvAddressSetString(localIpPrefix, &netAddr);

    /* Go through list of local ip addresses and choose the one that matches
       localIpPrefix & localIpMask */
    for (i=0 ; i<numofAddresses ; i++)
    {
        RvAddress* addr = &addresses[i];
        if ( (RvAddressIpv4GetIp(&addr->data.ipv4) &
              RvAddressIpv4GetIp(&maskAddr.data.ipv4)) == RvAddressIpv4GetIp(&netAddr.data.ipv4))
        {
            localIpPrefixFound = RV_TRUE;
            break;
        }
    }

    /* If the desired prefix was not found, take the first address on the list
       (it's as good as the others */
    if (localIpPrefixFound == RV_FALSE)
        i=0;

    /* Get the local hosts array from the core layer*/
    if (RV_ADDRESS_TYPE_IPV4 == eAddressType)
    {
        if (RV_ADDRESS_TYPE_IPV6 == RvAddressGetType(&addresses[0]))
        {
            IppLogMessage(RV_TRUE,
                      "TransportMgrGetDefaultHost - Failed to get default IPv4 address, computer supports only ipv6 addresses");
            return RV_ERROR_BADPARAM;
        }
    }
#if(RV_NET_TYPE & RV_NET_IPV6)
    if (RV_ADDRESS_TYPE_IPV6 == eAddressType)
    {
        static RvUint8 localLinkAddr[16] = {0xfe,0x80,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x01};

        while (RV_ADDRESS_TYPE_IPV4 == RvAddressGetType(&addresses[i]))
            i++;
        if (RV_ADDRESS_TYPE_IPV6 != RvAddressGetType(&addresses[i]))
        {
            return RV_ERROR_BADPARAM;
        }
        while (0 != memcmp(addresses[i].data.ipv6.ip,localLinkAddr,2) ||
               0 == memcmp(addresses[i].data.ipv6.ip,localLinkAddr,16))
        {
            i++;
            if (i > numofAddresses)
            {
                return RV_ERROR_NOT_FOUND;
            }
        }

    }
#endif /* (RV_NET_TYPE & RV_NET_IPV6) */
    RvAddressCopy(&addresses[i],pAddr);
    return RV_OK;
}


static void replaceZeroWithLocal(IN RvIppSampleGateway* gw,
                                 INOUT RvChar*          addressString,
                                 IN RvSize_t            len)
{
    RvAddress localAdd;

    if (!strcmp(addressString,"0.0.0.0"))
    {
        if (RV_OK !=IppUtilGetDefaultHost(NULL, RV_ADDRESS_TYPE_IPV4,
                            gw->gatewayBase.localIpPrefix,
                            gw->gatewayBase.localIpMask, &localAdd))
        {
            printf("error in calling IppUtilGetDefaultHost(RV_ADDRESS_TYPE_IPV4)");
            return;
        }
        RvAddressGetString(&localAdd, len, addressString);
    }
    else if (!strcmp(addressString,"0:0:0:0:0:0:0:0"))
    {
        if (RV_OK !=IppUtilGetDefaultHost(NULL, RV_ADDRESS_TYPE_IPV6,
                        gw->gatewayBase.localIpPrefix,
                        gw->gatewayBase.localIpMask, &localAdd))
        {
            printf("error in calling IppUtilGetDefaultHost(RV_ADDRESS_TYPE_IPV6)");
            return;
        }
        RvAddressGetString(&localAdd, len, addressString);
    }
}

/***************************************************************************
 * rvIppMediaParamLoad
 * ------------------------------------------------------------------------
 * General: Loads default audio IO device
 *
 ***************************************************************************/
static char* rvIppMediaParamLoad( RvIppSampleGatewayBase* gw, char* configBuf)
{
    char line[160]="";
    char params[80]="",val[80]="" ;
    char * ptr = configBuf;
    char * last = NULL;
    char* token;
    RvStrTok t;


    while(rvIppSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {
        /* new section */
        if(ptr[0]=='[')
            return last;
        last = ptr;

        /* read name and value */
        sscanf(ptr,"%s",line);
        rvStrTokConstruct(&t,"= ",line);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(params, token);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(val, token);

        if(!strcmp(params,"DefaultDevice") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.defDevice = tmp;
        }
        else if(!strcmp(params,"RTPAddress") )
        {
            strncpy(gw->mediaParam.mfControlParams.RTPAddress, val, sizeof(gw->mediaParam.mfControlParams.RTPAddress)-1);
            gw->mediaParam.mfControlParams.RTPAddress[sizeof(gw->mediaParam.mfControlParams.RTPAddress)-1] = '\0';
        }
        else if(!strcmp(params,"RTPPortBase") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.portLocalBase = (RvUint16)tmp;
        }
        else if(!strcmp(params,"RTPPortRange") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.max_num_portLocal = (RvUint16)tmp;
        }
        else if(!strcmp(params,"VideoFrameSize") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.nFrameSize = tmp;
        }
        else if(!strcmp(params,"VideoFrameRate") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.nFrameRatePerSecVideo = tmp;
        }
        else if(!strcmp(params,"RecvAudioPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.recv_aud_cntx_poll_interval_msec = tmp;
        }
        else if(!strcmp(params,"RecvVideoPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.recv_vid_cntx_poll_interval_msec = tmp;
        }

        else if(!strcmp(params,"PlayAudioPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.play_aud_cntx_poll_interval_msec = tmp;
        }
        else if(!strcmp(params,"PlayVideoPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->mediaParam.mfControlParams.play_vid_cntx_poll_interval_msec = tmp;
        }
        else if(!strcmp(params,"MfLogFilters") )
        {
            /* get the log filters for the MF logs */
            RvInt8      tmp;
            strcpy(val, token);

            if (!IppSipUtilFilterToInt(IPP_API_TYPE, val, &tmp))
            {
                printf("failed to determine Filter for the following line\n%s", line);
                break;
            }
            gw->mediaParam.mfControlParams.mfcLogMask = (RvLogMessageType)tmp;
        }
    }
    return NULL;
}
#ifdef RV_SIP_IMS_ON
/***************************************************************************
 * convertAkaAuthOpStrToArray
 * ------------------------------------------------------------------------
 * General: Convert a string with 16 hex values seperated by ',' to an array of
 *          uint8 values.
 *          The string contains values that are used when calculating AKA
 *          RES shared secret parameter.
 *          Example for this string in the config file:
 *          AkaAuth_op=0x63,0xbf,0xa5,0x0e,0xe6,0x52,0x33,x65,0xff,0x14,0xc1,0xf4,0x5f,0x88,0x73,0x7d
 *
 ***************************************************************************/
static void convertAkaAuthOpStrToArray(IN RvUint8* akaAuthOpArray, IN RvChar* akaAuthOpStr)
{
	char* token;
    RvStrTok commaTokenizer;
	RvInt8   i = 0;

    rvStrTokConstruct(&commaTokenizer, ",", akaAuthOpStr);
    while ((token = rvStrTokGetToken(&commaTokenizer)) != NULL)
	{
		if (i == AKA_OP_ARRAY_SIZE)
		{
			printf("\nToo many elements (> %d) in configuration parameter akaAuth_op \n", AKA_OP_ARRAY_SIZE);
			IppLogMessage(RV_FALSE,"convertAkaAuthOpStrToArray:: More than %d elements in configuration parameter akaAuth_op", AKA_OP_ARRAY_SIZE);
			break;
		}

        akaAuthOpArray[i] = (RvUint8)strtol(token, NULL, 0);
		i++;
	}

	if (i < AKA_OP_ARRAY_SIZE)
	{
		printf("\nOnly %d elements out of %d were configured in akaAuth_op array.\n", i, AKA_OP_ARRAY_SIZE);
		IppLogMessage(RV_FALSE,"convertAkaAuthOpStrToArray:: Only %d elements out of %d were configured in akaAuth_op array.", i, AKA_OP_ARRAY_SIZE);
		for (; i < AKA_OP_ARRAY_SIZE; i++ )
			akaAuthOpArray[i] = 0x00;

	}

	rvStrTokDestruct(&commaTokenizer);
}
#endif

/***************************************************************************
 * printConfigParams
 * ------------------------------------------------------------------------
 * General: Prints Ipp Sip Sample gateway parameters.
 * Note: The parameters that are printed here are relevant for sample only.
 * Other parameters of the config file are printed in printConfigution function
 *
 ***************************************************************************/
static void printConfigParams(RvIppSampleGateway *gw)
{
    IppLogMessage(RV_FALSE,"************************************************************");
    IppLogMessage(RV_FALSE,"**********Ipp Sip Sample Configuration Parameters:**********");
    IppLogMessage(RV_FALSE,"**********UiAlias            : %s", gw->uiAlias);
    IppLogMessage(RV_FALSE,"**********Dtmf Relay         : %d", gw->gatewayBase.dtmfRelay);
    IppLogMessage(RV_FALSE,"**********Auto Answer        : %d", gw->gatewayBase.autoAnswer);
    IppLogMessage(RV_FALSE,"**********EppIp              : %s", gw->gatewayBase.eppIp);
    IppLogMessage(RV_FALSE,"**********EppPort            : %d", gw->gatewayBase.eppPort);
    IppLogMessage(RV_FALSE,"**********localIpPrefix      : %s", gw->gatewayBase.localIpPrefix);
    IppLogMessage(RV_FALSE,"**********localIpMask        : %s", gw->gatewayBase.localIpMask);
    IppLogMessage(RV_FALSE,"**********callerIdPermission : %d", gw->gatewayBase.presentationInfo.callerIdPermission);
    IppLogMessage(RV_FALSE,"**********calleeIdPermission : %d", gw->gatewayBase.presentationInfo.calleeIdPermission);
    IppLogMessage(RV_FALSE,"**********presentationName   : %s", gw->gatewayBase.presentationInfo.presentationName);
#ifdef SAMPLE_MWI
    IppLogMessage(RV_FALSE,"**********SubsServerName     : %s", gw->subsServerName);
#endif
    IppLogMessage(RV_FALSE,"**********callForwardNoReplyTimeout: %s", gw->gatewayBase.callForwardNoReplyTimeout);

#ifdef RV_MTF_STUN
    IppLogMessage(RV_FALSE,"**********StunServerAddress   : %s", gw->stunServerAddress);
    IppLogMessage(RV_FALSE,"**********StunServerPort      : %d", gw->stunServerPort);
    IppLogMessage(RV_FALSE,"**********StunNeedMask        : %s", gw->stunNeedMask);
    IppLogMessage(RV_FALSE,"**********StunClientResponsePort: %d", gw->stunClientResponsePort);
#endif
    IppLogMessage(RV_FALSE,"************************************************************");
}





/***************************************************************************
 * loadIppSipGatewayParams
 * ------------------------------------------------------------------------
 * General: Loads gateway parameters from configuration buffer
 *
 ***************************************************************************/
static char* loadIppSipGatewayParams(RvIppSampleGateway* gw, char* configBuf)
{
    char line[160]="";
    char params[80]="",val[120]="" ;
    char* token;
    char * ptr = configBuf;
    char * last = NULL;
    RvStrTok t;

    gw->gatewayBase.cfwCallCfg.cfwCallBacks.activateCompleted = rvIppSampleCfwActivateCompletedCB;
    gw->gatewayBase.cfwCallCfg.cfwCallBacks.deactivateCompleted = rvIppSampleCfwDeactivateCompletedCB;

    while (rvIppSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {
        /* new section */
        if(ptr[0]=='[')
            return last;
        last = ptr;

        /* read name and value */
        sscanf(ptr,"%159s",line);
        rvStrTokConstruct(&t,"= ",line);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(params, token);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(val, token);

        if(!strcmp(params,"UserDomain"))
        {
            rvStringAssign(&gw->userDomain, val);
        }
        else if(!strcmp(params,"LocalAddress") )
        {
            replaceZeroWithLocal(gw, val, sizeof(val));

            strncpy(gw->gatewayBase.localAddress, val, sizeof(gw->gatewayBase.localAddress)-1);
            gw->gatewayBase.localAddress[sizeof(gw->gatewayBase.localAddress)-1] = '\0';

            /* Place the IP address as the endpoint ID unless we got one already */
            if (gw->gatewayBase.eppIp[0] == '\0')
            {
                strncpy(gw->gatewayBase.eppIp, val, sizeof(gw->gatewayBase.eppIp)-1);
                gw->gatewayBase.eppIp[sizeof(gw->gatewayBase.eppIp)-1] = '\0';
            }
        }
        else if(!strcmp(params,"EppIp") )
        {
            strncpy(gw->gatewayBase.eppIp, val, sizeof(gw->gatewayBase.eppIp)-1);
            gw->gatewayBase.eppIp[sizeof(gw->gatewayBase.eppIp)-1] = '\0';
        }
        else if(!strcmp(params,"localIpPrefix") )
        {
            strncpy(gw->gatewayBase.localIpPrefix, val, sizeof(gw->gatewayBase.localIpPrefix)-1);
            gw->gatewayBase.localIpPrefix[sizeof(gw->gatewayBase.localIpPrefix)-1] = '\0';
        }
        else if(!strcmp(params,"localIpMask") )
        {
            strncpy(gw->gatewayBase.localIpMask, val, sizeof(gw->gatewayBase.localIpMask)-1);
            gw->gatewayBase.localIpMask[sizeof(gw->gatewayBase.localIpMask)-1] = '\0';
        }
        else if(!strcmp(params,"RegistrarAddress"))
        {
            replaceZeroWithLocal(gw, val,sizeof(val));
            rvStringAssign(&gw->registrarAddress, val);
        }
        else if(!strcmp(params,"RegistrarPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->registrarPort = (RvUint16)tmp;
        }
        else if(!strcmp(params,"OutboundProxyAddress"))
        {
            rvStringAssign(&gw->outboundProxyAddress,val);
        }
        else if(!strcmp(params,"OutboundProxyPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->outboundProxyPort = (RvUint16)tmp;
        }
        else if(!strcmp(params,"EppPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->gatewayBase.eppPort = (RvUint16)tmp;
        }
        else if(!strcmp(params,"disableGuiMedia"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->gatewayBase.mediaParam.bDisableMedia = (RvBool)tmp;
        }


#ifdef RV_MTF_STUN
        else if(!strcmp(params,"StunServerAddress"))
        {
            strncpy(gw->stunServerAddress, val, sizeof(gw->stunServerAddress)-1);
            gw->stunServerAddress[sizeof(gw->stunServerAddress)-1] = '\0';
        }
        else if(!strcmp(params,"StunServerPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->stunServerPort =(RvUint16)tmp;
        }
        else if(!strcmp(params,"StunClientResponsePort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->stunClientResponsePort =(RvUint16)tmp;
        }
        else if(!strcmp(params,"StunNeedMask"))
        {
            rvStringAssign(&gw->stunNeedMask,val);
        }
#endif
        else if(!strcmp(params,"UiAlias"))
        {
            rvStringAssign(&gw->uiAlias, val);
        }
        else if(!strcmp(params,"username"))
        {
            rvStringAssign(&gw->username, val);
        }
        else if(!strcmp(params,"password"))
        {
            rvStringAssign(&gw->password, val);
        }
        else if(!strcmp(params,"TransportType"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->transportType = (RvSipTransport)tmp;
        }
        else if(!strcmp(params,"TcpPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->stackTcpPort =(RvUint16)tmp;
        }
        else if(!strcmp(params,"UdpPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->stackUdpPort =(RvUint16)tmp;
        }
        else if (!strcmp(params, "MaxCallLegs"))
        {
            sscanf(val,"%d",&gw->gatewayBase.maxCallLegs);
        }
        else if (!strcmp(params, "AutoRegistration"))
        {
            sscanf(val,"%d",&gw->autoRegister);
        }
        else if (!strcmp(params, "RegistrationExpire"))
        {
            sscanf(val,"%d",&gw->registrationExpire);
        }
		else if (!strcmp(params, "MaxAuthenticateRetries"))
        {
            sscanf(val,"%d",&gw->maxAuthenticateRetries);
        }
#ifdef RV_SIP_IMS_ON
		else if (!strcmp(params, "DisableAkaAuthentication"))
        {
            sscanf(val,"%d",&gw->disableAkaAuthentication);
        }
		else if(!strcmp(params,"AkaAuth_op"))
        {
			convertAkaAuthOpStrToArray(&gw->akaAuth_op[0], val);
			gw->isAkaAuthOpConfigured = RV_TRUE;
        }
#endif
        else if (!strcmp(params, "ReferTimeout"))
        {
            sscanf(val,"%d",&gw->referTimeout);
        }
        else if (!strcmp(params, "CallWaitingReply"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->callWaitingReply =(RvCallWaitingReply)tmp;
        }
        else if (!strcmp(params, "MaxRegisterClients"))
        {
            sscanf(val,"%d",&gw->maxRegClients);
        }
        else if (!strcmp(params, "TcpEnabled"))
        {
            sscanf(val,"%d",&gw->tcpEnabled);
        }
        else if(!strcmp(params,"DialToneDuration"))
        {
            sscanf(val,"%d",&gw->gatewayBase.dialToneDuration);
        }
        else if(!strcmp(params,"DtmfRelay"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->gatewayBase.dtmfRelay = (RvRtpDtmfRelay)tmp;
        }
        else if(!strcmp(params,"WatchdogInterval"))
        {
            sscanf(val,"%d",&gw->watchdogTimeout);
        }
        else if(!strcmp(params,"presentationName"))
        {
            rvMdmTermPresentationInfoSetName(&gw->gatewayBase.presentationInfo, val);
        }
        else if(!strcmp(params,"autoAnswer"))
        {
            sscanf(val,"%d",&gw->gatewayBase.autoAnswer);
        }
        else if (!strcmp(params, "CallForwardNoReplyTimeout"))
        {
            strncpy(gw->gatewayBase.callForwardNoReplyTimeout, val, sizeof(gw->gatewayBase.callForwardNoReplyTimeout)-1);
            gw->gatewayBase.callForwardNoReplyTimeout[sizeof(gw->gatewayBase.callForwardNoReplyTimeout)-1] = '\0';
        }
        else if(!strcmp(params,"EppUseTCP"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->gatewayBase.bConfigTCP = (tmp != 0);
        }
        else if(!strcmp(params,"EnableSdpLogs"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->gatewayBase.enableSdpLogs = (tmp != 0);
        }
        else if (!strcmp(params,"connectMediaOn180"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            gw->connectMediaOn180 = (tmp != 0);
        }

		/* params for UPDATE method support */
		else if (!strcmp(params,"AddUpdateSupport"))
        {
             sscanf(val,"%d",&gw->addUpdateSupport);
        }
		else if (!strcmp(params,"UpdateRetryAfterTimeout"))
        {
			sscanf(val,"%d",&gw->updateRetryAfterTimeout);
        }
		else if (!strcmp(params,"CallerUpdateResendTimeout"))
        {
			sscanf(val,"%d",&gw->callerUpdateResendTimeout);
        }
		else if (!strcmp(params,"CalleeUpdateResendTimeout"))
        {
			sscanf(val,"%d",&gw->calleeUpdateResendTimeout);
        }

        /* params for analog lines simulation */
        else if(!strcmp(params,"numOfAnalogLines"))
        {
            sscanf(val,"%d",&gw->gatewayBase.numOfAnalogLines);
        }
        else if(!strcmp(params,"numOfSimulationCalls"))
        {
            sscanf(val,"%d",&gw->gatewayBase.numOfSimulationCalls);
        }
        else if(!strcmp(params,"firstTermNum"))
        {
            sscanf(val,"%d",&gw->gatewayBase.firstTermNum);
        }
        else if(!strcmp(params,"firstDestDigit"))
        {
            sscanf(val,"%d",&gw->gatewayBase.firstDestDigit);
        }
        else if(!strcmp(params,"analogDestAddress"))
        {
            rvStringAssign(&gw->gatewayBase.analogDestAddress, val);
        }
        else if (!strcmp(params, "outgoingCallsEnabled"))
        {
            sscanf(val,"%d",&gw->gatewayBase.outgoingCallsEnabled);
        }


#ifdef SAMPLE_MWI
        else if(!strcmp(params,"SubsServerName"))
        {
            rvStringAssign(&gw->subsServerName, val);
        }
#endif
#ifdef RV_CFLAG_TLS
        else
        {
            loadIppSipGatewayTransportTlsParams(&gw->transportTlsCfg, params, val);
            loadIppSipGatewayKeyTlsParams(&gw->keyTlsCfg, params, val);
        }
#endif
    }
    return NULL;
}

/***************************************************************************
 * loadSIPLogOptions
 * ------------------------------------------------------------------------
 * General: Get names of LOG options to print in output device.
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Params:  IN  configBuf  - buffer containing options, specified by user
 *          OUT logOptions  - log options structure
 ***************************************************************************/
static void loadSIPLogOptions(RvIppSipLogOptions* logOptions, char* configBuf)
{
    char   * ptr = NULL;
    char   line[512];
    char module[80]="",filterString[80]="";
    RvStrTok t;
    RvSipStackModule moduleId;
    RvInt8  filter;
    char* token;

    while (rvIppSampleUtilGetNextLine(configBuf,&ptr) != NULL)
    {
        static RvBool inLogOptionSection=rvFalse;

        sscanf(ptr, "%511s", line);

        if (!inLogOptionSection)
        {
            /* detect [LogOptions] section */
            if(!strcmp(line,"[SipLogOptions]"))
            {
               inLogOptionSection = rvTrue;
               logOptions->num =0;
            }
        }
        else
        {
            if(ptr[0]=='[')
                return;

            /* read module name and filter string */
            sscanf(ptr,"%511s",line);
            rvStrTokConstruct(&t,"= ",line);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;
            strcpy(module, token);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;
            strcpy(filterString, token);

            if (IppSipUtilStringToStackModule(module,&moduleId) != rvTrue)
            {
                printf("failed to determine Module for the following line\n%s", line);
                break;
            }

            if (IppSipUtilFilterToInt(SIP_API_TYPE, filterString, &filter) != rvTrue)
            {
                printf("failed to determine Filter for the following line\n%s", line);
                break;
            }

            logOptions->filters[logOptions->num].moduleId = moduleId;
            logOptions->filters[logOptions->num].filter = (RvUint8)filter;
            logOptions->num++;
        }
    }
}


/***************************************************************************
 * loadIPPLogOptions
 * ------------------------------------------------------------------------
 * General: Get names of LOG options to print in output device.
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Params:  IN  configBuf  - buffer containing options, specified by user
 *          IN  numLogOptions - Number of options in the logOptions array
 *          OUT logOptions  - log options structure
 ***************************************************************************/
static void loadIPPLogOptions(
    OUT IppLogSourceFilterElm*  logOptions,
    IN  RvSize_t                numLogOptions,
    IN  RvChar*                 configBuf)
{
    RvChar*     ptr = NULL;
    RvChar      line[512];
    RvChar      module[80]="";
    RvChar      filterString[80]="";
    RvStrTok    t;
    RvInt8      filter;
    RvSize_t    index = 0;
    RvChar*     token;
    RvBool      inLogOptionSection = RV_FALSE;

    while (rvIppSampleUtilGetNextLine(configBuf, &ptr) != NULL)
    {
        sscanf(ptr, "%511s", line);

        if (!inLogOptionSection)
        {
            /* detect [LogOptions] section */
            if(!strcmp(line, "[IppLogOptions]"))
               inLogOptionSection = RV_TRUE;
        }
        else
        {
            if (ptr[0] == '[')
                break; /* We're done */

            /* read module name and filter string */
            sscanf(ptr, "%511s", line);
            rvStrTokConstruct(&t, "= ", line);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;

            strcpy(module, token);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;

            strcpy(filterString, token);

            if (!IppSipUtilFilterToInt(IPP_API_TYPE, filterString, &filter))
            {
                printf("failed to determine Filter for the following line\n%s", line);
                break;
            }

            if (index == numLogOptions)
            {
                printf("Too many filters...\n");
                break;
            }

            strncpy(logOptions[index].logSrcName, module, sizeof(logOptions[index].logSrcName)-1);
            logOptions[index].logSrcName[sizeof(logOptions[index].logSrcName)-1] = '\0';
            logOptions[index].messageMask = (RvLogMessageType)filter;
            index++;
        }
    }
}


static void loadSipGatewayParamsFromBuffer(
    IN RvIppSampleGateway*  gw,
    IN RvChar*              configBuf)
{
    RvChar *ptr = NULL;
    RvChar line[512];

    while (rvIppSampleUtilGetNextLine(configBuf, &ptr) != NULL)
    {
        /* Get a single line */
        sscanf(ptr, "%511s", line);

        /* Map to a given group of parameters */
        if(!strcmp(line,"[SIPParameters]"))
            ptr = loadIppSipGatewayParams(gw, ptr);
        else if(!strcmp(line,"[PhoneNumbers]"))
            ptr = rvIppSampleGatewayBaseLoadAddressList(&gw->gatewayBase, ptr);
        else if(!strcmp(line, "[MediaParam]"))
            ptr = rvIppMediaParamLoad( &gw->gatewayBase, ptr);
    }

    loadSIPLogOptions(&(gw->logOptions), configBuf);
}



static void constructGatewayParams(RvIppSampleGateway *gw)
{
    rvStringConstruct(&gw->userDomain, "sip", userDefaultAlloc);
    rvStringConstruct(&gw->registrarAddress, "", userDefaultAlloc);
    rvStringConstruct(&gw->outboundProxyAddress, "", userDefaultAlloc);
    rvStringConstruct(&gw->uiAlias, "", userDefaultAlloc);
    rvStringConstruct(&gw->username, "", userDefaultAlloc);
    rvStringConstruct(&gw->password, "", userDefaultAlloc);

#ifdef RV_MTF_STUN
    rvStringConstruct(&gw->stunNeedMask, "", userDefaultAlloc);
#endif

#ifdef SAMPLE_MWI
    rvStringConstruct(&gw->subsServerName, "", userDefaultAlloc);
#endif
}

static void destructGatewayParams(RvIppSampleGateway *gw)
{
    rvIppSampleGatewayBaseDestruct(&gw->gatewayBase);

    rvStringDestruct(&gw->userDomain);
    rvStringDestruct(&gw->registrarAddress);
    rvStringDestruct(&gw->outboundProxyAddress);

    rvStringDestruct(&gw->uiAlias);
    rvStringDestruct(&gw->username);
    rvStringDestruct(&gw->password);

#ifdef RV_MTF_STUN
    rvStringDestruct(&gw->stunNeedMask);
#endif

#ifdef SAMPLE_MWI
    rvStringDestruct(&gw->subsServerName);
#endif
}

static void loadSipConfigParams(RvIppSampleGateway *gw, RvIppSipPhoneCfg* cfg)
{
    /* Override any configuration parameters that were already set to the struct */
    cfg->userDomain             = (char *)rvStringGetData(&gw->userDomain);
    cfg->localAddress           = gw->gatewayBase.localAddress;
    cfg->stackTcpPort           = gw->stackTcpPort;
    cfg->stackUdpPort           = gw->stackUdpPort;
    cfg->registrarAddress       = (char *)rvStringGetData(&gw->registrarAddress);
    cfg->registrarPort          = gw->registrarPort;
    cfg->outboundProxyAddress   = (char *)rvStringGetData(&gw->outboundProxyAddress);
    cfg->outboundProxyPort      = gw->outboundProxyPort;
    cfg->username               = (char *)rvStringGetData(&gw->username);
    cfg->password               = (char *)rvStringGetData(&gw->password);
    cfg->priority               = RV_THREAD_PRIORITY_DEFAULT;
    cfg->transportType          = gw->transportType;
    cfg->autoRegister           = gw->autoRegister;
    if (gw->registrationExpire)
        cfg->registrationExpire     = gw->registrationExpire;
    if (gw->unregistrationExpire)
        cfg->unregistrationExpire   = gw->unregistrationExpire;
	cfg->maxAuthenticateRetries = gw->maxAuthenticateRetries;
#ifdef RV_SIP_IMS_ON
	if (gw->disableAkaAuthentication)
        cfg->disableAkaAuthentication   = gw->disableAkaAuthentication;
	if (gw->isAkaAuthOpConfigured)
		cfg->akaAuth_op             = &gw->akaAuth_op[0];
#endif
    cfg->referTimeout           = gw->referTimeout;
    cfg->dialToneDuration       = gw->gatewayBase.dialToneDuration;
    cfg->logOptions             = &(gw->logOptions);
    cfg->maxCallLegs            = gw->gatewayBase.maxCallLegs;
    cfg->maxRegClients          = gw->maxRegClients;
    cfg->tcpEnabled             = gw->tcpEnabled;
    cfg->callWaitingReply       = gw->callWaitingReply;
    cfg->watchdogTimeout        = gw->watchdogTimeout;
    cfg->outOfBandDtmf          = (gw->gatewayBase.dtmfRelay == RV_IPP_DTMF_RELAY_OOB);
    cfg->connectMediaOn180      = gw->connectMediaOn180;
	cfg->addUpdateSupport           = gw->addUpdateSupport;
	cfg->updateRetryAfterTimeout    = gw->updateRetryAfterTimeout;
	cfg->callerUpdateResendTimeout  = gw->callerUpdateResendTimeout;
	cfg->calleeUpdateResendTimeout  = gw->calleeUpdateResendTimeout;
    cfg->cfwCallCfg.cfwCallBacks.activateCompleted = gw->gatewayBase.cfwCallCfg.cfwCallBacks.activateCompleted;
    cfg->cfwCallCfg.cfwCallBacks.deactivateCompleted = gw->gatewayBase.cfwCallCfg.cfwCallBacks.deactivateCompleted;
    /* Disable SDP logging */
    if (gw->gatewayBase.enableSdpLogs == RV_FALSE)
    {
        cfg->sdpStackCfg.disableSdpLogs = RV_TRUE;
        cfg->sdpStackCfg.logManagerPtr = NULL;
    }
    /* Enable SDP logging (this is actually not mandatory since this is also the default setting) */
    else
    {
        cfg->sdpStackCfg.disableSdpLogs = RV_FALSE;
        cfg->sdpStackCfg.logManagerPtr = IppLogMgr();
    }

}

/*===============================================================================*/
/*===================    G A T E W A Y    F U N C T I O N S    ==================*/
/*===============================================================================*/

RvIppSampleGateway *rvIppSipSampleGatewayConstruct(RvIppSampleGateway *gw, char* configBuf)
{
    RvIppSampleGatewayBase* gwb = &gw->gatewayBase;
    RvIppSipPhoneCfg        cfg;
    IppLogSourceFilterElm   ippLogOptions[30];

#ifdef SAMPLE_MWI
    RvIppSampleSipMwiCfg    subsCfg;
#endif

    /* ------------------ */
    /* Initialize Logger  */
    /* ------------------ */

    memset(ippLogOptions, 0, sizeof(ippLogOptions));

    /* Load logging configuration from buffer */
    loadIPPLogOptions(ippLogOptions, 30, configBuf);

    /* Initialize log before we do anything else*/
    if (IppLogInit(ippLogOptions, MTF_LOG_PATH) != RV_OK)
        return NULL;

    /* ------------------------------ */
    /* Initialize MTF Sample objects  */
    /* ------------------------------ */

    /* Construct GW Base parameters with empty values*/
    rvIppSampleGatewayBaseConstruct(gwb);

    /* Construct GW SIP parameters with empty values*/
    constructGatewayParams(gw);

    /* --------------------------------- */
    /* Load MF configuration parameters */
    /* --------------------------------- */
    /* Initialize Media configuration structure with default values*/
    rvMtfMediaInitConfig( &gwb->mediaParam);

    /* --------------------------------- */
    /* Load MTF configuration parameters */
    /* --------------------------------- */

    /* Initialize MTF configuration structure with default values*/
    rvIppSipInitConfig(&cfg);

    /* Load parameters from configuration buffer to GW*/
    loadSipGatewayParamsFromBuffer(gw, configBuf);

    /* Load configuration parameters from GW to IPP configuration structure*/
    loadSipConfigParams(gw, &cfg);

    /* -------------- */
    /* Initialize TLS */
    /* -------------- */

#ifdef RV_CFLAG_TLS
    userRegisterIppSipTlsExt();

    /* Initialize TLS part of IPP configuration structure with default values*/
    rvIppSipTlsInitConfig(&cfg);

    /* Load TLS configuration parameters from GW to IPP configuration structure*/
    loadSipTlsConfigParams(&gw->transportTlsCfg, &cfg);
#endif

    /* --------------------------------- */
    /* Register Extensibility callbacks  */
    /* --------------------------------- */

    userRegisterIppSipExt();

    /* -------------------- */
    /* Initialize SIP stack */
    /* -------------------- */

    if (rvIppSipStackInitialize(&gw->stackHandle, &cfg) != RV_TRUE)
    {
        printf("Error initializing SIP stack\n");
        return NULL;
    }

    printConfigParams(gw);

    /* --------------- */
    /* Initialize MWI  */
    /* --------------- */

#ifdef SAMPLE_MWI
    /* After stack was initialized, we can use stack handle in order to construct SipSubsMgr object - responsible for
    * SUBSCRIBE/NOTIFY maintenance */

    subsCfg.stackHandle             = gw->stackHandle;
    subsCfg.localAddress            = gw->gatewayBase.localAddress;
    subsCfg.registrarAddress        = gw->registrarAddress;
    subsCfg.registrarPort           = gw->registrarPort;
    subsCfg.stackUdpPort            = gw->stackUdpPort;
    subsCfg.uiAlias                 = gw->uiAlias;
    subsCfg.subsServerName          = gw->subsServerName;

    rvIppSampleSipMwiInit(&subsCfg);
#endif

    /* --------------- */
    /* Initialize MTF  */
    /* --------------- */

    rvIppSipPhoneConstruct(&gwb->termMgr, &cfg, gw->stackHandle);

    /* ------------------ */
    /* For ENUM/Tel-Uri   */
    /* ------------------ */
    if (RegExpMgrConstruct((RV_LOG_Handle)IppLogMgr(), &gw->regExpMgr) != RV_OK)
    {
        printf("Error initializing Regular Expression Manager (ENUM/Tel-URI)\n");
        return NULL;
    }

    /* ---------------------- */
    /* Register MTF callbacks */
    /* ---------------------- */

    rvIppSampleGatewayBaseRegisterIppCallbacks(gwb);

    /* ---------------------- */
    /* Initialize MTF classes */
    /* ---------------------- */

    rvPhoneMgrInitPhoneClass(&gwb->termMgr, &gwb->phoneClass);
    rvPhoneMgrInitAtClass(&gwb->termMgr, &gwb->atClass);
    rvPhoneMgrInitUIClass(&gwb->termMgr, &gwb->uiClass);
    rvRtpLinkInitClass(&gwb->termMgr, &gwb->rtpClass);

    /* ---------------------- */
    /* Initialize EPP client  */
    /* ---------------------- */

    /* Make sure we have our socket connection to the GUI application */
    if ((rvPhoneMgrConstruct(&gwb->phoneMgr,
                            &gwb->termMgr,
                            gwb->bConfigTCP,
                            gwb->eppIp,
                            gwb->eppPort)) != RV_OK)
    {
        IppLogMessage(RV_TRUE, "rvIppSipSampleGatewayConstruct(). Failed in rvPhoneMgrConstruct()");
        return NULL;
    }

    /* ----------------------- */
    /* Load Media Capabilities */
    /* ----------------------- */

    /*Load media capabilities from configuration file*/
    if (rvIppSampleLoadMediaParamsFromBuffer(configBuf, gwb) != RV_TRUE)
    {
        IppLogMessage(RV_TRUE, "rvIppSipSampleGatewayConstruct(). Failed in rvIppSampleLoadMediaParamsFromBuffer() - Verify that config file has SDP");
        return NULL;
    }

    /* Load media capabilities to MTF (rtp class)*/
    if (!rvIppSampleGatewayBaseLoadMediaCaps(gwb, gwb->rtpClass))
    {
        IppLogMessage(RV_TRUE, "rvIppSampleGatewayBaseLoadMediaCaps(atClass)");
        return NULL;
    }

    /* Notify MTF capabilities have been loaded*/
    rvMdmTermMgrMediaCapabilitiesUpdated(&gwb->termMgr, gwb->rtpClass);

    /* Load media capabilities to MTF (at class)*/
    if (rvIppSampleGatewayBaseLoadMediaCaps(gwb, gwb->atClass) != RV_TRUE)
    {
        IppLogMessage(RV_TRUE, "rvIppSampleGatewayBaseLoadMediaCaps(atClass)");
        return NULL;
    }

    /* Load media capabilities to MTF (analog class)*/
    if (rvIppSampleGatewayBaseLoadMediaCaps(gwb, gwb->phoneClass) != RV_TRUE)
    {
        IppLogMessage(RV_TRUE, "rvIppSampleGatewayBaseLoadMediaCaps(phoneClass)");
        return NULL;
    }

    gwb->mediaParam.termMgr = &gwb->termMgr;
    gwb->mediaParam.rtpClass = gwb->rtpClass;
    gwb->mediaParam.atClass = gwb->atClass;
    gwb->mediaParam.phoneClass = gwb->phoneClass;
    gwb->mediaParam.sdpFullCaps = gwb->sdpOfFullCaps;
    gwb->mediaParam.sdpForInvite = gwb->sdpForInitialInvite;

    rvMtfMediaInit( &gwb->mediaParam);

#ifdef RV_MTF_MEDIA
        if(RV_OK != rvMtfMediaStart(NULL))
            IppLogMessage(RV_TRUE, "rvMtfMediaStart() failed");
#else
        /* we call rvMtfMediaStart() when GUI is registered in toolkit, see rvPhoneMgrRegUITermCompletedCB() */

        /* initialize proxy replacement of MfControl library */
        RvMediaControlCreate( gw->gatewayBase.phoneMgr.eppClient);
#endif


#ifdef RV_MTF_STUN
    stunClientInit(gw);
#endif

return gw;
}


void rvIppSipSampleGatewayDestruct(RvIppSampleGateway *gw)
{
    IppThreadSleep(1,0);

#ifdef RV_MTF_STUN
    stunClientEnd();
#endif

#ifdef SAMPLE_MWI
    rvIppSampleSipMwiEnd();
#endif

    rvMdmTermMgrStop(&gw->gatewayBase.termMgr, NULL);
    rvPhoneMgrDestruct(&gw->gatewayBase.phoneMgr);
    rvMdmTermMgrDestruct(&gw->gatewayBase.termMgr);

	RegExpMgrDestruct(gw->regExpMgr);
#ifdef RV_MTF_MEDIA
    rvMtfMediaStop(NULL);
#endif
    destructGatewayParams(gw);
}

