/******************************************************************************
Filename:    IppSampleSipPhoneTls.c
Description: TLS Sample functions for SIP Phone
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifdef RV_CFLAG_TLS
#include "IppSampleSipGateway.h"
#include "sipTls.h"
#include "IppSampleSipTls.h"

/******************************************************************************
*  loadIppSipGatewayTransportTlsParams
*  --------------------------------
*  General :       Loads TLS configuration parameter to RvIppTransportTlsCfg
*                  structure.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          gwTransportTlsCfg - pointer to TlsCfg structure
*                  params            - name of parameter
*                   val              - value of parameter
*
*  Output:         none.
******************************************************************************/
void loadIppSipGatewayTransportTlsParams(IN RvIppTransportTlsCfg* gwTransportTlsCfg, 
								         IN char* params, 
								         IN char *val)
{
	RvUint32	tmp;

	/* solve bug 41886 */
	gwTransportTlsCfg->tlsMethod = RVSIP_TRANSPORT_TLS_METHOD_UNDEFINED;

	if (!strcmp(params,"stackTlsPort"))
	{
		sscanf(val,"%d",&tmp);
		gwTransportTlsCfg->stackTlsPort =(RvUint16)tmp;
	}
	else if (!strcmp(params,"stackNumOfTlsAddresses"))
	{
		sscanf(val,"%d",&tmp);
		gwTransportTlsCfg->stackNumOfTlsAddresses =(RvInt16)tmp;
	}
	else if (!strcmp(params,"certDepth"))
	{
		sscanf(val,"%d",&gwTransportTlsCfg->certDepth);
	}
	else if (!strcmp(params,"privateKeyType"))
	{
		sscanf(val,"%d",&tmp);
		gwTransportTlsCfg->privateKeyType = (RvSipTransportPrivateKeyType)tmp ;
	}
	else if (!strcmp(params,"tlsMethod")) 
	{
		sscanf(val,"%d",&tmp);
		gwTransportTlsCfg->tlsMethod = ( RvSipTransportTlsMethod)tmp;
	}
	else if (!strcmp(params,"tlsPostConnectAssertFlag"))
	{
		sscanf(val, "%d", &gwTransportTlsCfg->tlsPostConnectAssertFlag);
	}

}


/******************************************************************************
*  loadIppSipGatewayKeyTlsParams
*  --------------------------------
*  General :       Loads TLS Key configuration parameters to RvIppKeyTlsCfg
*                  structure.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          gwKeyTlsCfg - pointer to KeyTlsCfg structure
*                  params            - name of parameter
*                  val              - value of parameter
*
*  Output:         none.
******************************************************************************/
void loadIppSipGatewayKeyTlsParams(IN RvIppKeyTlsCfg* gwKeyTlsCfg, 
								   IN char* params, 
								   IN char *val)
{
	static int	indCA=0;

	if (!strcmp(params,"privateKeyFileName")) 
	{
		sscanf(val,"%s",gwKeyTlsCfg->privateKeyFileName);			
	}
	else if (!strcmp(params,"caCertFileName")) 
	{   
		if (indCA < TLS_MAX_CA)
		{
			sscanf(val,"%s",gwKeyTlsCfg->caCertFileName[indCA++]);			
		}
	}
}

/******************************************************************************
*  loadSipTlsConfigParams
*  --------------------------------
*  General :       Copy TLS configuration parameters from sample app structure to 
*                  IPP TK structure.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          gwTransportTlsCfg - pointer to IppTlsCfg structure
*                  cfg               - pointer to ipp tk cfg structure
*                  
*
*  Output:         none.
******************************************************************************/
void loadSipTlsConfigParams(IN RvIppTransportTlsCfg *gwTransportTlsCfg, IN RvIppSipPhoneCfg* cfg)
{
	if (gwTransportTlsCfg->stackTlsPort)
		cfg->transportTlsCfg.stackTlsPort = gwTransportTlsCfg->stackTlsPort;

	if (gwTransportTlsCfg->stackTlsAddress)
		cfg->transportTlsCfg.stackTlsAddress = gwTransportTlsCfg->stackTlsAddress;
    
	if (gwTransportTlsCfg->certDepth)
		cfg->transportTlsCfg.certDepth = gwTransportTlsCfg->certDepth;
	
	cfg->transportTlsCfg.stackNumOfTlsAddresses = gwTransportTlsCfg->stackNumOfTlsAddresses;

	cfg->transportTlsCfg.privateKeyType = gwTransportTlsCfg->privateKeyType;
	
	if(gwTransportTlsCfg->tlsMethod != RVSIP_TRANSPORT_TLS_METHOD_UNDEFINED)
		cfg->transportTlsCfg.tlsMethod = gwTransportTlsCfg->tlsMethod;
	
	cfg->transportTlsCfg.tlsPostConnectAssertFlag = gwTransportTlsCfg->tlsPostConnectAssertFlag;
}
#else

static int ippSampleSipTls_dummy = 0; /* Warning removal */
#endif/*RV_CFLAG_TLS*/
