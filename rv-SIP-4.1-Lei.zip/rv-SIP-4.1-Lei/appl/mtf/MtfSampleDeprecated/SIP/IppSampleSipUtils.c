/******************************************************************************
Filename:    IppSampleSipUtils.c
Description: includes utility functions for the sample application
*******************************************************************************
                Copyright (c) 2004 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include <stdio.h> 
#include <stdlib.h>
#include <ctype.h>
#include "IppSampleSipUtils.h"
#include "rvstr.h"


typedef struct
{
    const char* strValue;
    RvInt32    enumValue;
} ConvertValue;


static ConvertValue rvIppSampleLogFilters[] =
{
    {"exception",	(RvInt32)RV_LOGLEVEL_EXCEP},
    {"error",       (RvInt32)RV_LOGLEVEL_ERROR},
    {"warning",		(RvInt32)RV_LOGLEVEL_WARNING},
    {"info",		(RvInt32)RV_LOGLEVEL_INFO},
    {"debug",		(RvInt32)RV_LOGLEVEL_DEBUG},
    {"enter",		(RvInt32)RV_LOGLEVEL_ENTER},
    {"leave",		(RvInt32)RV_LOGLEVEL_LEAVE},
    {"sync",		(RvInt32)RV_LOGLEVEL_SYNC},
    {NULL,          (RvInt32)0}
};


static ConvertValue cvLogDebugSipFilters[] =
{
    {"debug",      (RvInt32)RVSIP_LOG_DEBUG_FILTER},
    {"info",       (RvInt32)RVSIP_LOG_INFO_FILTER},
    {"warning",    (RvInt32)RVSIP_LOG_WARN_FILTER},
    {"error",      (RvInt32)RVSIP_LOG_ERROR_FILTER},
    {"exception",  (RvInt32)RVSIP_LOG_EXCEP_FILTER},
    {"lockdbg",    (RvInt32)RVSIP_LOG_LOCKDBG_FILTER},
    {NULL,         (RvInt32)0}
};



/* Defines the different modules of the RADVISION SIP stack. */
static ConvertValue cvLogDebugSipModules[] =
{
    {"callLogFilters",          (RvInt32)RVSIP_CALL},
    {"transactionLogFilters",   (RvInt32)RVSIP_TRANSACTION},
    {"msgLogFilters",           (RvInt32)RVSIP_MESSAGE},
    {"transportLogFilters",     (RvInt32)RVSIP_TRANSPORT},
    {"parserLogFilters",        (RvInt32)RVSIP_PARSER},
    {"stackLogFilters",         (RvInt32)RVSIP_STACK},
    {"msgBuilderLogFilters",    (RvInt32)RVSIP_MSGBUILDER},
    {"authenticatorLogFilters", (RvInt32)RVSIP_AUTHENTICATOR},
    {"regClientLogFilters",     (RvInt32)RVSIP_REGCLIENT},
    {"subscriptionLogFilters",  (RvInt32)RVSIP_SUBSCRIPTION},
	{"compartmentLogFilters",	(RvInt32)RVSIP_COMPARTMENT},
	{"transmitterLogFilters",	(RvInt32)RVSIP_TRANSMITTER},
	{"ads_rlistLogFilters",		(RvInt32)RVSIP_ADS_RLIST},
	{"ads_raLogFilters",		(RvInt32)RVSIP_ADS_RA},
	{"ads_rpoolLogFilters",		(RvInt32)RVSIP_ADS_RPOOL},
	{"ads_hashLogFilters",		(RvInt32)RVSIP_ADS_HASH},
	{"ads_pqueueLogFilters",	(RvInt32)RVSIP_ADS_PQUEUE},
	{"core_semaphoreLogFilters",(RvInt32)RVSIP_CORE_SEMAPHORE},
	{"core_mutexLogFilters",	(RvInt32)RVSIP_CORE_MUTEX},
	{"core_lockLogFilters",		(RvInt32)RVSIP_CORE_LOCK},
	{"core_memoryLogFilters",	(RvInt32)RVSIP_CORE_MEMORY},
	{"core_threadLogFilters",	(RvInt32)RVSIP_CORE_THREAD},
	{"core_queueLogFilters",	(RvInt32)RVSIP_CORE_QUEUE},
	{"core_timerLogFilters",	(RvInt32)RVSIP_CORE_TIMER},
	{"core_timestampLogFilters",(RvInt32)RVSIP_CORE_TIMESTAMP},
	{"core_clockLogFilters",	(RvInt32)RVSIP_CORE_CLOCK},
	{"core_tmLogFilters",		(RvInt32)RVSIP_CORE_TM},
	{"core_socketLogFilters",	(RvInt32)RVSIP_CORE_SOCKET},
	{"core_portrangeLogFilters",(RvInt32)RVSIP_CORE_PORTRANGE},
	{"core_selectLogFilters",	(RvInt32)RVSIP_CORE_SELECT},
	{"core_hostLogFilters",		(RvInt32)RVSIP_CORE_HOST},
	{"core_tlsLogFilters",		(RvInt32)RVSIP_CORE_TLS},
	{"core_aresLogFilters",		(RvInt32)RVSIP_CORE_ARES},
	{"coreLogFilters",			(RvInt32)RVSIP_CORE},
	{"adsLogFilters",			(RvInt32)RVSIP_ADS},
    {NULL,                      (RvInt32)0}
};



/***************************************************************************************
 * IppSipUtilLoadFile
 * -------------------------------------------------------------------------------------
 * General:   Opens a file and copies the content of the file to a buffer.
 * Return Value: RV_OK on success, other on failure.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 buf        - The buffer to fill in.
 *			 bufsize    - Maximum size of the buffer.
 *           fileName   - Name of file to load to memory.
 * Output:   buf        - The filled buffer (NULL terminated).
 **************************************************************************************/
RvStatus IppSipUtilLoadFile(
    IN RvChar*          buf,
    IN RvSize_t         bufsize,
    IN const RvChar*    fileName)
{
	FILE*       file;
	RvChar      line[512];
    RvSize_t    lineLength;
    RvSize_t    cnt = 0;
    RvChar      *p;
    RvChar      *pEnd;

	if ((file = fopen(fileName, "r")) == NULL)
    {
		printf("ERROR: %s File Not Found", fileName);
		return RV_ERROR_NOT_FOUND;
	}

    memset(buf, 0, bufsize);

    /* Read the file line by line */
	while (fgets(line, sizeof(line)-1, file) != NULL)
	{
        /* Skip whitespaces */
        line[sizeof(line)-1] = '\0';
        p = line;
        while (*p && isspace((RvInt)*p))
            p++;

		/* Kill comments */
        pEnd = strchr(p, (int)';');
        if (pEnd != NULL)
            *pEnd = '\0';

        /* Remove trailing whitespaces */
        pEnd = p + strlen(p) - 1;
        while ((pEnd > p) && isspace((RvInt)*pEnd))
            *pEnd--;

        if (pEnd <= p)
            continue; /* We ended up with an empty line */

        /* Add the darn line to what we already have */
        lineLength = pEnd - p + 2;
        *(pEnd+1) = '\n';
        *(pEnd+2) = '\0';
		if (cnt + lineLength < bufsize)
		{
            strcpy(buf + cnt, p);
	        cnt += lineLength;
		}
		else
		{
			fclose(file);
    		printf("ERROR: %s File too big to fit in memory (%d)", fileName, bufsize);
			return RV_ERROR_OUTOFRESOURCES;
		}
	}

	fclose(file);
	return RV_OK;
}


/***************************************************************************************
* rvIppSampleUtilString2Enum
* -------------------------------------------------------------------------------------
* General:  Convert a string value to its enumeration value
*           Used as a general conversion function
* Return Value: Parameter enumeration value
* -------------------------------------------------------------------------------------
* Arguments:
* Input: 	 string     - String parameter to convert
*           cvTable    - Conversion table to use
* Output:   none
**************************************************************************************/
static RvInt32 rvIppSampleUtilString2Enum(IN const RvChar* string, IN ConvertValue* cvTable)
{
    ConvertValue* val = cvTable;

    while (val->strValue != NULL)
    {
        if (strcmp(string, val->strValue) == 0)
            return val->enumValue;
        val++;
    }

    return -1;
}

/***************************************************************************************
 * IppSipUtilString2LogDebugFilters
 * -------------------------------------------------------------------------------------
 * General:   converts a string to RvSipLogFilters
 * Return Value: the string
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the string to be converted
 * Output:   none
 **************************************************************************************/
static RvInt8 IppSipUtilString2LogDebugFilters(IN const char *string)
{
    return (RvInt8)rvIppSampleUtilString2Enum(string, cvLogDebugSipFilters);
}

/***************************************************************************************
* IppSipUtilString2LogIppFilters
* -------------------------------------------------------------------------------------
* General:   converts a string to RvLogFilters
* Return Value: the string
* -------------------------------------------------------------------------------------
* Arguments:
* Input: 	 string - the string to be converted
* Output:   none
**************************************************************************************/
RvUint8 IppSipUtilString2LogIppFilters(IN const char *string)
{
    return (RvUint8)rvIppSampleUtilString2Enum(string, rvIppSampleLogFilters);
}

/***************************************************************************
 * IppSipUtilFilterToInt
 * ------------------------------------------------------------------------
 * General: calculates the numeric value of the
 *          filter string
 * Return Value: RV_Succes on success and RV_Failure otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	strValue -    The filter string
 *          iValue-       The returned calculated value
 ***************************************************************************/
RvBool IppSipUtilFilterToInt(IN APITYPE api_type, IN const char*  strValue, OUT RvInt8* iValue)
{
    char     strSeperateValue[80]; /*a single enum string*/
	int			index = 0;

    *iValue=0;

    /*break strValue into separate strings*/

    while(0 != strValue[0])
    {
        for(;' ' == strValue[0] || ',' == strValue[0];++strValue);
        while(' ' != strValue[0] && ',' != strValue[0] && '\0' != strValue[0])
        {
            strSeperateValue[index]=(char)tolower(strValue[0]);
            ++strValue;
            ++index;
        }
        if (0 == strSeperateValue[0])
        {
            break;
        }
        strSeperateValue[index]=0;

        /*add the new separated string to the value calculated
          so far*/

		switch(api_type)
		{
		case SIP_API_TYPE:
			*iValue=(RvInt8)(*iValue | (RvInt8)IppSipUtilString2LogDebugFilters(strSeperateValue));
			break;
		case IPP_API_TYPE:
			*iValue=(RvInt8)(*iValue | (RvInt8)IppSipUtilString2LogIppFilters(strSeperateValue));
			break;
		default:
			return rvFalse;

		}
		index = 0;
    }
    return rvTrue;
}



/***************************************************************************************
 * IppSipUtilStringToStackModule
 * -------------------------------------------------------------------------------------
 * General:   converts a string to Sip stack module ID
 * Return Value: the module ID
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the string to be converted
 * Output:   none
 **************************************************************************************/
RvBool IppSipUtilStringToStackModule(const char* str, RvSipStackModule* module){

	*module= rvIppSampleUtilString2Enum(str,cvLogDebugSipModules);
	if ((*module) == (RvSipStackModule)(-1))
		    return rvFalse;

	return rvTrue;

}



