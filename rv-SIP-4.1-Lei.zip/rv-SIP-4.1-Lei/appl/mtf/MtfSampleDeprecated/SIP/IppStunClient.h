#ifdef RV_MTF_STUN
#ifndef RV_IPP_STUN_CLIENT_H
#define RV_IPP_STUN_CLIENT_H


#define STUN_MAX_STRING 256
#define STUN_MAX_UNKNOWN_ATTRIBUTES 8
#define STUN_MAX_MESSAGE_SIZE 2048

#define DEFAULT_STUN_PORT 3478

typedef struct { unsigned char octet[16]; }  RvUint128;

typedef struct
{
      RvUint16 type;
      RvUint16 length;
} StunAtrHdr;

typedef struct
{
      RvUint32 value;
} StunAtrChangeRequest;

typedef struct
{
      char value[STUN_MAX_STRING];
      RvUint16 sizeValue;
} StunAtrString;


typedef struct
{
      RvUint16 port;
      RvUint32 addr;
} StunAddress4;


typedef struct
{
      RvUint8 pad;
      RvUint8 family;
      StunAddress4 ipv4;
} StunAtrAddress4;

typedef struct
{
      RvUint16 pad; // all 0
      RvUint8 errorClass;
      RvUint8 number;
      char reason[STUN_MAX_STRING];
      RvUint16 sizeReason;
} StunAtrError;

typedef struct
{
      RvUint16 attrType[STUN_MAX_UNKNOWN_ATTRIBUTES];
      RvUint16 numAttributes;
} StunAtrUnknown;


typedef struct
{
      char hash[20];
} StunAtrIntegrity;


typedef struct
{
      RvUint16 msgType;
      RvUint16 msgLength;
      RvUint128 id;

} StunMsgHdr;

typedef struct
{
      StunMsgHdr msgHdr;

      RvBool hasMappedAddress;
      StunAtrAddress4  mappedAddress;

      RvBool hasResponseAddress;
      StunAtrAddress4  responseAddress;

      RvBool hasChangeRequest;
      StunAtrChangeRequest changeRequest;

      RvBool hasSourceAddress;
      StunAtrAddress4 sourceAddress;

      RvBool hasChangedAddress;
      StunAtrAddress4 changedAddress;

      RvBool hasUsername;
      StunAtrString username;

      RvBool hasPassword;
      StunAtrString password;

      RvBool hasMessageIntegrity;
      StunAtrIntegrity messageIntegrity;

      RvBool hasErrorCode;
      StunAtrError errorCode;

      RvBool hasUnknownAttributes;
      StunAtrUnknown unknownAttributes;

      RvBool hasReflectedFrom;
      StunAtrAddress4 reflectedFrom;

      RvBool hasXorMappedAddress;
      StunAtrAddress4  xorMappedAddress;

      RvBool xorOnly;

      RvBool hasServerName;
      StunAtrString serverName;

      RvBool hasSecondaryAddress;
      StunAtrAddress4 secondaryAddress;
} StunMessage;



RvStatus stunParseMessage( RvChar* buf, unsigned int bufLen, StunMessage* msg);


RvStatus stunClientInit(IN RvIppSampleGateway* gw);
RvStatus stunClientEnd(void);

#endif /* RV_IPP_STUN_CLIENT_H*/
#endif /* RV_MTF_STUN */

