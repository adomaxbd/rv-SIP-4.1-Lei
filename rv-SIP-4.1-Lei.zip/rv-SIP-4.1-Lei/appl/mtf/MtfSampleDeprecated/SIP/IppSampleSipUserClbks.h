/******************************************************************************
Filename:    rvIppSampleSipUserClbks.h
Description: User Callbacks Header
*******************************************************************************
                Copyright (c) 2004 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef USER_CLBKS_H
#define USER_CLBKS_H

#include "rvSipControlApi.h"
#include "rvMdmControlApi.h"
#include "rvccapi.h"
#include "RvSipTransportTypes.h"


typedef struct userSipClbksData_ {
	RvSipTransportMgrHandle			transportMgr;		/*Handle to Transport manager*/
	RvSipTransportMgrEvHandlers		transportEvHandlers;/*Structure of Transport callbacks*/
	char							testLine[128];
	
}userSipClbksData;


void userCBDisplay(RvIppConnectionHandle	connHndl, 
					RvIppTerminalHandle		termHndl,
					RvCCTerminalEvent		event, 
					RvCCEventCause			cause,
					void*					displayData);

RvCCTerminalEvent userCBMapEvent(const char*		pkg, 
								 const char*		id,
								 RvMdmParameterList	*args, 
								 char*				key);

RvCCTerminalEvent userCBPreProcessEvent(RvIppConnectionHandle	connHndl,
										RvCCTerminalEvent		eventId,
										RvCCEventCause*			reason);

void userCBPostProcessEvent(RvIppConnectionHandle	connHndl,
							 RvCCTerminalEvent		eventId,
							 RvCCEventCause			reason);

void userRegisterIppSipExt(void);

#endif /*USER_CLBKS_H*/

