/******************************************************************************
Filename:    IppSampleSipUtils.h
Description: includes utility functions declarations for the sample application
*******************************************************************************
                Copyright (c) 2004 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make 
changes without obligation to notify any person of such revisions or 
changes.
******************************************************************************/
#ifndef IPP_SIP_UTIL_H
#define IPP_SIP_UTIL_H

#include "RvSipStackTypes.h"
#include "IppSampleGatewayBase.h"
#include "rvSipControlApi.h"
#include "rvtypes.h"

/***************************************************************************************
 * IppSipUtilLoadFile
 * -------------------------------------------------------------------------------------
 * General:   Opens a file and copies the content of the file to a buffer.
 * Return Value: RV_OK on success, other on failure.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 buf        - The buffer to fill in.
 *			 bufsize    - Maximum size of the buffer.
 *           fileName   - Name of file to load to memory.
 * Output:   buf        - The filled buffer (NULL terminated).
 **************************************************************************************/
RvStatus IppSipUtilLoadFile(
    IN RvChar*          buf,
    IN RvSize_t         bufsize,
    IN const RvChar*    fileName);

/***************************************************************************************
 * IppSipUtilStringToStackModule
 * -------------------------------------------------------------------------------------
 * General:   converts a string to Sip stack module ID
 * Return Value: the module ID
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the string to be converted
 * Output:   none
 **************************************************************************************/
RvBool IppSipUtilStringToStackModule(const char* str, RvSipStackModule* module);

/***************************************************************************
 * IppSipUtilFilterToInt
 * ------------------------------------------------------------------------
 * General: calculates the numeric value of the 
 *          filter string
 * Return Value: RV_Succes on succes and RV_Failure otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	strValue -    The filter string
 *          iValue-       The ruturned calculated value
 ***************************************************************************/
RvBool IppSipUtilFilterToInt(IN APITYPE api_type, IN const char*  strValue, OUT RvInt8* iValue);

#endif /*IPP_SIP_UTIL_H */
