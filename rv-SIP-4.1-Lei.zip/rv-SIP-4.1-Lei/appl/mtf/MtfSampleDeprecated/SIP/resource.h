//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IppSampleDlg.rc
//
#define IDD_FORM_CLIENT                 101
#define IDI_ICON1                       101
#define IDC_SEND_DATA                   1000
#define IDC_RECV_DATA                   1001
#define IDC_SERVER_NAME                 1002
#define IDC_PORT_NUM                    1003
#define IDC_CONNECT                     1004
#define IDC_STACK                       1004
#define IDC_EXIT                        1005
#define IDC_DISCONNECT                  1006
#define IDC_SEND                        1007
#define IDC_TCPIP                       1009
#define IDC_IRDA                        1010
#define IDC_INFO                        1011
#define IDC_FASTSTART                   1012
#define IDC_useThreadPriority           1012
#define IDC_H245TUNNELING               1013
#define IDC_EARLYH245                   1014
#define IDC_CHECK4                      1015
#define IDC_PARALLEL                    1015
#define IDC_SCROLLBAR3                  1020
#define IDC_Iterations                  1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
