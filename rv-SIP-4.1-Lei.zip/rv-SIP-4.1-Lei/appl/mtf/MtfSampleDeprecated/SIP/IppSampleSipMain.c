/******************************************************************************
Filename:    IppSampleSipMain.c
Description: Sample SIP IP Phone application
*******************************************************************************
                Copyright (c) 2001 RADVision Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD.

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"
#include "ippthread.h"
#include "IppSampleSipGateway.h"
#include "rvsdp.h"
#include "rvthread.h"
#include "rvmtfalloc.h"
#include "IppSampleSipUtils.h"


#if defined(RV_OS_NUCLEUS)
#include <plus\nucleus.h>
#endif
#if defined(RV_MEMTRACE_ON)
#include "rvmem.h"
#endif


/* TODO: remove all variables from here once possible */

RvAlloc*        userDefaultAlloc = NULL;

RvIppSampleGateway      gw;
RvIppSampleGatewayBase* pgw;
RV_BOOL                 startWarmRestart;
RV_BOOL                 startShutdown;

extern RV_BOOL notifyToStartWarmRestart;
extern RV_BOOL notifyToStartShutdown;
extern RV_BOOL unegisteredTerminationsLeft;



/*===================================================*/
void rvIppSipSampleDestruct(void)
{
    /* Nothing for now*/
}
/*===================================================*/
RvStatus rvIppSipSampleStart(
        IN  RvChar*     configBuf)
{
    /* Initialize the MTF */
    rvIppSipSystemInit();

    userDefaultAlloc = rvAllocGetDefaultAllocator();

    pgw = (RvIppSampleGatewayBase*)rvIppSampleGatewayGetSipBase(gw);

    if (rvIppSipSampleGatewayConstruct(&gw, (char *)configBuf) == NULL)
        return RV_ERROR_UNINITIALIZED;

    rvMdmTermMgrStart(&pgw->termMgr, NULL, 0);

    return RV_OK;
}

/*===================================================*/
RvStatus rvIppSipSampleConstruct(void)
{
    RvChar      *configBuf;
    RvStatus    status;
    
    /* Allocate a configuration block */
    configBuf = (RvChar *)malloc(SIP_CONFIGURATION_FILE_SIZE);
    
    status = IppSipUtilLoadFile(configBuf, SIP_CONFIGURATION_FILE_SIZE, SIP_CONFIGURATION_PATH);
    if (status != RV_OK)
    {
        free(configBuf);
        printf("ERROR: Failed to read %s File", SIP_CONFIGURATION_PATH);
        return status;
    }
    
    status = rvIppSipSampleStart(configBuf);
    free(configBuf);
    
    return status;
}

void rvIppSipSampleEnd(void)
{
    rvIppSipSampleGatewayDestruct(&gw);
    rvIppSipSystemEnd();
}

#if (RV_OS_TYPE != RV_OS_TYPE_WINCE)
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int MtfSipSample(int argc)
#else
int main(int argc, char **argv)
#endif
{
    RvStatus    status = RV_OK;
    int         i, numOfWarmRestarts = 0;

#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
    /*There is no argc and argv in vxWorks, so we have one argument only*/
    numOfWarmRestarts = argc;
#else
    /* Get number of warm restarts from command line */
    if (argc == 2)
        numOfWarmRestarts = atoi( argv[argc-1]);
#endif

    /* Run MTF for the first time */
    if ((status = rvIppSipSampleConstruct()) != RV_OK)
    {
        printf("*******rvIppSipSampleConstruct error = %d*******\n", status);
        return status;
    }

    /* Loop through Warm Restarts for the fun of it*/
    for (i=0 ; i < numOfWarmRestarts ; ++i)
    {

        /* Shut down MTF*/
        rvIppSipSampleEnd();

        printf("******* Shut Down is Completed! (number=%d) *******\n", i);

        /* Restart MTF*/
        rvIppSipSampleConstruct();

        printf("******* Startup is Completed (number=%d)*******\n", i);
    }

    startWarmRestart = RV_FALSE;
    startShutdown = RV_FALSE;

    while (startShutdown == RV_FALSE)
    {
        /* This boolean will be changed only by EPP thread to notify us the
           user wants to perform Restart or Shutdown*/
        while ((startWarmRestart == RV_FALSE) && (startShutdown == RV_FALSE))
        {
            IppThreadSleep(2, 0);
        }

        /* Shut down MTF*/
        rvIppSipSampleEnd();

        if (startWarmRestart == RV_TRUE)
        {
            /* Restart MTF if needed*/
            rvIppSipSampleConstruct();
        }

        startWarmRestart = RV_FALSE;
    }

#if defined(RV_MEMTRACE_ON)
    rvMemTraceDestruct();
#endif

    return 0;
}

/* In vxWorks we can either call vxMain() with no arguments for running application from seperated
   process (so we don't block the shell), or we can call MtfSipSample() directly
   (and block the shell) with one argument: number of warm restarts*/
#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
int vxMain()
{
    taskSpawn("User IPP",100,0,100000, MtfSipSample, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return 0;

}
#endif /*(RV_OS_TYPE_VXWORKS)*/


/*=========================== RV_OS_WINCE======================================*/

#else /*if !defined(RV_OS_WINCE)*/

#include "resource.h"

/* Global variables*/
HWND        g_hWnd=0;
HINSTANCE   g_hInst=NULL;
HWND        g_hDlg = NULL;

/* Function prototypes*/
RvBool InitApplication(HANDLE hInstance);
RvBool InitInstance(HANDLE hInstance, int nCmdShow);
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam);
RvBool    CALLBACK IppSipDialogBox(HWND hDlg, WORD wMsg, WORD wParam, LONG lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPWSTR lpCmdLine, int nCmdShow)
{

    g_hInst = hInstance;

    if (!hPrevInstance)
    {
        if (!InitApplication(hInstance))
            if (!InitInstance(hInstance, nCmdShow))
                return (FALSE);
    }

    DialogBox(g_hInst, MAKEINTRESOURCE(IDD_FORM_CLIENT), g_hWnd,
        (DLGPROC)IppSipDialogBox);

    /*Note: to load configuration from files, we should give the full path
      (\\Windows\Start Menu....), and give the file name in wide chars
      (use macro TEXT("\\Windows\RvIpp\SipPhone.cfg"))*/

    return (RV_TRUE);
}
RvBool InitApplication(HANDLE hInstance)
{
    WNDCLASS  wc;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = 0;
    wc.hCursor = 0;
    wc.hbrBackground = GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = TEXT("RADVISION IPP SIP Application");

    return (RegisterClass(&wc));
}

RvBool InitInstance(HANDLE hInstance, int nCmdShow)
{
    g_hInst = hInstance;

    g_hWnd = CreateWindow(
        TEXT("RADVISION IPP SIP Application"),
        TEXT("RADVISION IPP SIP Application"),
        0,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
        );
    if (!g_hWnd)
        return (FALSE);
    return (RV_TRUE);
}


/* Function: MainWndProc
//
// Description:
//    Main window callback.
*/
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam)
{
    switch (message)
    {
    case WM_CREATE:
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    case WM_CLOSE:
        return 0;
    default:
        return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return 0;
}



// Function: IppSipDialogBox (hDlg, wMsg, wParam, lParam)
//
// This is the callback function for messages for the dialog.
// It contains the code to handle window events as well as user
// input such as button clicks.
//
RvBool CALLBACK IppSipDialogBox(HWND hDlg, WORD wMsg, WORD wParam, LONG lParam)
{
    if (!g_hDlg)               // Assign global Dialog handle value if it was empty. Necessary only for
        g_hDlg = hDlg;         // the convenience of the wce_printf() function

    switch(wMsg)
    {
    case WM_INITDIALOG:
        {
            RvStatus status;
            status = rvIppSipSampleConstruct();
            if (status != RV_OK)
            {
                return FALSE;
            }
            ShowWindow(hDlg, SW_SHOW);

            return RV_TRUE;
        }
    case WM_COMMAND:
        {
            switch(wParam)
            {
            case IDC_EXIT:
                rvIppSipSampleEnd();
                // Exit the app
                EndDialog(hDlg, IDC_EXIT);
                break;
            }
            return RV_TRUE;
        }
    }
    return FALSE;
}


#endif /*RV_OS_WINCE*/





















