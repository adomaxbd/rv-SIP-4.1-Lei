/******************************************************************************
Filename:    rvccmdmmediacb.h
Description: MDM Control Video Header
*******************************************************************************
                Copyright (c) 2006 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#ifndef RV_CCMDM_MEDIACB_H
#define RV_CCMDM_MEDIACB_H

#include "MfControl.h"

/******************************************************************************
*  RvMtfCreateMediaNegotiateCB
*  ----------------------------
*  General :     user CB to negotiate media.
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:        
*               
******************************************************************************/
typedef RvBool (*RvMtfMediaNegotiateCB)( INOUT RvSdpMsg* msgLocal, 
                                         INOUT RvSdpMsg* msgRemote, 
                                         IN RvSdpMsg*    msgAvailable, 
                                         IN void*        userData);

typedef struct
{
    RvMdmTermMgr*           termMgr;  /*objects which media CB should be registered in*/
    RvMdmTermClass*         rtpClass; /*objects which media CB should be registered in*/
    RvMdmTermClass*         atClass;  /*objects which media CB should be registered in*/
    RvMdmTermClass*         phoneClass;  /*objects which media CB should be registered in*/
    RvMtfMediaNegotiateCB   mediaNegotiate;/* negotiation policy. called in media CB implementations*/
    /*MfControl parameters to initialize Media library*/
    RvBool                      bDisableMedia; /* if false the following mfControlParams is irrelevant*/
    RvMfControlConstructParam   mfControlParams;
    RvSdpMsg*               sdpFullCaps;
	RvSdpMsg*               sdpForInvite;
}RvMtfMediaConstructParam;

/******************************************************************************
*  rvMtfMediaInitConfig
*  ----------------------------
*  General :        Set default values for parameters which may be used in rvMtfMediaInit
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInitConfig( INOUT RvMtfMediaConstructParam* p);

/******************************************************************************
*  rvMtfMediaInit
*  ----------------------------
*  General :        Register Media CB for TK etc. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInit( IN RvMtfMediaConstructParam* p);

/******************************************************************************
*  rvMtfMediaEnd
*  ----------------------------
*  General :        Unregister Media CB for TK. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaEnd();

/******************************************************************************
*  rvMtfMediaStart
*  ----------------------------
*  General :        Start internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
RvStatus rvMtfMediaStart( void* context);

/******************************************************************************
*  rvMtfMediaStop
*  ----------------------------
*  General :        Stop internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaStop( void* context);

#endif /*RV_CCMDM_MEDIACB_H*/

