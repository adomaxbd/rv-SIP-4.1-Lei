/******************************************************************************
Filename:    MtfMediaCallbacks.c
Description: MDM Control Video Header
*******************************************************************************
                Copyright (c) 2006 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#include "ipp_inc_std.h"
#include "rvccapi.h"
#include "IppSampleGatewayBase.h"
#include "MtfMediaCallbacksHelper.h"
#include "MtfMediaCallbacks.h"
#include "IppSampleMediaNegotiate.h"
#include "rvcctext.h"

/*==============    GLOBALS  ==========*/
RvMtfMediaConstructParam  g_param;
/*====================================================*/
/***************************************************************************
 * rtpConnect
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrConnectCB
 *
 ***************************************************************************/
static RvBool MtfRtpConnect(
										RvMdmTermMgr *mgr,
										RvMdmTerm *source,
										RvMdmMediaStream *m1,
										RvMdmTerm *target,
										RvMdmMediaStream *m2,
	                                    RvMdmStreamDirection direction, 
                                        RvMdmError *mdmError);

/***************************************************************************
 * rtpDisconnect
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrDisconnectCB
 *
 ***************************************************************************/
static RvBool MtfRtpDisconnect(   RvMdmTermMgr *mgr,
	                        RvMdmTerm *source,
                            RvMdmMediaStream *m1,
                            RvMdmTerm *target,
                            RvMdmMediaStream *m2,
	                        RvMdmError *mdmError);

/******************************************************************************
*  rtpCreateMedia
*  ----------------------------
*  General :        Media CB for TK. 
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         rvTrue on success.
******************************************************************************/
static RvBool MtfRtpCreateMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,           /*obsolete*/
							 RvMdmMediaStreamDescr* streamDescr,/*obsolete except field: param*/
							 OUT RvMdmError* mdmError           /*obsolete*/
                             );

/******************************************************************************
*  rtpModifyMedia
*  ----------------------------
*  General :        Media CB for TK. 
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         rvTrue on success.
******************************************************************************/
static RvBool MtfRtpModifyMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,
							 RvMdmMediaStreamDescr* streamDescr,
                             RvMdmError* mdmError);


/******************************************************************************
*  rtpDestroyMedia
*  ----------------------------
*  General :        Media CB for TK
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         rvTrue on success.
******************************************************************************/
static RvBool MtfRtpDestroyMedia( RvMdmTerm *term, RvMdmMediaStream *media, OUT RvMdmError *mdmError);


static RvBool MtfPhysCreateMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,           /*obsolete*/
							 RvMdmMediaStreamDescr* streamDescr,/*obsolete except field: param*/
							 OUT RvMdmError* mdmError           /*obsolete*/);

static RvBool MtfPhysModifyMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,
							 RvMdmMediaStreamDescr* streamDescr,
                             RvMdmError* mediaError);

static RvBool MtfPhysDestroyMedia(RvMdmTerm *term, RvMdmMediaStream *media, OUT RvMdmError *mdmError);


/******************************************************************************
*  rvMtfMediaInitConfig
*  ----------------------------
*  General :        Set default values for parameters which may be used in rvMtfMediaInit
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInitConfig( INOUT RvMtfMediaConstructParam* p)
{
    RvMfControlConstructParam*  mfcParam = &p->mfControlParams;
    void*                       logMgr = rvMtfGetLogMgr();

    memset( p, 0, sizeof(RvMtfMediaConstructParam));
    p->bDisableMedia = rvFalse;
    p->mediaNegotiate = MtfMediaNegotiate;

    RvMfControlSetDefaultConfig( mfcParam, logMgr);
}

/******************************************************************************
*  rvMtfMediaInit
*  ----------------------------
*  General :        Register Media CB for TK etc. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaInit( IN RvMtfMediaConstructParam* p)
{
    g_param = *p;

    /*TermMgr CB*/
    rvMdmTermMgrRegisterConnectCB( p->termMgr, MtfRtpConnect);
    rvMdmTermMgrRegisterDisconnectCB( p->termMgr, MtfRtpDisconnect);
    /* ephemeral term CB*/
    rvMdmTermClassRegisterCreateMediaCB( p->rtpClass, MtfRtpCreateMedia);
    rvMdmTermClassRegisterModifyMediaCB( p->rtpClass, MtfRtpModifyMedia);
    rvMdmTermClassRegisterDestroyMediaCB( p->rtpClass, MtfRtpDestroyMedia);
    
    /* Register media callbacks for IPP mode*/
    rvMdmTermClassRegisterCreateMediaCB(p->atClass, MtfPhysCreateMedia);
    rvMdmTermClassRegisterModifyMediaCB(p->atClass, MtfPhysModifyMedia);
    rvMdmTermClassRegisterDestroyMediaCB(p->atClass, MtfPhysDestroyMedia);

    /* Register media callbacks for Analog mode*/
    rvMdmTermClassRegisterCreateMediaCB(p->phoneClass, MtfPhysCreateMedia);
    rvMdmTermClassRegisterModifyMediaCB(p->phoneClass, MtfPhysModifyMedia);
    rvMdmTermClassRegisterDestroyMediaCB(p->phoneClass, MtfPhysDestroyMedia);

    /* Initialize codec analyze utility*/
    IppCodecInitialize(IppLogMgr());
    
}


/******************************************************************************
*  rvMtfMediaEnd
*  ----------------------------
*  General :        Unregister Media CB for TK. Called once
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaEnd()
{
    /* End codec analyze utility*/
    IppCodecEnd();
}

/******************************************************************************
*  rvMtfMediaStart
*  ----------------------------
*  General :        Start internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
RvStatus rvMtfMediaStart( void* context)
{
    if(!g_param.bDisableMedia)
    {
        RvStatus    rc = wrapControlInit( context, &g_param.mfControlParams);
        if(RV_OK != rc)
            IppLogMessage(rvTrue,"wrapControlInit Failed");
        return rc;
    }    
    else
        return RV_OK;
}

/******************************************************************************
*  rvMtfMediaStop
*  ----------------------------
*  General :        Stop internal engine. Start()->Stop() cycle may be called several times
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*         RvMtfMediaConstructParam    - initializing parameters
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvMtfMediaStop( void* context)
{
    if(!g_param.bDisableMedia)
        wrapControlEnd( context);
}

/******************************************************************************
*  mediaEnableDev
*  ----------------------------
*  General :     Open or close specified device. See list of supported devices above
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*   devId           -   device id.   
*   bEnable         -   rvTrue  - open device, 
*                       rvFalse - close device   
*
*  Input:        
*               
******************************************************************************/
static RvStatus mediaEnableDev( void* context, RvIppMediaDevice devId, RvBool bEnable);

static void defaultGetMediaAvailable( OUT RvSdpMsg*   msgAvailable);
                                        
/*====================================================*/
/*===============================================================================*/



static void printSdp( RvSdpMsg *sdp, const char* title)
{
    char	buf[1024];
    int		len = sizeof(buf) -1;
    RvSdpStatus  stat;

    rvSdpMsgEncodeToBuf( sdp, buf, len, &stat);

    if (stat != RV_SDPSTATUS_OK)
    {
        IppLogMessage(rvTrue,"%s printSdp() failed", title);
        return;
    }

    IppLogMessage(rvFalse,"%s\n%s\n", title, buf);

}

/*===============================================================================*/
/*================== C A L L B A C K	F U N C T I O N S	=====================*/
/*===============================================================================*/
static void defaultGetMediaAvailable(    OUT RvSdpMsg*   msgAvailable)
                                            
{
    rvSdpMsgCopy( msgAvailable, g_param.sdpFullCaps);
}

/***************************************************************************
 * rtpConnect
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrConnectCB
 *
 ***************************************************************************/
RvBool MtfRtpConnect(
						RvMdmTermMgr *mgr,
						RvMdmTerm *source,
						RvMdmMediaStream *m1,
						RvMdmTerm *target,
						RvMdmMediaStream *m2,
	                    RvMdmStreamDirection direction, 
                        RvMdmError *mdmError)
{
	RvStatus		rc = RV_ERROR_UNKNOWN;
	const char*		termIdSrc = rvMdmTermGetId( source); /*it may be  termination  device or RTP */
	const char*		termId = rvMdmTermGetId( target); /*it's always termination representing RTP */
    void*           context;
	RvCCTerminalType  termType;

    RvIppTerminalHandle   ccTerminalEph;

	RV_UNUSED_ARG(mgr);
	RV_UNUSED_ARG(mdmError);
	RV_UNUSED_ARG(m1);
	RV_UNUSED_ARG(m2);
	RV_UNUSED_ARG(direction);

    IppLogMessage(rvFalse,"********* MtfRtpConnect() is Called for terms: source=%s and target=%s", termIdSrc, termId);   

    if(g_param.bDisableMedia)
	    return rvTrue;

    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( target);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);

	/*
	 *	As this function called both to connect rtp session to device and
	 *	to join 2 rtp sessions in case of conference we must separate these situations
	 */
	termType = rvIppMdmTerminalGetType (rvIppMdmTerminalGetHandle(source));
	switch(termType)
    {
    case RV_CCTERMINALTYPE_AT:
	case RV_CCTERMINALTYPE_ANALOG:
        
		rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_MIC, termId);
        if (rc == RV_OK)
			rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_SPEAKER, termId);
       
		break;
#ifdef RV_MTF_VIDEO
	case RV_CCTERMINALTYPE_VT:

		rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_CAMERA, termId);
        if (rc == RV_OK)
			rc = mcHelperConnectRtpToDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, termId);
        break;
#endif
		
    case RV_CCTERMINALTYPE_EPHEMERAL:
		rc = mcHelperConnectRtpToRtp( context, termIdSrc, termId);
        break;
		
    case RV_CCTERMINALTYPE_UI:
	case RV_CCTERMINALTYPE_UNKNOWN:
        break;

	default:
		IppLogMessage(rvTrue, "MtfRtpConnect:: Unknown terminal type - %d", termType);
    }
	
	return (rc == RV_OK);
}

/***************************************************************************
 * rtpDisconnect
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrDisconnectCB
 *
 ***************************************************************************/
RvBool MtfRtpDisconnect(   RvMdmTermMgr *mgr,
	                        RvMdmTerm *source,
                            RvMdmMediaStream *m1,
                            RvMdmTerm *target,
                            RvMdmMediaStream *m2,
	                        RvMdmError *mdmError)
{
	RvStatus        rc = RV_ERROR_UNKNOWN;
	const char*		termIdSrc = rvMdmTermGetId( source); /*it may be  termination  device or RTP */
	const char*		termId = rvMdmTermGetId( target); /*it's always termination representing RTP */
	RvMdmTermType	srcType = rvMdmTermGetType( source);
    void*           context;
    RvIppTerminalHandle ccTerminalEph;

	RV_UNUSED_ARG(mgr);
	RV_UNUSED_ARG(mdmError);
	RV_UNUSED_ARG(m1);
	RV_UNUSED_ARG(m2);

    IppLogMessage(rvFalse,"********* MtfRtpDisconnect() is Called for terms: source=%s and target=%s", termIdSrc, termId);   
    
    if(g_param.bDisableMedia)
	    return rvTrue;

    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( target);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);

    switch(srcType)
    {
    case RV_MDMTERMTYPE_PHYSICAL:
        if(!strcmp( termIdSrc, "at/hs"))
        {
    	    rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_MIC, termId);
            if (rc == RV_OK)
    		rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_SPEAKER, termId);
        }
        else if(!strcmp( termIdSrc, "vt/cam"))
        {
       	    rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_CAMERA, termId);
            if (rc == RV_OK)
    		rc = mcHelperDisconnectRtpFromDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, termId);
        }
        break;

    case RV_MDMTERMTYPE_EPHEMERAL:
		rc = mcHelperDisconnectRtpFromRtp( context, termIdSrc, termId);
        break;

    case RV_MDMTERMTYPE_UNKNOWN:
        break;
    }

	return (rc == RV_OK);
}

/******************************************************************************
*  MtfRtpCreateMedia
*  ----------------------------
*  General :        Media CB for TK. Used in version with MediaFrameWork
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         rvTrue on success.
******************************************************************************/
RvBool MtfRtpCreateMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,           /*obsolete*/
							 RvMdmMediaStreamDescr* streamDescr,/*obsolete except field: param*/
							 OUT RvMdmError* mdmError           /*obsolete*/
                             )
{
    RvSdpMsg    msgAvailable;
    RvMdmMediaParam* param= &streamDescr->param;
    void*           context;
    RvIppTerminalHandle ccTerminalEph;

    const char* termId  = rvMdmTermGetId( term);
    RvSdpMsgList	*sdpListLocal	= rvMdmMediaStreamDescrGetLocalDescr(streamDescr);
    RvSdpMsgList	*sdpListRemote	= rvMdmMediaStreamDescrGetRemoteDescr(streamDescr);
    RvSdpMsg		*msgLocal		= NULL;
    RvSdpMsg		*msgRemote		= NULL;
    
     IppLogMessage(rvFalse,"********* MtfRtpCreateMedia() is Called with mode = %s (term = %s)", 
        rvCCTextStreamMode(rvMdmMediaStreamDescrGetMode(streamDescr)), termId);
    
    msgLocal = rvSdpMsgListGetElement( sdpListLocal, 0);
    
    printSdp( msgLocal, "********* MtfRtpCreateMedia() is Called with Local SDP:");
    
    if (sdpListRemote != NULL)
    {
        msgRemote = rvSdpMsgListGetElement( sdpListRemote, 0);
        
        printSdp( msgRemote, "********* MtfRtpCreateMedia() is Called with Remote SDP:");
    }
    else
    {
        IppLogMessage(rvFalse, "********* MtfRtpCreateMedia() is Called with Remote SDP: <empty>");
    }    
    
    RV_UNUSED_ARG(media);
	RV_UNUSED_ARG(mdmError);

    msgLocal		= param->normal.localSdp;
    msgRemote		= param->normal.remoteSdp;

    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( term);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);

    if (param->cmd != RVMDM_CMD_CREATE)
        goto err_exit;

    rvSdpMsgConstruct( &msgAvailable);
    defaultGetMediaAvailable( &msgAvailable);
	if (msgRemote == NULL)
	{
		/* This is an outgoing invite. Change the localMedia, which is currently
		   equal to the media capabilities, to contain the media of outgoing invite */
		RvSize_t		i;
		RvSdpMediaDescr	*descrOfInvite;
		RvSdpMsg        *sdpOfInvite;
	
		rvSdpMsgClearMediaDescr(msgLocal);
		sdpOfInvite =  g_param.sdpForInvite;

		for(i=0; i < rvSdpMsgGetNumOfMediaDescr( sdpOfInvite); ++i)
		{
			descrOfInvite = rvSdpMsgGetMediaDescr( sdpOfInvite, i);
			rvSdpMsgInsertMediaDescr ( msgLocal, descrOfInvite);
		}
	}

    /*user Media Negotiation*/
    if (!g_param.mediaNegotiate( msgLocal, msgRemote, &msgAvailable, NULL))
		goto err_exit;

    /*call Media Framework*/
    if(msgLocal)
    {
        if(rvSdpMsgGetNumOfMediaDescr (msgLocal))
        {
            if(!g_param.bDisableMedia)
            {
                RvStatus    rc;
                CHECK_FUNC( mcHelperCreateRtpLocal(context,  (RvUint32)term, rvMdmTermGetId( term), msgLocal));
            }
        }
        else
            goto err_exit;
    }

    if(msgRemote)
    {
        if(rvSdpMsgGetNumOfMediaDescr (msgRemote))
        {
            if(!g_param.bDisableMedia)
            {
              RvStatus    rc;
              CHECK_FUNC( mcHelperModifyRtpRemoteBySdp( context, 
                                                        (RvUint32)term, 
                                                        rvMdmTermGetId( term), 
                                                        msgRemote));
            }
        }
        else
            goto err_exit;
    }
    rvSdpMsgDestruct( &msgAvailable);

    return rvTrue;
err_exit:
    rvSdpMsgDestruct( &msgAvailable);
	IppLogMessage(rvTrue,"rtpCreateMedia() failed. term= %p", term );
    return rvFalse;
}

/******************************************************************************
*  MtfRtpModifyMedia
*  ----------------------------
*  General :        Media CB for TK. Used in version with MediaFrameWork
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         rvTrue on success.
******************************************************************************/
RvBool MtfRtpModifyMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,
							 RvMdmMediaStreamDescr* streamDescr,
                             RvMdmError* mdmError)
{
    RvStatus    rc;
    RvMdmMediaParam* param     = &streamDescr->param;
    void*           context;
    RvIppTerminalHandle ccTerminalEph;
    const char* termId  = rvMdmTermGetId( term);

    RvSdpMsgList	*sdpListLocal	= rvMdmMediaStreamDescrGetLocalDescr(streamDescr);
    RvSdpMsgList	*sdpListRemote	= rvMdmMediaStreamDescrGetRemoteDescr(streamDescr);
    RvSdpMsg		*msgLocal		= NULL;
    RvSdpMsg		*msgRemote		= NULL;
    
    IppLogMessage(rvFalse,"********* MtfRtpModifyMedia() is Called with mode = %s (term = %s)", 
                rvCCTextStreamMode(rvMdmMediaStreamDescrGetMode(streamDescr)), termId);

    msgLocal = rvSdpMsgListGetElement( sdpListLocal, 0);
    
    printSdp( msgLocal, "********* MtfRtpModifyMedia() is Called with Local SDP:");

    if (sdpListRemote != NULL)
    {
        msgRemote = rvSdpMsgListGetElement( sdpListRemote, 0);
        
        printSdp( msgRemote, "********* MtfRtpModifyMedia() is Called with Remote SDP:");
    }
    else
    {
        IppLogMessage(rvFalse, "********* MtfRtpModifyMedia() is Called with Remote SDP: <empty>");
    }

	RV_UNUSED_ARG(media);
	RV_UNUSED_ARG(mdmError);

    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( term);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);


    /*call Media Framework*/
    switch( param->cmd)
    {
    case RVMDM_CMD_MUTE_ALL:
    case RVMDM_CMD_UNMUTE_ALL:
        if(g_param.bDisableMedia)
        {
		    rc = RV_OK;
		    break;
        }
		rc = mcHelperModifyRtpRemote( context, (RvUint32)term, 
                                      termId,
                                      param->mute_all.remoteSdp,
                                      param->cmd);
        break;

    case RVMDM_CMD_HOLD_REMOTE:
    case RVMDM_CMD_UNHOLD_REMOTE:
    case RVMDM_CMD_HOLD_LOCAL_TO_INACTIVE:
    case RVMDM_CMD_UNHOLD_INACTIVE_TO_LOCAL:
        if(g_param.bDisableMedia)
        {
		    rc = RV_OK;
		    break;
        }
        rc = mcHelperModifyRtpRemote( context, (RvUint32)term,
                                      termId,
                                      param->hold_remote.remoteSdp,
                                      param->cmd);
        break;

    case RVMDM_CMD_HOLD_LOCAL:
    case RVMDM_CMD_UNHOLD_LOCAL:
    case RVMDM_CMD_HOLD_REMOTE_TO_INACTIVE:
    case RVMDM_CMD_UNHOLD_INACTIVE_TO_REMOTE:
        if(g_param.bDisableMedia)
        {
		    rc = RV_OK;
            break;
        }
        rc = mcHelperModifyRtpLocal( context, (RvUint32)term,
                                     termId,
                                     param->hold_local.localSdp,
                                     param->cmd);
        break;

    case RVMDM_CMD_NORMAL:
        {
            RvSdpMsg    msgAvailable;
	        RvSdpMsg	*msgLocal	= param->normal.localSdp;
	        RvSdpMsg	*msgRemote	= param->normal.remoteSdp;

            rvSdpMsgConstruct( &msgAvailable);
            defaultGetMediaAvailable( &msgAvailable);

            /*user Media Negotiation*/
			if (!g_param.mediaNegotiate( msgLocal, msgRemote, &msgAvailable, NULL))
			{ 
				rc = RV_ERROR_UNKNOWN;
				rvSdpMsgDestruct( &msgAvailable);
				break;
			}
			else
				rvSdpMsgDestruct( &msgAvailable);

            if(g_param.bDisableMedia)
            {
			    rc = RV_OK;
			    break;
            }
           /*call Media Framework*/
            rc = mcHelperModifyRtpLocalBySdp( context, (RvUint32)term, 
                                              termId, 
                                              param->normal.localSdp);
            if(rc != RV_OK)
                break;
            rc = mcHelperModifyRtpRemoteBySdp( context, (RvUint32)term, 
                                               termId, 
                                               param->normal.remoteSdp);
        }
        break;

    case RVMDM_CMD_IDLE:
    case RVMDM_CMD_CREATE:
    case RVMDM_CMD_UNKNOWN:
    default:
        rc = RV_ERROR_UNKNOWN;
    }

    return (rc == RV_OK);
}



/******************************************************************************
*  MtfRtpDestroyMedia
*  ----------------------------
*  General :        Media CB for TK. Used in version with MediaFrameWork
*
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*
*  Output:         rvTrue on success.
******************************************************************************/
RvBool MtfRtpDestroyMedia( RvMdmTerm *term, RvMdmMediaStream *media, OUT RvMdmError *mdmError)
{
	RvBool		rc;
    void*           context;
    RvIppTerminalHandle ccTerminalEph;

	RV_UNUSED_ARG(media);
	RV_UNUSED_ARG(mdmError);

    IppLogMessage(rvFalse,"********* MtfRtpDestroyMedia() is Called for term = %s", rvMdmTermGetId(term));   

    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( term);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);

    if(g_param.bDisableMedia)
        return rvTrue;
	rc = (RV_OK == mcHelperDestroyRtp( context, rvMdmTermGetId(term)));

	return rc;
}

RvBool MtfPhysCreateMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,           /*obsolete*/
							 RvMdmMediaStreamDescr* streamDescr,/*obsolete except field: param*/
							 OUT RvMdmError* mdmError           /*obsolete*/)
{
    const char* id = rvMdmTermGetId( term);
     void*      context;
    RvIppTerminalHandle ccTerminalEph;

	RV_UNUSED_ARG(media);
	RV_UNUSED_ARG(streamDescr);
	RV_UNUSED_ARG(mdmError);

    IppLogMessage(rvFalse,"********* MtfPhysCreateMedia() is Called for term = %s", id);   

    if(g_param.bDisableMedia)
			return rvTrue;
    
    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( term);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);

    if(!strcmp( id,"vt/cam"))
    {
        mediaEnableDev( context, RVIPP_MEDIA_DEV_CAMERA, rvTrue);
        mediaEnableDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, rvTrue);
    }
    else
    {
        mediaEnableDev( context, RVIPP_MEDIA_DEV_MIC, rvTrue);
        mediaEnableDev( context, RVIPP_MEDIA_DEV_SPEAKER, rvTrue);
    }

	return rvTrue;
}

RvBool MtfPhysModifyMedia(struct RvMdmTerm_* term,
                             RvMdmMediaStream* media,
							 RvMdmMediaStreamDescr* streamDescr,
                             RvMdmError* mediaError)
{
	RV_UNUSED_ARG(term);
	RV_UNUSED_ARG(media);
	RV_UNUSED_ARG(streamDescr);
	RV_UNUSED_ARG(mediaError);

    IppLogMessage(rvFalse,"********* MtfPhysModifyMedia() is Called for term = %s", rvMdmTermGetId(term));   

	return rvTrue;
}

RvBool MtfPhysDestroyMedia(RvMdmTerm *term, RvMdmMediaStream *media, OUT RvMdmError *mdmError)
{
    const char* id = rvMdmTermGetId( term);
    void*      context;
    RvIppTerminalHandle ccTerminalEph;

	RV_UNUSED_ARG(media);
	RV_UNUSED_ARG(mdmError);

    IppLogMessage(rvFalse,"********* MtfPhysDestroyMedia() is Called for term = %s", id);   

    if(g_param.bDisableMedia)
			return rvTrue;
    
    /*
    * extract context from target (RTP termination)
    */
    ccTerminalEph = rvIppMdmTerminalGetHandle( term);
    context = rvIppMdmTerminalGetUserData ( ccTerminalEph);

    if(!strcmp( id,"vt/cam"))
    {
        mediaEnableDev( context, RVIPP_MEDIA_DEV_CAMERA, rvFalse);
        mediaEnableDev( context, RVIPP_MEDIA_DEV_DISPLAY_WINDOW, rvFalse);
    }
	else
    {
        mediaEnableDev( context, RVIPP_MEDIA_DEV_MIC, rvFalse);
        mediaEnableDev( context, RVIPP_MEDIA_DEV_SPEAKER, rvFalse);
    }
	return rvTrue;
}


/******************************************************************************
*  mediaEnableDev
*  ----------------------------
*  General :     Open or close specified device. See list of supported devices above
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*   devId           -   device id.
*   bEnable         -   rvTrue  - open device,
*                       rvFalse - close device
*
*  Input:
*
******************************************************************************/
static RvStatus mediaEnableDev( void* context, RvIppMediaDevice devId, RvBool bEnable)
{

	IppLogMessage(rvFalse,"mediaEnableDev(devId=%d, bEnable=%d)", devId, bEnable);

    if (devId <= RVIPP_MEDIA_DEV_MIN && devId >= RVIPP_MEDIA_DEV_MAX)
    {
        IppLogMessage(rvTrue,"mediaEnableDev(devId=%d, bEnable=%d) failed. devId out of range", devId, bEnable);
        return RV_ERROR_UNKNOWN;
    }

	if (bEnable)
    {
        return mcHelperOpenDev(context, devId);
    }
	else
    {
        return mcHelperCloseDev( context, devId);
    }
	IppLogMessage(rvFalse,"mediaEnableDev()=0");

    return RV_OK;
}



static int rvccmdmmediacb_dummy = 0;
