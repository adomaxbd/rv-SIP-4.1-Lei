/******************************************************************************
Filename:    IppSampleUserClbks.c
Description: Implementations for user Extension APIs
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************
$Revision:$
$Date:   03.02.05$
$Author: Yochi Moran$
******************************************************************************/
#include "IppStdInc.h"
#include "rvmdm.h"
#include "rvMdmControlApi.h"
#include "IppSampleGatewayBase.h"
#include "IppSamplePhoneLink.h"
#include "IppSampleSipGateway.h"
#include "ippthread.h"
#ifdef RV_MTF_VIDEO
#include "rvMdmControlVideoApi.h"
#endif
#include "rvccconnmdm.h"

#define USER_CCTERMEVENT_BACKSPACE      (RV_CCTERMEVENT_USER + 1)
#define USER_CCTERMEVENT_FLASH          (RV_CCTERMEVENT_USER + 2)

#define DISPLAY_BUFFER_SIZE         64

char g_displayRegisterStatus[RV_MEDIUM_STR_SZ] = "Register: <Not Defined>";
char emptyLine[50] = {"                                        "};

extern RvIppSampleGatewayBase*   pgw;
extern RvIppSampleGateway	     gw;


/*===============================================================================*/
/*==========        P R I V A T E           F U N C T I O N S       =============*/
/*===============================================================================*/

static RvIppDisplayRawsOrder mapLineIdToRaw(int lineId)
{
    if (lineId == 1)
        return RVIPP_RAW_LINE1_STATUS;
    else
        return RVIPP_RAW_LINE2_STATUS;
}

static void clearLineStatus(RvIppTerminalHandle termHndl, int raw)
{
    rvIppMdmTerminalSetDisplay(termHndl, emptyLine, raw, RVIPP_DISPLAY_COLUMN_LINE);
    rvIppMdmTerminalSetDisplay(termHndl, emptyLine, raw+1, RVIPP_DISPLAY_COLUMN_LINE);
}

static void userDisplayCallerId(RvIppConnectionHandle       connHndl,
                                RvIppTerminalHandle         termHndl,
                                char*                       prefix,
                                int                         raw,
                                int                         column)
{
    RvMdmTermPresentationInfo   presentationInfo;
    RvChar callerId[128];

    rvIppMdmConnGetRemotePresentationInfo(connHndl, &presentationInfo);

    if ((rvMdmTermPresentationInfoGetName(&presentationInfo, callerId,
                                                    sizeof(callerId))) == rvFalse)
    {
        if ((rvIppMdmConnGetCallerId(connHndl, callerId, sizeof(callerId))) == rvFalse)
            if ((rvIppMdmConnGetCallerName(connHndl, callerId, sizeof(callerId))) == rvFalse)
                strcpy(callerId, "No Name");
    }
    else
    {
        RvMdmTermPresentationType permit;

        permit = rvMdmTermPresentationInfoGetCallerPermission(&presentationInfo);

        switch (permit)
        {
        case RV_MDM_PRSENTATION_RESTRICTED:
            strcpy(callerId, "Restricted"); break;
        case RV_MDM_ADDRESS_NOT_AVAILABLE:
            strcpy(callerId, "Anonymous"); break;
        case RV_MDM_PRSENTATION_ALLOWED:
        case RV_MDM_PRSENTATION_NONE:
            break;
        }
    }

    clearLineStatus(termHndl, raw);
    rvIppMdmTerminalSetDisplay(termHndl, prefix, raw, column);
    rvIppMdmTerminalSetDisplay(termHndl, callerId, raw+1, column);
}

static void userDisplayRemotePartyId(RvIppConnectionHandle      connHndl,
                                RvIppTerminalHandle         termHndl,
                                char*                       message,
                                int                         raw,
                                int                         column)
{
    RvMdmTermPresentationInfo   presentationInfo;
    char calleeId[RV_NAME_STR_SZ];

    /* Display presentation info only if exists */
    if ((rvIppMdmConnGetRemotePresentationInfo(connHndl, &presentationInfo)) == RV_TRUE)
    {
        if ((rvMdmTermPresentationInfoGetName(&presentationInfo, calleeId, sizeof(calleeId))) == rvFalse)
        {
                if ((rvIppMdmConnGetCallerId(connHndl, calleeId, sizeof(calleeId))) == RV_FALSE)
                if ((rvIppMdmConnGetCallerName(connHndl, calleeId, sizeof(calleeId))) == rvFalse)
                    strcpy(calleeId, "No Name");
        }
        else
        {
            RvMdmTermPresentationType permit;

            permit = rvMdmTermPresentationInfoGetCalleePermission(&presentationInfo);

            switch (permit)
            {
            case RV_MDM_PRSENTATION_RESTRICTED:
                        strcpy(calleeId, "Restricted");
                        break;
            case RV_MDM_ADDRESS_NOT_AVAILABLE:
                        strcpy(calleeId, "Anonymous");
                        break;
            case RV_MDM_PRSENTATION_ALLOWED:
                if ((rvMdmTermPresentationInfoGetName(&presentationInfo, calleeId, sizeof(calleeId))) == rvFalse)
                    strcpy(calleeId, "No Name");
                break;
            case RV_MDM_PRSENTATION_NONE:
                strcpy(calleeId, "");
                break;
            default:
                strcpy(calleeId, "");
                break;
            }
        }
        rvIppMdmTerminalSetDisplay(termHndl, calleeId, raw+1, column);
    }

    clearLineStatus(termHndl, raw);
    rvIppMdmTerminalSetDisplay(termHndl, message, raw, column);
}


static RvBool uiTermDisplay(RvIppConnectionHandle       connHndl,
                                RvIppTerminalHandle     termHndl,
                                RvCCTerminalEvent       event,
                                RvCCEventCause          cause,
                                void*                   displayData) {

    char buf[DISPLAY_BUFFER_SIZE];
    char dialString[128];
    RvCCConnState state = rvIppMdmConnGetState(connHndl);
    RvBool keepDisplay = rvFalse;
    char userDisplay[136] = "";
/*  RvIppConnectionHandle activeConn = rvIppMdmTerminalGetActiveConnection(termHndl);*/
    int lineId = rvIppMdmConnGetLineId(connHndl);


    RV_UNUSED_ARG(cause);
    RV_UNUSED_ARG(displayData);

    switch (event)
    {
    case RV_CCTERMEVENT_OFFHOOK:

        break;

        case RV_CCTERMEVENT_HOLD:
            if (state == RV_CCCONNSTATE_CONNECTED)
            {
                rvIppMdmTerminalSetDisplay(termHndl, emptyLine, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                userDisplayRemotePartyId(connHndl, termHndl, "On Hold", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_UNHOLD:
        /* No break*/
        case RV_CCTERMEVENT_CALLANSWERED:
            if (state == RV_CCCONNSTATE_CONNECTED)
            {
                RvCCConnMdm* mdmConn = rvCCConnMdmGetIns((RvCCConnection*) connHndl);
                rvIppMdmTerminalSetDisplay(termHndl, emptyLine, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                strncpy(dialString, rvStringGetData(&mdmConn->dialString), sizeof(dialString));
                 dialString[sizeof(dialString)-1] = '\0';

                sprintf(userDisplay, "Talking:%s", dialString);
                rvIppMdmTerminalSetDisplay(termHndl, userDisplay, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);

            //  userDisplayRemotePartyId(connHndl, termHndl, "Connected:", mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;

        case RV_CCTERMEVENT_RINGING:
            if (state == RV_CCCONNSTATE_ALERTING)
            {
                userDisplayCallerId(connHndl, termHndl, "Call From:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                keepDisplay = rvTrue;
            }
            break;
        case RV_CCTERMEVENT_RINGBACK:
            if (state == RV_CCCONNSTATE_CALL_DELIVERED)
            {
                userDisplayRemotePartyId(connHndl, termHndl, "Calling:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_DIGITS:
            if (state == RV_CCCONNSTATE_DIALING)
            {
                RvSize_t dialStringLength;
                rvIppMdmTerminalGetDialString(termHndl, dialString, sizeof(dialString));
                dialStringLength = strlen(dialString);
                /* First digit */
                if (dialStringLength == 1)
                {
                    //  rvIppMdmTerminalClearDisplay(termHndl);
                    rvIppMdmTerminalSetDisplay(termHndl, emptyLine, (int)mapLineIdToRaw(lineId), (int)strlen("Dial:")+(int)RVIPP_DISPLAY_COLUMN_LINE+2);
                }
                if (dialStringLength > 0)
                {
                    /* Echo digit */
                    buf[0] = dialString[dialStringLength - 1];
                    buf[1] = '\0';
                    rvIppMdmTerminalSetDisplay(termHndl, buf, (int)mapLineIdToRaw(lineId), (int)strlen(dialString)+(int)strlen("Dial:")+(int)RVIPP_DISPLAY_COLUMN_LINE+2);
                }
            }
            break;
        case RV_CCTERMEVENT_DIALTONE:
            if (state == RV_CCCONNSTATE_DIALING)
            {
                if (rvIppMdmTerminalGetState(termHndl) == RV_CCTERMINAL_CFW_ACTIVATING_STATE)
                {
                    rvIppMdmTerminalSetDisplay(termHndl, emptyLine, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                /*  rvIppMdmTerminalSetDisplay(termHndl, "CFW", (int)RVIPP_RAW_CFW, 0);*/
                    rvIppMdmTerminalSetDisplay(termHndl, "CFW:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                }
                else
                {
                    rvIppMdmTerminalSetDisplay(termHndl, "Dial:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                }
            }
            break;
        case RV_CCTERMEVENT_DIALCOMPLETED:
            if (state == RV_CCCONNSTATE_ADDRESS_ANALYZE)
            {

                RvCCConnMdm* mdmConn = rvCCConnMdmGetIns((RvCCConnection*) connHndl);
                clearLineStatus(termHndl, (int)mapLineIdToRaw(lineId));

            // at this stage mdm term dial string has already been reset, take it from the connection
            //  rvIppMdmTerminalGetDialString(termHndl, dialString, sizeof(dialString));


                strncpy(dialString, rvStringGetData(&mdmConn->dialString), sizeof(dialString));
                 dialString[sizeof(dialString)-1] = '\0';

                sprintf(userDisplay, "Calling %s", dialString);
                rvIppMdmTerminalSetDisplay(termHndl, userDisplay, (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            //  userDisplayRemotePartyId(connHndl, termHndl, "Trying:", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            else if ((state == RV_CCCONNSTATE_FAILED) && (cause == RV_CCCAUSE_NOT_FOUND))
            {
                rvIppMdmTerminalSetDisplay(termHndl, "Not Found", (int)mapLineIdToRaw(lineId)+1, (int)RVIPP_DISPLAY_COLUMN_LINE);
            }

            break;
        case RV_CCTERMEVENT_MEDIAFAIL:
            if (state == RV_CCCONNSTATE_FAILED)
            {
                clearLineStatus(termHndl, (int)mapLineIdToRaw(lineId));
                rvIppMdmTerminalSetDisplay(termHndl, "Media Failed!", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_DISCONNECTING:
            if (state == RV_CCCONNSTATE_DISCONNECTED)
            {
                clearLineStatus(termHndl, (int)mapLineIdToRaw(lineId));
                rvIppMdmTerminalSetDisplay(termHndl, "Idle", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_REMOTE_DISCONNECTED:
            if (state == RV_CCCONNSTATE_DISCONNECTED)
            {
                clearLineStatus(termHndl, (int)mapLineIdToRaw(lineId));
                if (cause == RV_CCCAUSE_BUSY)
                    userDisplayRemotePartyId(connHndl, termHndl, "Busy", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
                else
                    userDisplayRemotePartyId(connHndl, termHndl, "Disconnected", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            }
            break;
        case RV_CCTERMEVENT_ONHOOK:
            clearLineStatus(termHndl, (int)mapLineIdToRaw(lineId));
            rvIppMdmTerminalSetDisplay(termHndl, "Idle", (int)mapLineIdToRaw(lineId), (int)RVIPP_DISPLAY_COLUMN_LINE);
            break;
        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    return keepDisplay;
}

static void sendOffHookEvent(RvIppTerminalHandle terminalHndl)
{
    RvMdmTerm* mdmTerm = rvIppMdmTerminalGetMdmTerm(terminalHndl);
    RvMdmParameterList params;
    RvMdmPackageItem item;

    rvMdmParameterListConstruct(&params);
    rvMdmPackageItemConstruct(&item, "", "keyid");
    rvMdmParameterListOr(&params, &item, "kh");

    rvMdmTermProcessEvent(mdmTerm, "kf", "kd", NULL, &params);

    rvMdmPackageItemDestruct(&item);
    rvMdmParameterListDestruct(&params);
}

/*===============================================================================*/
/*=======  M D M    C A L L B A C K     I M P L E M E N T A T I O N S   =========*/
/*===============================================================================*/

void userCBDisplay(RvIppConnectionHandle    connHndl,
                    RvIppTerminalHandle     termHndl,
                    RvCCTerminalEvent       event,
                    RvCCEventCause          cause,
                    void*                   displayData)
{
    RvIppConnectionHandle activeConn = rvIppMdmTerminalGetActiveConnection(termHndl);
    RvBool keepDisplay;
    
    /* Process the event for the connection and the
       active connection if they are different */
    keepDisplay = uiTermDisplay(connHndl, termHndl, event, cause, displayData);
    if ((keepDisplay == rvFalse) && (activeConn != connHndl))
    {
        uiTermDisplay(activeConn, termHndl, event, cause, displayData);
    }

}

RvCCTerminalEvent userCBMapEvent(const char*        pkg,
                                 const char*        id,
                                 RvMdmParameterList *args,
                                 char*              key)
{

    RV_UNUSED_ARG(pkg);
    RV_UNUSED_ARG(args);
    RV_UNUSED_ARG(key);

    {
        /*Backspace implementation*/
        if (!strcmp(id, "bs"))
            return USER_CCTERMEVENT_BACKSPACE;

        else if (!strcmp(id, "flash"))
            return USER_CCTERMEVENT_FLASH;
    }

    return RV_CCTERMEVENT_NONE;
}


RvCCTerminalEvent userCBPreProcessEvent(
    IN RvIppConnectionHandle    connHndl,
    IN RvCCTerminalEvent        eventId,
    IN RvCCEventCause*          reason)
{
    RvIppTerminalHandle t = rvIppMdmConnGetTerminal(connHndl);

    RvCCTermConnState termState = rvIppMdmConnGetTermState(connHndl);

    RvCCConnState connState = rvIppMdmConnGetState(connHndl);

    IppLogMessage(RV_FALSE, "userCBPreProcessEvent: event=%d, termState=%d, connState=%d", eventId, termState, connState);

    RV_UNUSED_ARG(reason);

    switch (eventId)
    {

    /*-----------------------------------------*/
    /*----- Reset Terminal---------------------*/
    /*-----------------------------------------*/
        case RV_CCTERMEVENT_GW_ACTIVE:
        {
            /* Reset signals and indicators*/
            rvIppMdmTerminalStopSignals(t);
            rvIppMdmTerminalStopRingingSignal(t);
            rvIppMdmTerminalSetHoldInd(t, rvFalse);
            rvIppMdmTerminalSetLineInd(t, 1, 1);
            rvIppMdmTerminalSetLineInd(t, 2, 1);
            rvIppMdmTerminalClearDisplay(t);

            /* Display logo*/
            /* Display Lines states*/
#ifdef RV_MTF_MEDIA
            rvIppMdmTerminalSetDisplay(t, "Media", 1, 27);
#else
            rvIppMdmTerminalSetDisplay(t, "NoMedia", 1, 27);
#endif
            rvIppMdmTerminalSetDisplay(t, "...................", (int)RVIPP_RAW_LOGO_SEPERATOR1, 0);
            rvIppMdmTerminalSetDisplay(t, "1>> Idle", (int)RVIPP_RAW_LINE1_STATUS, 0);
            rvIppMdmTerminalSetDisplay(t, "2>> Idle", (int)RVIPP_RAW_LINE2_STATUS, 0);
            rvIppMdmTerminalSetDisplay(t, "...................", (int)RVIPP_RAW_LINE2_CALLER+1, 0);

            /* Registration status was stored previously by SIP user callback (userSipPreRegClientStateChanged)
               in a global string (g_displayRegisterStatus), since we don't have access
               to SIP data from this Common adaptor*/
            rvIppMdmTerminalSetDisplay(t, g_displayRegisterStatus, (int)RVIPP_RAW_REGISTER_STATUS, 0);
        }

        break;

    /*-----------------------------------------*/
    /*----- Reject a Call ---------------------*/
    /*-----------------------------------------*/
    /*  case RV_CCTERMEVENT_MAKECALL:

            *reason  = RV_CCCAUSE_CALL_CANCELLED;
            return RV_CCTERMEVENT_REJECTCALL;
        break;
    */
    /*-----------------------------------------*/
    /*----- Backspace -------------------------*/
    /*-----------------------------------------*/

    /*  case USER_CCTERMEVENT_BACKSPACE:
        {
            RvIppTerminalHandle t = rvIppMdmConnGetTerminal(connHndl);
            char dialString[128];

            rvIppMdmTerminalGetDialString(t, dialString, 128);

    //      if (strcmp(dialString, "")) {
                rvStringResize(&term->dialString,rvStringGetSize(&term->dialString)-1);
            }
    //

            return RV_CCTERMEVENT_NONE;

        }
        break;
    */
    /*-----------------------------------------*/
    /*----- Disable Call Waiting --------------*/
    /*-----------------------------------------*/

    /*  case RV_CCTERMEVENT_RINGING:
        {
            RvCCTermConnState termState = rvIppMdmConnGetTermState(connHndl);

            if (termState == RV_CCTERMCONSTATE_BRIDGED)
            {
                *reason = RV_CCCAUSE_BUSY;

                //Stop Call Waiting tone...

                return RV_CCTERMEVENT_REJECTCALL;
            }
        }
        break;
    */

    /*-----------------------------------------*/
    /*----- Automatic Disconnect --------------*/
    /*-----------------------------------------*/

        case RV_CCTERMEVENT_REMOTE_DISCONNECTED:
        if (pgw->autoAnswer)
        {
            RvCCTermConnState termState = rvIppMdmConnGetTermState(connHndl);

            if (termState == RV_CCTERMCONSTATE_TALKING)
            {
                return RV_CCTERMEVENT_ONHOOK;
            }
        }
        break;


    /*-----------------------------------------*/
    /*----- Automatic Answer ------------------*/
    /*-----------------------------------------*/

    /*  case RV_CCTERMEVENT_MAKECALL:

          return RV_CCTERMEVENT_OFFHOOK;
        break;
*/
    /*-----------------------------------------*/
    /*----- Ignore Hold in Conference----------*/
    /*-----------------------------------------*/

/*      case RV_CCTERMEVENT_HOLD:
        {
            RvCCCallState callState = rvIppMdmConnGetCallState(connHndl);
            if (callState == RV_CCCALLSTATE_CONFERENCE_COMPLETED)
                return RV_CCTERMEVENT_NONE;
        }
        break;
*/
    /*-----------------------------------------*/
    /*----- Get SIP Call Leg  -----------------*/
    /*-----------------------------------------*/

/*      case USER_CCTERMEVENT_FLASH:
        {
            This code requires adding:
            #include "RvSipCallLegTypes.h"
            #include "rvSipControlApi.h"
            RvIppConnectionHandle sipConnHndl = rvIppMdmConnGetConnectParty(connHndl);
            RvSipCallLegHandle sipCallLeg = rvIppSipControlGetCallLeg(sipConnHndl);

        }
        break;
*/
/* Replace with a button:
#ifdef RV_MTF_VIDEO
        case RV_CCTERMEVENT_TESTFASTUPDATE:
        {
            static int count=0;
            switch (count % 4)
            {
            case 0:
                RvLogInfo(ippLogSource,(ippLogSource,"***Sending VideoFastUpdatePicture::terminal(%p) ", t));
                rvIppMdmSendFastUpdatePicture((RvIppTerminalHandle) t);
                break;
            case 1:
                RvLogInfo(ippLogSource,(ippLogSource,"***Sending VideoFastUpdateGob::terminal(%p) firstGob:%d numGobs:%d",
                                     t, count, count));
                rvIppMdmSendFastUpdateGOB((RvIppTerminalHandle) t, count, count);
                break;
            case 2:
                RvLogInfo(ippLogSource,(ippLogSource,"***Sending VideoFastUpdateMb::terminal(%p) firstGob:%d firstMb:%d numMbs:%d",
                                     t, count, count, count));
                rvIppMdmSendFastUpdateMB((RvIppTerminalHandle)  t, count, count, count );
                break;
            case 3:
                RvLogInfo(ippLogSource,(ippLogSource,"***Sending VideoFastUpdatePictureFreeze::terminal(%p) ", t));
                rvIppMdmSendFastUpdatePictureFreeze((RvIppTerminalHandle)   t);
                break;
            }
            ++count;
        }
#endif
*/

    default:
        return eventId;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    return eventId;

}

void userCBPostProcessEvent(RvIppConnectionHandle   connHndl,
                             RvCCTerminalEvent      eventId,
                             RvCCEventCause         reason)
{
    RvIppTerminalHandle termHndl = rvIppMdmConnGetTerminal(connHndl);

    RV_UNUSED_ARG(reason);

    switch (eventId)
    {
    /*-----------------------------------------*/
    /*----- Automatic Answer ------------------*/
    /*-----------------------------------------*/

        case RV_CCTERMEVENT_RINGING:
            if (pgw->autoAnswer)
            {
                sendOffHookEvent(termHndl);
            }

        break;

/*  case RV_CCTERMEVENT_ONHOOK: */
        /*-----------------------------------------*/
        /*-------  Line on Hold alert      --------*/
        /*-----------------------------------------*/

        /* The following code causes a terminal to ring if one call was disconnected
           and another call is on hold. It alerts the user that another call
           is on hold.
           The terminal will not ring if a call is on hold because of transfer or
           conference activation  */

    /*  if (rvIppMdmTerminalOtherHeldConnExist(termHndl, connHndl) == rvTrue)
            {
                RvIppConnectionHandle heldConn;
                RvCCCallState  callState;
            RvInt32         lineId;

                heldConn = rvIppMdmTerminalGetHeldConn(termHndl, &lineId);
                callState = rvIppMdmConnGetCallState(heldConn);
                if (callState == RV_CCCALLSTATE_NORMAL)
                    rvIppMdmTerminalStartRingingSignal(termHndl);
            }

        break;*/
/*    case RV_CCTERMEVENT_UNHOLD:*/
        /*-----------------------------------------*/
        /*-------  Line on Hold alert      --------*/
        /*-----------------------------------------*/
        /* In case the Line on Hold alert was uncommented in the RV_CCTERMEVENT_ONHOOK
           case above, open the comment here as well. This code stops the ringing that was
           started when a line was in hold while the active call was disconnected.
           Note: Some user applications may need to set a flag when starting ringing
           and check it here before stopping the signal to avoid cases when a signal is
           stopped without being activated.*/
    /*  rvIppMdmTerminalStopRingingSignal(termHndl);

        break;*/

        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }
}

void userCBConnectionCreated(RvIppConnectionHandle connHndl)
{
    RV_UNUSED_ARG(connHndl);
    printf("ConnectionCreatedCB\n");
}

void userCBConnectionDestructed(RvIppConnectionHandle connHndl)
{
    RV_UNUSED_ARG(connHndl);

    /* DO NOT UNCOMMENT THE FOLLOWING.
    In case of SEMI-TRANSFER it does not working since it makes A to be ringing */
    /* RvIppTerminalHandle t = rvIppMdmConnGetTerminal(connHndl);

    if (rvIppMdmTerminalOtherHeldConnExist(t, connHndl) == rvTrue)
        rvIppMdmTerminalStartRingingSignal(t); */

}


RvIppMdmExtClbks  userMdmClbks =
{
    /*RvIppMdmDisplayCB                 display;*/
    userCBDisplay,
	/*void*						    	displayData; */
	NULL,
    /*RvIppMdmMapUserEventCB            mapUserEvent;*/
    userCBMapEvent,
    /*RvIppMdmPreProcessEventCB         preProcessEvent;*/
    userCBPreProcessEvent,
    /*RvIppMdmPostProcessEventCB        postProcessEvent;*/
    userCBPostProcessEvent,
    /*RvIppMdmConnectionCreatedCB       connectionCreated;*/
    userCBConnectionCreated,
    /*RvIppMdmConnectionDestructedCB    connectionDestructed;*/
    userCBConnectionDestructed
};



void userRegisterIppMdmExt(void)
{
    rvIppMdmRegisterExtClbks(&userMdmClbks);
}

