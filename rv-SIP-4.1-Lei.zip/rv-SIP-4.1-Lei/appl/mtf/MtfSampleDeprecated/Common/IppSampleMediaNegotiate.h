

/******************************************************************************
*  IppSampleMediaNegotiateCB
*  ----------------------------
*  General :     user CB to negotiate media.
*
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:        
*               
******************************************************************************/
RvBool MtfMediaNegotiate(  INOUT RvSdpMsg* msgLocal, 
                           INOUT RvSdpMsg* msgRemote, 
                           IN RvSdpMsg*    msgAvailable, 
                           IN void*        userData /*userData passed during RTP session creation*/);
