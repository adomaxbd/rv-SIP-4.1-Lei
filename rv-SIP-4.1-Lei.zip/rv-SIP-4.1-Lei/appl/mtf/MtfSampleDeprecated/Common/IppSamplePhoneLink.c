/******************************************************************************
Filename:    IppSamplePhoneLink.c
Description: Ip Phone termination handling
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#include "IppStdInc.h"
#include "ippthread.h"
#include "ippmisc.h"
#include "IppSamplePhoneLink.h"
#include "IppSampleGatewayBase.h"
#include "MtfMediaCallbacks.h"
#include "IppSampleSipUserClbks.h"
#include "rvstr.h"

#include "rvmdm.h"

#ifdef SAMPLE_MWI
#include "IppSampleSipMWI.h"
#endif

#define RV_UNREGISTER_AND_SHUTDOWN      1
#define RV_UNREGISTER_AND_RESTART       2

RV_BOOL notifyToStartWarmRestart = RV_FALSE;
RV_BOOL notifyToStartShutdown = RV_FALSE;
RV_BOOL unegisteredTerminationsLeft = RV_TRUE;

extern RvIppSampleGatewayBase*      pgw;
extern RV_BOOL                      startWarmRestart;
extern RV_BOOL                      startShutdown;

RvBool rvPhoneMgrMapDialStringToAddressCB(RvMdmTerm* term, const char* dialString, char* address);

/*--------------------------------------------------------------------------------*/
#if 0 //MARKA
RvPhoneLink *rvPhoneLinkConstruct(RvPhoneLink *x,  RvEppClientEndpoint *ece)
{
    x->endpoint = ece;
    return x;
}

void rvPhoneLinkDestruct(RvPhoneLink *x)
{
    RV_UNUSED_ARG(x);
}
#endif

static void cleanParam(char* str)
{
    int i=0;

    if (str[0] != '"')
        return;

    while (str[i] != '\0') {
        str[i] = str[i+1];
        ++i;
    }

    str[i-2] = '\0';

}
/******************************************************************************/
void rvPhoneMgrOnUnregister(RvEppClient*            ec,
                            RvEppClientEndpoint*    ece,
                            void*                   data,
                            char*                   params)
{
    RvPhoneMgr *phoneMgr = (RvPhoneMgr *)data;
    RvMdmTerm *termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
//MARKA     RvPhoneLink *phoneLink = (RvPhoneLink *)rvMdmTermGetUserData(termination);

    RV_UNUSED_ARG(ec);

   /*
     *  remove reference to phoneLink from termination
     *  remove reference to termination from ece
     */
    if (termination != NULL)
    {
        rvMdmTermSetUserData(termination,NULL);
    }

    rvEppClientEndpointSetUserData(ece, NULL);

    if (params != NULL)
    {
        cleanParam(params);

        if (atoi(params) == RV_UNREGISTER_AND_RESTART)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            notifyToStartWarmRestart = RV_TRUE;
        }
        else if (atoi(params) == RV_UNREGISTER_AND_SHUTDOWN)
        {
            /* This will cause main loop to stop sleeping and shutdown MTF */
            notifyToStartShutdown = RV_TRUE;
        }
    }

    if (ec->numEndpoints == 1)
    {
        unegisteredTerminationsLeft = RV_FALSE;
    }

    /*
     * unregister and delete termination
     */
    if (termination != NULL)
    {
        rvMdmTermMgrUnregisterTerminationAsync(phoneMgr->termMgr, termination, NULL);
    }
 /*
     * destroy and delete phoneLink
     */
//MARKA     rvPhoneLinkDestruct(phoneLink);
//MARKA     rvMtfAllocatorDealloc(phoneLink);
}

void rvIppSampleGatewayAddParam(RvMdmParameterList* list, char* paramName, char* paramValue)
{
    RvMdmPackageItem pkgItem;

    rvMdmPackageItemConstruct(&pkgItem, "", paramName);
    rvMdmParameterListOr(list, &pkgItem, paramValue);
    rvMdmPackageItemDestruct(&pkgItem);
}


void buildEventParamsList(RvMdmParameterList* list,  char* pkg,  char*id,
                                   char* params)
{
    RvStrTok tokenizer;
    char* val;
    RvIppCfwType typeNumber;

    if (!params)
        return;

    rvStrTokConstruct(&tokenizer, ",", params);
    if ((!strcmp(pkg, "kp")) ||  (!strcmp(pkg, "kf") ) || (!strcmp(pkg, "labelkey"))) {

        if (!strcmp(id, "kd")) {
            val = rvStrTokGetToken(&tokenizer);
            cleanParam(val);
            rvIppSampleGatewayAddParam(list, "keyid", val);
        }
        if (!strcmp(id, "ku")) {
            val = rvStrTokGetToken(&tokenizer);
            cleanParam(val);
            rvIppSampleGatewayAddParam(list, "keyid", val);
            /*simulateIppUserEvent(pkg, id, val); */
            val = rvStrTokGetToken(&tokenizer);
            if (val != NULL) {
                cleanParam(val);
                rvIppSampleGatewayAddParam(list, "duration", val);
            }
        }
    }
    if (!rvStrIcmp("ku",id))
    {
        if ((typeNumber = rvCCCfwGetTypeNumber(params)) != RV_IPP_CFW_TYPE_NONE) /* cfw type */
        {
            if (pgw->callForwardTypeIsActive[typeNumber] == rvFalse /* off */) /* Need to switch */
            {
                rvIppSampleGatewayAddParam(list, "activate", "on");
                if (typeNumber == RV_IPP_CFW_TYPE_NO_REPLY) /* update with timeout value in case of cfw no reply */
                {
                    rvIppSampleGatewayAddParam(list, "timeout", pgw->callForwardNoReplyTimeout);
                }
                pgw->callForwardTypeIsActive[typeNumber] = rvTrue;
            }
            else /* activate parameter is 'on' (1) */
            {
                rvIppSampleGatewayAddParam(list, "activate", "off");
                pgw->callForwardTypeIsActive[typeNumber] = rvFalse;
            }
        }
    }

    if ((!strcmp(pkg, "rvcc")) && (!strcmp(id, "reject")))
    {
        rvIppSampleGatewayAddParam(list, "keyid", params);
    }

    rvStrTokDestruct(&tokenizer);
}

/*
static void sendOffHookEvent(RvIppTerminalHandle    termHandle)
{
    RvMdmTerm* mdmTerm = rvIppMdmTerminalGetMdmTerm(termHandle);
    RvMdmParameterList params;
    RvMdmPackageItem item;

    rvMdmParameterListConstruct(&params);
    rvMdmPackageItemConstruct(&item, "", "keyid");
    rvMdmParameterListOr(&params, &item, "kh");

    rvMdmTermProcessEvent(mdmTerm, "kf", "kd", NULL, &params);

    rvMdmPackageItemDestruct(&item);
    rvMdmParameterListDestruct(&params);
}


static void sendOnHookEvent(RvIppTerminalHandle termHandle)
{
    RvMdmTerm* mdmTerm = rvIppMdmTerminalGetMdmTerm(termHandle);
    RvMdmParameterList params;
    RvMdmPackageItem item;

    rvMdmParameterListConstruct(&params);
    rvMdmPackageItemConstruct(&item, "", "keyid");
    rvMdmParameterListOr(&params, &item, "kh");

    rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &params);

    rvMdmPackageItemDestruct(&item);
    rvMdmParameterListDestruct(&params);
}
*/

void rvPhoneMgrOnEvent(RvEppClient *ec, RvEppClientEndpoint *ece, const char *eventName,
                            char* eventParams, void *data)
{
    RvMdmParameterList paramsList;
    RvStrTok tokenizer;
    char *dtmfDetect = "dd", *analogLine = "al";
    char ddEvent[] = "d?";
    char *pkg=NULL, *id=NULL;
    char event[32]="";
    char pkgName[32];
    RvBool sendEvent = rvTrue;

    RV_UNUSED_ARG(ec);
    RV_UNUSED_ARG(data);

    rvStrTokConstruct(&tokenizer, "/", (char*)eventName);
    pkg = rvStrTokGetToken(&tokenizer);
    id = rvStrTokGetToken(&tokenizer);

    if (pkg == NULL)
        return;

    /*no package, need to map event name and package*/
    if (id == NULL)
    {
        strcpy(event, pkg);
        if(!event[1] && event[0]) /* length of eventName == 1 */
        {
            pkg = dtmfDetect;
            id = ddEvent;
            if (event[0] == '*')
                ddEvent[1] = 's';
            else if(event[0] == '#')
                ddEvent[1] = 'o';
            else
                ddEvent[1] = event[0];
        }
        else if(!rvStrIcmp(event, "hd"))
            pkg = analogLine, id = "of";
        else if(!rvStrIcmp(event, "hu"))
            pkg = analogLine, id = "on";
        else if(!rvStrIcmp(event, "hf"))
            pkg = analogLine, id = "fl";
    }

    else if (!rvStrIcmp(pkg, "ks"))
    {
        if (!rvStrIcmp(id,  "ku"))
        {
            char tempStr[32];

            strcpy(tempStr,eventParams);
            cleanParam(tempStr);

            if(strstr(tempStr,"sk2")!=NULL)
            {
                /* pkg = "kf", eventParams = "kbt"; */


                /* The following code was used to test new API that handles unregistration of specific termination from network */
                /* It assumes that the 1st registration was done by the IPPTK using "Reconnect" button */

                RvMdmTerm *termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
                RvPhoneMgr *phoneMgr = (RvPhoneMgr *)data;
                rvMdmTermMgrUnregisterTermFromNetwork_(phoneMgr->termMgr, termination);
                sendEvent = rvFalse;
            }
        }
    }

    /* Dynamic media change - send Re-Invite */
    /* ------------------------------------- */
    else if (!rvStrIcmp(pkg, "modify_media"))
    {
		RvMdmTerm*          termination = NULL;
		RvSdpParseStatus    status;
		RvSdpMsg            sdpMsg;
		int                 len;
        char                tempStr[1024];

        /*No need to send an event to MDM*/
        sendEvent = rvFalse;
        cleanParam(id);

		strcpy(tempStr, eventParams);
        cleanParam(tempStr);

        len = strlen(tempStr);

        /* Use SDP message that was received in EPP message */
        if (!rvStrIcmp(id, "reinvite"))
        {
            if ((rvSdpMsgConstructParse(&sdpMsg, tempStr, &len, &status)) != NULL)
            {
                termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
                rvMdmTermModifyMedia( termination, &sdpMsg);
                sendEvent = RV_FALSE;
            }
        }

		/* Dynamic media change - send Update */
		/* ---------------------------------- */
		/* Use SDP message that was received in EPP message */
        if (!rvStrIcmp(id, "update"))
        {
            if ((rvSdpMsgConstructParse(&sdpMsg, tempStr, &len, &status)) != NULL)
            {
                termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
                rvMdmTermModifyMediaByUpdate( termination, &sdpMsg);
                sendEvent = RV_FALSE;
            }
        }
    }

    /* Make Call */
    /* --------- */
    else if (!rvStrIcmp(pkg, "call"))
    {
        if (!rvStrIcmp(id, "make"))
        {
            char    destination[1024];

            RvMdmTerm *termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
            RvIppTerminalHandle     termHandle = rvIppMdmTerminalGetHandle(termination);
          /*  sendOffHookEvent(termHandle);*/

            strcpy(destination, eventParams);
            cleanParam(destination);
            rvMtfTerminalMakeCall(termHandle, destination);

        }
    }

    /* Register to SIP Registrar */
    /* ------------------------- */
    else if (!rvStrIcmp(pkg, "register"))
    {
        /* Register this terminal to SIP Registrar */
        if (!rvStrIcmp(id, "network"))
        {
            RvMdmTerm *termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
            RvPhoneMgr *phoneMgr = (RvPhoneMgr *)data;
            rvMdmTermMgrRegisterTermToNetwork(phoneMgr->termMgr, termination);
            sendEvent = rvFalse;

        }
        /* Register all terminals to SIP Registrar */
        else if (!rvStrIcmp(id, "all"))
        {
            RvPhoneMgr *phoneMgr = (RvPhoneMgr *)data;
            rvMdmTermMgrRegisterAllTermsToNetwork(phoneMgr->termMgr);
            sendEvent = rvFalse;

        }
    }

    /* Change terminal parameters */
    /* -------------------------- */
    else if (!rvStrIcmp(pkg, "set"))
    {
        if (!rvStrIcmp(id, "registrar_address"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "registrar_port"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "proxy_address"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "proxy_port"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "expires"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "username"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "password"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
    }

    /* Unregister from SIP Registrar */
    /* ----------------------------- */
    else if (!rvStrIcmp(pkg, "unregister"))
    {
        if (!rvStrIcmp(id, "network"))
        {
            RvMdmTerm *termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
            RvPhoneMgr *phoneMgr = (RvPhoneMgr *)data;
            rvMdmTermMgrUnregisterTermFromNetwork(phoneMgr->termMgr, termination);
            sendEvent = rvFalse;

        }
    }

    if (sendEvent == RV_TRUE)
    {
        if ((id != NULL) && (pkg != NULL))
        {
            RvMdmTerm *termination = (RvMdmTerm *)rvEppClientEndpointGetUserData(ece);
            rvMdmParameterListConstruct(&paramsList);
            strcpy(pkgName,pkg);
            strcpy(event,id);
            buildEventParamsList(&paramsList, pkgName, event, eventParams);
            rvMdmTermProcessEvent(termination, pkgName, event, NULL, &paramsList);
            rvMdmParameterListDestruct(&paramsList);
        }
    }

    rvStrTokDestruct(&tokenizer);
}

void rvAddParam(const RvMdmParameterList* list, char* paramName, char* str)
{
    const RvMdmParameterValue* value;
    char val[128];
    char c = '"';

    if ((value = rvMdmParameterListGet2(list, paramName)) != NULL)
    {
        if (!strcmp(str, ""))
            sprintf(val, "%c%s%c", c, rvMdmParameterValueGetValue(value), c);
        else
            sprintf(val, ",%c%s%c", c, rvMdmParameterValueGetValue(value), c);
        strcat(str, val);
    }
}
RvBool rvGetSignalParams(const RvMdmSignal *s, char *str)
{
    const RvMdmParameterList* params;

    params = rvMdmSignalGetArguments(s);
    if (rvMdmParameterListIsEmpty(rvMdmSignalGetArguments(s)) == RV_TRUE)
        return RV_FALSE;

    if ((!strcmp(rvMdmSignalGetPkg(s), "dis")) && (!strcmp(rvMdmSignalGetId(s), "di")))
    {
        rvAddParam(params, "str", str);
        rvAddParam(params, "r", str);
        rvAddParam(params, "c", str);
    }

    if ((!strcmp(rvMdmSignalGetPkg(s), "ind")) && (!strcmp(rvMdmSignalGetId(s), "is")))
    {
        rvAddParam(params, "Indid", str);
        rvAddParam(params, "state", str);
        rvAddParam(params, "distRing", str);
    }

    if ((!strcmp(rvMdmSignalGetPkg(s), "cg")) && (!strcmp(rvMdmSignalGetId(s), "rt")))
    {
        rvAddParam(params, "distRing", str);
    }

    if ((!strcmp(rvMdmSignalGetPkg(s), "ks")) && (!strcmp(rvMdmSignalGetId(s), "sd")))
    {
        rvAddParam(params, "keyid", str);
        rvAddParam(params, "displayContent", str);
    }

    if ((!strcmp(rvMdmSignalGetPkg(s), "rvcc")) && (!strcmp(rvMdmSignalGetId(s), "callerid")))
    {
        rvAddParam(params, "name", str);
        rvAddParam(params, "number", str);
        rvAddParam(params, "address", str);
        rvAddParam(params, "id", str);
    }

    return RV_TRUE;
}

/******************************************************************************
*  rvMtfMediaEnableDev
*  ----------------------------
*  General :     Open or close specified device.
*  Return Value: None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*   devId           -   device id.
*   bEnable         -   rvTrue  - open device,
*                       rvFalse - close device
*
*  Input:
*
******************************************************************************/

/*******************************************************************************************/
/*********************  C A L L B A C K S    I M P L E N T A T I O N S**********************/
/*******************************************************************************************/

static RvBool rvPhoneMgrStartSignalCB(RvMdmTerm *term, RvMdmSignal *s, OUT RvMdmError *mdmError)
{
//MARKA    RvPhoneLink *phoneLink=NULL;
    char signalLine[256];
    char args[512];

//MARKA    phoneLink = (RvPhoneLink *)rvMdmTermGetUserData(term);
    RvEppClientEndpoint* ece =  (RvEppClientEndpoint *)rvMdmTermGetUserData(term);

    RV_UNUSED_ARG(mdmError);

    if (ece == NULL)
    {
//MARKA    if (phoneLink == NULL) /*In case we didn't sleep enough....*/
        return rvFalse;
    }

    strcpy(args, "");
    rvGetSignalParams(s, args);

    if (!strcmp(args, ""))
        sprintf(signalLine, "%s/%s", rvMdmSignalGetPkg(s), rvMdmSignalGetId(s));

    else
        sprintf(signalLine, "%s/%s %s", rvMdmSignalGetPkg(s), rvMdmSignalGetId(s), args);

    if(signalLine != NULL)
    {
//MARKA        rvEppClientStart( phoneLink->endpoint, signalLine);
        rvEppClientStart( ece, signalLine);

    }

    return rvTrue;
}

RvBool rvPhoneMgrPlaySignalCB(struct RvMdmTerm_* term,RvMdmSignal * s,RvBool reportCompletion,
                                         OUT RvMdmError* mdmError)
{

    RV_UNUSED_ARG(reportCompletion);
    return rvPhoneMgrStartSignalCB(term, s, mdmError);
}

RvBool rvPhoneMgrStopSignalCB(RvMdmTerm *term, RvMdmSignal *s, OUT RvMdmError *mdmError)
{
    char signal[64];

//MARKA    RvPhoneLink *phoneLink = (RvPhoneLink *)rvMdmTermGetUserData(term);
//    if (phoneLink == NULL)
//        return RV_FALSE;
    RvEppClientEndpoint* ece =  (RvEppClientEndpoint *)rvMdmTermGetUserData(term);

    RV_UNUSED_ARG(mdmError);

    if( ece == NULL)
    {
        return rvFalse;
    }

    sprintf(signal, "%s/%s", rvMdmSignalGetPkg(s), rvMdmSignalGetId(s));

    if(signal != NULL)
    {
//MARKA        rvEppClientStop(phLink->endpoint, signal);
        rvEppClientStop( ece, signal);
    }
    return RV_TRUE;
}

static void rvPhoneMgrRegPhysTermCompletedCB( RvMdmTerm* term, RvMdmError* mdmError)
{
//MARKA     RvPhoneLink         *phoneLink = NULL;
    RvIppTerminalHandle termHndl;
    RvCCTerminalType    termType;
    RvEppClientEndpoint* ece =  (RvEppClientEndpoint *)rvMdmTermGetUserData(term);
	RV_UNUSED_ARG(mdmError);

	termHndl = rvIppMdmTerminalGetHandle(term);
	if (termHndl != NULL)
	{
            termType = rvIppMdmTerminalGetType(termHndl);
	}
	else
		return;

	if( ece !=NULL)
	{

	//MARKA    phoneLink = rvMdmTermGetUserData(term);
	//    phoneLink = rvMdmTermGetUserData(term);
	//    if (phoneLink != NULL)
	//    {
	//        ece = phoneLink->endpoint;

			rvEppClientEndpointSetUserData(ece, term);

			if (termHndl != NULL)
			{
				termType = rvIppMdmTerminalGetType(termHndl);
				if ((termType == RV_CCTERMINALTYPE_UI) || (termType == RV_CCTERMINALTYPE_ANALOG))
				{
					rvMdmTermProcessEvent( term, "rvcc", "ga", NULL, NULL);
				}
			}
	//    }
	}

#ifndef RV_MTF_MEDIA
    /* Initialize media engine*/
    /* -----------------------*/
    /* When RV_MTF_MEDIA is defined, we called RvMfControlInit() earlier, see rvIppSipSampleGatewayConstruct() */
    /* we called rvMtfMediaStart() earlier, see rvIppSipSampleGatewayConstruct() */

    if (termType == RV_CCTERMINALTYPE_ANALOG)
    {

        void*   context = rvMdmTermGetUserData ( term);

        if(RV_OK != rvMtfMediaStart( context))
        {
            IppLogMessage(rvTrue,"RvMfControlInit Failed");
            return;
        }
    }
#endif
}

static void rvPhoneMgrRegUITermCompletedCB(RvMdmTerm* term, RvMdmError* mdmError)
{
    rvPhoneMgrRegPhysTermCompletedCB( term, mdmError);

#ifndef RV_MTF_MEDIA
    /* Initialize media engine*/
    /* -----------------------*/
    /* When RV_MTF_MEDIA is defined, we call RvMfControlInit() earlier, see rvIppSipSampleGatewayConstruct() */
    /* we called rvMtfMediaStart() earlier, see rvIppSipSampleGatewayConstruct() */
    {
        void*   context = rvMdmTermGetUserData ( term);

        if(RV_OK != rvMtfMediaStart( context))
        {
            IppLogMessage(rvTrue,"RvMfControlInit Failed");
            return;
        }
    }
#endif
}

static void rvPhoneMgrUnregPhysTermCompletedCB(RvMdmTerm* term, RvMdmError* mdmError)
{
    RvIppTerminalHandle termHndl;
    RvCCTerminalType    termType;

    RV_UNUSED_ARG(term);
    RV_UNUSED_ARG(mdmError);

    if (unegisteredTerminationsLeft == RV_FALSE)
    {
        if (notifyToStartWarmRestart == RV_TRUE)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            startWarmRestart = RV_TRUE;
            notifyToStartWarmRestart = RV_FALSE;
            unegisteredTerminationsLeft = RV_TRUE;
        }
        else if (notifyToStartShutdown == RV_TRUE)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            startShutdown = RV_TRUE;
            notifyToStartShutdown = RV_FALSE;
            unegisteredTerminationsLeft = RV_TRUE;
        }
    }

#ifndef RV_MTF_MEDIA
    termHndl = rvIppMdmTerminalGetHandle(term);
    if (termHndl != NULL)
    {
        termType = rvIppMdmTerminalGetType(termHndl);
    }
    else
    {
        return;
    }

    /* Stop media engine */
    /* ----------------- */
    /* When RV_MTF_MEDIA is defined, we call rvMtfMediaStop() later, see rvIppSipSampleGatewayDestruct() */
    if (termType == RV_CCTERMINALTYPE_ANALOG)
    {
        void*   context = rvMdmTermGetUserData ( term);
       rvMtfMediaStop( context);
    }
#endif

}

static void rvPhoneMgrUnregUITermCompletedCB(RvMdmTerm* term, RvMdmError* mdmError)
{
    /* we get here twice (due to registerToNetwork). Should be handled later
     stop media support )*/
#ifndef RV_MTF_MEDIA
    /* Stop media engine */
    /* ----------------- */
    /* When RV_MTF_MEDIA is defined, we call rvMtfMediaStop() later, see rvIppSipSampleGatewayDestruct() */
    {
       void*   context = rvMdmTermGetUserData ( term);
       rvMtfMediaStop( context);
    }
#endif
    rvPhoneMgrUnregPhysTermCompletedCB( term, mdmError);
}

static void rvPhoneMgrUnregTermFromNetworkCompletedCB(RvMdmTerm* term, RvMdmError* mdmError)
{
    RV_UNUSED_ARG(term);
    RV_UNUSED_ARG(mdmError);

}


static RvBool rvPhoneMgrDeletePhysicalTerm(RvMdmTerm *termination, void *termMgr)
{
//    RvPhoneLink *phoneLink = (RvPhoneLink *)rvMdmTermGetUserData(termination);
    RV_UNUSED_ARG(termination);
    RV_UNUSED_ARG(termMgr);

//    rvPhoneLinkDestruct(phoneLink);
//    rvMtfAllocatorDealloc(phoneLink);

    return rvFalse;
}



RvBool rvUserInterCreateMediaCB(struct RvMdmTerm_* term,
                                         RvMdmMediaStream* media,           /*obsolete*/
                                         RvMdmMediaStreamDescr* streamDescr,/*obsolete except field: param*/
                                         OUT RvMdmError* mdmError           /*obsolete*/
                                         )
{
    RV_UNUSED_ARG(term);
    RV_UNUSED_ARG(media);
    RV_UNUSED_ARG(streamDescr);
    RV_UNUSED_ARG(mdmError);

    return rvTrue;
}

RvBool rvUserInterModifyMediaCB(RvMdmTerm* term,
                                RvMdmMediaStream* media,           /*obsolete*/
                                RvMdmMediaStreamDescr* streamDescr,/*obsolete except field: param*/
                                OUT RvMdmError* mdmError           /*obsolete*/
                                      )
{
    RV_UNUSED_ARG(term);
    RV_UNUSED_ARG(media);
    RV_UNUSED_ARG(streamDescr);
    RV_UNUSED_ARG(mdmError);

    return rvTrue;
}

RvBool rvUserInterDestroyMediaCB(RvMdmTerm *term, RvMdmMediaStream *media, OUT RvMdmError *mdmError)
{
    RV_UNUSED_ARG(term);
    RV_UNUSED_ARG(media);
    RV_UNUSED_ARG(mdmError);


    return rvTrue;
}


RvStatus rvPhoneMgrConstruct(
    IN RvPhoneMgr*      mgr,
    IN RvMdmTermMgr*    termMgr,
    IN RvBool           bConfigTCP,
    IN const RvChar*    eppClientIp,
    IN RvUint16         eppPort)
{
    static RvEppClient eppClient;
    RvStatus status;

    mgr->termMgr = termMgr;

    status = rvEppClientConstruct(
        &eppClient, bConfigTCP, eppClientIp, eppPort,
        rvPhoneMgrOnRegister, rvPhoneMgrOnEvent, rvPhoneMgrOnUnregister, mgr);
    if (status != RV_OK)
        return status;

    mgr->eppClient = &eppClient;

    return RV_OK;
}

void rvPhoneMgrDestruct(RvPhoneMgr *mgr)
{
    rvEppClientDestruct(mgr->eppClient);
    rvMdmTermMgrForEachPhysicalTerm(mgr->termMgr, rvPhoneMgrDeletePhysicalTerm, mgr->termMgr);
}


void rvPhoneMgrInitPhoneClass(RvMdmTermMgr* termMgr, RvMdmTermClass** phoneClass)
{
    *phoneClass = rvMdmTermMgrCreateTermClass(termMgr);
    rvMdmTermClassRegisterStartSignalCB(*phoneClass, rvPhoneMgrStartSignalCB);
    rvMdmTermClassRegisterStopSignalCB(*phoneClass, rvPhoneMgrStopSignalCB);
    rvMdmTermClassRegisterPlaySignalCB(*phoneClass, rvPhoneMgrPlaySignalCB);
    rvMdmTermClassRegisterRegisterPhysTermCompletedCB(*phoneClass, rvPhoneMgrRegPhysTermCompletedCB);
    rvMdmTermClassRegisterUnregisterTermCompletedCB(*phoneClass,rvPhoneMgrUnregPhysTermCompletedCB);
    rvMdmTermClassRegisterMapDialStringToAddressCB(*phoneClass, rvPhoneMgrMapDialStringToAddressCB);
    rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB(*phoneClass,rvPhoneMgrUnregTermFromNetworkCompletedCB);

    rvMdmTermClassSetAnalogLinePackages(*phoneClass);
    /* We don't want to limit analog terminal to analog events and signals*/
    rvMdmTermClassSetIPPhoneUIPackages(*phoneClass);
}

void rvPhoneMgrInitUIClass(RvMdmTermMgr* termMgr, RvMdmTermClass** uiClass)
{
    *uiClass   = rvMdmTermMgrCreateTermClass(termMgr);
    rvMdmTermClassRegisterStartSignalCB(*uiClass, rvPhoneMgrStartSignalCB);
    rvMdmTermClassRegisterStopSignalCB(*uiClass, rvPhoneMgrStopSignalCB);
    rvMdmTermClassRegisterPlaySignalCB(*uiClass, rvPhoneMgrPlaySignalCB);
    rvMdmTermClassRegisterMapDialStringToAddressCB(*uiClass, rvPhoneMgrMapDialStringToAddressCB);
    rvMdmTermClassRegisterRegisterPhysTermCompletedCB(*uiClass, rvPhoneMgrRegUITermCompletedCB);
    rvMdmTermClassRegisterUnregisterTermCompletedCB(*uiClass,rvPhoneMgrUnregUITermCompletedCB);

    rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB(*uiClass,rvPhoneMgrUnregTermFromNetworkCompletedCB);

    rvMdmTermMgrRegisterIPPhoneUiPackages(termMgr);
    rvMdmTermClassSetIPPhoneUIPackages(*uiClass);

#ifdef SAMPLE_MWI
    rvMdmTermMgrRegisterUserSignal(termMgr, "msg", "MWI");
    rvMdmTermMgrSetUserPackage(*uiClass, "msg");
#endif
}

void rvPhoneMgrInitAtClass(RvMdmTermMgr* termMgr, RvMdmTermClass** atClass)
{
    *atClass   = rvMdmTermMgrCreateTermClass(termMgr);
    rvMdmTermClassRegisterStartSignalCB(*atClass, rvPhoneMgrStartSignalCB);
    rvMdmTermClassRegisterPlaySignalCB(*atClass, rvPhoneMgrPlaySignalCB);
    rvMdmTermClassRegisterStopSignalCB(*atClass, rvPhoneMgrStopSignalCB);
    rvMdmTermClassRegisterRegisterPhysTermCompletedCB(*atClass, rvPhoneMgrRegPhysTermCompletedCB);
    rvMdmTermClassRegisterUnregisterTermCompletedCB(*atClass,rvPhoneMgrUnregPhysTermCompletedCB);
    rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB(*atClass,rvPhoneMgrUnregTermFromNetworkCompletedCB);

    rvMdmTermClassSetAudioTransducerPackages(pgw->atClass);

    /*Register user signal*/
    rvMdmTermMgrRegisterUserSignal(termMgr, "upkg", "usig");
    rvMdmTermMgrSetUserPackage(*atClass, "upkg");
}

