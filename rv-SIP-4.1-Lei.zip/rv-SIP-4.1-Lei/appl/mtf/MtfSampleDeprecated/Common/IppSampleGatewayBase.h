/******************************************************************************
Filename:    IppSampleGatewayBase.h
Description: Common module of Sample Gateway
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_IPPGATEWAYBASE_H
#define RV_IPPGATEWAYBASE_H

#include "rvstring.h"
#include "IppSamplePhoneLink.h"
#include "MtfMediaCallbacks.h"
#include "rvIppCfwApi.h"

#include "MfControl.h"

#if defined(__cplusplus)
extern "C" {
#endif

rvDeclareMap(RvString, RvString);

typedef enum
{
	H323_API_TYPE,
	SIP_API_TYPE,
	IPP_API_TYPE
}APITYPE;

#define RVIPP_DISPLAY_COLUMN_LINE	4
#define RVIPP_DISPLAY_REG_PREFIX    "Register:"

typedef enum RvIppDisplayRawsOrder_
{
	RVIPP_RAW_LOGO				= 0, /* Lines 0 and 1 are unused by MTF, reserved for GUI*/
	RVIPP_RAW_LOGO_SEPERATOR1	= 2,
	RVIPP_RAW_LINE1_STATUS		= 3,
	RVIPP_RAW_LINE1_CALLER		= 4,
	RVIPP_RAW_LINE2_STATUS		= 6,
	RVIPP_RAW_LINE2_CALLER		= 7,
    RVIPP_RAW_LOGO_SEPERATOR2	= 8,
	RVIPP_RAW_CFWU				= 9,
	RVIPP_RAW_CFWB				= 10,
	RVIPP_RAW_CFWNR				= 11,
	RVIPP_RAW_REGISTER_STATUS	= 12
} RvIppDisplayRawsOrder;

/*
 *	structure RvIppSampleGatewayBase is base class (in C++ terms) of RvIppSampleGateway class in Sip/H323
 */
typedef struct
{
	RvMdmTermMgr	termMgr;
	RvMdmTermClass	*rtpClass;/* ephemeral term class */
	RvMdmTermClass *phoneClass, *uiClass, *atClass;
	RvPhoneMgr		phoneMgr;
	RvMap(RvString, RvString)	addressList;
	RvChar          localAddress[64];
	unsigned int	dialToneDuration;	/*Duration of dial tone signal, in milliseconds*/
	int             maxCallLegs;
	RvSdpMsg        *sdpForInitialInvite;  /* to be sent when initiating a call */
	RvSdpMsg		*sdpOfFullCaps;        /* full MTF capabilities   */
/*REMOVE_sdpLastCreate	RvSdpMsg		sdpLastCreate;*/	/*meanwhile used in SIP: to store a few parameters from outgoing INVITE*/
	RvRtpDtmfRelay	dtmfRelay;
	int			autoAnswer;		/* auto answer in sample, 1 - on, 0 - off */
	RvMdmTermPhoneNumbers		phoneNumbers;
	RvMdmTermPresentationInfo	presentationInfo;
	/*Will be sent to IPP at user request to replace existing info*/
	RvMdmTermPresentationInfo	presentationInfoNew;
    RvBool          bConfigTCP;
	char			eppIp[80];
	RvUint16		eppPort;
    char            localIpPrefix[128];
    char            localIpMask[128];

	/* Call Forward Feature */
	/* ...IsActive parameters will be used dynamically.
	1st press on cfwTypeX button, its "typeXIsActive parameter will be switch from off to be on.
	2nd press on cfwTypeX button, its "typeXIsActive parameter will be switch from on to off...
	Every press on cfwTypeX will be switch the value of its "IsActive" parameter. */
	RvBool			callForwardTypeIsActive[RV_IPP_CFW_MAX_NUMBER_OF_TYPES];
	/* NoReply timeout will be used in case of call forward no reply.
	Its value will be used when a request to activate cfnr is required.
	This value is set in configuration time and can not be set dynamically */
	RvChar          callForwardNoReplyTimeout[10];
	RvIppCfwCfg	    cfwCallCfg;

//MARKA    RvBool          bDisableMedia;
    RvMtfMediaConstructParam    mediaParam;
        RvBool                      enableSdpLogs;  /*When set to true, SDP logging will be generated to log file */

	/* params for analog lines simulation */
	RvInt32                     numOfAnalogLines;
	RvInt32                     numOfSimulationCalls;
	RvInt32                     firstTermNum;
	RvInt32                     firstDestDigit;
	RvString                    analogDestAddress;
	RvBool                      outgoingCallsEnabled;
} RvIppSampleGatewayBase;

void rvIppSampleGatewayBaseConstruct(RvIppSampleGatewayBase* gwb);
void rvIppSampleGatewayBaseDestruct(RvIppSampleGatewayBase* gwb);
void rvIppSampleGatewayBaseRegisterIppCallbacks(RvIppSampleGatewayBase* gwb);
RvMdmTerm *rvIppSampleGatewayBaseSelectTermination(RvIppSampleGatewayBase* gwb, RvMdmTermMgr *mgr);

void rvIppSampleGatewayBaseLoadIppLogging(IppLogSourceFilterElm* logOptions, char* configBuf);
RvBool rvIppSampleGatewayBaseLoadMediaCaps(RvIppSampleGatewayBase* gwb, RvMdmTermClass* c);
char* rvIppSampleGatewayBaseLoadAddressList(RvIppSampleGatewayBase* gwb, char* configBuf);


/***************************************************************************************
 * rvIppSampleUtilGetNextLine
 * -------------------------------------------------------------------------------------
 * General:   Goes through the received buffer, and returns the beginning of the next line.
 * Return Value: Returns a pointer to the beginning of the next line
 * Note: This function assumes all lines have info in them, and that they are already
 *       trimmed on both sides.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer to be parsed
 * Output:   string pointer - pointer to the beginning of the next line
 **************************************************************************************/
RvChar* rvIppSampleUtilGetNextLine(IN RvChar* buf, OUT RvChar** p);

void rvIppSampleGatewayDeleteEphTerm(RvMdmTermMgr *mgr, RvMdmTerm *ephTerm);

/***************************************************************************************
 * rvIppSampleLoadMediaParamsFromBuffer
 * -------------------------------------------------------------------------------------
 * General:   Seek for a section titled [MediaParameters{index}], say  [MediaParameters1].
 *				Convert contents of the section to RvSdpMsg and collect them in RvSdpMsgList
 * Return Value: True is succeeded, False if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer
 *			 integer - index part of section name
 * Output:   RvSdpMsg* sdp - fulfilled structure
 **************************************************************************************/
RvBool rvIppSampleLoadMediaParamsFromBuffer(IN const char* buffer, OUT RvIppSampleGatewayBase* gwb);

void rvIppSampleCfwActivateCompletedCB(RvIppTerminalHandle	term,
                                       RvIppCfwType			cfwType,
                                       char*					cfwDestination,
                                       RvIppCfwReturnReasons	returnCode);

void rvIppSampleCfwDeactivateCompletedCB(RvIppTerminalHandle		term,
                                         RvIppCfwType 	 	cfwType,
                                         RvIppCfwReturnReasons returnCode);

void userRegisterIppMdmExt(void);
#ifdef RV_MTF_VIDEO
void userRegisterIppMdmVideoExt(void);
#endif


#if defined(__cplusplus)
}
#endif

#endif /*RV_IPPGATEWAYBASE_H*/
