/******************************************************************************
Filename:    IppSampleGatewayBase.c
Description: Common module of Sample Gateway
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"
#include "IppSampleGatewayBase.h"
#include "IppSampleMediaNegotiate.h"
#include "IppSampleSipUserClbks.h"
#include "rvstr.h"

rvDefineMap(RvString, RvString);
/*===============================================================================*/
/*==============    GLOBALS  ==========*/
extern RvIppSampleGatewayBase*	 pgw;
/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/



/*===============================================================================*/
/*==============    C A L L B A C K		I M P L E M E N T A T I O N S  ==========*/
/*===============================================================================*/


/***************************************************************************
 * rvIppSampleGatewayDeleteEphTerm
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrDeleteEphTermCB
 *
 ***************************************************************************/
void rvIppSampleGatewayDeleteEphTerm(RvMdmTermMgr *mgr, RvMdmTerm *ephTerm)
{
//MARKA	RvRtpLink *rtpLink = (RvRtpLink *)rvMdmTermGetUserData(ephTerm);
    RV_UNUSED_ARG(mgr);
	IppLogMessage(RV_FALSE, "rvIppSampleGatewayDeleteEphTerm: ephTerm = %p", ephTerm);
//MARKA	rvRtpLinkDestruct(rtpLink);
//	rvMtfAllocatorDealloc(rtpLink);
}



/*===============================================================================*/
/*==============    G A T E W A Y	 B A S E	A P I  ==========================*/
/*===============================================================================*/
static char emptyFullLine[24] = {"                  "};

static void clearCfwRaw(RvIppTerminalHandle termHndl, int raw)
{
	rvIppMdmTerminalSetDisplay(termHndl, emptyFullLine, raw, 0);
	rvIppMdmTerminalSetDisplay(termHndl, emptyFullLine, raw+1, 0);
}

static void rvIppRemoveScheme(char* str, char* address)
{
	char *p = strchr(str, ':');

	if (p != NULL)
	{
		strcpy(address, p+1);

	}
	else
		address[0]='\0';
}

static RvBool findPhoneNumber(IN char* address, OUT char* phoneNumber)
{
	RvMapIter(RvString, RvString) iter = NULL;
	
	for (iter = rvMapBegin(RvString, RvString)(&pgw->addressList);
			iter != rvMapEnd(RvString, RvString)(&pgw->addressList);
			iter = rvMapIterNext(iter))
	{
		RvString* destAddress = rvMapIterGetValue(RvString, RvString)(iter);
		const char* number = *rvMapIterGetKey(RvString, RvString)(iter);

		if (strstr(rvStringGetData(destAddress), address))
		{
			strcpy(phoneNumber, number);
			return rvTrue;
		}
	}

	return rvFalse;

}

static void rvCCCfwActivateTypesDisplay(
    IN RvIppTerminalHandle	term, 
	IN RvIppCfwType			cfwType,
	IN const RvChar*		cfwDestination)
{
	RvChar cfwDisplayString[RV_NAME_STR_SZ];
		
	pgw->callForwardTypeIsActive[cfwType] = RV_TRUE;
	
	switch (cfwType)
	{
		case  RV_IPP_CFW_TYPE_UNCONDITIONAL:
			RvSprintf(cfwDisplayString, "CFW-U: %s", cfwDestination);
			rvIppMdmTerminalSetDisplay(term, cfwDisplayString, (int)RVIPP_RAW_CFWU, 0);
			break;
		case RV_IPP_CFW_TYPE_BUSY:
			RvSprintf(cfwDisplayString, "CFW-B: %s", cfwDestination);
			rvIppMdmTerminalSetDisplay(term, cfwDisplayString, (int)RVIPP_RAW_CFWB, 0);
			break;
		case RV_IPP_CFW_TYPE_NO_REPLY:
			RvSprintf(cfwDisplayString, "CFW-NR: %s", cfwDestination);
			rvIppMdmTerminalSetDisplay(term, cfwDisplayString, (int)RVIPP_RAW_CFWNR, 0);
			break;
        case RV_IPP_CFW_TYPE_NONE:    
		default:
			IppLogMessage(RV_TRUE, "cfwActivateCompleteCB - Unknown CFW Type: %d", cfwType);
	}
}

static void rvCCCfwDeactivateTypesDisplay(
    IN RvIppTerminalHandle	term, 
	IN RvIppCfwType			cfwType)
{
	pgw->callForwardTypeIsActive[cfwType] = rvFalse;

	switch (cfwType)
	{
		case  RV_IPP_CFW_TYPE_UNCONDITIONAL:
			clearCfwRaw(term, (int)RVIPP_RAW_CFWU);
			break;
		case RV_IPP_CFW_TYPE_BUSY:
			clearCfwRaw(term, (int)RVIPP_RAW_CFWB);
			break;
		case RV_IPP_CFW_TYPE_NO_REPLY:
			clearCfwRaw(term, (int)RVIPP_RAW_CFWNR);
			break;
        case RV_IPP_CFW_TYPE_NONE:    
		default:
			IppLogMessage(RV_TRUE, "cfwActivateCompleteCB - Unknown CFW Type: %d", cfwType);
	}
}

void rvIppSampleCfwActivateCompletedCB(RvIppTerminalHandle	term, 
							RvIppCfwType			cfwType,
							char*					cfwDestination,
							RvIppCfwReturnReasons	returnCode) 
{
	if (returnCode == RV_IPP_CFW_SUCCESS)
	{
		char phoneNumber[RV_NAME_STR_SZ];
		char address[RV_NAME_STR_SZ];

		/*Remove "sip:" from the address*/
		rvIppRemoveScheme(cfwDestination, address);

		/* Update the text display - phone number if found, or address if not*/
  		if (findPhoneNumber(address, phoneNumber) == rvTrue)
		{
			rvCCCfwActivateTypesDisplay(term, cfwType, phoneNumber);
		}
		else
		{
			rvCCCfwActivateTypesDisplay(term, cfwType, address);
		}
		IppLogMessage(RV_FALSE, "cfwActivateCompleteCB on type %d Succeeded", cfwType);
	}
	else
	{
		IppLogMessage(RV_FALSE, "cfwActivateCompleteCB Failed on type %d, returnCode = %d", cfwType, returnCode);
	}
}

void rvIppSampleCfwDeactivateCompletedCB(RvIppTerminalHandle		term, 
							RvIppCfwType 	 	cfwType,
							RvIppCfwReturnReasons returnCode) 
{
	if ((returnCode == RV_IPP_CFW_SUCCESS) || (returnCode == RV_IPP_CFW_INVALID_DEACTIVATION))
	{
		/* Update the text display*/
		rvCCCfwDeactivateTypesDisplay(term, cfwType);
		IppLogMessage(RV_FALSE, "cfwDeactivateCompleteCB on type %d Succeeded", cfwType);
	}
	else
	{
		IppLogMessage(RV_FALSE, "cfwDeactivateCompleteCB Failed on type %d, returnCode = %d", cfwType, returnCode);
	}
}

/***************************************************************************
 * rvIppSampleGatewayBaseConstruct
 * ------------------------------------------------------------------------
 * Constructs Gateway common parameters
 *
 ***************************************************************************/
void rvIppSampleGatewayBaseConstruct(RvIppSampleGatewayBase* gwb)
{
	memset(gwb, 0, sizeof(RvIppSampleGatewayBase));

	gwb->bConfigTCP = rvFalse;
	gwb->eppPort = 3044;

    strcpy(gwb->localIpPrefix, "");
    strcpy(gwb->localIpMask, "");

	rvMapConstruct(RvString, RvString)(&gwb->addressList, userDefaultAlloc);

	/* The following sdpMsgs are constructed in proc rvIppSampleLoadMediaParamsFromBuffer */
	gwb->sdpForInitialInvite = NULL;
	gwb->sdpOfFullCaps = NULL;

    rvMdmTermPhoneNumbersConstruct(&gwb->phoneNumbers);

	rvMdmTermPresentationInfoConstruct(&gwb->presentationInfo);
	rvMdmTermPresentationInfoConstruct(&gwb->presentationInfoNew);
	/* param for analog lines simulation */
	rvStringConstruct(&gwb->analogDestAddress, "", userDefaultAlloc);
}

/***************************************************************************
 * rvIppSampleGatewayBaseDestruct
 * ------------------------------------------------------------------------
 * Constructs Gateway common parameters
 *
 ***************************************************************************/
void rvIppSampleGatewayBaseDestruct(RvIppSampleGatewayBase* gwb)
{
	rvMapDestruct(&gwb->addressList);

	if (gwb->sdpOfFullCaps !=  gwb->sdpForInitialInvite)
		rvSdpMsgDestruct(gwb->sdpOfFullCaps);

	if (gwb->sdpForInitialInvite != NULL)
		rvSdpMsgDestruct(gwb->sdpForInitialInvite);

	/* param for analog lines simulation */
	rvStringDestruct(&gwb->analogDestAddress);
	
}
/***************************************************************************
 * rvIppSampleGatewayBaseLoadAddressList
 * ------------------------------------------------------------------------
 * Loads address list from configuration to Gateway
 *
 ***************************************************************************/
char* rvIppSampleGatewayBaseLoadAddressList(RvIppSampleGatewayBase* gwb, char* configBuf)
{
	char line[128];
	RvString address, dialString;
	char * ptr = configBuf;
	char * last = NULL;
	char *ind;
	char* token;
	RvStrTok t;
	RvSize_t tokenLen;

	/*load the mapping list between dial string and address (URI)*/
	rvStringConstruct(&address, "", userDefaultAlloc);
	rvStringConstruct(&dialString, "", userDefaultAlloc);

	while(rvIppSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {
		if(ptr[0]=='[')
        {
            ptr=last;
            break;
        }
		last = ptr;

		/* Find display state and value*/
		tokenLen = (RvSize_t)(rvStrFindFirstOf(ptr,"\n") - ptr);
		
		/* Make sure it doesn't exceed line length*/
		if (tokenLen >= sizeof(line))
			tokenLen = sizeof(line)-1;
		
		/* copy to line and make sure it's NULL terminated*/
		strncpy(line, ptr, tokenLen);
		line[tokenLen] = '\0';
		
		ind = strchr(line,'\r');
		if (ind)
			*ind='\0';
		
		if (!strcmp(line,""))
		  break;

		rvStrTokConstruct(&t," ",line);
		if ((token = rvStrTokGetToken(&t)) == NULL)
			continue;
		rvStringAssign(&dialString, token);
		if ((token = rvStrTokGetToken(&t)) == NULL)
			continue;
		rvStringAssign(&address, token);
		rvMapSetValue(RvString, RvString)(&gwb->addressList, &dialString, &address);
		memset(line, 0, 128);
	}
	rvStringDestruct(&address);
	rvStringDestruct(&dialString);

	return ptr;
}


/***************************************************************************
 * rvIppSampleSelectTermination
 * ------------------------------------------------------------------------
 * General: IPP Callback implementation of RvMdmTermMgrSelectTerminationCB
 *
 ***************************************************************************/
static RvMdmTerm *rvIppSampleSelectTermination(RvMdmTermMgr *mgr, RvMdmTerm *tempTerm)
{
	/* assume for now that unknown ones are ephemeral */
	/* later we will need a way to determine type */
	if(rvMdmTermGetType(tempTerm) == RV_MDMTERMTYPE_EPHEMERAL ||
		rvMdmTermGetType(tempTerm) == RV_MDMTERMTYPE_UNKNOWN)
	{
		RvIppSampleGatewayBase *gwBase = (RvIppSampleGatewayBase*)rvMdmTermMgrGetUserData(mgr);

		return rvIppSampleGatewayBaseSelectTermination(gwBase, mgr);

	}
	return NULL;
}
/***************************************************************************
 * rvIppSampleGatewayBaseRegisterMdmCallbacks
 * ------------------------------------------------------------------------
 * General: Registers IP Phone TK MDM callbacks
 *
 ***************************************************************************/
void rvIppSampleGatewayBaseRegisterMdmCallbacks(RvIppSampleGatewayBase* gwBase)
{

	RvMdmTermMgr	*termMgr= &gwBase->termMgr;

	rvMdmTermMgrSetUserData(termMgr, gwBase);

	rvMdmTermMgrRegisterSelectTermCB(termMgr, rvIppSampleSelectTermination);
	rvMdmTermMgrRegisterDeleteEphTermCB(termMgr, rvIppSampleGatewayDeleteEphTerm);
}


void rvIppSampleGatewayBaseRegisterIppCallbacks(RvIppSampleGatewayBase* gwBase)
{
	/* Register IPP callbacks*/
	rvIppSampleGatewayBaseRegisterMdmCallbacks(gwBase);

	/* Register user callbacks*/
	userRegisterIppMdmExt();
#ifdef RV_MTF_MEDIA
#ifdef RV_MTF_VIDEO
	userRegisterIppMdmVideoExt();
#endif
#endif
}



/***************************************************************************
 * rvIppSampleGatewayBaseSelectTermination
 * ------------------------------------------------------------------------
 * General: Registers an ephemeral termination to IPP TK
 *
 ***************************************************************************/
RvMdmTerm *rvIppSampleGatewayBaseSelectTermination(RvIppSampleGatewayBase* gwb, RvMdmTermMgr *mgr)
{

//MARKA	RvRtpLink *rtpLink = NULL;
	static int termNum = 1;
	char termName[16];
	RvMdmTerm *termination = NULL;

//MARKA	rvMtfAllocatorAlloc(sizeof(RvRtpLink), (void**)&rtpLink);
//	rvRtpLinkConstruct(rtpLink);
	sprintf(termName, "rtp/%d", termNum++);
	termination = rvMdmTermMgrRegisterEphemeralTermination(mgr, gwb->rtpClass, termName, NULL);
//MARKA	rvMdmTermSetUserData(termination, rtpLink);

	return termination;
}


/***************************************************************************
 * rvIppSampleGatewayBaseLoadMediaCaps
 * ------------------------------------------------------------------------
 * Loads media capabilities to IPP TK.
 *
 ***************************************************************************/
RvBool rvIppSampleGatewayBaseLoadMediaCaps(RvIppSampleGatewayBase* gwb, RvMdmTermClass* c)
{
	RvSdpMsgList			sdpList;
	RvSdpMsg                *sdpMsg;
	RvSdpMsg				*msgGateway = NULL;

	msgGateway = gwb->sdpOfFullCaps;

	rvSdpMsgListConstructA(&sdpList, userDefaultAlloc);
	sdpMsg = rvSdpMsgListAddMsg( &sdpList);

	rvSdpMsgCopy( sdpMsg, msgGateway);

	rvMdmTermClassAddMediaCapabilities(c, &sdpList, &sdpList, NULL);

	rvSdpMsgListDestruct(&sdpList);

	return rvTrue;
}


/*===============================================================================*/
/*===================    U T I L I T Y	  F U N C T I O N S    ==================*/
/*===============================================================================*/

/***************************************************************************************
 * rvIppSampleUtilGetNextLine
 * -------------------------------------------------------------------------------------
 * General:   Goes through the received buffer, and returns the beginning of the next line.
 * Return Value: Returns a pointer to the beginning of the next line
 * Note: This function assumes all lines have info in them, and that they are already
 *       trimmed on both sides.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer to be parsed
 * Output:   string pointer - pointer to the beginning of the next line
 **************************************************************************************/
RvChar* rvIppSampleUtilGetNextLine(IN RvChar* buf, OUT RvChar** p)
{
    RvChar *tmp = *p;

	if (*p == NULL)
    {
        /* We're at the beginning - give the first line */
		*p = buf;
		return buf;
	}

	/* Skip current line by getting to the next new line */
    while (*tmp && (*tmp != '\n'))
        tmp++;
    if (*tmp == '\n')
        tmp++;
    *p = tmp;

    if (!*tmp)
        return NULL; /* We're done */

	return *p;
}

static RvBool buf2sdp( IN char* bufSdp, OUT RvSdpMsg* sdpMsg)
{
    RvSdpMsg            tempSdpMsg;
	RvSdpParseStatus	stat	=	RV_SDPPARSER_STOP_ZERO;
	RvUint				actlen	=	0;

	actlen	=	strlen( bufSdp);

	if (actlen ==0) /*No SDP message was sent*/
		return rvTrue;


	if (actlen!=0)
	{
        /* Parse buffer into a local sdp message, which will be copied to the output
           sdp message*/
		if ((rvSdpMsgConstructParseA(&tempSdpMsg, bufSdp, (int *)&actlen, &stat, userDefaultAlloc)) != NULL)
		{
            /* sdpMsg should have been constructed before this function was called */
            rvSdpMsgCopy(sdpMsg, &tempSdpMsg);
            /* Local sdp message can be released now*/
            rvSdpMsgDestruct(&tempSdpMsg);
			return rvTrue;
		}
		else
			return rvFalse;
	}
	else
		return rvFalse;
}
/*-----------------------------------------------------------------*/
/***************************************************************************************
 * sampleUtilFile2Sdp
 * -------------------------------------------------------------------------------------
 * General:   Seek for a section titled [MediaParameters{index}], say  [MediaParameters1].
 *				Convert contents of the section to RvSdpMsgList
 * Return Value: True is succeeded, False if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer
 *			 string - section name
 * Output:   RvBool - success/failure
 **************************************************************************************/
static RvBool sampleUtilFile2Sdp(IN const char* buffer, IN const char* szSectionName, OUT RvSdpMsg* sdpMsg)
{
	char		    szPureSdpBuf[4096];
	const RvChar*   ptrFirst;
	const RvChar*	ptrLast;

	/*
	 *	find the first char of a section content.
	 */
	ptrFirst = strstr(buffer, szSectionName);
	if (ptrFirst == NULL)
		return RV_FALSE;
	ptrFirst += strlen(szSectionName) + 1;

	/*
	 *	find the first char after end of a section content.
	 */
	ptrLast = strchr( ptrFirst, '[');
	if (!ptrLast)
		ptrLast = (char*)buffer + strlen(buffer);

	/*
	 *	copy a filtered section content to szPureSdpBuf.
	 */
	{
		RvChar*	        to = szPureSdpBuf;
		const RvChar*	from = ptrFirst;
		RvBool	        bLineStart = RV_TRUE;

		while ((from < ptrLast) && (to < szPureSdpBuf + sizeof(szPureSdpBuf)))
		{
			if (bLineStart)
			{
				if (*from == '#')
				{
					from = strchr(from, '\n') + 1;
					continue;
				}
			}
			else
			{
				if (*from == '\n')
				{
					bLineStart = rvTrue;
					continue;
				}
			}
			*to = *from;
			to++;
            from++;
		}

		*to = '\0';
	}

	/* Convert pure buffer to sdp structure, sdpMsg should be a constructed object*/
	buf2sdp(szPureSdpBuf, sdpMsg);

	return RV_TRUE;
}
/*-----------------------------------------------------------------*/




/***************************************************************************************
 * rvIppSampleLoadMediaParamsFromBuffer
 * -------------------------------------------------------------------------------------
 * General:   Seek for a section titled [MediaParameters{index}], say  [MediaParameters1] for all indexes, starting 0.
 *				Convert contents of the section to RvSdpMsgList
 * Return Value: True is succeeded, False if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer
 *			 integer - index part of section name
 * Output:   RvBool - success/failure
 **************************************************************************************/
RvBool rvIppSampleLoadMediaParamsFromBuffer(IN const char* buffer, OUT RvIppSampleGatewayBase* gwb)
{
	RvSdpMsg	sdpMsg;
	RV_BOOL     res = RV_TRUE;

	rvSdpMsgConstructA(&sdpMsg, userDefaultAlloc);
	/* get media for initial INVITE */
	/* If this media is not configured it will be filled by the media full caps later */
	if(sampleUtilFile2Sdp( buffer, "[MediaParameters0]", &sdpMsg))
	{
		gwb->sdpForInitialInvite = rvSdpMsgConstructCopyA(gwb->sdpForInitialInvite, &sdpMsg, userDefaultAlloc);	
		rvSdpMsgDestruct(&sdpMsg);
		rvSdpMsgConstructA(&sdpMsg, userDefaultAlloc);
	}

    /*
    * load SDP with full capability from [MediaParametersFull] section. If it doesn't exist get it from
	* [MediaParameters0] section.
    */
	if(sampleUtilFile2Sdp( buffer, "[MediaParametersFull]", &sdpMsg ))

	{
		gwb->sdpOfFullCaps = rvSdpMsgConstructCopyA(gwb->sdpOfFullCaps, &sdpMsg, userDefaultAlloc);

		if (gwb->sdpForInitialInvite == NULL)
		{
			/* [mediaparameters0] was not configured, point to media full caps instead */
			gwb->sdpForInitialInvite = gwb->sdpOfFullCaps;
		}
	}
	else
	{
		if (gwb->sdpForInitialInvite != NULL)
		{
	
			/* point to the sdp of initial invite */
			gwb->sdpOfFullCaps =  gwb->sdpForInitialInvite;
		}
		else
		{
			IppLogMessage(RV_TRUE, "rvIppSampleLoadMediaParamsFromBuffer - no sdp for initial INVITE or full caps");
			res = RV_FALSE;
		}

	}

	rvSdpMsgDestruct(&sdpMsg);
	
	return res;
}

