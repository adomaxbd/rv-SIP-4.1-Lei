/******************************************************************************
Filename:    rvrtplink.c
Description: rtp termination handling
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#include "ipp_inc_std.h"
#include "ippmisc.h"
#include "rvsdpenc.h"
#include "IppSampleRtpLink.h"
#include "IppSampleGatewayBase.h"
#include "IppSampleMediaNegotiate.h"
#include "IppSamplePhoneLink.h"
#include "rvstr.h"

#include "rvcctext.h"
#ifndef RV_MTF_MEDIA
#include "mediaControlHelperLocal.h"
#include "rvmdm.h"
#endif


extern RvIppSampleGatewayBase*	 pgw;

RvPtrList*	prtpLinkSendMethod = NULL;/*initialized by stun client*/


/*==================================================================================
======================= D E F A U L T   M E D I A   C A L L B A C K S  ======================
===================================================================================*/
static void defaultModifyMediaCompletedCB(  IN struct RvMdmTerm_*		term,
											IN RvBool					status,
											IN RvMdmMediaDescriptor*	media,
											IN RvMdmMediaStreamDescr*	streamDescr,
											IN RvMdmTermReasonModifyMedia reason)
{
    RV_UNUSED_ARG(term);
    RV_UNUSED_ARG(status);
    RV_UNUSED_ARG(media);
    RV_UNUSED_ARG(streamDescr);
    RV_UNUSED_ARG(reason);
}

static void rvRtpLinkUnregTermCompletedCB(RvMdmTerm* term, RvMdmError     *mdmError)
{
	RV_UNUSED_ARG(mdmError);

	/* destruct the rtplink which is stored in the term->userData */
/*	rvMdmTermMgrDeleteEphTerm_(&pgw->termMgr, term);*/
	rvIppSampleGatewayDeleteEphTerm(&pgw->termMgr, term);
	
}

#if 0
/*==================================================================================
======================= R T P	L I N K		F U N C T I O N S ======================
===================================================================================*/

RvRtpLink *rvRtpLinkConstruct( IN RvRtpLink *x)

{
	IppLogMessage(RV_FALSE, "rvRtpLinkConstruct() success. RvRtpLink=%p", x);
	return x;
}

void rvRtpLinkDestruct(RvRtpLink *x)
{
	/*unregister in stunClient database*/
	if(prtpLinkSendMethod)
		rvPtrListRemove ( prtpLinkSendMethod, &x->sendMethod);

	IppLogMessage(RV_FALSE, "rvRtpLinkDestruct(RvRtpLink=%p), thr=%p", x, RvThreadCurrent());
}

RvRtpLink* RvRtpLinkListGetAudio(RvRtpLinkList* list)
{
	if (list == NULL)
		return NULL;

	return &(list->audio);
}

RvRtpLink* RvRtpLinkListGetVideo(RvRtpLinkList* list)
{
	if (list == NULL)
		return NULL;

	return &(list->video);
}
#endif

/******************************************************************************
*  defaultRtpClassInit
*  ----------------------------
*  General :        Register Media CB for TK. Used in version with MediaFrameWork
*					
*					
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          
*				
*
*  Output:         rvTrue on success.
******************************************************************************/
void rvRtpLinkInitClass(RvMdmTermMgr* termMgr, RvMdmTermClass** rtpClass)
{
	*rtpClass   = rvMdmTermMgrCreateTermClass(termMgr);
	rvMdmTermClassRegisterModifyMediaCompletedCB(*rtpClass, defaultModifyMediaCompletedCB);
	rvMdmTermClassRegisterUnregisterTermCompletedCB(*rtpClass, rvRtpLinkUnregTermCompletedCB);
}




