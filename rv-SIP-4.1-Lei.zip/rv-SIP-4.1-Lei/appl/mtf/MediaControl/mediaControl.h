/******************************************************************************
Filename:    IppMediaControl.h
Description: Common module of Sample Gateway
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_IPP_I_MEDIA_CONTROL_H
#define RV_IPP_I_MEDIA_CONTROL_H

#ifndef IPP_MEDIA_CONTROL_REMOTE
#include "rveppclient.h"
#endif
#include "rvtypes.h"
#include "rvaddress.h"
#include "rvlog.h"
#include "rvsdp.h"

RvLogMgr*       mcLogMgr();
RvLogSource*    mcLogSrc();
/***************************************************************************************
      !!!!!!!!!!!!!!!!!!!!!!!!!!!    NOTE   !!!!!!!!!!!!!!!!!!!!!

	The Media Control project plays a role in the MTF NO MEDIA configurations and in the
	GUI MEDIA configurations. It supports configurations where the media is supported
	by the GUI and not by the MTF.
****************************************************************************************/


/***************************************************************************************
* This module:
*	Defines interface between 2 levels of application code:
 *	the 1st receives device and rtp stream -related commands from TK,
 *	the 2nd controls device and rtp sessions.
 *
 **************************************************************************************/

/*=====================================================*/
#if defined(__cplusplus)
extern "C" {
#endif
/*=====================================================*/
#define MAX_MC_BUF		2048
#define MAX_SDPMSG_SIZE	1000
#define _HEADER_MAGIC(n)	"MFC"#n
#define HEADER_MAGIC(n)	_HEADER_MAGIC(n)
/***************************************************************************************
*				H E L P E R    F U N C T I O N S   D E C L A R A T I O N
*
**************************************************************************************/

typedef enum
{
    __DbGetOperElmIn    ,
	__DbGetOperElmOut   ,
	__DbLinkFindByName  ,
	__DbOperFindByName  ,
    __Init              ,
	__End               ,
	__LinkNew           ,
	__LinkDelete        ,
	__LinkStart         ,
	__LinkStop          ,
	__LinkModify        ,
	__LinkIsStarted     ,
	__OperatorNew       ,
	__OperatorDelete    ,
	__OperatorCmd

}FuncEnum;
/***************************************************************************************/
RvUint32 serializeHeader_to( INOUT RvUint8* buf, IN FuncEnum en); /*return number of serialized bytes*/
RvUint32 serializeHeader_from( IN RvUint8* buf, OUT FuncEnum* en); /*return number of serialized bytes*/
/***************************************************************************************/
RvUint32 serializeUint32_to( INOUT RvUint8* buf, IN RvUint32 n); /*return number of serialized bytes*/
RvUint32 serializeUint32_from( IN RvUint8* buf, OUT RvUint32* n); /*return number of serialized bytes*/
/***************************************************************************************/
RvUint32 serializePtr_to( INOUT RvUint8* buf, IN void* p); /*return number of serialized bytes*/
RvUint32 serializePtr_from( IN RvUint8* buf, OUT void** p); /*return number of serialized bytes*/
/***************************************************************************************/
RvUint32 serializeStr_to( INOUT RvUint8* buf, IN const char* sz); /*return number of serialized bytes*/
RvUint32 serializeStr_from( IN RvUint8* buf, INOUT const char* sz); /*return number of serialized bytes*/
/***************************************************************************************/
RvUint32 serializeSdpMsg_to( INOUT RvUint8* buf, IN RvSdpMsg* msg); /*return number of serialized bytes*/
RvUint32 serializeSdpMsg_from( INOUT RvUint8* buf, INOUT RvSdpMsg* msg); /*return number of serialized bytes*/
/***************************************************************************************/
RvUint32 serializeSdpDescr_to( INOUT RvUint8* buf, IN RvSdpMediaDescr* descr); /*return number of serialized bytes*/
RvUint32 serializeSdpDescr_from( INOUT RvUint8* buf, INOUT RvSdpMediaDescr* descr,
								 RvBool isDescrEmpty); /*return number of serialized bytes*/
/***************************************************************************************/
#ifndef IPP_MEDIA_CONTROL_REMOTE
RvStatus sendBuf( void* context, RvUint8* buf, RvUint32 bytesToSend);
#else
RvStatus sendBuf( RvUint8* buf, RvUint32 bytesToSend);
#endif
/***************************************************************************************/
/***************************************************************
*				M A C R O
***************************************************************/
#define	CHECK_PTR( p, return_code) if(p==NULL){rc = return_code; goto err_exit;}
#define	CHECK_FUNC( f) rc = f; if(rc != 0) goto err_exit;


#ifdef IPP_MEDIA_CONTROL_REMOTE
#if(RV_LOGMASK != RV_LOGLEVEL_NONE)

#define MCLOG_DBG(str)					RvLogDebug(mcLogSrc(), (mcLogSrc(),str))
#define MCLOG_DBG1(format,p1)			RvLogDebug(mcLogSrc(), (mcLogSrc(),format,p1))
#define MCLOG_DBG2(format,p1,p2)		RvLogDebug(mcLogSrc(), (mcLogSrc(),format,p1,p2))
#define MCLOG_DBG3(format,p1,p2, p3)	RvLogDebug(mcLogSrc(), (mcLogSrc(),format,p1,p2, p3))
#define MCLOG_DBG4(format,p1,p2, p3,p4)	RvLogDebug(mcLogSrc(), (mcLogSrc(),format,p1,p2, p3,p4))
#define MCLOG_DBG5(format,p1,p2, p3,p4,p5)	RvLogDebug(mcLogSrc(), (mcLogSrc(),format,p1,p2, p3,p4,p5))

#define MCLOG_INF0(str)					RvLogInfo(mcLogSrc(), (mcLogSrc(),str))
#define MCLOG_INF1(format,p1)			RvLogInfo(mcLogSrc(), (mcLogSrc(),format,p1))
#define MCLOG_INF2(format,p1,p2)		RvLogInfo(mcLogSrc(), (mcLogSrc(),format,p1,p2))
#define MCLOG_INF3(format,p1,p2, p3)	RvLogInfo(mcLogSrc(), (mcLogSrc(),format,p1,p2, p3))
#define MCLOG_WRN0(str)					RvLogWarning(mcLogSrc(), (mcLogSrc(),str))
#define MCLOG_WRN1(format,p1)		    RvLogWarning(mcLogSrc(), (mcLogSrc(),format,p1))
#define MCLOG_WRN2(format,p1,p2)		RvLogWarning(mcLogSrc(), (mcLogSrc(),format,p1,p2))
#define MCLOG_WRN3(format,p1,p2, p3)	RvLogWarning(mcLogSrc(), (mcLogSrc(),format,p1,p2, p3))
#define MCLOG_ERR0(str)					RvLogError(mcLogSrc(), (mcLogSrc(),str))
#define MCLOG_ERR1(format,p1)		    RvLogError(mcLogSrc(), (mcLogSrc(),format,p1))
#define MCLOG_ERR2(format,p1,p2)		RvLogError(mcLogSrc(), (mcLogSrc(),format,p1,p2))
#define MCLOG_ERR3(format,p1,p2, p3)	RvLogError(mcLogSrc(), (mcLogSrc(),format,p1,p2, p3))

#else

#define MCLOG_INF0(str)
#define MCLOG_INF1(format,p1)
#define MCLOG_INF2(format,p1,p2)
#define MCLOG_INF3(format,p1,p2, p3)
#define MCLOG_WRN0(str)
#define MCLOG_WRN1(format,p1)
#define MCLOG_WRN2(format,p1,p2)
#define MCLOG_WRN3(format,p1,p2, p3)
#define MCLOG_ERR0(str)
#define MCLOG_ERR1(format,p1)
#define MCLOG_ERR2(format,p1,p2)
#define MCLOG_ERR3(format,p1,p2, p3)

#endif /*(RV_LOGMASK != RV_LOGLEVEL_NONE)*/
#endif /*IPP_MEDIA_CONTROL_REMOTE*/



/***************************************************************************************/
/***********         MEDIA CONTROL INTERFACE       *************************************/
/***************************************************************************************/
/***************************************************************************************
 * RvIppMediaControlHandle
 * -------------------------------------------------------------------------------------
 * General: Manifests an object that implements RvIppMediaControl interface.
 *			Application allocates and constructs this object by  RvIppMediaControlCreate()
 *			passing own (application) callbacks.
 *			Application destructs and deallocates this object by  RvIppMediaControlDelete()
 *
 **************************************************************************************/
typedef void*	RvIppMediaControlHandle;


#ifdef IPP_MEDIA_CONTROL_REMOTE

typedef int (*sendPacketCB)(
                            IN void* obj,
                            IN char * buf,
                            IN int lenToSend,
                            IN int* plenSent
                            );

/***************************************************************************************
 * RvIppMediaControlRemoteCreate
 * -------------------------------------------------------------------------------------
 * General:   allocates and constructs RvIppMediaControlRemote object
 *
 * Return Value: object handle or NULL if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvIppRtpControl*		- application CBs
 *			 RvIppDevControl*		- application CBs
 * Output:   None
 **************************************************************************************/
RvIppMediaControlHandle RvMediaControlCreate( IN RvBool bConfigTCP, IN void* obj, IN sendPacketCB send);

void RvMtfMediaControlDelete( );


#else /*IPP_MEDIA_CONTROL_REMOTE*/
/***************************************************************************************/
/***********         MEDIA CONTROL       ***********************************************/
/***************************************************************************************/

/***************************************************************************************
 * RvIppMediaControlCreate
 * -------------------------------------------------------------------------------------
 * General:   allocates and constructs RvIppMediaControl object
 *
 * Return Value: object handle or NULL if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvIppRtpControl*		- application CBs
 *			 RvIppDevControl*		- application CBs
 * Output:   None
 **************************************************************************************/
/*RvIppMediaControlHandle RvIppMediaControlCreate( IN RvIppMediaControlCB* callbacks,
												IN RvEppClient*	ec); */

void RvMediaControlCreate( IN RvEppClient*	ec);

void RvMtfMediaControlDelete( );
/***************************************************************************************
 * RvIppMediaControlDelete
 * -------------------------------------------------------------------------------------
 * General:   destructs and deallocates RvIppMediaControl object
 *
 * Return Value: None
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvIppMediaControlHandle	- object handle
 *
 * Output:   None
 **************************************************************************************/
void RvIppMediaControlDelete( RvIppMediaControlHandle hnd);


#endif /*IPP_MEDIA_CONTROL_REMOTE*/


/***************************************************************************************
 * RvIppMediaDispatchCommand
 * -------------------------------------------------------------------------------------
 * General: This is an additional function aimed to workaround the current design restriction.
 *
 *			We need to support an external mechanism of communication via GUI-incorporated listening socket.
 *			Listening socket calls this function upon each receiving buffer. If returned parameter - bHandled - is true
 *			it means that passed buffer was utilized by current library.
 *			If bHandled =false than listen socket should handle this message itself.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	RvIppMediaControlHandle	- object handle
 *			RvAddress*				- sockFromAddr /sock address that sends this buf/
 * 			RvUint8*				- buf,
 *
 * Output:   None
 *			RvBool*					- bHandled  /true if the buffer is handled by this module/
 *
 **************************************************************************************/
RvStatus RvIppMediaDispatchCommand(IN RvAddress*	sockFromAddr,
								   IN RvUint8*		buf,
								   OUT RvBool*		bHandled);


/*=====================================================*/
#if defined(__cplusplus)
}
#endif
/*=====================================================*/

#endif /*RV_IPP_I_MEDIA_CONTROL_H*/
