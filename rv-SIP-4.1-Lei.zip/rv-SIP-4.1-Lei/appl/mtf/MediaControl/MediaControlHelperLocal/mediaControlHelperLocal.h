/******************************************************************************
Filename:    IppSampleMediaControlHelper.h
Description: rtp termination handling
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#ifndef RV_MC_HELPER_LOCAL_H
#define RV_MC_HELPER_LOCAL_H


#if defined(__cplusplus)
extern "C" {
#endif
	
#ifndef IPP_MEDIA_CONTROL_REMOTE
#include "mediaControl.h"
#include "MfControl.h"



/*==================================*/
/*====== Database interface  =======*/
/*==================================*/
/******************************************************************************
* PrxDb - is prefix of API that provides an access to internal database 
*         that any MfControl implementation must maintain.
*         This database contains 2 types of records: for Link objects and for Operator objects.
*         Record adding/removing/modifying is accomplished by MfControl and is transparent for user.
*         Link object record is inserted to DB during RvMfCLinkNew() and is removed during RvMfCLinkdelete().
*         Each Link object record has unique key - char* linkName. PrxDbLinkFindByName(). 
*         PrxDbLinkFindByName()     - find Link object in DB
*         PrxDbGetOperElmIn()       - find operator object that passed link finishes in.  
*         PrxDbGetOperElmOut()      - find operator object that passed link starts from.   
*         
*         Operator object record is inserted during RvMfCOperatorNew() and is removed during PrxOperatorDelete().
*         Each Operator object record has unique key - char* opName.
*         PrxDbOperFindByName()     - find operator object in DB
*  
******************************************************************************/

/******************************************************************************
*  PrxDbLinkFindHndl
*  ----------------------------
*  General :       search Link DB and returns Link handle (if any)
*  Return Value:   RvMfCLinkHandle on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          char*               linkName
*
*  Output          None.
******************************************************************************/
RVAPI HLinkDB PrxDbLinkFindByName( IN void* context, IN const char* linkName);

/******************************************************************************
*  PrxDbOperFindByName
*  ----------------------------
*  General :       search operator DB and returns operator handle (if any)
*  Return Value:   HOperDB on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          const char*       opName
*
*  Output          None.
******************************************************************************/
RVAPI HOperDB PrxDbOperFindByName( IN void* context, IN const char* opName);

/******************************************************************************
*  PrxDbGetOperElmIn
*  ----------------------------
*  General :       Read from a link record. Return a handle of operator this link finish in.  
*  Return Value:   HOperDB on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          HLinkDB       hLinkElm
*
*  Output          None.
******************************************************************************/
RVAPI HOperDB    PrxDbGetOperElmIn( IN void* context, IN HLinkDB hLinkElm);

/******************************************************************************
*  PrxDbGetOperElmOut
*  ----------------------------
*  General :       Read from a link record. Return a handle of operator this link start from.  
*  Return Value:   HOperDB on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          HLinkDB       hLinkElm
*
*  Output          None.
******************************************************************************/
RVAPI HOperDB    PrxDbGetOperElmOut( IN void* context, IN HLinkDB hLinkElm);


/***************************************************************************************
 * RvMfControlConstruct
 * -------------------------------------------------------------------------------------
 * General:   initialize internal RvMfControl object
 *
 * Return Value: none
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvMfControlConstructParam*		- params of initialization
 * Output:   None
 **************************************************************************************/
RVAPI
RvStatus PrxControlInit( IN void* context, IN RvMfControlConstructParam* param);

/***************************************************************************************
 * RvMfControlDestruct
 * -------------------------------------------------------------------------------------
 * General:   destruct internal RvMfControl object
 *
 * Return Value: none
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvMfControlHandle      handle of internal object
 * Output:   None
 **************************************************************************************/
RVAPI
void PrxControlEnd();

/***************************************************************************************
* RvMfCLinkNew
* -------------------------------------------------------------------------------------
* General:  Create Link object.
*           Possible link object types enumerated in RvMfCLinkType struct.
*           Link type and additional parameters for each type are defined in appropriate RvMfCXXXParam structures. 
*           Role and tasks of each Link type are detailed in comments for these structures. 
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			RvMfCLinkParamBase*	- param: in reality one of RvMfCXXXParam is passed.
*
* Output:
*			HLinkDB	        - hLink: handle of created Link object
*
**************************************************************************************/
RVAPI RvStatus PrxLinkNew(  IN void* context, OUT HLinkDB *hLink,INOUT RvMfCLinkParamBase* param);


/***************************************************************************************
* RvMfCLinkDelete
* -------------------------------------------------------------------------------------
* General: Delete Link object.
*
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			HLinkDB	        - hLink: handle of Link object
* Output:
*			None
*
**************************************************************************************/
RVAPI RvStatus PrxLinkDelete( IN void* context, IN HLinkDB hLink);


/***************************************************************************************
* RvMfCLinkStart
* -------------------------------------------------------------------------------------
* General: Start buffer handling and propagating activity.
*
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			HLinkDB	        - hLink: handle of Link object
* Output:
*			None
*
**************************************************************************************/
RVAPI RvStatus PrxLinkStart  ( IN void* context, IN HLinkDB hLink);


/***************************************************************************************
* RvMfCLinkStop
* -------------------------------------------------------------------------------------
* General:  Stop buffer handling and propagating activity. 
*           Release all buffers hung inside Link object (say, in asynchronous nodes)
*  
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			HLinkDB	        - hLink: handle of Link object
* Output:
*			None
*
**************************************************************************************/
RVAPI RvStatus PrxLinkStop ( IN void* context, IN HLinkDB hLink);

/***************************************************************************************
* RvMfCLinkModify
* -------------------------------------------------------------------------------------
* General: Modify media link object.
*          Compare current object parameters with requested ones.
*			If parameters may be changed on-fly accomplishes this job.
*			Else return error.
*			Example of possible change is request to silence support/unsupport for some audio codecs
*			Example of impossible change is request to change IP address:
*			                             RtpReceiver node (built inside LinkRtpIn object) cannot do it.
*
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			HLinkDB	        - hLink: handle of Link object
*			RvMfCLinkModifyParam*	- param: parameters of media
* Output:
*			None
*
**************************************************************************************/
RVAPI RvStatus PrxLinkModify ( IN void* context, IN HLinkDB hLink, IN RvMfCLinkModifyParam* param);



/***************************************************************************************
* RvMfCLinkIsStarted
* -------------------------------------------------------------------------------------
* General:  Check if Link object in Start or Stop mode. 
*  
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			HLinkDB	        - hLink: handle of Link object
* Output:
*			None
*
**************************************************************************************/
RVAPI RvBool PrxLinkIsStarted ( IN void* context, IN HLinkDB hLink);

/***************************************************************************************
 *
 * Operator object and operations on it
 * Operator types
 * Operations on Operator object
 *
 **************************************************************************************/


/***************************************************************************************
* RvMfCOperatorNew
* -------------------------------------------------------------------------------------
* General:  Create Operator object.
*           Possible link object types enumerated in RvMfCOprType.
*           Operator type and additional parameters for each type are defined in appropriate RvMfCOprXXXParam structures. 
*           Role and tasks of each Operator type are detailed in comments for these structures. 
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			RvMfCLinkParamBase*	- param: in reality one of RvMfCXXXParam is passed.
*
* Output:
*			HLinkDB	        - hLink: handle of created Link object
*
**************************************************************************************/
RVAPI RvStatus PrxOperatorNew(  IN void* context, OUT HOperDB *hOperator, IN const char* opName, IN RvMfCOprBaseParam* param);


/***************************************************************************************
* PrxOperatorDelete
* -------------------------------------------------------------------------------------
* General: Delete Operator object.
*
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			HLinkDB	        - hLink: handle of Link object
* Output:
*			None
*
**************************************************************************************/
RVAPI void PrxOperatorDelete( IN void* context, IN HOperDB hOperator);

/**************************************************************************************
 * Commands defined over Operator object
**************************************************************************************/

/***************************************************************************************
* RvMfCOperatorCmd
* -------------------------------------------------------------------------------------
* General:  Send command to Operator object.
*           Possible command types enumerated in RvMfCOpCmd.
*           Command type and additional parameters for each type are defined in  RvMfCOpCmdParam structure. 
*           Role and tasks of each command type are detailed in comments for these structures. 
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*			RvMfCLinkParamBase*	- param: in reality one of RvMfCXXXParam is passed.
*
* Output:
*			HLinkDB	        - hLink: handle of created Link object
*
**************************************************************************************/
RVAPI RvStatus PrxOperatorCmd( IN void* context, IN RvMfCOpCmd cmd, IN RvMfCOpCmdParam* param);
												
#endif /* #ifndef IPP_MEDIA_CONTROL_REMOTE */
#if defined(__cplusplus)
}
#endif

#endif
