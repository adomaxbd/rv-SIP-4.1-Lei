/******************************************************************************
Filename:    rvrtplink.c
Description: rtp termination handling
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>


#include "rvmemory.h"
#include "rvconfig.h"
#include "rvalloc.h"
#include "rvtypes.h"
#include "rverror.h"
#include "rvtm.h"
#include "rvlog.h"
#include "rvmutex.h"
#include "rvsocket.h"

#include "rvsdpenc.h"
#include "ippcodec.h"
#include "MfControl.h"
#include "mediaControl.h"


/***************************************************************************************/


/***************************************************************************************
*       MfControl        
*		L O C A L    I M P L E M E N T A T I O N  
*
**************************************************************************************/

/***************************************************************************************/
/***************************************************************************************/
RVAPI 
HOperDB    PrxDbGetOperElmIn( IN void* context, IN HLinkDB hLink)
{
    RvStatus    rc;
    RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    HOperDB     hRet =NULL;
        
    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __DbGetOperElmIn);
    
    /*serialize param fields*/
    offset += serializePtr_to( &buf[offset], (void*)hLink); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializePtr_from( buf, (void**)&hRet);

    return hRet;
err_exit:
	IppLogMessage(RV_TRUE, "PrxDbGetOperElmIn() failed");
    return NULL;
}
/***************************************************************************************/
RVAPI 
HOperDB    PrxDbGetOperElmOut( IN void* context, IN HLinkDB hLink)
{
    RvStatus    rc;
    RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    HOperDB     hRet =NULL;
        
    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __DbGetOperElmOut);
    
    /*serialize param fields*/
    offset += serializePtr_to( &buf[offset], (void*)hLink); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializePtr_from( buf, (void**)&hRet);

    return hRet;
err_exit:
	IppLogMessage(RV_TRUE, "PrxDbGetOperElmOut() failed");
    return NULL;
}
/***************************************************************************************/

/******************************************************************************
*  PrxDbLinkFindHndl
*  ----------------------------
*  General :       search Link DB and returns Link handle if any
*  Return Value:   RvMfCLinkHandle on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          char*               linkName
*
*  Output          None.
******************************************************************************/
RVAPI 
HLinkDB PrxDbLinkFindByName( IN void* context, IN const char* linkName)
{
    RvStatus    rc;
    RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    HLinkDB     hRet =NULL;
        
    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __DbLinkFindByName);
    
    /*serialize param fields*/
    offset += serializeStr_to( &buf[offset], linkName); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializePtr_from( buf, (void**)&hRet);

    return hRet;
err_exit:
	IppLogMessage(RV_TRUE, "PrxDbLinkFindByName() failed");
    return NULL;
}
/***************************************************************************************/

/******************************************************************************
*  PrxDbOperFindByName
*  ----------------------------
*  General :       search operator DB and returns oper handle if any
*  Return Value:   HOperDB on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          const char*       opName
*
*  Output          None.
******************************************************************************/
RVAPI 
HOperDB PrxDbOperFindByName( IN void* context, IN const char* opName)
{
    RvStatus    rc;
    RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    HOperDB     hRet =NULL;
    
    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __DbOperFindByName);
    
    /*serialize param fields*/
    offset += serializeStr_to( &buf[offset], opName); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializePtr_from( buf, (void**)&hRet);

    return hRet;
err_exit:
	IppLogMessage(RV_TRUE, "PrxDbOperFindByName() failed");
    return NULL;
}
/***************************************************************************************/

/***************************************************************************************/

/******************************************************************************
*  PrxDbOperIsEmpty
*  ----------------------------
*  General :       check if oper has no in and out links
*  Return Value:   RvMfCOperatorHandle on success or NULL
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          RvMfCOperatorHandle  hOper
*                  RvMfCLinkHandle hLink
*
*  Output          None.
******************************************************************************/
#if 0
RVAPI 
RvBool PrxDbOperIsEmpty( IN void* context, IN HOperDB hOper, ContainerDir dir)
{
    RvBool      rc;
    RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    RvUint32    tmp;
        
    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __DbOperIsEmpty);
    
    /*serialize param fields*/
    offset += serializePtr_to( &buf[offset], (void*)hOper); 
    offset += serializeUint32_to( &buf[offset], dir);
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, &tmp); rc = tmp;
    return rc;
err_exit:
	IppLogMessage(RV_TRUE, "PrxDbOperIsEmpty() failed");
    return rvFalse;
}
#endif
/***************************************************************************************/



RVAPI
RvStatus PrxControlInit( IN void* context, IN RvMfControlConstructParam* param)
{
    RvStatus    rc;
    RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
	static RvUint32  dataDownloadCounter = 0;
    
    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __Init);
    
    /*serialize param fields*/
    /* log file name is not passed to remote */
    offset += serializeUint32_to( &buf[offset], param->mfcLogMask);// max number of incoming chains (including mic)

    //limits
    offset += serializeUint32_to( &buf[offset], param->max_num_in_chains);// max number of incoming chains (including mic)
    offset += serializeUint32_to( &buf[offset], param->max_num_out_chains);// max number of outgoing chains (including mic)
    
    offset += serializeUint32_to( &buf[offset], param->max_num_nodes_of_chain);
    offset += serializeUint32_to( &buf[offset], param->max_num_groups       );//max number of groups in system
    offset += serializeUint32_to( &buf[offset], param->max_num_messages     );//max number of persisting Control Messages in system
    offset += serializeUint32_to( &buf[offset], param->amax_num_messageSize );//max Control Message size
    offset += serializeUint32_to( &buf[offset], param->max_num_rtpSessions  );//max number of CMFRtpSocket objects (open sockets are *2 more) in system
    offset += serializeStr_to( &buf[offset], param->RTPAddress);        //base port for CMFPortPool object
    /* In case of many endpoints of one MTF (e.g. analog endpoints), each endpoint should be assigned with
	   different base port for RTP. Therefore after each data download to an endpoint the portDownloadCounter is
	   incremented by one The downloaded base port number is incremented by this counter * max num of ports per endpoint */
	offset += serializeUint32_to( &buf[offset], param->portLocalBase + (dataDownloadCounter * param->max_num_portLocal));        //base port for CMFPortPool object
    dataDownloadCounter++;
    offset += serializeUint32_to( &buf[offset], param->max_num_portLocal    );//port range for CMFPortPool object
    
    //contexts
    offset += serializeUint32_to( &buf[offset], param->recv_aud_cntx_poll_interval_msec);//
    offset += serializeUint32_to( &buf[offset], param->recv_aud_cntx_priority);//
    offset += serializeUint32_to( &buf[offset], param->recv_vid_cntx_poll_interval_msec);//
    offset += serializeUint32_to( &buf[offset], param->recv_vid_cntx_priority);//
    offset += serializeUint32_to( &buf[offset], param->recv_cntx_stack_size);//
    
    offset += serializeUint32_to( &buf[offset], param->play_aud_cntx_poll_interval_msec);//
    offset += serializeUint32_to( &buf[offset], param->play_vid_cntx_poll_interval_msec);//
    offset += serializeUint32_to( &buf[offset], param->play_serv_priority);//
    offset += serializeUint32_to( &buf[offset], param->play_cntx_stack_size);//
    
    //callback that must build MfControlInternal - derived object
    // if NULL builds MfControlInternal object itself
    /* not passed to remote
    RvMfCCreateInternalCB    createInternalCB;
    */
    // sample frequency frame size
    offset += serializeUint32_to( &buf[offset], param->nSamplesPerSecAudio);
    offset += serializeUint32_to( &buf[offset], param->nSamplesPerFrameAudio);
    offset += serializeUint32_to( &buf[offset], param->nSamplesPerSecVideo);
    offset += serializeUint32_to( &buf[offset], param->nFrameRatePerSecVideo);// capture frame rate
    // video resolution on start
    offset += serializeUint32_to( &buf[offset], param->nFrameSize); // camera capturing resolution
    offset += serializeUint32_to( &buf[offset], param->nFrameSizeLocal); //LOCAL display resolution
    
    offset += serializeUint32_to( &buf[offset], param->defDevice); // default device to be initialized on the start-up of the system: headset, handset ot mic&speak
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, (RvUint32*)&rc);
    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfControlInit() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfControlInit() failed");
    return RV_ERROR_UNKNOWN;
}
/*===================================================================*/
/***************************************************************************************
 * RvMfControlDestruct
 * -------------------------------------------------------------------------------------
 * General:   destruct internal RvMfControl object
 *
 * Return Value: none
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvMfControlHandle      handle of internal object
 * Output:   None
 **************************************************************************************/
RVAPI
void PrxControlEnd( IN void* context)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __End);
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    return ;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfControlEnd() failed");
    return ;

}
/*===================================================================*/
RVAPI RvStatus PrxLinkNew( IN void* context, OUT HLinkDB *hLink, INOUT RvMfCLinkParamBase* param)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    RvMfCLinkNewParam*      p = (RvMfCLinkNewParam*)param;

    *hLink = NULL;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __LinkNew);

    /*serialize common fields*/
    offset += serializeUint32_to( &buf[offset], param->type); 
    offset += serializeStr_to( &buf[offset], param->szLinkName); 

    /*serialize link specific fields*/
    switch(param->type)
    {
    case RVMFC_LINK_TYPE_MIC:
        {
            offset += serializeUint32_to( &buf[offset], p->mic.nSamplesPerFrame); 
            offset += serializeUint32_to( &buf[offset], p->mic.nSamplesPerSec); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset += serializePtr_from( &buf[offset], (void**)hLink);
        }
        break;

    case RVMFC_LINK_TYPE_SPEAK:
        {
            offset += serializeUint32_to( &buf[offset], p->speaker.samplesPerFrame); 
            offset += serializeUint32_to( &buf[offset], p->mic.nSamplesPerSec); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset += serializePtr_from( &buf[offset], (void**)hLink);
        }
        break;

    case RVMFC_LINK_TYPE_RTP_IN:
        {
            offset += serializeUint32_to( &buf[offset], p->in.bIsIPV6); 
            offset += serializeUint32_to( &buf[offset], p->in.bIsVideo); 
            offset += serializeUint32_to( &buf[offset], p->in.frameSize); 
            offset += serializeUint32_to( &buf[offset], p->in.nFrameRate); 
            offset += serializeUint32_to( &buf[offset], p->in.nSamplesPerFrame); 
            offset += serializeUint32_to( &buf[offset], p->in.nSamplesPerSec); 
            offset += serializeUint32_to( &buf[offset], p->in.portLocal); 
            offset += serializeUint32_to( &buf[offset], p->in.sessId); 
            offset += serializeStr_to( &buf[offset], p->in.szDescr); 
            offset += serializeStr_to( &buf[offset], p->in.szIpLocal); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
            {
    	        offset += serializePtr_from( &buf[offset], (void**)hLink);
		        offset += serializeStr_from( &buf[offset], p->in.szDescr);
            }
        }

        break;
    case RVMFC_LINK_TYPE_RTP_OUT:
        {
            offset += serializeUint32_to( &buf[offset], p->out.bIsIPV6); 
            offset += serializeUint32_to( &buf[offset], p->out.bIsVideo); 
            offset += serializeUint32_to( &buf[offset], p->out.frameSize); 
            offset += serializeUint32_to( &buf[offset], p->out.nFrameRate); 
            offset += serializeUint32_to( &buf[offset], p->out.nSamplesPerFrame); 
            offset += serializeUint32_to( &buf[offset], p->out.nSamplesPerSec); 
            offset += serializeUint32_to( &buf[offset], p->out.portLocal); 
            offset += serializeUint32_to( &buf[offset], p->out.sessId); 
            offset += serializeStr_to( &buf[offset], p->out.szDescr); 
            offset += serializeStr_to( &buf[offset], p->out.szIpLocal); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset += serializePtr_from( &buf[offset], (void**)hLink);
        }
        break;

#ifdef RV_MTF_VIDEO
        /*video physical terminations*/
    case RVMFC_LINK_TYPE_CAMERA:
        {
            offset += serializeUint32_to( &buf[offset], p->camera.bDisplayLocal); 
            offset += serializeUint32_to( &buf[offset], p->camera.frameRate); 
            offset += serializeUint32_to( &buf[offset], p->camera.frameSize); 
            offset += serializeUint32_to( &buf[offset], p->camera.frameSizeLocal); 
#ifdef WIN32
            offset += serializePtr_to( &buf[offset], (void*)p->camera.hVideoObj); 
#else
			/* when running in non-windows machines there is no camera.hVideoObj. Assign NULL instead.
			   The GUI application will probably not retrieve this value as its mediaControl is built
			   without RV_MTF_VIDEO */
			offset += serializePtr_to( &buf[offset], NULL); 
#endif
            offset += serializeUint32_to( &buf[offset], p->camera.local_display_poll_interval_msec); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset += serializePtr_from( &buf[offset], (void**)hLink);
        }
        break;
        
    case RVMFC_LINK_TYPE_WINDOW:
        {
            offset += serializeUint32_to( &buf[offset], p->wnd.frameRate); 
            offset += serializeUint32_to( &buf[offset], p->wnd.frameSize); 
#ifdef WIN32
            offset += serializePtr_to( &buf[offset], (void*)p->wnd.hVideoObj); 
#else
			/* when running in non-windows machines there is no wnd.hVideoObj. Assign NULL instead.
			The GUI application will probably not retrieve this value as its mediaControl is built
			without RV_MTF_VIDEO */
			offset += serializePtr_to( &buf[offset], NULL); 
#endif

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset += serializePtr_from( &buf[offset], (void**)hLink);
        }
        break;
#endif
    default:
    	IppLogMessage(RV_TRUE, " RvMfCLinkNew(). Not supported link type = %d",param->type);
        goto err_exit;
    }

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCLinkNew() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCLinkNew() failed");
    return RV_ERROR_UNKNOWN;
}
////////////////////////////////////////////////
RvStatus PrxLinkDelete( IN void* context, IN HLinkDB hLink)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __LinkDelete);

    /*serialize fields*/
    offset += serializePtr_to( &buf[offset], (void*)hLink); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, (RvUint32*)&rc);

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCLinkDelete() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCLinkDelete() failed");
    return RV_ERROR_UNKNOWN;
}
////////////////////////////////////////////////
RVAPI RvStatus PrxLinkStart ( IN void* context, IN HLinkDB hLink)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __LinkStart);

    /*serialize fields*/
    offset += serializePtr_to( &buf[offset], (void*)hLink); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, (RvUint32*)&rc);

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCLinkStart() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCLinkStart() failed");
    return RV_ERROR_UNKNOWN;
}
////////////////////////////////////////////////
RVAPI RvStatus PrxLinkStop ( IN void* context, IN HLinkDB hLink)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __LinkStop);

    /*serialize fields*/
    offset += serializePtr_to( &buf[offset], (void*)hLink); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, (RvUint32*)&rc);

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCLinkStop() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCLinkStop() failed");
    return RV_ERROR_UNKNOWN;
}
////////////////////////////////////////////////
RVAPI RvBool PrxLinkIsStarted ( IN void* context, IN HLinkDB hLink)
{
    RvBool    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __LinkIsStarted);

    /*serialize fields*/
    offset += serializePtr_to( &buf[offset], (void*)hLink); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, (RvUint32*)&rc);

    return rc;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCLinkIsStarted() failed");
    return rvFalse;
}
////////////////////////////////////////////////
RVAPI RvStatus PrxLinkModify ( IN void* context, IN HLinkDB hLink, IN RvMfCLinkModifyParam* p)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;
    RvMfCLinkParamBase*     param = (RvMfCLinkParamBase*)p;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __LinkModify);

    /*serialize common fields*/
    offset += serializeUint32_to( &buf[offset], param->type); 
    offset += serializeStr_to( &buf[offset], param->szLinkName); 
    offset += serializePtr_to(  &buf[offset], (void*)hLink);

    /*serialize link specific fields*/
    switch(param->type)
    {
    case RVMFC_LINK_TYPE_RTP_IN:
        {
            offset += serializeUint32_to( &buf[offset], p->in.bIsIPV6); 
            offset += serializeUint32_to( &buf[offset], p->in.bIsVideo); 
            offset += serializeUint32_to( &buf[offset], p->in.frameSize); 
            offset += serializeUint32_to( &buf[offset], p->in.nFrameRate); 
            offset += serializeUint32_to( &buf[offset], p->in.nSamplesPerFrame); 
            offset += serializeUint32_to( &buf[offset], p->in.nSamplesPerSec); 
            offset += serializeUint32_to( &buf[offset], p->in.portLocal); 
            offset += serializeUint32_to( &buf[offset], p->in.sessId); 
            offset += serializeStr_to( &buf[offset], p->in.szDescr); 
            offset += serializeStr_to( &buf[offset], p->in.szIpLocal); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }

        break;
    case RVMFC_LINK_TYPE_RTP_OUT:
        {
            offset += serializeUint32_to( &buf[offset], p->out.bIsIPV6); 
            offset += serializeUint32_to( &buf[offset], p->out.bIsVideo); 
            offset += serializeUint32_to( &buf[offset], p->out.frameSize); 
            offset += serializeUint32_to( &buf[offset], p->out.nFrameRate); 
            offset += serializeUint32_to( &buf[offset], p->out.nSamplesPerFrame); 
            offset += serializeUint32_to( &buf[offset], p->out.nSamplesPerSec); 
            offset += serializeUint32_to( &buf[offset], p->out.portLocal); 
            offset += serializeUint32_to( &buf[offset], p->out.sessId); 
            offset += serializeStr_to( &buf[offset], p->out.szDescr); 
            offset += serializeStr_to( &buf[offset], p->out.szIpLocal); 
						offset += serializeUint32_to( &buf[offset], p->out.Command); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));

	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;

    default:
    	IppLogMessage(RV_TRUE, " RvMfCLinkModify(). Not supported link type = %d",param->type);
        goto err_exit;
    }

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCLinkModify() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCLinkModify() failed");
    return RV_ERROR_UNKNOWN;
}
////////////////////////////////////////////////
////////////////////////////////////////////////
RVAPI RvStatus PrxOperatorNew( IN void* context, OUT HOperDB *hOperator, IN const char* opName, IN RvMfCOprBaseParam* param)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    *hOperator = NULL;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __OperatorNew);

    /*serialize common fields*/
    offset += serializeUint32_to( &buf[offset], param->type); 
    offset += serializeStr_to( &buf[offset], opName); 

    /*serialize link specific fields*/
    switch(param->type)
    {
    case OPR_TYPE_MIX_AUDIO:
        {
            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset = serializePtr_from( &buf[offset], (void**)hOperator);
        }
        break;

#ifdef RV_MTF_VIDEO
    case OPR_TYPE_MIX_VIDEO:
        {
            RvMfCOprMixVideoParam*      p = (RvMfCOprMixVideoParam*)param;

            offset += serializeUint32_to( &buf[offset], p->frameSize); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
	        if( RV_OK == (RvStatus)rc)
    	        offset = serializePtr_from(  &buf[offset], (void**)hOperator);
        }
        break;
#endif
    default:
    	IppLogMessage(RV_TRUE, " RvMfCOperatorNew(). Not supported operator type = %d",param->type);
        goto err_exit;
    }

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCOperatorNew() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCOperatorNew() failed");
    
    return RV_ERROR_UNKNOWN;
}
////////////////////////////////////////////////
RVAPI void PrxOperatorDelete( IN void* context, IN HOperDB hOperator)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __OperatorDelete);

    /*serialize fields*/
    offset += serializePtr_to( &buf[offset], (void*)hOperator); 
    
    /*send to remote side*/
    CHECK_FUNC( sendBuf( context, buf, offset));
    
    /*get output. */
    offset = serializeUint32_from( buf, (RvUint32*)&rc);

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCOperatorDelete() failed on remote side");
        goto err_exit;
    }
    return;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCOperatorDelete() failed");
    return ;
}
////////////////////////////////////////////////
RVAPI RvStatus PrxOperatorCmd( IN void* context, IN RvMfCOpCmd cmd, IN RvMfCOpCmdParam* param)
{
    RvStatus    rc;
	RvUint8     buf[MAX_MC_BUF];
    RvUint32    offset;

    /*serialize  Header*/
    offset = serializeHeader_to(  buf, __OperatorCmd);
    /*serialize  common fields*/
    offset += serializeUint32_to(  &buf[offset], (RvUint32)cmd);

    switch(cmd)
    {
    case OPCMD_MIX_AUDIO_ADD_IN:
        {
            /*serialize fields*/
            offset += serializePtr_to( &buf[offset], (void*)param->mix_audio_add_in.hOperator); 
            offset += serializePtr_to( &buf[offset], (void*)param->mix_audio_add_in.hLinkIn); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;

    case OPCMD_MIX_AUDIO_ADD_OUT:
        {
            /*serialize fields*/
            offset += serializePtr_to( &buf[offset], (void*)param->mix_audio_add_out.hOperator); 
            offset += serializePtr_to( &buf[offset], (void*)param->mix_audio_add_out.hLinkOut); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;

/*=====================================================*/
#ifdef RV_MTF_VIDEO
/*=====================================================*/
    case OPCMD_MIX_VIDEO_ADD_IN:
        {
            /*serialize fields*/
            offset += serializePtr_to( &buf[offset], (void*)param->mix_video_add_in.hOperator); 
            offset += serializePtr_to( &buf[offset], (void*)param->mix_video_add_in.hLinkIn); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;

    case OPCMD_MIX_VIDEO_ADD_OUT:
        {
            /*serialize fields*/
            offset += serializePtr_to( &buf[offset], (void*)param->mix_video_add_out.hOperator); 
            offset += serializePtr_to( &buf[offset], (void*)param->mix_video_add_out.hLinkOut); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;
/*=====================================================*/
#endif /// RV_MTF_VIDEO
/*=====================================================*/


    case OPCMD_REMOVE_IN:
        {
            /*serialize fields*/
            offset += serializePtr_to( &buf[offset], (void*)param->remove_in.hOperator); 
            offset += serializePtr_to( &buf[offset], (void*)param->remove_in.hLinkIn); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;
    case OPCMD_REMOVE_OUT:
        {
            /*serialize fields*/
            offset += serializePtr_to( &buf[offset], (void*)param->remove_out.hOperator); 
            offset += serializePtr_to( &buf[offset], (void*)param->remove_out.hLinkOut); 

            /*send to remote side*/
	        CHECK_FUNC( sendBuf( context, buf, offset));
	        /*get output. */
	        offset = serializeUint32_from( buf, (RvUint32*)&rc);
        }
        break;
    default:
        IppLogMessage(RV_FALSE,  "RvMfCOperatorCmd(). not yet implemented cmd =%d", cmd);
        
        return RV_ERROR_UNKNOWN;
    }

    if(RV_OK != rc)
    {
    	IppLogMessage(RV_TRUE, "RvMfCOperatorCmd() failed on remote side");
        goto err_exit;
    }
    return RV_OK;
err_exit:
	IppLogMessage(RV_TRUE, "RvMfCOperatorCmd() failed. cmd = %d", cmd);
	return rc;
}

