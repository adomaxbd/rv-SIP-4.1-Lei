/******************************************************************************
Filename   :
Description:
******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:$
$Author: S. Cipolli$
******************************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "IppStdInc.h"
#include "ippmisc.h"
#include "ippthread.h"
#include "rvstr.h"
#include "rvansi.h"
#include "rvhost.h"
#include "rvlist.h"
#include "rveppclient.h"



/* EppClientEndpoint */
static RvEppClientEndpoint* rvEppClientEndpointConstruct(
    IN RvEppClient*     ec,
    IN const RvChar*    name,
    IN const RvChar*    ip,
    IN RvUint16         port,
    IN int              profile,
	IN RvChar*          regParams)
{
    RvEppClientEndpoint*    ece;
    RvAddress               localAddr;
    RvStatus                status;

    if (ec->numEndpoints == EPP_MAX_ENDPOINTS)
    {
        IppLogMessage(RV_TRUE, "rvEppClientEndpointConstruct() - no room for more clients");
        return NULL;
    }

    ece = &ec->endpoints[ec->numEndpoints];
    ece->ec = ec;

    if(!ec->bConfigTCP)
    {
        IppLogMessage(RV_FALSE, "rvEppClientEndpointConstruct(). ip:port= %s:%d", ip, port);

        RvAddressConstructFromString((RvChar*)ip, &ece->address);
        RvAddressSetIpPort(&ece->address,port);

        status = RvSocketConstruct(ece->address.addrtype, RvSocketProtocolUdp, IppLogMgr(), &ece->s);
        if (RV_OK != status)
        {
            IppLogMessage(RV_TRUE, "rvEppClientEndpointConstruct::RvSocketConstruct fail error =%d", status);
            return NULL;
        }
        RvAddressConstructCopy(&ec->localAddr, &localAddr);
        RvAddressSetIpPort(&localAddr, RV_ADDRESS_IPV4_ANYPORT);

        status = RvSocketSetBlocking( &ece->s, RV_TRUE, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientEndpointConstruct::set socket to non blocking fail error =%d", status);
        
        status = RvSocketBind(&ece->s, &localAddr, NULL, IppLogMgr());
        if (RV_OK != status)
        {
            IppLogMessage(RV_TRUE, "rvEppClientEndpointConstruct::RvSocketConstruct fail error =%d", status);
            RvSocketDestruct(&ece->s, RV_FALSE, NULL, IppLogMgr());
            return NULL;
        }
    }
    else
    {
        ;/*do nothing*/
    }

    if ((profile == EP_PROFILE_IPPHONE) || (profile == EP_PROFILE_ANALOG))
    {
        ece->profile = profile;
    }
    else
    {
        ece->profile = EP_PROFILE_ANALOG;
    }
    strcpy(ece->name, name);

    /* We increase numEndpoints before calling Register callback since if we increase
       it later it may be executed only after we are checking it */
    ec->numEndpoints++;
    if (!ec->eRegister(ece, regParams))
    {

        /* Seems like someone out there doesn't like this client */
        ec->numEndpoints--;
        if(!ec->bConfigTCP)
        {
            RvSocketDestruct(&ece->s, RV_FALSE, NULL, IppLogMgr());
        }
        
        return NULL;
    }

    return ece;
}

void rvEppClientEndpointDestruct(RvEppClientEndpoint* ece)
{
    if(!ece->ec->bConfigTCP)
    {
        RvSocketDestruct(&ece->s, rvFalse, NULL, IppLogMgr ());
    }
}

static RvBool eppPacketRecv( RvSocket* s,
                      IN RvSize_t msgRcvdMaxSize,
                      OUT char* msgRcvd)
{
    RvStatus    rc;
    RvSize_t    len, tmpRcv;
    RvSize_t    i =0, step;

    /* Implements the following protocol:
    * 1. Reads string (of 3 character + 0-terminated) that represent length of receiving afterward data buffer
    * 2. Reads data buffer of given length
    */
    /* read buffer of 4 bytes that contains length of following data buffer.
    *  then read buffer of given length.
    */
    for(step =0, len = 4;   step <2;   step++, len = atoi( msgRcvd))
    {
        if( msgRcvdMaxSize < len)
        {
            IppLogMessage(RV_TRUE, "eppPacketRecv() too small buffer. msgRcvdMaxSize =%d. buf size = %d", msgRcvdMaxSize, len);
            return rvFalse;
        }
        for( i=0; len >0; len -=tmpRcv, i +=tmpRcv)
        {
            rc  = RvSocketReceiveBuffer( s, (unsigned char*)&msgRcvd[i], len, IppLogMgr(), &tmpRcv, NULL);
            if(rc != RV_OK || tmpRcv ==0)
                return rvFalse;
        }
    }
    return rvTrue;
}

static void convertMultiString( OUT char* msgLog, IN char* msg, IN RvSize_t len)
{
    RvSize_t    i;
	if (len == 0)
	{
		return;
	}

    /* before printing we replace all '\0' by '|'*/
    msgLog[ len -1] = '\0';
    memcpy( msgLog, msg, len-1);
    for(i=0; i < len -1; i++)
        if(msgLog[i] =='\0')
            msgLog[i] ='|';
}

void rvEppClientEndpointSend( IN RvEppClientEndpoint* ece,
                              IN char* msgSend,
                              IN RvSize_t sizeSend,
                              IN RvSize_t msgRcvdMaxSize,
                              OUT char* msgRcvd)
{
    RvSize_t    bytesSent;
    RvStatus    rc;
    RvSize_t    len;
    char       msgLog [1024];

	if (ece == NULL)
	{
		strcpy(msgRcvd, "");
		return;
	}

    if(ece->ec->bConfigTCP)
    {
	    RvChar      szlen[4];
        
        RvMutexLock( &ece->ec->sendGuard, IppLogMgr());

        /*-------------------------------------------------------*/
        /* Implements the following protocol:
        * 1. Sends string (of 3 character + 0-terminated) that represent length of sending afterward data buffer
        * 2. Sends requested data buffer
        */
        /*send length*/
        sprintf( szlen, "%3.3d", (RvInt) sizeSend);
        len = strlen( szlen)+1;


        rc = RvSocketSendBuffer( &ece->ec->s,(RvUint8*)szlen, len, NULL, IppLogMgr (), &bytesSent);

        if( rc !=RV_OK || bytesSent != len)
        {
            IppLogMessage(RV_TRUE, "rvEppClientEndpointSend() failed to send for %p socket", &ece->ec->s);
            RvMutexUnlock( &ece->ec->sendGuard, IppLogMgr());
            return;
        }
        IppLogMessage(RV_FALSE, "EPP --> %s, %d", szlen, len);

        /*send buff*/
        rc = RvSocketSendBuffer( &ece->ec->s, (RvUint8*)msgSend, sizeSend, NULL, IppLogMgr (), &bytesSent);

        if( rc !=RV_OK || bytesSent != sizeSend)
        {
            IppLogMessage(RV_TRUE, "rvEppClientEndpointSend() failed to send for %p socket", &ece->ec->s);
            RvMutexUnlock( &ece->ec->sendGuard, IppLogMgr());
            return;
        }
        else
        {
            /* before printing we replace all '\0' by '|'*/
            convertMultiString( msgLog, msgSend, RvMin( sizeof(msgLog), sizeSend));
            IppLogMessage(RV_FALSE, "EPP --> %s, %d", msgLog, sizeSend);
        }
        /* do a receive */
        /*-------------------------------------------------------*/
        if( eppPacketRecv( &ece->ec->s, msgRcvdMaxSize, msgRcvd))
        {
            /* before printing we replace all '\0' by '|'*/
            convertMultiString( msgLog, msgRcvd, RvMin( sizeof(msgLog), len));
            IppLogMessage(RV_FALSE, "EPP <-- %s, %d", msgRcvd, len);
        }
        else
        {
            IppLogMessage(RV_TRUE, "rvEppClientEndpointSend: failed to read from socket");
            RvMutexUnlock( &ece->ec->sendGuard, IppLogMgr());
            return;
        }

        RvMutexUnlock( &ece->ec->sendGuard, IppLogMgr());
    }
    else
    {
        RvAddress   fromAddr, toAddr;
        rc = RvAddressConstructCopy(&ece->address,&toAddr);

        rc = RvSocketSendBuffer( &ece->s,(RvUint8*)msgSend, sizeSend, &toAddr, IppLogMgr (), &bytesSent);

        if( rc !=RV_OK || bytesSent != sizeSend)
        {
            IppLogMessage(RV_TRUE, "rvEppClientEndpointSend() failed to send for %p socket", &ece->s);
            return;
        }
        /* before printing we replace all '\0' by '|'*/
        convertMultiString( msgLog, msgSend, RvMin( sizeof(msgLog), sizeSend));
        IppLogMessage(RV_FALSE, "EPP --> %s, %d", msgLog, sizeSend);


        /* do a receive */
        rc = RvSocketReceiveBuffer(&ece->s, (RvUint8*)msgRcvd, msgRcvdMaxSize,IppLogMgr(),&len, &fromAddr);
        if ((rc != RV_OK) || (len == 0))
        {
            IppLogMessage(RV_TRUE, "RvSocketReceiveBuffer() failed to receive for %p socket", &ece->s);
            return;
        }
            /* before printing we replace all '\0' by '|'*/
        convertMultiString( msgLog, msgRcvd, RvMin( sizeof(msgLog), len));
        IppLogMessage(RV_FALSE, "EPP <-- %s, %d", msgRcvd, len);

        RvAddressDestruct( &toAddr);
        RvAddressDestruct( &fromAddr);
    }

#ifndef RV_IO_NONE
    printf("Received: %s\n", msgRcvd);
#endif
}

/*-------------------------------------------------------*/
static void rvEppClientRemoveEndpoint(
    IN RvEppClient*     ec,
    IN const RvChar*    endpointName,
    IN RvChar*          params)
{
    RvSize_t i;

    for (i = 0; i < ec->numEndpoints; i++)
    {
        if (strcmp(endpointName, ec->endpoints[i].name) == 0)
        {
            ec->eUnregister(ec, &ec->endpoints[i], ec->data, params);
            rvEppClientEndpointDestruct(&ec->endpoints[i]);

            /* Replace with the last one */
            if (i != ec->numEndpoints-1)
                ec->endpoints[i] = ec->endpoints[ec->numEndpoints-1];
            ec->numEndpoints--;
            break;
        }
    }
}

static RvBool rvEppClientIsEndpointExist(
    IN RvEppClient*     ec,
    IN const RvChar*    endpointName)
{
    RvSize_t i;

    for (i = 0; i < ec->numEndpoints; i++)
    {
        if (strcmp(endpointName, ec->endpoints[i].name) == 0)
            return RV_TRUE;
    }

    return RV_FALSE;
}


static void rvEppClientWrapper(IN RvThread* thread, IN void* data)
{
    RvEppClient*    ec = (RvEppClient*)data;
    RvUint8         msg[APP_MEDIUM_STR_SZ];
    RvChar*         command;
    RvChar*         endpointName;
    RvStrTok        tokenizer;
    RvStatus        rc;
    RvSize_t        len;
    RvAddress       remoteAddress;
    RvAddress*      resultAddr;

    RV_UNUSED_ARG(thread);

    if(ec->bConfigTCP)
    {   /*constructing ec->sEv and ec->s by accept() */

        /* initialize socket for received events*/
        if( RV_OK != RvSocketAccept( &ec->sListening, IppLogMgr(), &ec->sEv, &remoteAddress))
        {
            IppLogMessage(RV_TRUE, "rvEppClientWrapper() failed in RvSocketAccept()", &ec->sEv);
        }
        rc = RvSocketSetBlocking( &ec->sEv, RV_TRUE, IppLogMgr());
        if (rc != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientWrapper::set socket to non blocking fail error =%d", rc);

        /* initialize socket for sending signals. Later should be replaced by per-endpoint socket*/
        if( RV_OK != RvSocketAccept( &ec->sListening, IppLogMgr(), &ec->s, &remoteAddress))
        {
            IppLogMessage(RV_TRUE, "rvEppClientWrapper() failed in RvSocketAccept()", &ec->s);
        }
        rc = RvSocketSetBlocking( &ec->s, RV_TRUE, IppLogMgr());
        if (rc != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientWrapper::set socket to non blocking fail error =%d", rc);
    }
    else
    {
        resultAddr = RvAddressConstruct(ec->localAddr.addrtype, &remoteAddress);

        if (resultAddr == NULL)
        {
            IppLogMessage(RV_TRUE, "rvEppClientWrapper() failed in RvAddressConstruct() for %p socket");
            return;
        }
        else
        {
            RvChar          szDest[64];
            RvAddressGetString(&ec->localAddr, sizeof(szDest), szDest);
            IppLogMessage(RV_FALSE, "rvEppClientWrapper constructed address %s", szDest);
        }
    }

    while (!ec->done)
    {
        /* Get what we find on this socket */
        if(ec->bConfigTCP)
        {
            if(!eppPacketRecv( &ec->sEv, sizeof(msg), (char*)msg))
            {
                IppLogMessage(RV_TRUE, "rvEppClientWrapper: failed to read from socket");
			    ec->done = rvTrue;
                continue;
            }
        }
        else
        {
            if(RV_OK != RvSocketReceiveBuffer(&ec->sEv, msg, sizeof(msg), IppLogMgr(), &len, &remoteAddress))
            {
                IppLogMessage(RV_TRUE, "rvEppClientWrapper() failed to receive for %p socket", &ec->s);
			    ec->done = rvTrue;
                continue;
            }
            if (len == 0)
            {
                /* Nothing on the socket - sleep for a while */
                IppThreadSleep(0, 50);
                continue;
            }
        }

        /*
        * Analyze received data
        */ 

        IppLogMessage(RV_FALSE, "Received from GUI: %s", msg);
        
        rvStrTokConstruct(&tokenizer, " ,\t", (char*)msg);

        command = rvStrTokGetToken(&tokenizer);
        endpointName = rvStrTokGetToken(&tokenizer);

        if (strcmp(command, "register") == 0)
        {
            char* param = rvStrTokGetToken(&tokenizer);
            char* ip = rvStrTokGetToken(&tokenizer);
            RvUint16 port = (RvUint16)atoi(rvStrTokGetToken(&tokenizer));
			RvChar*  regParams = rvStrTokGetCurPosition(&tokenizer);
            int profile;
            RvEppClientEndpoint* ece;

            if (!strcmp(param, "ipphone"))
                profile = EP_PROFILE_IPPHONE;
            else /*if (!strcmp(param, "analog"))*/
                profile = EP_PROFILE_ANALOG; /* make analog the default */

            /*check if it should be registered*/
            if ((rvEppClientIsEndpointExist(ec, endpointName)) == rvTrue)
            {
                IppLogMessage(RV_TRUE, "rvEppClientWrapper: Terminal Registration failed: %s", endpointName);
                rvStrTokDestruct(&tokenizer);
                continue;
            }

            /* Construct endpoint and add it to the client */
            ece = rvEppClientEndpointConstruct(ec, endpointName, ip, port, profile, regParams);
            if (ece == NULL)
            {
                IppLogMessage(RV_TRUE, "rvEppClientWrapper: Unable to construct endpoint");
            }
        }
        else if (!strcmp(command, "event"))
        {
            RvSize_t i;

            for (i = 0; i < ec->numEndpoints; i++)
            {
                if (strcmp(endpointName, ec->endpoints[i].name) == 0)
                {
                    RvChar* event = rvStrTokGetToken(&tokenizer);
                    RvChar* params = rvStrTokGetCurPosition(&tokenizer);
                    ec->eEvent(ec, &ec->endpoints[i], event, params, ec->data);
                    break;
                }
            }
        }
        else if (strcmp(command, "unregister") == 0)
        {
            char* param = rvStrTokGetToken(&tokenizer);
            param = rvStrTokGetToken(&tokenizer);
            rvEppClientRemoveEndpoint(ec, endpointName, param);
        }
        else
        {
            IppLogMessage(RV_TRUE, "rvEppClientWrapper: Unknown EPP event %s", command);
        }

        rvStrTokDestruct(&tokenizer);
    }

    if(ec->bConfigTCP)
    {   /*destructing ec->sEv and ec->s */
        RvStatus    status;
        
        status = RvSocketDestruct(&ec->sEv, RV_FALSE, NULL, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "RvSocketDestruct failed %p", &ec->sEv);

        status = RvSocketDestruct(&ec->s, RV_FALSE, NULL, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "RvSocketDestruct failed %p", &ec->s);
    }
    else
    {
        ;/*do nothing*/
    }

    memset(msg, 0, sizeof(msg));

}


/******************************************************************************
 * rvEppClientConstruct
 * ----------------------------------------------------------------------------
 * General:
 *  Create an EPP client. EPP is used as means to connect between the MTF and
 *  the GUI application. We use two separate processes mainly to enable easy
 *  testing on embedded operating systems without nice GUI.
 *
 *  For some unknown reason, the EPP uses TCP as its protocol of choice, able
 *  to send and receive messages on it.
 *
 * Arguments:
 * Input:  ec           - The EPP client to construct
 *         eppIp        - The IP address in a string format, and without a port
 *         port         - Port number to use.
 *         eRegister    - Callback function to call when a new address tries to
 *                        register itself with the EPP.
 *         eEvent       - Callback function to call for incoming events.
 *         eUnregister  - Callback function to call when someone tries to
 *                        unregister itself from the EPP.
 *         userData     - User data to use for the callback functions.
 * Output: None.
 *
 * Return Value: RV_OK on success, other on failure.
 *****************************************************************************/
RvStatus rvEppClientConstruct(
    IN RvEppClient*             ec,
    IN RvBool                   bConfigTCP,
    IN const RvChar*            eppIp,
    IN RvUint16                 port,
    IN RvEppClientRegister      eRegister,
    IN RvEppClientEvent         eEvent,
    IN RvEppClientUnregister    eUnregister,
    IN void*                    userData)
{
    RvStatus    status;

    memset(ec, 0, sizeof(RvEppClient));

    ec->bConfigTCP   = bConfigTCP;
    ec->eRegister   = eRegister;
    ec->eEvent      = eEvent;
    ec->eUnregister = eUnregister;
    ec->data        = userData;
    
    RvMutexConstruct( IppLogMgr(), &ec->sendGuard);


    /* We always use IPv4 here */
    IppLogMessage(RV_FALSE, "rvEppClientConstruct() TCP =%d. IP:port =%s:%d", ec->bConfigTCP, eppIp, port);
    RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &ec->localAddr);
    RvAddressSetString(eppIp, &ec->localAddr);
    RvAddressSetIpPort(&ec->localAddr, port);

    if( ec->bConfigTCP)
    {
        /*Open TCP connection with configured local address in case we have more than one.*/
        status = RvSocketConstruct(RV_ADDRESS_TYPE_IPV4, RvSocketProtocolTcp, IppLogMgr(), &ec->sListening);
        if (status != RV_OK)
        {
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::RvSocketConstruct fail error =%d", status);
            return status;
        }

        status = RvSocketSetBlocking( &ec->sListening, RV_TRUE, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::set socket to non blocking fail error =%d", status);
        
        /* Bind the socket to the wanted local address */
        status = RvSocketBind( &ec->sListening, &ec->localAddr, NULL, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::bind fail error =%d", status);
        
        /* Make the socket to listen */
        status = RvSocketListen( &ec->sListening, 16, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::listen fail error =%d", status);
    }
    else
    {
        /*Open UDP connection with configured local address in case we have more than one.*/
        status = RvSocketConstruct(RV_ADDRESS_TYPE_IPV4, RvSocketProtocolUdp, IppLogMgr(), &ec->sEv);
        if (status != RV_OK)
        {
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::RvSocketConstruct fail error =%d", status);
            return status;
        }
        
        /* For Windows the socket will be successfully closed by RvSocketDestruct.
        That permits to "exit" from UDP_RECV and consequently to destruct the EPP thread
        For Linux this does not work: RvSocketDestruct does not permit to exit from UDP_RECV
        of EPP thread, which is stuck    and can not be destructed.
        The solution is: declare the EPP socket as non blocking
        */
        status = RvSocketSetBlocking(&ec->sEv, RV_FALSE, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::set socket to non blocking fail error =%d", status);
        
        /* Bind the socket to the wanted local address */
        status = RvSocketBind(&ec->sEv, &ec->localAddr, NULL, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientConstruct::bind fail error =%d", status);
    }
    
    /* Create a thread to handle the EPP connections */
    if (status == RV_OK)
    {
        status  = RvThreadConstruct(rvEppClientWrapper, ec, IppLogMgr(), &ec->thread);
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientConstruct(). Failed in RvThreadConstruct()");
        
        if (status == RV_OK)
        {
            status = RvThreadSetPriority(&ec->thread, RV_THREAD_PRIORITY_DEFAULT);
            
            if (status == RV_OK)
                status = RvThreadSetStack(&ec->thread, NULL, 32768);
            
            if (status == RV_OK)
            {
                RvThreadSetName(&ec->thread, "EPP_THRD");
                ec->done = RV_FALSE;
                status = RvThreadCreate(&ec->thread);
            }
            
            if (status == RV_OK)
                status = RvThreadStart(&ec->thread);
            
            if (status != RV_OK)
            {
                IppLogMessage(RV_TRUE, "rvEppClientConstruct(). Failed to jump start the thread");
                RvThreadDestruct(&ec->thread);
            }
        }
    }
    
    if (status != RV_OK)
    {
        {
            RvChar txt[16];
			sprintf(txt,"%d",ec->s);
            IppLogMessage(RV_FALSE, "Destructing the socket %d\n", ec->s);
		}

        RvSocketDestruct( &ec->sListening, RV_FALSE, NULL, IppLogMgr());
	}

    return status;
}

void rvEppClientDestruct(RvEppClient* ec)
{
    RvSize_t i;
    RvStatus status = RV_OK;

    IppLogMessage(RV_FALSE, "rvEppClientDestruct() ec = %p", ec);
    ec->done = RV_TRUE;

    if(ec->bConfigTCP)
    {
        status = RvSocketDestruct(&ec->sListening, RV_FALSE, NULL, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientDestruct::RvSocketDestruct %d", status);

        status = RvThreadDestruct(&ec->thread);
        if(status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientDestruct::RvThreadDestruct %d", status);
    }
    else
    {
        status = RvSocketDestruct(&ec->sEv, RV_FALSE, NULL, IppLogMgr());
        if (status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientDestruct::RvSocketDestruct %d", status);
        status = RvThreadDestruct(&ec->thread);
        if(status != RV_OK)
            IppLogMessage(RV_TRUE, "rvEppClientDestruct::RvThreadDestruct %d", status);
    }

    for (i = 0; i < ec->numEndpoints; i++)
        rvEppClientEndpointDestruct(&ec->endpoints[i]);
}

RvBool rvEppClientStart( RvEppClientEndpoint* ece, const char* signal)
{
    RvUint8     len;
    char msg[256];
    RvStrTok tokenizer;
    char* token;

/*    RvSnprintf(msg,sizeof(msg), "start %s %s", ece->name, signal);*/
    RvSnprintf(msg,sizeof(msg), "start ui %s", signal);

    len = (RvUint8)(strlen(msg) +1);
    rvEppClientEndpointSend( ece, msg, len,sizeof(msg),msg);

    rvStrTokConstruct(&tokenizer, " \t\n", msg);
    token = rvStrTokGetToken(&tokenizer);
	if(token ==NULL)
	{
        IppLogMessage(RV_TRUE, "rvEppClientStart() - received empty string instead reply");
	    return rvFalse;
	}
    if (strcmp(token, "reply") == 0)
	{
        token = rvStrTokGetToken(&tokenizer);
        if (strcmp(token, "ack") == 0)
            return  rvTrue;
    }

    return rvFalse;
}

RvBool rvEppClientStop( RvEppClientEndpoint* ece, const char* signal) {
    RvUint8     len;
    char msg[256];
    RvStrTok tokenizer;
    char* token;

/*    RvSnprintf(msg,sizeof(msg), "stop %s %s", ece->name, signal);*/
    RvSnprintf(msg,sizeof(msg), "stop ui %s", signal);
    len = (RvUint8)(strlen(msg) +1);
    rvEppClientEndpointSend( ece, msg, len, sizeof(msg),msg);

    rvStrTokConstruct(&tokenizer, " \t\n", msg);
    token = rvStrTokGetToken(&tokenizer);
    if (strcmp(token, "reply") == 0) {
        token = rvStrTokGetToken(&tokenizer);
        if (strcmp(token, "ack") == 0)
            return  rvTrue;
    }

    return rvFalse;
}

