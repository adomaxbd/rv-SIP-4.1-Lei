/******************************************************************************
Filename    :rvsdpattr.c
Description :attributes manipulation routines.

  ******************************************************************************
  Copyright (c) 2005 RADVision Inc.
  ************************************************************************
  NOTICE:
  This document contains information that is proprietary to RADVision LTD.
  No part of this publication may be reproduced in any form whatsoever
  without written prior approval by RADVision LTD..

    RADVision LTD. reserves the right to revise this publication and make
    changes without obligation to notify any person of such revisions or
    changes.
    ******************************************************************************
Author:Rafi Kiel
******************************************************************************/
#include <string.h>
#include <stdlib.h>
#include "rvsdpprivate.h"

#include "rvstrutils.h"
#include "rvsdpprsutils.h"

#include "rvsdpapiprivate.h"
#include "rvansi.h"

/*
 *	To allocate the memory for RvSdpAttribute object (called by the pool)
 *  Return:
 *      valid RvSdpAttribute pointer
 *      or NULL if fails
 */
RvSdpAttribute* rvSdpAttributeCreateByPool(RvSdpMsg* msg)
{
    RvSdpAttribute *attr;
    attr = rvSdpAllocAllocate(msg->iAllocator,sizeof(RvSdpAttribute));
    if (!attr)
        return NULL;
    memset(attr,0,sizeof(RvSdpAttribute));
    attr->iObj = msg;
    return attr;
}

/***************************************************************************
 * rvSdpAttributeConstruct2
 * ------------------------------------------------------------------------
 * General:
 *      Constructs the RvSdpAttribute object.
 *
 * Return Value:
 *      A pointer to the constructed object, or NULL if the function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - pointer to valid RvSdpMsg object or NULL. If the parameter is not
 *            NULL and 'attr' is NULL the attribute will be allocated from
 *            the 'msg' pool of attributes. If 'msg' is not NULL the constructed
 *            attribute will be appended to 'msg' list of attributes. If the 'msg'
 *            is NULL the 'a' allocator will be used.
 *      attr - a pointer to valid RvSdpAttribute object or NULL.
 *      name - the name of the attribute.
 *      value - the value of the attribute.
 *      a  - allocator to be used for memory allocations, if allocator is NULL
 *           the default allocator is used.
 *      dontConstruct - if set to RV_TRUE the 'attr' must point to valid & constructed
 *                      RvSdpAttribute object. This parameter (with RV_TRUE value)
 *                      is used when objects are copied without construction.
 ***************************************************************************/
RvSdpAttribute*
rvSdpAttributeConstruct2(RvSdpMsg* msg, RvSdpAttribute* attr, const char* name,
                         const char* value, RvAlloc* a, RvBool dontConstruct)
{
    RvBool takenFromPool = RV_FALSE;

    if (!dontConstruct || !attr)
    {
        if (msg)
            /* the RvSdpMsg is provided, all allocations will be performed in the msg context */
        {
            if (!attr)
            {
                /* the 'attr' can't be set it has to be allocated from the msg attributes pool */
                attr = rvSdpPoolTake(&msg->iAttrsPool);
                if (!attr)
                    /* failed to allocate from the msg attributes pool */
                    return NULL;
                takenFromPool = RV_TRUE;
            }
            attr->iObj = msg;
        }
        else
        {
            /* obsolete API usage:
                no msg context given, will be using allocator */

            if (!attr)
                /* attr must be supplied */
                return NULL;
            memset(attr,0,sizeof(RvSdpAttribute));
            if (!a)
                /* the default allocator will be used */
                a = rvSdpGetDefaultAllocator();
            /* save the allocator used */
            attr->iObj = a;
        }
    }

    attr->iLabel = 0;

    if (msg)
        rvSdpMsgPromiseBuffer(msg,((name)?(int)strlen(name):0)+((value)?(int)strlen(value):0));

    if (rvSdpSetTextField(&attr->iAttrName,attr->iObj,name) != RV_SDPSTATUS_OK ||
        rvSdpSetTextField(&attr->iAttrValue,attr->iObj,value) != RV_SDPSTATUS_OK)
    {
        rvSdpUnsetTextField(&attr->iAttrName,attr->iObj);
        rvSdpUnsetTextField(&attr->iAttrValue,attr->iObj);
        if (takenFromPool && msg)
            rvSdpPoolReturn(&msg->iAttrsPool,attr);
        return NULL;
    }

    if (!dontConstruct)
    {
        if (msg)
            rvSdpLineObjsListInsert(msg,SDP_FIELDTYPE_ATTRIBUTE,&attr->iLineObj,
                            RV_OFFSETOF(RvSdpAttribute,iLineObj));
    }

    return attr;
}

/* Deallocates RvSdpAttribute netto memory	*/
void rvSdpAttributeDestructNetto(
                     RvSdpAttribute* attr,   /* the attribute pointer */
                     RvBool retToPool)       /* whether to return to attributes pool */
{
    if (!attr->iObj)
        /* cannot deallocate memory */
        return;

    rvSdpUnsetTextField(&attr->iAttrName,attr->iObj);
    rvSdpUnsetTextField(&attr->iAttrValue,attr->iObj);

	attr->iSpecAttrData = NULL;

    if (RV_SDP_OBJ_IS_MESSAGE(attr))
    {
        rvSdpLineObjsListRemove(attr->iObj,&attr->iLineObj);
        /* RvSdpMsg context was used */
        if (retToPool)
            rvSdpPoolReturn(&((RvSdpMsg*)(attr->iObj))->iAttrsPool,attr);
    }
}

/***************************************************************************
 * rvSdpAttributeDestruct
 * ------------------------------------------------------------------------
 * General:
 *      Destructs the media descriptor object.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to the RvSdpAttribute object.
***************************************************************************/

void rvSdpAttributeDestruct(RvSdpAttribute* attr)
{
	if (attr->iSpecAttrData && attr->iSpecAttrData->destroyFunc)
    {
        const RvSdpInternalSpecAttrData* spAttrD;
        spAttrD = attr->iSpecAttrData;
		(spAttrD->destroyFunc)(spAttrD->iName,spAttrD->iAttrFieldType,spAttrD->iAppData,attr);
    }
	else
		rvSdpAttributeDestructNetto(attr,RV_TRUE);
}

/*
 *	To free the memory for RvSdpAttribute object (called by the pool)
 */
void rvSdpAttributeDestroyByPool(RvSdpAttribute* p)
{
    rvSdpAllocDeallocate(((RvSdpMsg*)(p->iObj))->iAllocator,sizeof(RvSdpAttribute),p);
}

/***************************************************************************
 * rvSdpAttributeCopy2
 * ------------------------------------------------------------------------
 * General:
 *      Copies the instance of RvSdpAttribute from 'src' to 'dest'.
 *      If the destination object is NULL pointer, the destination
 *      object will be allocated & constructed within the function.
 *      The destination object will or willl not be constructed depending
 *      on 'dontConstruct' value. If 'dontConstruct' is true the 'dest'
 *      must point to valid & constructed object.
 *
 * Return Value:
 *      A pointer to the input RvSdpAttribute object, or NULL if the
 *      function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      dest - pointer to valid RvSdpAttribute object or NULL.
 *      src - a pointer to the source object
 *      dstMsg - the RvSdpMsg instance that will own the destination object
 ***************************************************************************/
RvSdpAttribute* rvSdpAttributeCopy2(RvSdpAttribute* dest,
                                    const RvSdpAttribute* src, RvSdpMsg* dstMsg)
{

	if (src->iSpecAttrData && src->iSpecAttrData->copyFunc)
    {
        const RvSdpInternalSpecAttrData* spAttrD;
        spAttrD = src->iSpecAttrData;
        dest = (spAttrD->copyFunc)(spAttrD->iName,spAttrD->iAttrFieldType,spAttrD->iAppData,dstMsg,src);
		return dest;
    }
	else
	{
        dest = rvSdpAttributeConstruct2(dstMsg,dest,src->iAttrName,src->iAttrValue,NULL,RV_FALSE);
		if (dest && src->iSpecAttrData)
			/*
			 * treat the case when the special attribute does not have the copy function (conn-mode)
			 */
			dest->iSpecAttrData = src->iSpecAttrData;
		return dest;
	}
}

/***************************************************************************
 * rvSdpSpecAttrGetValue
 * ------------------------------------------------------------------------
 * General:
 *      Gets the value of a special attribute;
 *      The value is first calculated using the appropriate callback
 *      (iGetValueFunc) in RvSdpInternalSpecAttrData structure and then stored
 *      in iAttrValue field of the RvSdpAttribute instance.
 *      The iAttrValue is returned
 *
 * Return Value:
 *      The value of iAttrValue of RvSdpAttribute is returned.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - pointer to RvSdpAttribute instance.
 ***************************************************************************/
const RvChar* rvSdpSpecAttrGetValue(RvSdpAttribute *attr)
{
    const RvChar* aVal;
	if (attr->iSpecAttrData && attr->iSpecAttrData->encodeFunc)
	{
        const RvSdpInternalSpecAttrData* spAttrD;
        spAttrD = attr->iSpecAttrData;
        aVal = (spAttrD->encodeFunc)(spAttrD->iName,spAttrD->iAttrFieldType,spAttrD->iAppData,attr);
	}
    else
        aVal = attr->iAttrValue;
    return RV_SDP_EMPTY_STRING(aVal);
}



/* this function help in getting spec attr data from
   the global array gcSpecAttributesData */
const RvSdpInternalSpecAttrData*
rvSdpFindSpecAttrDataByFieldType(RvSdpFieldTypes fieldType)
{
	const RvSdpInternalSpecAttrData* attrData;
    RvInt cnt;
    RV_SDP_USE_GLOBALS;

    for (cnt = 0, attrData = gSpecAttrs; cnt < gSpecAttrsCnt; cnt++,attrData++)
	{
		if (attrData->iAttrFieldType == (RvSdpFieldTypes)fieldType)
			return attrData;
	}
	return NULL;
}

/* this function help in getting spec attr data from
   the global array gcSpecAttributesData */
RVSDPCOREAPI const RvSdpInternalSpecAttrData* rvSdpFindSpecAttrDataByName(const char* name)
{
	const RvSdpInternalSpecAttrData* attrData;
    RvInt cnt;
    RV_SDP_USE_GLOBALS;

    for (cnt = 0, attrData = gSpecAttrs; cnt < gSpecAttrsCnt; cnt++,attrData++)
	{
		if (!strcasecmp(attrData->iName,name))
			return attrData;
	}
	return NULL;
}

#define RV_SDP_IS_SPEC_ATTR(_attr,_t) \
	(((_t) == SDP_FIELDTYPE_NOT_SET \
            && (_attr)->iSpecAttrData == NULL) ||\
               ((_attr)->iSpecAttrData && \
               (_attr)->iSpecAttrData->iAttrFieldType == (_t)))

/***************************************************************************
 * rvSdpGetNumOfSpecialAttr
 * ------------------------------------------------------------------------
 * General:
 *      Gets  the number of special attributes of specific type in message
 *      or media descrtiptor.
 *
 * Return Value:
 *      Returns the number of special attributes  of specific type in message
 *      or media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media where number of
 *                  special attributes is needed.
 *          specAttrType - the type of special attribute is question.
 ***************************************************************************/
RvSize_t rvSdpGetNumOfSpecialAttr(
            const RvSdpCommonFields* commF,
            RvSdpFieldTypes specAttrType)
{
    RvSize_t cnt = 0;
    RvSdpAttribute *attr;
    RvSdpListIter iter;

    for (attr = (RvSdpAttribute*)rvSdpListGetFirst(&commF->iAttrList,&iter); attr; attr = (RvSdpAttribute*)rvSdpListGetNext(&iter))
    {
		if (RV_SDP_IS_SPEC_ATTR(attr,specAttrType))
            cnt++;
    }
    return cnt;
}

/***************************************************************************
 * rvSdpGetFirstSpecialAttr
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first special attribute object of specific type defined
 *      in the message or  media descriptor.
 *      Also sets the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute  object or the NULL pointer if there are no
 *      special attributes of given type defined in the message or media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          iter - pointer to RvSdpListIter to be used for subsequent
 *                 rvSdpGetNextSpecialAttr calls.
 *          specAttrType - the type of special attribute is question.
 ***************************************************************************/
RvSdpAttribute* rvSdpGetFirstSpecialAttr(
            RvSdpCommonFields* commF,
            RvSdpListIter* iter,
            RvSdpFieldTypes specAttrType)
{
    RvSdpAttribute *attr;
    for (attr = (RvSdpAttribute*)rvSdpListGetFirst(&commF->iAttrList,iter); attr; attr = (RvSdpAttribute*)rvSdpListGetNext(iter))
    {
        if (RV_SDP_IS_SPEC_ATTR(attr,specAttrType) )
            return attr;
    }
    return NULL;
}

/***************************************************************************
 * rvSdpGetNextSpecialAttr
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next special attribute object of specific type defined
 *      in the message or  media descriptor.
 *      Also modifies the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute  object or the NULL pointer if there are no
 *      more special attributes of given type defined in the message or media
 *      descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *          iter - pointer to RvSdpListIter to be used for subsequent
 *                 rvSdpGetNextSpecialAttr calls.
 *          specAttrType - the type of special attribute is question.
 ***************************************************************************/
RvSdpAttribute* rvSdpGetNextSpecialAttr(
            RvSdpListIter* iter,
            RvSdpFieldTypes specAttrType)
{
    RvSdpAttribute *attr;
    for (attr = (RvSdpAttribute*)rvSdpListGetNext(iter);attr;
                        attr = (RvSdpAttribute*)rvSdpListGetNext(iter))
    {
        if (RV_SDP_IS_SPEC_ATTR(attr,specAttrType))
            return  attr;
    }
    return NULL;
}

/***************************************************************************
 * rvSdpGetSpecialAttr
 * ------------------------------------------------------------------------
 * General:
 *      Returns the special attribute object of specific type defined
 *      in the message or media descriptor by zero-based index.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute  object.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          index - zero-based index of special attribute.
 *          specAttrType - the type of special attribute is question.
 ***************************************************************************/
RvSdpAttribute* rvSdpGetSpecialAttr(
            RvSdpCommonFields* commF,
            RvSize_t index,
            RvSdpFieldTypes specAttrType)
{
    RvSdpAttribute *sa;
    RvSdpListIter i;
    for (sa = rvSdpGetFirstSpecialAttr(commF,&i,specAttrType); sa;
                            sa = rvSdpGetNextSpecialAttr(&i,specAttrType), index--)
        if (index == 0)
            return sa;
        return NULL;
}


/***************************************************************************
 * rvSdpGetSpecialAttrValue
 * ------------------------------------------------------------------------
 * General:
 *      Returns the special attribute's value of specific type defined
 *      in the message or media descriptor by zero-based index.
 *
 * Return Value:
 *      Attributes value.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          index - zero-based index of special attribute.
 *          specAttrType - the type of special attribute is question.
 ***************************************************************************/
RVSDPCOREAPI const RvChar* rvSdpGetSpecialAttrValue(
            RvSdpCommonFields* commF,
            RvSize_t index,
            RvSdpFieldTypes specAttrType)
{
    RvSdpAttribute *sa;
    RvSdpListIter i;
    const RvChar* p;
    p = NULL;

    for (sa = rvSdpGetFirstSpecialAttr(commF,&i,specAttrType); sa;
                            sa = rvSdpGetNextSpecialAttr(&i,specAttrType), index--)
    {
        if (index == 0)
        {
            p = rvSdpAttributeGetValue(sa);
            break;
        }
    }
    return RV_SDP_EMPTY_STRING(p);
}



/***************************************************************************
 * rvSdpRemoveSpecialAttr
 * ------------------------------------------------------------------------
 * General:
 *      Removes and destroys the special attribute object of specific type defined
 *      in the message or media descriptor by zero-based index.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          index - zero-based index of special attribute.
 *          specAttrType - the type of special attribute is question.
 ***************************************************************************/
void rvSdpRemoveSpecialAttr(
            RvSdpCommonFields* commF,
            RvSize_t index,
            RvSdpFieldTypes specAttrType)
{
    RvSdpAttribute* sa;
    sa = rvSdpGetSpecialAttr(commF,index,specAttrType);
    if (!sa)
        return;
    rvSdpListRemoveByValue(&commF->iAttrList,sa);
}

/***************************************************************************
 * rvSdpClearSpecialAttr
 * ------------------------------------------------------------------------
 * General:
 *      Removes and destroys all special attribute object of specific type defined
 *      in the message or media descriptor.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          specAttrType - the type of special attributes is question.
 ***************************************************************************/
void rvSdpClearSpecialAttr(RvSdpCommonFields* commF, RvSdpFieldTypes specAttrType)
{
    RvSdpListIter i;
    void *sa;
    for (;;)
    {
        sa = rvSdpGetFirstSpecialAttr(commF,&i,specAttrType);
        if (!sa)
            break;
        rvSdpListRemoveCurrent(&i);
    }
}

/***************************************************************************
 * rvSdpGetNumOfAttrByName
 * ------------------------------------------------------------------------
 * General:
 *      Gets  the number of attributes with the given name in message
 *      or media descrtiptor.
 *
 * Return Value:
 *      Returns the number of attributes with the given name in message
 *      or media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media where number of
 *                  special attributes is needed.
 *          attrName - the name of the attribute
 ***************************************************************************/
RvSize_t rvSdpGetNumOfAttrByName(
            const RvSdpCommonFields* commF,
            const RvChar* attrName)
{
    RvSize_t cnt = 0;
    RvSdpAttribute *attr;
    RvSdpListIter iter;

    for (attr = (RvSdpAttribute*)rvSdpListGetFirst(&commF->iAttrList,&iter); attr; attr = (RvSdpAttribute*)rvSdpListGetNext(&iter))
    {
		if (attr->iAttrName && strcasecmp(attr->iAttrName,attrName) == 0)
            cnt++;
    }
    return cnt;
}

/***************************************************************************
 * rvSdpGetFirstAttrByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first attribute object with the given name defined
 *      in the message or  media descriptor.
 *      Also sets the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute  object or the NULL pointer if there are no
 *      attributes with the given name defined in the message or media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          iter - pointer to RvSdpListIter to be used for subsequent
 *                 rvSdpGetNextAttrByName calls.
 *          attrName - the name of the attribute
 ***************************************************************************/
RvSdpAttribute* rvSdpGetFirstAttrByName(
            RvSdpCommonFields* commF,
            RvSdpListIter* iter,
            const RvChar* attrName)
{
    RvSdpAttribute *attr;
    for (attr = (RvSdpAttribute*)rvSdpListGetFirst(&commF->iAttrList,iter); attr; attr = (RvSdpAttribute*)rvSdpListGetNext(iter))
    {
        if (attr->iAttrName && strcasecmp(attr->iAttrName,attrName) == 0)
            return attr;
    }
    return NULL;
}

/***************************************************************************
 * rvSdpGetNextAttrByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next attribute object with the given name defined
 *      in the message or  media descriptor.
 *      Also modifies the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute  object or the NULL pointer if there are no
 *      more attributes with the given name defined in the message or media
 *      descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *          iter - pointer to RvSdpListIter to be used for subsequent
 *                 rvSdpGetNextAttrByName calls.
 *          attrName - the name of the attribute
 ***************************************************************************/
RvSdpAttribute* rvSdpGetNextAttrByName(
            RvSdpListIter* iter,
            const RvChar* attrName)
{
    RvSdpAttribute *attr;
    for (attr = (RvSdpAttribute*)rvSdpListGetNext(iter);attr;
                        attr = (RvSdpAttribute*)rvSdpListGetNext(iter))
    {
        if (attr->iAttrName && strcasecmp(attr->iAttrName,attrName) == 0)
            return  attr;
    }
    return NULL;
}

/***************************************************************************
 * rvSdpGetAttrByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the attribute object with the given name defined
 *      in the message or media descriptor by zero-based index.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute  object.
 * ------------------------------------------------------------------------
 * Arguments:
 *          commF - common fields pointer of message or media descriptor.
 *          index - zero-based index of special attribute.
 *          attrName - the name of the attribute
 ***************************************************************************/
RvSdpAttribute* rvSdpGetAttrByName(
            RvSdpCommonFields* commF,
            RvSize_t index,
            const RvChar* attrName)
{
    RvSdpAttribute *sa;
    RvSdpListIter i;
    for (sa = rvSdpGetFirstAttrByName(commF,&i,attrName); sa;
                            sa = rvSdpGetNextAttrByName(&i,attrName), index--)
        if (index == 0)
            return sa;
        return NULL;
}

/***************************************************************************
 * rvSdpGetConnectionMode
 * ------------------------------------------------------------------------
 * General:
 *      Gets the connection mode of the message or media
 *      descriptor.
 *
 * Return Value:
 *      Returns the connection mode or RV_SDPCONNECTMODE_NOTSET if the
 *      SDP_FIELDTYPE_CONNECTION_MODE special attribute is not set in the message
 *      or media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      commF - the RvSdpCommonFields instance of message or media.
 ***************************************************************************/
RvSdpConnectionMode rvSdpGetConnectionMode(const RvSdpCommonFields* commF)
{
    RvSdpAttribute *attr;
    RvSdpConnectionMode m = RV_SDPCONNECTMODE_NOTSET;
    RvSdpCommonFields *cf = (RvSdpCommonFields*)commF;

	attr = rvSdpGetSpecialAttr(cf,0,SDP_FIELDTYPE_CONNECTION_MODE);
	if (!attr)
		return RV_SDPCONNECTMODE_NOTSET;

	m = rvSdpConnModeTxt2Val(attr->iAttrName);
    if (m != RV_SDPCONNECTMODE_NOTSET)
		return m;
	attr->iSpecAttrData = NULL;
	return RV_SDPCONNECTMODE_NOTSET;
}

/***************************************************************************
 * rvSdpSetConnectionMode
 * ------------------------------------------------------------------------
 * General:
 *      Sets/modifies/removes the connection mode of the message or media
 *      descriptor.
 *      If the SDP_FIELDTYPE_CONNECTION_MODE special attribute was not set
 *      in a message or media it will be added. In case the 'mode' is
 *      RV_SDPCONNECTMODE_NOTSET the special attribute will be removed.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - the RvSdpMsg instance.
 *      media - the RvSdpMediaDescr instance or NULL if the message level is needed.
 *      mode - the desired connection mode.
 ***************************************************************************/
RVSDPCOREAPI RvSdpStatus
rvSdpSetConnectionMode(RvSdpMsg* msg, RvSdpMediaDescr* media, RvSdpConnectionMode m)
{
    const RvChar *v;
    const RvSdpInternalSpecAttrData* sad;


    if (m == RV_SDPCONNECTMODE_NOTSET) {
        rvSdpClearSpecialAttr((media)?&media->iCommonFields:&msg->iCommonFields,SDP_FIELDTYPE_CONNECTION_MODE);
        return RV_SDPSTATUS_OK;
    }

    v = rvSdpConnModeVal2Txt(m);
    sad = rvSdpFindSpecAttrDataByName(v);

    return (rvSdpSpecialAttrAdd(msg,media,SDP_FIELDTYPE_NOT_SET,NULL,sad)) ?
        RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;
}


/***************************************************************************
 * rvSdpMediaDescrGetMidValueStr
 * ------------------------------------------------------------------------
 * General:
 *      Gets the Mid Value of a media descriptor as a string.
 *
 * Return Value:
 *      Returns the Mid Value as a string.
 *      EMPTY STRING is returned if the correspondent attribute is not set.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
const char* rvSdpMediaDescrGetMidValueStr(RvSdpMediaDescr* descr)
{
    RvSdpAttribute * attr;
    const char     * midValStr;

	attr = rvSdpGetSpecialAttr(&descr->iCommonFields,0,SDP_FIELDTYPE_MEDIA_ID);
    /*if there is no mid attribute in the mediaDesc*/
    if(!attr)
        return NULL;

    midValStr = attr->iAttrValue;

    if(!midValStr)
    {
        attr->iSpecAttrData = NULL;
    }
    return RV_SDP_EMPTY_STRING(midValStr);
}


/***************************************************************************
 * rvSdpMediaDescrGetMidValueAsInt
 * ------------------------------------------------------------------------
 * General:
 *      Gets the Mid Value of a media descriptor as an int.
 *      check if it is a legal int value - otherwise throw warning
 *
 * Return Value:
 *      Returns the Mid Value as an Int .returns -1 if the
 *      Mid Value special attribute is not set in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RvInt rvSdpMediaDescrGetMidValueAsInt(RvSdpMediaDescr* descr)
{
    const char     * midValStr;
    RvInt            midValAsInt;

	midValStr = rvSdpMediaDescrGetMidValueStr(descr);

    if (midValStr)
    {
        midValAsInt = RV_SDP_STR_2_NUM(midValStr);
        return  midValAsInt;
    }
    return RV_SDP_INT_NOT_SET;

}


/***************************************************************************
 * rvSdpMediaDescrSetMidValueAsInt
 * ------------------------------------------------------------------------
 * General:
 *      Sets/modifies/removes the Mid Value of the media descriptor.
 *      If the SDP_FIELDTYPE_MEDIA_ID special attribute was not set yet
 *      in the media desc - a new mid attr will be added to the media level.
 *      Only one media value is allowed!
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      midIntVal  - the media Id value to be set as a string.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetMidValueAsInt(
                                            RvSdpMediaDescr* descr,
                                            const RvInt      midIntVal)
{
    RvChar midValAsStr[20] = {'\0'} ;

    if(midIntVal >= 0)
    {
        RvSprintf(midValAsStr,"%d",midIntVal);
        return rvSdpMediaDescrSetMidValueStr(descr,midValAsStr);
    }
    return RV_SDPSTATUS_ILLEGAL_SET;
}


RvSdpSpecAttrParseAction rvSdpParseRegisteredAttribute(
    RvSdpParserData* pD,
    const RvSdpInternalSpecAttrData* attrData,
    RvSdpMsg *pMsg,
    RvSdpMediaDescr *pMedia,
    RvSdpAttribute** pAttr,
    RvChar** pV);


/***************************************************************************
 * rvSdpSpecialAttrAdd
 * ------------------------------------------------------------------------
 * General:
 *      For special attributes allowing multiple appearances adds another
 *      instance of given type special attribute with given name.
 *      For special attributes with at most single appearance modifies the
 *      value of attribute if it was set before or creates the attribute
 *      if it was not set before.
 *
 * Return Value:
 *      Returns the pointer to the RvSdpAttribute of created/modified object.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - the RvSdpMsg where change happens.
 *      media - the RvSdpMediaDescr pointer or NULL if the changes happens
 *              at message level
 *      specAttrType - the type of special attributes is question.
 *      value - the desired value of special attribute.
 ***************************************************************************/
RvSdpAttribute* rvSdpSpecialAttrAdd(RvSdpMsg         * msg,
                                         RvSdpMediaDescr  * media,
										 RvSdpFieldTypes specAttrType,
                                         const char*        value,
                                         const RvSdpInternalSpecAttrData* sad)
{
    RvChar vtxt[1024], *v;
    const RvChar* cv;
    RvSdpSpecAttrParseAction specAttrPrsRes;
    RvSdpCommonFields *commF;
    RvSdpAttribute *pAttr = NULL;

#if (RV_LOGMASK != RV_LOGLEVEL_NONE)
    RV_SDP_USE_GLOBALS;
#endif

    if (!msg)
        msg = media->iSdpMsg;

    commF = (media) ? &media->iCommonFields : &msg->iCommonFields;

    if (!sad)
	    sad = rvSdpFindSpecAttrDataByFieldType(specAttrType);

    if (!sad)
    {
        RvLogError(pSdpLogSource, (pSdpLogSource, "rvSdpSpecialAttrAdd: could not find SpecAttrData for %d",
            specAttrType));
        return NULL;
    }

    if (specAttrType == SDP_FIELDTYPE_NOT_SET)
        specAttrType = sad->iAttrFieldType;

    if (sad->bIsSingle)
    {
        /* if there are some attributes of this type remove them (this attribute cannot be multiple) */
        pAttr = rvSdpGetSpecialAttr(commF,0,sad->iAttrFieldType);
        if (pAttr)
        {
            if (sad->parseFunc || sad->bIntegerValue)
                /* if the attribute defines the parse function we cannot just replace its value, since there
                   could be some object associated with this attribute */
                rvSdpClearSpecialAttr(commF,specAttrType);
            else {
                rvSdpSetTextField(&pAttr->iAttrName,pAttr->iObj,sad->iName);
                rvSdpSetTextField(&pAttr->iAttrValue,pAttr->iObj,value);
                pAttr->iSpecAttrData = sad;
                return pAttr;
            }
        }
    }

    if (!value)
        v = NULL;
    else {
        RvInt len = (RvInt) strlen(value);
        if (len > (RvInt)sizeof(vtxt)-1)
        {
            RvLogError(pSdpLogSource, (pSdpLogSource, "rvSdpSpecialAttrAdd: the value is too long %d",
                len));
            return NULL;
        }
        memcpy(vtxt,value,len+1);
        v = vtxt;
    }

    {
        RvSdpParserData pData;
        memset(&pData,0,sizeof(pData));
        msg->iPrsData = &pData;
        pData.iMsg = msg;
        pData.iMediaDescr = media;
        if (v)
            pData.iCurrValueLen = (RvUint16)strlen(v);
        specAttrPrsRes = rvSdpParseRegisteredAttribute(NULL,sad,msg,media,&pAttr,&v);
        msg->iPrsData = NULL;
    }


    if (specAttrPrsRes != RV_SDP_SPEC_ATTR_PARSE_OK)
    {
        RvLogError(pSdpLogSource, (pSdpLogSource, "rvSdpSpecialAttrAdd: failed in adding the attribute %s (%d)",
            sad->iName,specAttrPrsRes));
        return NULL;
    }

    cv = v;

    pAttr = rvSdpAddAttr2(msg,commF,pAttr,sad->iName,cv);
    if (!pAttr)
    {
        RvLogError(pSdpLogSource, (pSdpLogSource, "rvSdpSpecialAttrAdd: failed in adding the attribute %s. Allocation problem",
            sad->iName));
        return NULL;
    }

    pAttr->iSpecAttrData = sad;

    return pAttr;
}

/***************************************************************************
 * rvSdpAttributeCopy
 * ------------------------------------------------------------------------
 * General:
 *      Copies the values from a source attribute to destination.
 *      Only generic attributes can be copied in this way. If one of the
 *      arguments is special attribute NULL will be returned.
 *
 * Return Value:
 *      A pointer to the destination object, or NULL if the function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      dest - a pointer to destination generic attribute. Must point
 *             to constructed RvSdpAttribute object.
 *      src - a source generic attribute.
 ***************************************************************************/
RvSdpAttribute* rvSdpAttributeCopy(RvSdpAttribute* dest, const RvSdpAttribute* src)
{
    RvSdpMsg *msg;

    if (!dest || !src)
        return NULL;

    if (dest && dest->iSpecAttrData)
        return NULL;
    if (src && src->iSpecAttrData)
        return NULL;

    if (dest && RV_SDP_OBJ_IS_MESSAGE(dest))
        msg = dest->iObj;
    else
        msg = NULL;

    return rvSdpAttributeConstruct2(msg,dest,src->iAttrName,
        src->iAttrValue,dest->iObj,RV_TRUE);
}

/***************************************************************************
 * rvSdpAttributeCompare
 * ------------------------------------------------------------------------
 * General:
 *      Compares two RvSdpAttribute objects.
 *
 * Return Value:
 *      RV_TRUE, if attributes are equal.
 * ------------------------------------------------------------------------
 * Arguments:
 *      a1 - RvSdpAttribute object.
 *      a2 - RvSdpAttribute object.
 ***************************************************************************/
RVSDPCOREAPI RvBool rvSdpAttributeCompare(
            const RvSdpAttribute* a1,
            const RvSdpAttribute* a2)
{
    const char* a1Val;
    const char* a2Val;
    RvSdpAttribute *attr1, *attr2;

    if (0 != strcmp(a1->iAttrName, a2->iAttrName))
        return RV_FALSE;

    attr1 = (RvSdpAttribute*)a1;
    attr2 = (RvSdpAttribute*)a2;

    a1Val = rvSdpAttributeGetValue((RvSdpAttribute*)attr1);
    a2Val = rvSdpAttributeGetValue((RvSdpAttribute*)attr2);

    if (NULL != a1Val && NULL != a2Val)
    {
        if (0 != strcmp(a1Val, a2Val))
            return RV_FALSE;
    }
    else if (NULL != a1Val  ||  NULL != a2Val)
    {
        return RV_FALSE;
    }

    return RV_TRUE;
}



/***************************************/
/*START OF    ifndef RV_SDP_USE_MACROS */
/***************************************/


#ifndef RV_SDP_USE_MACROS

/***************************************************************************
 * rvSdpMsgGetNumOfSpecialAttrByType
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of special (registered) attributes of the specific
 *      attribute type at the message level.
 *
 * Return Value:
 *      Number of special attributes of the message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
RVSDPCOREAPI RvSize_t rvSdpMsgGetNumOfSpecialAttrByType(
            const RvSdpMsg* msg,
            RvInt attrFieldType)
{
    return rvSdpGetNumOfSpecialAttr(&msg->iCommonFields,attrFieldType);
}

/***************************************************************************
 * rvSdpMsgGetFirstSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first special (registered) attribute of the specific
 *      attribute type at the message level.
 *      Also sets the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there are no
 *      special attributes of the specific type defined in the SDP message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter to be used for further
 *             GetNext calls.
 ***************************************************************************/
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetFirstSpecialAttributeByType(
            RvSdpMsg* msg,
            RvInt attrFieldType,
            RvSdpListIter* iter)
{
    return  (RvSdpAttribute*)rvSdpGetFirstSpecialAttr(&msg->iCommonFields,
                                                     iter,attrFieldType);
}

/***************************************************************************
 * rvSdpMsgGetNextSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next special attribute object of specific type defined
 *      in the SDP message.
 *      The 'next' object is defined based on the list iterator state.
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      more special attributes of the specific type defined in the SDP message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/

RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetNextSpecialAttributeByType(
            RvInt attrFieldType,
            RvSdpListIter* iter)
{
    return (RvSdpAttribute*)rvSdpGetNextSpecialAttr(iter,attrFieldType);
}

/***************************************************************************
* rvSdpMsgGetSpecialAttributeByType
* ------------------------------------------------------------------------
* General:
*      Gets a special attribute of the specific type defined
*      at the message level by index.
*
* Return Value:
*      The requested special attribute object.
* ------------------------------------------------------------------------
* Arguments:
*      msg - a pointer to the RvSdpMsg object.
*      attrFieldType - the attribute type. It is one of the values
*              defined in the RvSdpFieldTypes enum or the value returned
*              by rvSdpSpecialAttrRegister call.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent
*              rvSdpMsgGetNumOfSpecialAttrByType() call.
***************************************************************************/

RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetSpecialAttributeByType(
            const RvSdpMsg* msg,
            RvInt attrFieldType,
            RvSize_t index)
{
    return rvSdpGetSpecialAttr((RvSdpCommonFields*)&msg->iCommonFields,index,attrFieldType);
}

/***************************************************************************
 * rvSdpMsgAddSpecialAttributeByType
 ***************************************************************************/
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgAddSpecialAttributeByType(
            RvSdpMsg* msg,
            RvInt attrFieldType,
            const char* value)
{
    return (rvSdpSpecialAttrAdd(msg,NULL,attrFieldType,value,NULL));
}


/***************************************************************************
 * rvSdpMsgRemoveSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) the special attribute of the specific type
 *      by index. This function removes the the attribute at message level.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 *      index - the index. The index should start at zero (0) and must be smaller
 *              than the number of elements in the list. The number of elements
 *              in the list is retrieved by correspondent
 *              rvSdpMsgGetNumOfSpecialAttrByType call.
 ***************************************************************************/
RVSDPCOREAPI void rvSdpMsgRemoveSpecialAttributeByType(
            RvSdpMsg* msg,
            RvInt attrFieldType,
            RvSize_t index)
{
    rvSdpRemoveSpecialAttr(&msg->iCommonFields,index,attrFieldType);
}

/***************************************************************************
 * rvSdpMsgClearSpecialAttributesByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) all special attributes of the specific type
 *      set in SDP message.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
RVSDPCOREAPI void rvSdpMsgClearSpecialAttributesByType(
            RvSdpMsg* msg,
            RvInt attrFieldType)
{
    rvSdpClearSpecialAttr(&msg->iCommonFields,attrFieldType);
}


/***************************************************************************
 * rvSdpMediaDescrGetNumOfSpecialAttrByType
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of special (registered) attributes of the specific
 *      attribute type at the media descriptor level.
 *
 * Return Value:
 *      Number of special attributes of the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
RVSDPCOREAPI RvSize_t rvSdpMediaDescrGetNumOfSpecialAttrByType(
            const RvSdpMediaDescr* media,
            RvInt attrFieldType)
{
    return rvSdpGetNumOfSpecialAttr(&media->iCommonFields,attrFieldType);
}

/***************************************************************************
 * rvSdpMediaDescrGetFirstSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first special (registered) attribute of the specific
 *      attribute type at the media descriptor level.
 *      Also sets the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there are no
 *      special attributes of the specific type defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter to be used for further
 *             GetNext calls.
 ***************************************************************************/
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetFirstSpecialAttributeByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType,
            RvSdpListIter* iter)
{
    return  (RvSdpAttribute*)rvSdpGetFirstSpecialAttr(&media->iCommonFields,
                                                     iter,attrFieldType);
}

/***************************************************************************
 * rvSdpMediaDescrGetNextSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next special attribute object of specific type defined
 *      in the media descriptor.
 *      The 'next' object is defined based on the list iterator state.
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      more special attributes of the specific type defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/

RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetNextSpecialAttributeByType(
            RvInt attrFieldType,
            RvSdpListIter* iter)
{
    return (RvSdpAttribute*)rvSdpGetNextSpecialAttr(iter,attrFieldType);
}

/***************************************************************************
* rvSdpMediaDescrGetSpecialAttributeByType
* ------------------------------------------------------------------------
* General:
*      Gets a special attribute of the specific type defined
*      at the media descriptor level by index.
*
* Return Value:
*      The requested special attribute object.
* ------------------------------------------------------------------------
* Arguments:
*      media - a pointer to the RvSdpMediaDescr object.
*      attrFieldType - the attribute type. It is one of the values
*              defined in the RvSdpFieldTypes enum or the value returned
*              by rvSdpSpecialAttrRegister call.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent
*              rvSdpMediaDescrGetNumOfSpecialAttrByType() call.
***************************************************************************/

RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetSpecialAttributeByType(
            const RvSdpMediaDescr* media,
            RvInt attrFieldType,
            RvSize_t index)
{
    return rvSdpGetSpecialAttr((RvSdpCommonFields*)&media->iCommonFields,index,attrFieldType);
}

/***************************************************************************
 * rvSdpMediaDescrAddSpecialAttributeByType
 ***************************************************************************/
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrAddSpecialAttributeByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType,
            const char* value)
{
    return (rvSdpSpecialAttrAdd(NULL,media,attrFieldType,value,NULL));
}


/***************************************************************************
 * rvSdpMediaDescrRemoveSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) the special attribute of the specific type
 *      by index. This function removes the the attribute at media descriptor level.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 *      index - the index. The index should start at zero (0) and must be smaller
 *              than the number of elements in the list. The number of elements
 *              in the list is retrieved by correspondent
 *              rvSdpMediaDescrGetNumOfSpecialAttrByType call.
 ***************************************************************************/
RVSDPCOREAPI void rvSdpMediaDescrRemoveSpecialAttributeByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType,
            RvSize_t index)
{
    rvSdpRemoveSpecialAttr(&media->iCommonFields,index,attrFieldType);
}

/***************************************************************************
 * rvSdpMediaDescrClearSpecialAttributesByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) all special attributes of the specific type
 *      set in media descriptor.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
RVSDPCOREAPI void rvSdpMediaDescrClearSpecialAttributesByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType)
{
    rvSdpClearSpecialAttr(&media->iCommonFields,attrFieldType);
}


/***************************************************************************
 * rvSdpMediaDescrDestroyMidAttr
 * ------------------------------------------------------------------------
 * General:  "a=mid: val "
 *      removes the mid attribute from the media descriptor.
 *
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RVSDPCOREAPI void rvSdpMediaDescrDestroyMidAttr(RvSdpMediaDescr* descr)
{
    rvSdpRemoveSpecialAttr(&(descr)->iCommonFields,0,SDP_FIELDTYPE_MEDIA_ID);
}

/***************************************************************************
 * rvSdpMediaDescrSetMidValueStr
 * ------------------------------------------------------------------------
 * General:
 *      Adds/Sets/modifies the Mid Value (as string) in the SDP media descr level.
 *      create new mid attr if there was none under this media,or updates mid value
 *      if there is already mid attr.only one mid attr is allowed per media.
 *      Only one media value is allowed!
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr      - a pointer to the RvSdpMediaDescr object.
 *      midValStr  - the media Id value to be set as a string.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetMidValueStr(
                                         RvSdpMediaDescr* descr,
                                         const char     * midValStr)
{
    return (rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,SDP_FIELDTYPE_MEDIA_ID,midValStr,NULL))
                ? RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;
}

/***************************************************************************
 * rvSdpAttributeSetName
 * ------------------------------------------------------------------------
 * General:
 *      Sets the attribute name.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to RvSdpAttribute object.
 *      name - the new attribute's name.
 ***************************************************************************/
RvSdpStatus
rvSdpAttributeSetName(RvSdpAttribute* attr, const char* name)
{
    return (attr->iSpecAttrData != NULL) ?
        RV_SDPSTATUS_ILLEGAL_SET : rvSdpSetTextField(&attr->iAttrName,attr->iObj,name);
}

/***************************************************************************
 * rvSdpAttributeGetName
 * ------------------------------------------------------------------------
 * General:
 * Return Value:
 *      Returns the attribute name.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to RvSdpAttribute object.
 ***************************************************************************/
const char* rvSdpAttributeGetName(RvSdpAttribute* attr)
{
    return RV_SDP_EMPTY_STRING(attr->iAttrName);
}

/***************************************************************************
 * rvSdpAttributeGetValue
 * ------------------------------------------------------------------------
 * General:
 * Return Value:
 *      Returns the attribute value or the empty string if the value is not set.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to RvSdpAttribute object.
 ***************************************************************************/
const char* rvSdpAttributeGetValue(RvSdpAttribute* attr)
{
    return (attr->iSpecAttrData == NULL) ?
        RV_SDP_EMPTY_STRING(attr->iAttrValue) : rvSdpSpecAttrGetValue(attr);
}

/***************************************************************************
 * rvSdpAttributeSetValue
 * ------------------------------------------------------------------------
 * General:
 *      Sets the attribute value.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to RvSdpAttribute object.
 *      name - the new attribute's value.
 ***************************************************************************/
RvSdpStatus
rvSdpAttributeSetValue(RvSdpAttribute* attr, const char* value)
{
    return (attr->iSpecAttrData != NULL) ?
            RV_SDPSTATUS_ILLEGAL_SET :
            rvSdpSetTextField(&attr->iAttrValue,attr->iObj,value);
}

/***************************************************************************
 * rvSdpAttributeConstructA
 * ------------------------------------------------------------------------
 * General:
 *      Constructs the RvSdpAttribute object.
 *      This function is obsolete. The 'rvSdpMsgAddAttr' or 'rvSdpMediaDescrAddAttr'
 *      should be used instead.
 *
 * Return Value:
 *      A pointer to the constructed object, or NULL if the function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to valid RvSdpAttribute object.
 *      name - the name of the attribute.
 *      value - the value of the attribute.
 *      a  - allocator to be used for memory allocations, if allocator is NULL
 *           the default allocator is used.
 ***************************************************************************/
RvSdpAttribute*
rvSdpAttributeConstructA(RvSdpAttribute* attr, const char* name,
                         const char* value, RvAlloc* a)
{
    return rvSdpAttributeConstruct2(NULL,attr,name,value,a,RV_FALSE);
}

/***************************************************************************
 * rvSdpAttributeConstruct
 * ------------------------------------------------------------------------
 * General:
 *      Constructs the RvSdpAttribute object using default allocator.
 *      This function is obsolete. The 'rvSdpMsgAddAttr' or 'rvSdpMediaDescrAddAttr'
 *      should be used instead.
 *
 * Return Value:
 *      A pointer to the constructed object, or NULL if the function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      attr - a pointer to valid RvSdpAttribute object.
 *      name - the name of the attribute.
 *      value - the value of the attribute.
 ***************************************************************************/
RvSdpAttribute*
rvSdpAttributeConstruct(RvSdpAttribute* attr, const char* name, const char* value)
{
    return rvSdpAttributeConstruct2(NULL,attr,name,value,NULL,RV_FALSE);
}

/***************************************************************************
 * rvSdpAttributeConstructCopy
 * ------------------------------------------------------------------------
 * General:
 *      Constructs an attribute  object and copies the values from a source
 *      attribute.
 *      This function is obsolete. The 'rvSdpMsgAddAttr' or 'rvSdpMediaDescrAddAttr'
 *      should be used instead.
 *
 * Return Value:
 *      A pointer to the constructed object, or NULL if the function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      dest - a pointer to attribute to be constructed. Must point
 *             to valid memory.
 *      src - a source attribute.
 ***************************************************************************/
RvSdpAttribute* rvSdpAttributeConstructCopy(RvSdpAttribute* dest,
                                            const RvSdpAttribute* src)
{
    return rvSdpAttributeConstruct2(NULL,dest,src->iAttrName,
        src->iAttrValue,NULL,RV_FALSE);
}

/***************************************************************************
 * rvSdpAttributeConstructCopyA
 * ------------------------------------------------------------------------
 * General:
 *      Constructs an attribute  object and copies the values from a source
 *      attribute.
 *      This function is obsolete. The 'rvSdpMsgAddAttr' or 'rvSdpMediaDescrAddAttr'
 *      should be used instead.
 *
 * Return Value:
 *      A pointer to the constructed object, or NULL if the function fails
 * ------------------------------------------------------------------------
 * Arguments:
 *      dest - a pointer to attribute to be constructed. Must point
 *             to valid memory.
 *      src - a source attribute.
 *      a  - allocator to be used for memory allocations, if allocator is NULL
 *           the default allocator is used.
 ***************************************************************************/
RvSdpAttribute* rvSdpAttributeConstructCopyA(RvSdpAttribute* dest,
                                             const RvSdpAttribute* src, RvAlloc* a)
{
    return rvSdpAttributeConstruct2(NULL,dest,src->iAttrName,
        src->iAttrValue,a,RV_FALSE);
}


/* framerate attribute */

/***************************************************************************
 * rvSdpMediaDescrGetFrameRate
 * ------------------------------------------------------------------------
 * General:
 *      Gets the frame-rate special attribute value of the media descriptor.
 *
 * Return Value:
 *      Returns the attributes value.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RVSDPCOREAPI const char* rvSdpMediaDescrGetFrameRate(
				RvSdpMediaDescr* descr)
{
     return rvSdpGetSpecialAttrValue(&descr->iCommonFields,0,SDP_FIELDTYPE_FRAMERATE);
}

/***************************************************************************
 * rvSdpMediaDescrSetFrameRate
 * ------------------------------------------------------------------------
 * General:
 *      Sets/modifies the frame-rate special attribute of the media descriptor.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      val - the frame rate attribute value.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetFrameRate(RvSdpMediaDescr* descr, const char* val)
{
	return (rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,
						SDP_FIELDTYPE_FRAMERATE,val,NULL)) ?
						RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;
}

/***************************************************************************
 * rvSdpMediaDescrDestroyFrameRate
 * ------------------------------------------------------------------------
 * General:
 *      Gets the frame-rate special attribute value of the media descriptor.
 *
 * Return Value:
 *      Returns the attributes value.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
void rvSdpMediaDescrDestroyFrameRate(RvSdpMediaDescr* descr)
{
	rvSdpRemoveSpecialAttr(&descr->iCommonFields,0,SDP_FIELDTYPE_FRAMERATE);
}


/*those function must be under the flag '#ifndef RV_SDP_USE_MACROS' */

/***************************************************************************
 * rvSdpMediaDescrGetAcceptTypesVal
 * ------------------------------------------------------------------------
 * General:
 *      Gets the accept-types Value of a media descriptor as a string.
 *
 * Return Value:
 *      Returns the accept-types Value as a string.
 *      EMPTY STRING is returned if the correspondent attribute is not set.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RVSDPCOREAPI const char* rvSdpMediaDescrGetAcceptTypesVal(RvSdpMediaDescr* descr)
{
    return rvSdpGetSpecialAttrValue(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_ACC_TYPES);
}

/***************************************************************************
 * rvSdpMediaDescrGetAcceptWrappedTypesVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=accept-wrapped-types: val"
 *      Gets the accept-wrapped-types Value of a media descriptor as a string.
 *
 * Return Value:
 *      Returns the accept-types Value as a string.
 *      EMPTY STRING is returned if the correspondent attribute is not set.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RVSDPCOREAPI const char* rvSdpMediaDescrGetAcceptWrappedTypesVal(RvSdpMediaDescr* descr)
{
    return rvSdpGetSpecialAttrValue(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_ACC_WRAPPED_TYPES);
}


/***************************************************************************
 * rvSdpMediaDescrGetMaxSizeVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=max-size: val"
 *      Gets the max-size Value of a media descriptor as a string.
 *
 * Return Value:
 *      Returns the max-size Value as a string.
 *      EMPTY STRING is returned if the correspondent attribute is not set.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RVSDPCOREAPI const char* rvSdpMediaDescrGetMaxSizeVal(RvSdpMediaDescr* descr)
{
    return rvSdpGetSpecialAttrValue(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_MAX_SIZE);
}


/***************************************************************************
 * rvSdpMediaDescrGetPathVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=path: val"
 *      Gets the path Value of a media descriptor as a string.
 *
 * Return Value:
 *      Returns the path Value as a string.
 *      EMPTY STRING is returned if the correspondent attribute is not set.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RVSDPCOREAPI const char* rvSdpMediaDescrGetPathVal(RvSdpMediaDescr* descr)
{
    return rvSdpGetSpecialAttrValue(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_PATH);
}

/***************************************************************************
 * rvSdpMediaDescrSetAcceptTypesVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=accept-types: val"
 *      Adds/modifies a new accept-types special attribute object to the media descriptor.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      val - the value of new accept-types special attribute.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetAcceptTypesVal(RvSdpMediaDescr* descr,
                                             const char     * val)
{
    return (rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,SDP_FIELDTYPE_MSRP_ACC_TYPES,val,NULL))
        ? RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;
}

/***************************************************************************
 * rvSdpMediaDescrSetAcceptWrappedTypesVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=accept-wrapped-types: val"
 *      Adds/modifies a new accept-wrapped-types special attribute
 *      object to the media descriptor.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      val - the value of new accept-wrapped-types special attribute.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetAcceptWrappedTypesVal(RvSdpMediaDescr* descr,
                                                        const char     * val)
{
    return (rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,SDP_FIELDTYPE_MSRP_ACC_WRAPPED_TYPES,val,NULL))
        ? RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;

}

/***************************************************************************
 * rvSdpMediaDescrSetMaxSizeVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=max-size: val"
 *      Adds/modifies a new max-size special attribute object to the media descriptor.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      val - the value of new max-size special attribute.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetMaxSizeVal(RvSdpMediaDescr* descr,
                                             const char     * val)
{
    return (rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,SDP_FIELDTYPE_MSRP_MAX_SIZE,val,NULL))
        ? RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;
}

/***************************************************************************
 * rvSdpMediaDescrSetPathVal
 * ------------------------------------------------------------------------
 * General: syntax : "a=accept-types: val"
 *      Adds/modifies a new accept-types special attribute object to the media descriptor.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      val - the value of new accept-types special attribute.
 ***************************************************************************/
RvSdpStatus rvSdpMediaDescrSetPathVal(RvSdpMediaDescr* descr,
                                          const char     * val)
{
    return (rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,SDP_FIELDTYPE_MSRP_PATH,val,NULL))
        ? RV_SDPSTATUS_OK : RV_SDPSTATUS_ALLOCFAIL;

}

/***************************************************************************
 * rvSdpMediaDescrDestroyAcceptTypesAttr
 * ------------------------------------------------------------------------
 * General:
 *      removes the accept-type attribute from the media descriptor.
 *
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
void rvSdpMediaDescrDestroyAcceptTypesAttr(RvSdpMediaDescr* descr)
{
	rvSdpRemoveSpecialAttr(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_ACC_TYPES);
}

/***************************************************************************
 * rvSdpMediaDescrDestroyWrappedAcceptTypesAttr
 * ------------------------------------------------------------------------
 * General:
 *      removes the wrapped-accept-types attribute from the media descriptor.
 *
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
void rvSdpMediaDescrDestroyWrappedAcceptTypesAttr(RvSdpMediaDescr* descr)
{
	rvSdpRemoveSpecialAttr(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_ACC_WRAPPED_TYPES);
}

/***************************************************************************
 * rvSdpMediaDescrDestroyMaxSizeAttr
 * ------------------------------------------------------------------------
 * General:
 *      removes the max-size attribute from the media descriptor.
 *
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
void rvSdpMediaDescrDestroyMaxSizeAttr(RvSdpMediaDescr* descr)
{
	rvSdpRemoveSpecialAttr(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_MAX_SIZE);
}

/***************************************************************************
 * rvSdpMediaDescrDestroyPathAttr
 * ------------------------------------------------------------------------
 * General:
 *      removes the path attribute from the media descriptor.
 *
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
void rvSdpMediaDescrDestroyPathAttr(RvSdpMediaDescr* descr)
{
	rvSdpRemoveSpecialAttr(&descr->iCommonFields,0,SDP_FIELDTYPE_MSRP_PATH);
}


/* fmtp attribute */

/***************************************************************************
 * rvSdpMediaDescrRemoveCurrentFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) the fmtp special attribute object pointed
 *      by list iterator in the context  of media descriptor.
 *      The value of iterator becomes undefined after the function call.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/
void rvSdpMediaDescrRemoveCurrentFmtp(RvSdpListIter* iter)
{
    rvSdpListRemoveCurrent(iter);
}


/***************************************************************************
 * rvSdpMediaDescrRemoveFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) the fmtp special attribute object by index in the
 *      context of media descriptor.
 *
 * Return Value:
 *      None
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      index - the index. The index should start at zero (0) and must be smaller
 *              than the number of elements in the list. The number of elements
 *              in the list is retrieved by correspondent
 *              rvSdpMediaDescrGetNumOfFmtp call.
 ***************************************************************************/
void rvSdpMediaDescrRemoveFmtp(RvSdpMediaDescr* descr, RvSize_t index)
{
	rvSdpRemoveSpecialAttr(&descr->iCommonFields,index,SDP_FIELDTYPE_FMTP);
}

/***************************************************************************
 * rvSdpMediaDescrClearFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) all fmtp special attributes set in media descriptor.
 *
 * Return Value:
 *      None
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
void rvSdpMediaDescrClearFmtp(RvSdpMediaDescr* descr)
{
	rvSdpClearSpecialAttr(&descr->iCommonFields,SDP_FIELDTYPE_FMTP);
}

/***************************************************************************
 * rvSdpMediaDescrGetFirstFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first fmtp special attribute defined in the media descriptor.
 *      Also sets the list iterator for the further use.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute (of fmtp)  object or the NULL pointer if there
 *      are no fmtp attributes defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      iter - pointer to RvSdpListIter to be used for subsequent
 *             rvSdpMediaDescrGetNextFmtp calls
 ***************************************************************************/
RvSdpAttribute* rvSdpMediaDescrGetFirstFmtp(RvSdpMediaDescr* descr, RvSdpListIter* iter)
{
	return rvSdpGetFirstSpecialAttr(&descr->iCommonFields,iter,SDP_FIELDTYPE_FMTP);
}

/***************************************************************************
 * rvSdpMediaDescrGetNextFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next fmtp special attribute defined in the media descriptor.
 *      The 'next' object is defined based on the list iterator state.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute (fmtp) object or the NULL pointer if there is no
 *      more fmtp attributes defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to rvSdpMediaDescr(GetFirst/Next)Fmtp function.
 ***************************************************************************/
RvSdpAttribute* rvSdpMediaDescrGetNextFmtp(RvSdpListIter* iter)
{
	return rvSdpGetNextSpecialAttr(iter,SDP_FIELDTYPE_FMTP);
}

/***************************************************************************
* rvSdpMediaDescrGetFmtp
* ------------------------------------------------------------------------
* General:
*      Gets an fmtp special attribute object by index (in media descriptor context).
*
* Return Value:
*      The requested RvSdpAttribute (of fmtp special attribute) pointer.
* ------------------------------------------------------------------------
* Arguments:
*      descr - a pointer to the RvSdpMediaDescr object.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent
*              rvSdpMediaDescrGetNumOfFmtp() call.
***************************************************************************/
RvSdpAttribute* rvSdpMediaDescrGetFmtp(const RvSdpMediaDescr* descr, RvSize_t index)
{
	return rvSdpGetSpecialAttr((RvSdpCommonFields*)&descr->iCommonFields,
							   index,SDP_FIELDTYPE_FMTP);
}

/***************************************************************************
 * rvSdpMediaDescrAddFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Adds the new fmtp special attribute object to the media descriptor.
 *
 * Return Value:
 *      Returns the pointer to the newly created RvSdpAttribute object if the
 *      function succeeds or NULL pointer if the function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      val - the value of new fmtp special attribute.
 ***************************************************************************/
RvSdpAttribute* rvSdpMediaDescrAddFmtp(RvSdpMediaDescr* descr, const char* val)
{
	return rvSdpSpecialAttrAdd(descr->iSdpMsg,descr,
									SDP_FIELDTYPE_FMTP,val,NULL);
}

/***************************************************************************
 * rvSdpMediaDescrGetNumOfFmtp
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of media descriptor fmtp special attributes.
 *
 * Return Value:
 *      Number of fmtp attributes defined.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 ***************************************************************************/
RvSize_t rvSdpMediaDescrGetNumOfFmtp(const RvSdpMediaDescr* descr)
{
	return rvSdpGetNumOfSpecialAttr(&descr->iCommonFields,
									SDP_FIELDTYPE_FMTP);
}


#endif /*#ifndef RV_SDP_USE_MACROS*/


RvSdpStatus rvSdpSpecAttrInternalRegister(
    IN  const RvChar* attrName,
    IN  RvInt pFieldTypeIn,
    IN  RvSdpSpecAttrData *pSpecAttrData,
    IN  void *pAppData,
    OUT RvInt* pFieldTypeOut,
    RvSdpInternalSpecAttrData** retD)
{
    RvSdpInternalSpecAttrData *d;
    RvSize_t len;

    RV_SDP_USE_GLOBALS;
    if (gSpecAttrsCnt == RV_SDP_SPEC_ATTRS_MAX_NUM)
    {
        RvLogError(pSdpLogSource, (pSdpLogSource, "rvSdpSpecAttrInternalRegister: can't register attribute %s, no more room",attrName));
        return RV_SDPSTATUS_OUT_OF_SPACE;
    }

    d = gSpecAttrs + gSpecAttrsCnt;

    memset(d,0,sizeof(RvSdpInternalSpecAttrData*));

#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = -1;
#endif

    len = strlen(attrName);
    if (len > RV_SDP_MAX_SPEC_ATTR_NAME_LEN)
    {
        RvLogError(pSdpLogSource, (pSdpLogSource, "rvSdpSpecAttrInternalRegister: can't register attribute %s, name too long (max is %d)",attrName,len));
        return RV_SDPSTATUS_ILLEGAL_SET;
    }

    strcpy(d->iName,attrName);
    if (pFieldTypeIn == SDP_FIELDTYPE_NOT_SET)
    {
        d->iAttrFieldType = (RvSdpFieldTypes)gSpecAttrRunningFieldType;
        gSpecAttrRunningFieldType ++;
    }
    else
    {
        d->iAttrFieldType = (RvSdpFieldTypes)pFieldTypeIn;
    }

    if (pFieldTypeOut)
        *pFieldTypeOut = d->iAttrFieldType;

    if (retD)
        *retD = d;

    d->parseFunc = pSpecAttrData->parseFunc;
    d->copyFunc = pSpecAttrData->copyFunc;
    d->destroyFunc = pSpecAttrData->destroyFunc;
    d->encodeFunc = pSpecAttrData->encodeFunc;
    d->bIsSingle = pSpecAttrData->bIsSingle;
    d->iAppData = pAppData;

    d->bValueProhibited = pSpecAttrData->bValueProhibited;
    d->appearsWithValue = pSpecAttrData->appearsWithValue;

    d->bMessageScopeOnly = pSpecAttrData->bMessageScopeOnly;
    d->appearsInMediaScope = pSpecAttrData->appearsInMediaScope;

    d->bMediaScopeOnly = pSpecAttrData->bMediaScopeOnly;
    d->appearsInMsgScope = pSpecAttrData->appearsInMsgScope;

    d->bIntegerValue = pSpecAttrData->bIntegerValue;
    d->maxIntegerValue = pSpecAttrData->maxIntegerValue;
    d->valueNotInRange = pSpecAttrData->valueNotInRange;

    gSpecAttrsCnt ++;
    RvLogInfo(pSdpLogSource, (pSdpLogSource, "rvSdpSpecAttrInternalRegister: registered the attribute %s, registered now %d",attrName,gSpecAttrsCnt));
    return RV_SDPSTATUS_OK;
}


RVSDPCOREAPI RvSdpStatus rvSdpSpecialAttrRegister(
    IN  const RvChar* attrName,
    IN  RvSdpSpecAttrData *pSpecAttrData,
    IN  void *pAppData,
    OUT RvInt* pFieldType)
{
    return rvSdpSpecAttrInternalRegister(attrName,SDP_FIELDTYPE_NOT_SET,pSpecAttrData,pAppData,pFieldType,NULL);
}


void rvSdpRegisterAttributes(void)
{
    RvSdpSpecAttrData attrD;
    RvSdpInternalSpecAttrData *d;

    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_FALSE;
    attrD.parseFunc = rvSdpRtpMapParsing;
    attrD.encodeFunc = rvSdpRtpMapGetValue;
    attrD.destroyFunc = rvSdpRtpMapSpecAttrDestruct;
    attrD.copyFunc = rvSdpRtpMapSpecAttrCopy;
    rvSdpSpecAttrInternalRegister("rtpmap",SDP_FIELDTYPE_RTP_MAP,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpRtpMapReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpRtpMap,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpRtpMapCreateBadSyntax;
#endif

    memset(&attrD,0,sizeof(attrD));
    attrD.bValueProhibited = RV_TRUE;
    attrD.appearsWithValue = RV_SDP_SPEC_ATTR_PARSE_CREATE_AS_REGULAR;
    attrD.bIsSingle = RV_TRUE;
    rvSdpSpecAttrInternalRegister("sendonly",SDP_FIELDTYPE_CONNECTION_MODE,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("recvonly",SDP_FIELDTYPE_CONNECTION_MODE,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("sendrecv",SDP_FIELDTYPE_CONNECTION_MODE,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("inactive",SDP_FIELDTYPE_CONNECTION_MODE,&attrD,NULL,NULL,&d);

    memset(&attrD,0,sizeof(attrD));
    attrD.parseFunc = rvSdpKeyMgmtParsing;
    attrD.encodeFunc = rvSdpKeyMgmtGetValue;
    attrD.destroyFunc = rvSdpKeyMgmtSpecAttrDestruct;
    attrD.copyFunc = rvSdpKeyMgmtCopy;
    rvSdpSpecAttrInternalRegister("key-mgmt",SDP_FIELDTYPE_KEY_MGMT,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpKeyMgmtReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpKeyMgmtAttr,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpKeyMgmtCreateBadSyntax;
#endif /* RV_SDP_CHECK_BAD_SYNTAX */


    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_TRUE;
    attrD.parseFunc = rvSdpRtcpParsing;
    attrD.encodeFunc = rvSdpRtcpGetValue;
    attrD.destroyFunc = rvSdpRtcpDestruct;
    attrD.copyFunc = rvSdpRtcpCopy;
    rvSdpSpecAttrInternalRegister("rtcp",SDP_FIELDTYPE_RTCP,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpRtcpAttrReshuffle;


    memset(&attrD,0,sizeof(attrD));
    attrD.parseFunc = rvSdpCryptoParsing;
    attrD.encodeFunc = rvSdpCryptoGetValue;
    attrD.destroyFunc = rvSdpCryptoDestruct;
    attrD.copyFunc = rvSdpCryptoCopy;
    rvSdpSpecAttrInternalRegister("crypto",SDP_FIELDTYPE_CRYPTO,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpCryptoReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpCryptoAttr,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpCryptoCreateBadSyntax;
#endif /* RV_SDP_CHECK_BAD_SYNTAX */

    memset(&attrD,0,sizeof(attrD));
    attrD.parseFunc = rvSdpMediaGroupAttrParsing;
    attrD.encodeFunc = rvSdpMediaGroupAttrGetValue;
    attrD.destroyFunc = rvSdpMediaGroupAttrDestruct;
    attrD.copyFunc = rvSdpMediaGroupAttrCopy;
    attrD.bMessageScopeOnly = RV_TRUE;
    attrD.appearsInMediaScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("group",SDP_FIELDTYPE_MEDIA_GROUP,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpMediaGroupAttrReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpMediaGroupAttr,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpGroupAttrCreateBadSyntax;
#endif

    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_TRUE;
    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("mid",SDP_FIELDTYPE_MEDIA_ID,&attrD,NULL,NULL,&d);



    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_TRUE;
    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("framerate",SDP_FIELDTYPE_FRAMERATE,&attrD,NULL,NULL,&d);

    memset(&attrD,0,sizeof(attrD));
    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("fmtp",SDP_FIELDTYPE_FMTP,&attrD,NULL,NULL,&d);

    memset(&attrD,0,sizeof(attrD));
    attrD.parseFunc = rvSdpPreconditionAttrParsing;
    attrD.encodeFunc = rvSdpPreconditionAttrGetValue;
    attrD.destroyFunc = rvSdpPreconditionAttrDestruct;
    attrD.copyFunc = rvSdpPreconditionAttrCopy;
    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("curr",SDP_FIELDTYPE_PRECONDITION,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpPreconditionAttrReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpPreconditionAttr,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpPreconditionAttrCreateBadSyntax;
#endif /* RV_SDP_CHECK_BAD_SYNTAX */

    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("des",SDP_FIELDTYPE_PRECONDITION,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpPreconditionAttrReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpPreconditionAttr,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpPreconditionAttrCreateBadSyntax;
#endif /* RV_SDP_CHECK_BAD_SYNTAX */

    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("conf",SDP_FIELDTYPE_PRECONDITION,&attrD,NULL,NULL,&d);
    d->iReshuffleFunc = (rvAttrReshuffleCB)rvSdpPreconditionAttrReshuffle;
#if defined(RV_SDP_CHECK_BAD_SYNTAX)
    d->iBadValueOffset = RV_OFFSETOF(RvSdpPreconditionAttr,iBadSyntaxField);
    d->iCrtBadSyncFunc = rvSdpPreconditionAttrCreateBadSyntax;
#endif /* RV_SDP_CHECK_BAD_SYNTAX */




    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_TRUE;
    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("accept-types",SDP_FIELDTYPE_MSRP_ACC_TYPES,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("accept-wrapped-types",SDP_FIELDTYPE_MSRP_ACC_WRAPPED_TYPES,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("path",SDP_FIELDTYPE_MSRP_PATH,&attrD,NULL,NULL,&d);

    attrD.bIntegerValue = RV_TRUE;
    attrD.valueNotInRange = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("max-size",SDP_FIELDTYPE_MSRP_MAX_SIZE,&attrD,NULL,NULL,&d);

    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_TRUE;
    attrD.bMessageScopeOnly = RV_TRUE;
    attrD.appearsInMediaScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("cat",SDP_FIELDTYPE_ATTR_CAT,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("keywds",SDP_FIELDTYPE_ATTR_KEYWDS,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("tool",SDP_FIELDTYPE_ATTR_TOOL,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("type",SDP_FIELDTYPE_ATTR_TYPE,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("charset",SDP_FIELDTYPE_ATTR_CHARSET,&attrD,NULL,NULL,&d);

    memset(&attrD,0,sizeof(attrD));
    attrD.bIsSingle = RV_TRUE;
    attrD.bMediaScopeOnly = RV_TRUE;
    attrD.appearsInMsgScope = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
    rvSdpSpecAttrInternalRegister("orient",SDP_FIELDTYPE_ATTR_ORIENT,&attrD,NULL,NULL,&d);
/*
    attrD.bIntegerValue = RV_TRUE;
    attrD.valueNotInRange = RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR;
*/
    rvSdpSpecAttrInternalRegister("ptime",SDP_FIELDTYPE_ATTR_PTIME,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("maxptime",SDP_FIELDTYPE_ATTR_MAXPTIME,&attrD,NULL,NULL,&d);
    rvSdpSpecAttrInternalRegister("quality",SDP_FIELDTYPE_ATTR_QUALITY,&attrD,NULL,NULL,&d);



    memset(&attrD,0,sizeof(attrD));
    rvSdpSpecAttrInternalRegister("lang",SDP_FIELDTYPE_ATTR_LANG,&attrD,NULL,NULL,&d);



}

/***************************************************************************
 * rvSdpGetAttrFieldTypeByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the field type number of the registered special attribute
 *      by attribute name.
 *
 * Return Value:
 *      Returns the field type number or SDP_FIELDTYPE_NOT_SET if the name
 *      was not registered.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the registered attribute.
 ***************************************************************************/
RVSDPCOREAPI RvInt rvSdpGetAttrFieldTypeByName(
    IN  const RvChar* attrName)
{
    const RvSdpInternalSpecAttrData* pAttrData;
    pAttrData = rvSdpFindSpecAttrDataByName(attrName);
    return (pAttrData) ? pAttrData->iAttrFieldType : SDP_FIELDTYPE_NOT_SET;
}

