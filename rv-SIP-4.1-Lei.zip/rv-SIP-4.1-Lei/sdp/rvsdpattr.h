/******************************************************************************
Filename    :rvsdptypes.h
Description :This file exists for backward compatibility.

******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef _rvsdpattr_h
#define _rvsdpattr_h


/********************************************************************************************
 * Generic and registered (special) Attributes: Expanding the SDP stack by application
 *
 *  SDP attributes is the major way allowing the SDP standard to evolve. That is different
 *  SDP usages define new SDP attributes each with own rules and value syntax grammar. 
 *  The attribute rules define whether this attribute allow multiple appearances, the scope
 *  where this attribute may appear and more. For obvious reasons no SDP library can 
 *  provide parsing of all SDP attributes but RADVISION SDP libabry provides
 *  convinient and flexible way allowing the application to enrich library functionality
 *  by registering some attributes that are specifically important to that application. 
 *  When application registers the attribute it may (but not must) provide its own code 
 *  that will parse the attribute value, possibly creating application object. This object 
 *  will become a part of SDP message and application will be able to access it at any 
 *  moment. 
 *  
 *  Thus SDP attributes can be separated into generic attributes and registered or special
 *  attributes. Generic attributes allow to access (set/get) its name and value. Application 
 *  may add/remove/iterate attribute objects in the scope (media descriptor or the whole 
 *  message) where these attributes are defined.
 *    
 *  Special attributes are the attributes that were registered within the SDP library.
 *  RADVISION SDP library comes with some attributes that were already registered and
 *  application may add as many registered attributes as it needs. When the SDP attribute
 *  is registered it gets the field type number. Using this number application may 
 *  iterate on the attributes having the same field type number, destroy all such 
 *  attributes and more.
 *  The RADVISION SDP stack comes with the number of registered attributes. This
 *  include all attributes defined by RFC 4566 and some more.
 *  
 *  These are:
 *        . Connection mode (a = sendonly/recvonly/sendrecv/inactive)
 *        . RTP map (a=rtpmap: ...)
 *        . Key management (a=key-mgmt: ...)
 *        . Crypto (a=crypto: ...)
 *        . Framerate (a=framerate: ...)
 *        . Codec format parameters (a=fmtp: ...)
 *        . Media grouping attributes (a=mid/group:...)
 *        . Preconditions attributes (a=curr/des/conf:...)
 *        . MSRP attributes (a=accept-types/accept-wrapped-types/maxsize/path:...)
 *        . RTCP attribute (a=rtcp:...)
 *        . Category attribute (a=cat:...)
 *        . Key words attribute (a=keywds:...)
 *        . Tool attribute (a=tool:...)
 *        . Type attribute (a=type:...)
 *        . Character set attribute (a=charset:...)
 *        . Orientation attribute (a=orient:...)
 *        . Packet time attribute (a=ptime:...)
 *        . Max packet time attribute (a=maxptime:...)
 *        . Quality attribute (a=quality:...)
 *        . Language attribute (a=lang:...)
 *        
 *  Please see the RvSdpFieldTypes enumeration for the field type values (starting from from the value 
 *  SDP_FIELDTYPE_RTP_MAP) of pre-registered special attributes. These values may be used when calling
 *  special attributes "ByType" API functions like: rvSdpMsgGetNumOfSpecialAttrByType, 
 *  rvSdpMsgGetFirstSpecialAttributeByType, etc.
 *          
 *  Some of pre-registered special attributes define dedicated attribute types and dedicated API functions. 
 *  For example RTCP attribute define the RvSdpRtcp special attribute type and dedicated API functions
 *  like: rvSdpMediaDescrGetRtcp or rvSdpRtcpSetPort.
 *            
 *  In order to register new special attribute the API function rvSdpSpecialAttrRegister needs to be called.
 *  After successfull function call application will receive the ID of the new special attribute or field type
 *  number. This number can be used later when calling "ByType" special attributes functions.
 *  The same attribute name cannot be registered for the second time. That is an attempt to register attribute 
 *  that was already registered will fail.
 *       
 *  When the attribute is registered an application may specify various attribute characteristics. Please see
 *  the RvSdpSpecAttrData data structture defined in the rvsdpattr.h for full explanations.
 *       
 *  An application may provide its own parsing routine to parse the value of registered attribute as the value of 
 *  parseFunc member of RvSdpSpecAttrData structure. Within this function an application may create its own
 *  object representing the attribute. This application created object will become part of SDP message. The 
 *  C structure of that object must have the first data field of type RvSdpAttribute. That is if application creates
 *  object of type struct ApplicationAttrubuteData it must defined in the following way:
 *
 *    typedef struct ApplicationAttrubuteData {
 *            RvSdpAttribute sdpAttr;   	/ * the first field must be RvSdpAttribute * /
 *            ....  						/ * all other neccessary fiels * /
 *    };
 *  This is needed to allow safe casting between the application object's type and RvSdpAttribute type.
 *        
 *  Please note that the function rvSdpSpecialAttrRegister is not thread safe. It is expected that application will 
 *  register all its attributes in one thread at application start. When all attributes were registered it is safe
 *  to perform siumultaneous parsing of different messages from different threads.
 *    
 *    
 *  There are two sets of attribute-handling functions. The first set handles only
 *  generic attributes, while the second handles both generic and special attributes.
 *  For example, the rvSdpMsgGetNumOfAttr() function will get only the number
 *  of generic attributes defined in the context of an RvSdpMsg. All special
 *  attributes pre-registered by SDP stack itself or registered by application 
 *  will not be counted by this function. The rvSdpMsgGetNumOfAttr2() function will get 
 *  the number of all attributes
 *  (generic and special) defined in the context of an RvSdpMsg. Both functions will
 *  not count the attributes defined in the context of one of the media descriptors
 *  defined in the message. Special and generic attributes functions add the number
 *  �2� to the name of generic-only attribute functions.
 */


typedef struct _RvSdpMsg RvSdpMsg;
typedef struct _RvSdpMediaDescr RvSdpMediaDescr;
typedef struct _RvSdpAttribute RvSdpAttribute;

/* 
 * The possible return codes of the application provided function of type
 * rvSdpSpecAttrParseFunc used to parse the attributes not parsed by SDP 
 * stack. These values are returned by the application and instruct the
 * SDP stack on the necessary steps regarding the attribute treatment. 
 */
typedef enum {
    RV_SDP_SPEC_ATTR_PARSE_OK = RV_OK,
            /* The attribute was parsed successfully and possibly the 
               argument 'pAppAttr' of function rvSdpSpecAttrParseFunc 
               was created */
    RV_SDP_SPEC_ATTR_PARSE_CREATE_AS_REGULAR,
            /* The attribute parsing has failed and the application requests
               to create this attribute as 'regular' and not 'special'.*/
    RV_SDP_SPEC_ATTR_PARSE_IGNORE_ATTR,
            /* The attribute parsing has failed and the application requests
               to ignore this attribute and not to create any attribute 
               object at all for this 'a=' line in the SDP input. */
    RV_SDP_SPEC_ATTR_PARSE_FAIL_MESSAGE
            /* The attribute parsing has failed and the application requests
               to fail the whole SDP message parsing. That is the whole
               call to SDP parsing function rvSdpMsgConstructParse (or alike)
               should fail.
             */
} RvSdpSpecAttrParseAction;


/***************************************************************************
 * rvSdpSpecAttrParseFunc
 * ------------------------------------------------------------------------
 * General:
 *  This function is an application-defined callback.
 *  This function is called by SDP parser for the attributes that were successfully  
 *  registered by application with rvSdpSpecialAttrRegister call. 
 *  This function will parse the value part of the attribute and possibly
 *  create the application object that will contain the RvSdpAttribute object. 
 *
 * Return Value:
 *      One of the values defined by RvSdpSpecAttrParseAction enum. Please see
 *      RvSdpSpecAttrParseAction annotation for more information.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute being parsed. An SDP line for
 *              attribute looks like: a=name:value. Thus the 'attrName' 
 *              is equal to 'name'.
 *      fieldType - the field type generated by the SDP stack when the 
 *              attribute was regiestered with rvSdpSpecialAttrRegister 
 *              call.
 *      pAppData - this is the application context pointer provided when 
 *              the attribute was registered with rvSdpSpecialAttrRegister
 *              call.
 *      attrValue - the value (after the ':' sign) of the attribute being
 *              parsed. The value is zero terminated string. Please note 
 *              that the attrValue is not 'const' memory, that is the application
 *              is allowed to modify the memory pointed by 'attrValue' while
 *              in the parsing process (for example replace spaces by 
 *              zero bytes) but at the end of parse process the value MUST
 *              be returned to the original state.
 *      pMsg - a pointer to the RvSdpMsg object owning the attribute object.
 *      pDescr - a pointer to the RvSdpMediaDescr object owning the attribute
 *              object or NULL if the attribute is in the message scope and 
 *              does not belong to specific media descriptor.
 *      pAppAttr - as a result of parse operation an application may create 
 *              its own object representing the parsed attribute. This 
 *              object is returned as the value of 'pAppAttr'. If application 
 *              creates its own object representing the parsed attribute the C
 *              data structure for this application object MUST have the 
 *              first data field of type  struct RvSdpAttribute. Thus the 
 *              casting between the application defined type and the 
 *              RvSdpAttribute type (and vice-versa) is safe.
 *              If application does not create its own object as a result
 *              of parse operation the value pointed by pAttr ('*pAttr') 
 *              must be set to NULL. 
 *              Generally the only purpose of defining the parse callback 
 *              which does not create application object is to test the 
 *              compatibility of attribute value to some predefined (and 
 *              known to the application) syntax.
 ***************************************************************************/
typedef RvSdpSpecAttrParseAction (*rvSdpSpecAttrParseFunc)(
    IN const RvChar* attrName,
    IN RvInt fieldType,
    IN void* pAppData,
    IN RvChar* attrValue,
    IN RvSdpMsg* pMsg,
    IN RvSdpMediaDescr* pDescr,
    OUT RvSdpAttribute** pAttr);

/***************************************************************************
 * rvSdpSpecAttrEncodeFunc
 * ------------------------------------------------------------------------
 * General:
 *  This function is an application-defined callback.
 *  This function is called by SDP stack for the attributes that were successfully  
 *  registered by application with rvSdpSpecialAttrRegister call. 
 *  This function will produce the textual value of the attribute using the 
 *  application produced attribute object 'pAttr'. This object was probably
 *  created by application when the attribute was parsed using application 
 *  provided function rvSdpSpecAttrParseFunc. Since this application object
 *  MUST have the struct RvSdpAttribute as its first data field the casting 
 *  between its type and RvSdpAttribute is safe.
 *  Please note that this function returns the pointer to the memory allocated 
 *  internally by the application. 
 *  If application does not register this callback SDP stack will use the value part
 *  of the attribute when the attribute is encoded.
 *  
 * Return Value:
 *      The textual representation of attribute value.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute being encoded.
 *      fieldType - the field type generated by the SDP stack when the 
 *              attribute was regiestered with rvSdpSpecialAttrRegister.
 *      pAppData - this is the application context pointer provided when 
 *              the attribute was registered with rvSdpSpecialAttrRegister
 *              call.
 *      pAttr - a pointer to the application object created when 
 *              the attribute was parsed or RvSdpAttribute instance pointer 
 *              created by SDP stack instead of application.
 ***************************************************************************/
typedef const RvChar* (*rvSdpSpecAttrEncodeFunc)(
    IN const RvChar* attrName,
    IN RvInt fieldType,
    IN void* pAppData,
    IN RvSdpAttribute* pAttr);

/***************************************************************************
 * rvSdpSpecAttrDestroyFunc
 * ------------------------------------------------------------------------
 * General:
 *  This function is an application-defined callback.
 *  This function is called by SDP for the attributes that were successfully  
 *  registered by application with rvSdpSpecialAttrRegister call. 
 *  This function is called when the attribute is destroyed and thus application
 *  created object (containing the RvSdpAttribute) needs to be destroyed as well.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute being encoded.
 *      fieldType - the field type generated by the SDP stack when the 
 *                 attribute was regiestered with rvSdpSpecialAttrRegister.
 *      pAppData - this is the application context pointer provided when 
 *              the attribute was registered with rvSdpSpecialAttrRegister
 *              call.
 *      pAttr - a pointer to the application object created when 
 *              the attribute was parsed or RvSdpAttribute instance pointer 
 *              created by SDP stack instead of application.
 ***************************************************************************/
typedef void (*rvSdpSpecAttrDestroyFunc)(
    IN const RvChar* attrName,
    IN RvInt fieldType,
    IN void* pAppData,
    IN RvSdpAttribute* attr);

/***************************************************************************
 * rvSdpSpecAttrCopyFunc
 * ------------------------------------------------------------------------
 * General:
 *  This function is an application-defined callback.
 *  This function is called by SDP for the attributes that were successfully  
 *  registered by application with rvSdpSpecialAttrRegister call. 
 *  This function is called when the attribute is copied. Thus it allows the application
 *  to take the necessary steps when the copy of application created object needs to 
 *  be created for the destination attribute object. The application created as a result
 *  of copy operation must be created according the same rules as for application 
 *  object created during the attribute parse process.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute being encoded.
 *      fieldType - the field type generated by the SDP stack when the 
 *              attribute was regiestered with rvSdpSpecialAttrRegister.
 *      pAppData - this is the application context pointer provided when 
 *              the attribute was registered with rvSdpSpecialAttrRegister
 *              call.
 *      pDestMsg - a pointer to the RvSdpMsg object owning the destination
 *              attribute object.
 *      pSrcAttr - a pointer to the source RvSdpAttribute object. This 
 *              pointer may point to the application object having the
 *              RvSdpAttribute as its first data field.
 ***************************************************************************/
typedef RvSdpAttribute* (*rvSdpSpecAttrCopyFunc)(
    IN const RvChar* attrName,
    IN RvInt fieldType,
    IN void* pAppData,
    IN RvSdpMsg *pDestMsg,
    IN const RvSdpAttribute* pSrcAttr);


/***************************************************************************
 * RvSdpSpecAttrData
 * ------------------------------------------------------------------------
 * This structure contains some application provided callbacks used by SDP stack
 * when handling application registered 'special' attributes. The filled instance of
 * this structure must be provided by application when it registers the new
 * special attribute with rvSdpSpecialAttrRegister function call.
 ***************************************************************************/
typedef struct {

    rvSdpSpecAttrParseFunc parseFunc;
        /* Called by SDP stack when the attribute is parsed. An application may
           create its own object representing the attribute within the parse function.
           If application does not provide the parse function the registered 
           'special' attribute will not be represented by dedicated type but still
           application may provide some rules (bIsSingle,bMediaScopeOnly, etc) 
           instructing the SDP parser how to treat the appearance of this attribute.
           Also even without the dedicated type the attribute is created as special
           what allows the application to use the 'special' attributes functions 
           (rvSdpMsgGetNumOfSpecialAttrByType,rvSdpMsgGetFirstSpecialAttributeByType etc)
           for these attributes.
           Please note that if the application does provide the parse function that 
           creates its own object for the attribute it MUST provide functions for
           attribute destroy, encode and copy operations. Failing to do so may cause
           hard to debug errors. For example if there is no attribute destroy callback
           for the application created object the attribute object (RvSdpAttribute)
           will be destroyed as the object owned by SDP stack what will cause 
           unpredictable results.
        */

    rvSdpSpecAttrEncodeFunc encodeFunc;
        /* Called by SDP stack when the attribute is encoded. */

    rvSdpSpecAttrDestroyFunc destroyFunc;
        /* Called by SDP stack when the attribute is destroyed. */

    rvSdpSpecAttrCopyFunc copyFunc;
        /* Called by SDP stack when the attribute is copied. */

    RvBool bIsSingle;
        /* Defines whether the multiple appearances of this attribute is legal.
           If the value of this parameter is set to RV_TRUE that is the only one
           appearance of this attribute is allowed in the scope of the message
           or media descriptor and the parsed SDP message contains more than one 
           appearance all attribute appearances starting from the second will
           be ignored. */

    RvBool   bValueProhibited;      
        /* The value is prohibited for this attribute. If the attribute comes with the 
           value the SDP parser action is defined according to the 'appearsWithValue' */
    RvSdpSpecAttrParseAction appearsWithValue;
    
    RvBool  bMessageScopeOnly;            
        /* If set to RV_TRUE the attribute may appear in the scope of message only 
           (not in the scope of media desciptor). If the attribute does appear in the
           media descriptor scope the SDP parser action is defined according to 
           the 'appearsInMediaScope' */
    RvSdpSpecAttrParseAction appearsInMediaScope; 

    RvBool  bMediaScopeOnly;      
         /* If set to RV_TRUE the attribute may appear in the scope of media descriptor only 
           (not in the scope of the whole message). If the attribute does appear in the
           message the parser action is defined according to the 'appearsInMsgScope' */
    RvSdpSpecAttrParseAction appearsInMsgScope;

    RvBool  bIntegerValue;      
         /* The value is non-negative integer in range between 0 and 'maxIntegerValue' 
            If the attribute value fails to be integer or fails to be within the range
            the SDP parser action is defined according to the 'valueNotInRange'. */
    RvInt32 maxIntegerValue;
    RvSdpSpecAttrParseAction valueNotInRange; 
} RvSdpSpecAttrData;


/***************************************************************************
 * rvSdpSpecialAttrRegister
 * ------------------------------------------------------------------------
 * General:
 *      Registers another special attribute.
 *
 * Return Value:
 *      Returns RV_SDPSTATUS_OK if the function succeeds, or an error code if the
 *      function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute being registered.
 *      pSpecAttrData - this struct accumulates information describing the 
 *              attribute being registered. Please see the annotated 
 *              RvSdpSpecAttrData structure.
 *      pAppData - application provided context. This user data pointer will be 
 *              associated with the registered attribute and afterwards will be 
 *              provided to the application when the application callbacks
 *              are called.
 *      pFieldType - will be set to the ID identifying this regsistered special
 *              attribute. An application may use this number later when 
 *              working with the special attributes using functions like 
 *              rvSdpMsgGetNumOfSpecialAttrByType. 
 *              This parameter may also be set to NULL.
 ***************************************************************************/
RVSDPCOREAPI RvSdpStatus rvSdpSpecialAttrRegister(
    IN  const RvChar* attrName,
    IN  RvSdpSpecAttrData *pSpecAttrData,
    IN  void *pAppData,
    OUT RvInt* pFieldType);

/***************************************************************************
 * rvSdpGetAttrFieldTypeByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the field type number of the registered special attribute 
 *      by attribute name.
 *
 * Return Value:
 *      Returns the field type number or SDP_FIELDTYPE_NOT_SET if the name
 *      was not registered.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the registered attribute.
 ***************************************************************************/
RVSDPCOREAPI RvInt rvSdpGetAttrFieldTypeByName(
    IN  const RvChar* attrName);

/***************************************************************************
 * rvSdpMsgGetNumOfSpecialAttrByType
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of special (registered) attributes of the specific 
 *      attribute type at the message level.
 *
 * Return Value:
 *      Number of special attributes of the message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSize_t rvSdpMsgGetNumOfSpecialAttrByType(
            const RvSdpMsg* msg,
            RvInt attrFieldType);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetNumOfSpecialAttrByType(_msg,_attrFieldType) \
			rvSdpGetNumOfSpecialAttr(&(_msg)->iCommonFields,(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMsgGetFirstSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first special (registered) attribute of the specific 
 *      attribute type at the message level.
 *      Also sets the list iterator for the further use. 
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there are no
 *      special attributes of the specific type defined in the SDP message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter to be used for further
 *             GetNext calls.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetFirstSpecialAttributeByType(
            RvSdpMsg* msg,
            RvInt attrFieldType,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetFirstSpecialAttributeByType(_msg,_attrFieldType,_iter) \
			(RvSdpAttribute*)rvSdpGetFirstSpecialAttr(&(_msg)->iCommonFields,\
                                                      (_iter),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMsgGetNextSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next special attribute object of specific type defined 
 *      in the SDP message.
 *      The 'next' object is defined based on the list iterator state. 
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      more special attributes of the specific type defined in the SDP message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetNextSpecialAttributeByType(
            RvInt attrFieldType,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetNextSpecialAttributeByType(_attrFieldType,_iter) \
			(RvSdpAttribute*)rvSdpGetNextSpecialAttr((_iter),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
* rvSdpMsgGetSpecialAttributeByType
* ------------------------------------------------------------------------
* General:
*      Gets a special attribute of the specific type defined 
*      at the message level by index. 
*
* Return Value:
*      The requested special attribute object.
* ------------------------------------------------------------------------
* Arguments:
*      msg - a pointer to the RvSdpMsg object.
*      attrFieldType - the attribute type. It is one of the values
*              defined in the RvSdpFieldTypes enum or the value returned 
*              by rvSdpSpecialAttrRegister call.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent 
*              rvSdpMsgGetNumOfSpecialAttrByType() call.
***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetSpecialAttributeByType(
            const RvSdpMsg* msg,
            RvInt attrFieldType,
            RvSize_t index);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetSpecialAttributeByType(_msg,_attrFieldType,_index)   \
			rvSdpGetSpecialAttr((RvSdpCommonFields*)&(_msg)->iCommonFields,\
                                                 (_index),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMsgAddSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Adds the new special attribute object or replaces the existing.
 *      The attribute is added or replaced based on the way this special
 *      attribute has been registered. If the attribute does not allow multiple 
 *      appearances (bIsSingle field of RvSdpSpecAttrData struct was set 
 *      to RV_TRUE when the attribute was registered) AND there is already
 *      one special attribute with this specific type the attribute will be
 *      replaced. Otherwise new special attribute will be added.
 *      All other fields of RvSdpSpecAttrData structure are also 
 *      considered. For example if the attribute was registered 
 *      as media scope only it cannot be added at the message level.
 *      Please note that this function will call application provided
 *      parse function (parseFunc field of RvSdpSpecAttrData struct)
 *      This function adds/replaces attributes at the message level.
 *
 * Return Value:
 *      Returns the pointer to the newly created/replaced RvSdpAttribute object if the
 *      function succeeds or NULL pointer if the function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      value - the generic attribute value.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgAddSpecialAttributeByType(
            RvSdpMsg* msg,
            RvInt attrFieldType,
            const char* value);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgAddSpecialAttributeByType(_msg,_attrFieldType,_value) \
        (rvSdpSpecialAttrAdd((_msg),NULL,(_attrFieldType),(_value),NULL))            
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMsgRemoveSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) the special attribute of the specific type
 *      by index. This function removes the the attribute at message level.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      index - the index. The index should start at zero (0) and must be smaller
 *              than the number of elements in the list. The number of elements
 *              in the list is retrieved by correspondent
 *              rvSdpMsgGetNumOfSpecialAttrByType call.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI void rvSdpMsgRemoveSpecialAttributeByType(
            RvSdpMsg* msg,
            RvInt attrFieldType,
            RvSize_t index);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgRemoveSpecialAttributeByType(_msg,_attrFieldType,_index) \
			rvSdpRemoveSpecialAttr(&(_msg)->iCommonFields,(_index),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMsgClearSpecialAttributesByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) all special attributes of the specific type 
 *      set in SDP message.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI void rvSdpMsgClearSpecialAttributesByType(
            RvSdpMsg* msg,
            RvInt attrFieldType);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgClearSpecialAttributesByType(_msg,_attrFieldType) \
			rvSdpClearSpecialAttr(&(_msg)->iCommonFields,(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMediaDescrGetNumOfSpecialAttrByType
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of special (registered) attributes of the specific 
 *      attribute type at the media descriptor level.
 *
 * Return Value:
 *      Number of special attributes of the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSize_t rvSdpMediaDescrGetNumOfSpecialAttrByType(
            const RvSdpMediaDescr* media,
            RvInt attrFieldType);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetNumOfSpecialAttrByType(_media,_attrFieldType) \
			rvSdpGetNumOfSpecialAttr(&(_media)->iCommonFields,(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMediaDescrGetFirstSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first special (registered) attribute of the specific 
 *      attribute type at the media descriptor level.
 *      Also sets the list iterator for the further use. 
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there are no
 *      special attributes of the specific type defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter to be used for further
 *             GetNext calls.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetFirstSpecialAttributeByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetFirstSpecialAttributeByType(_media,_attrFieldType,_iter) \
			(RvSdpAttribute*)rvSdpGetFirstSpecialAttr(&(_media)->iCommonFields,\
                                                      (_iter),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMediaDescrGetNextSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next special attribute object of specific type defined 
 *      in the media descriptor.
 *      The 'next' object is defined based on the list iterator state. 
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      more special attributes of the specific type defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetNextSpecialAttributeByType(
            RvInt attrFieldType,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetNextSpecialAttributeByType(_attrFieldType,_iter) \
			(RvSdpAttribute*)rvSdpGetNextSpecialAttr((_iter),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
* rvSdpMediaDescrGetSpecialAttributeByType
* ------------------------------------------------------------------------
* General:
*      Gets a special attribute of the specific type defined 
*      at the media descriptor level by index. 
*
* Return Value:
*      The requested special attribute object.
* ------------------------------------------------------------------------
* Arguments:
*      media - a pointer to the RvSdpMediaDescr object.
*      attrFieldType - the attribute type. It is one of the values
*              defined in the RvSdpFieldTypes enum or the value returned 
*              by rvSdpSpecialAttrRegister call.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent 
*              rvSdpMediaDescrGetNumOfSpecialAttrByType() call.
***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetSpecialAttributeByType(
            const RvSdpMediaDescr* media,
            RvInt attrFieldType,
            RvSize_t index);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetSpecialAttributeByType(_media,_attrFieldType,_index)   \
			rvSdpGetSpecialAttr((RvSdpCommonFields*)&(_media)->iCommonFields,\
                                                 (_index),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMediaDescrAddSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Adds the new special attribute object or replaces the existing.
 *      The attribute is added or replaced based on the way this special
 *      attribute has been registered. If the attribute does not allow multiple 
 *      appearances (bIsSingle field of RvSdpSpecAttrData struct was set 
 *      to RV_TRUE when the attribute was registered) AND there is already
 *      one special attribute with this specific type the attribute will be
 *      replaced. Otherwise new special attribute will be added.
 *      All other fields of RvSdpSpecAttrData structure are also 
 *      considered. For example if the attribute was registered 
 *      as media scope only it cannot be added at the message level.
 *      Please note that this function will call application provided
 *      parse function (parseFunc field of RvSdpSpecAttrData struct)
 *      This function adds/replaces attributes at the media descriptor level.
 *
 * Return Value:
 *      Returns the pointer to the newly created/raplaced RvSdpAttribute object if the
 *      function succeeds or NULL pointer if the function fails.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      value - the generic attribute value.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrAddSpecialAttributeByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType,
            const char* value);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrAddSpecialAttributeByType(_media,_attrFieldType,_value) \
        (rvSdpSpecialAttrAdd(NULL,(_media),(_attrFieldType),(_value),NULL))            
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMediaDescrRemoveSpecialAttributeByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) the special attribute of the specific type
 *      by index. This function removes the the attribute at media 
 *      descriptor level.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 *      index - the index. The index should start at zero (0) and must be smaller
 *              than the number of elements in the list. The number of elements
 *              in the list is retrieved by correspondent
 *              rvSdpMediaDescrGetNumOfSpecialAttrByType call.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI void rvSdpMediaDescrRemoveSpecialAttributeByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType,
            RvSize_t index);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrRemoveSpecialAttributeByType(_media,_attrFieldType,_index) \
			rvSdpRemoveSpecialAttr(&(_media)->iCommonFields,(_index),(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMediaDescrClearSpecialAttributesByType
 * ------------------------------------------------------------------------
 * General:
 *      Removes (and destructs) all special attributes of the specific type 
 *      set in media descriptor.
 *
 * Return Value:
 *      None.
 * ------------------------------------------------------------------------
 * Arguments:
 *      media - a pointer to the RvSdpMediaDescr object.
 *      attrFieldType - the attribute type. It is one of the values
 *              defined in the RvSdpFieldTypes enum or the value returned 
 *              by rvSdpSpecialAttrRegister call.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI void rvSdpMediaDescrClearSpecialAttributesByType(
            RvSdpMediaDescr* media,
            RvInt attrFieldType);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrClearSpecialAttributesByType(_media,_attrFieldType) \
			rvSdpClearSpecialAttr(&(_media)->iCommonFields,(_attrFieldType))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMsgGetNumOfAttrByName
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of attributes having the given name in the session 
 *      level attributes list.
 *
 * Return Value:
 *      Number of attributes with the given name.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrName - the name of the attribute to be retrieved.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSize_t rvSdpMsgGetNumOfAttrByName(
            const RvSdpMsg* msg,
            const RvChar* attrName);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetNumOfAttrByName(_msg,_attrName) \
			rvSdpGetNumOfAttrByName(&(_msg)->iCommonFields,(_attrName))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMsgGetFirstAttributeByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first attribute object with the given name defined 
 *      in the SDP message. Also sets the list iterator for the further use. 
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      attribute with the given name in the SDP message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      msg - a pointer to the RvSdpMsg object.
 *      attrName - the name of the attribute to be retrieved.
 *      iter - pointer to RvSdpListIter to be used for further
 *             GetNext calls.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetFirstAttributeByName(
            RvSdpMsg* msg,
            const RvChar* attrName,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetFirstAttributeByName(_msg,_attrName,_iter) \
			(RvSdpAttribute*)rvSdpGetFirstAttrByName(&(_msg)->iCommonFields,\
                                                      (_iter),(_attrName))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMsgGetNextAttributeByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next attribute object with the given name defined 
 *      in the SDP message. The 'next' object is defined based on the list
 *      iterator state.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      more attributes with the given name defined in the SDP message.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute to be retrieved.
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetNextAttributeByName(
            const RvChar* attrName,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetNextAttributeByName(_attrName,_iter) \
			(RvSdpAttribute*)rvSdpGetNextAttrByName((_iter),(_attrName))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
* rvSdpMsgGetAttributeByName
* ------------------------------------------------------------------------
* General:
*      Gets an attribute object with the given name by index. 
*
* Return Value:
*      The requested attribute object.
* ------------------------------------------------------------------------
* Arguments:
*      msg - a pointer to the RvSdpMsg object.
*      attrName - the name of the attribute to be retrieved.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent rvSdpMsgGetNumOfAttrByName() call.
***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMsgGetAttributeByName(
            const RvSdpMsg* msg,
            const RvChar* attrName,
            RvSize_t index);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMsgGetAttributeByName(_msg,_attrName,_index)   \
			rvSdpGetAttrByName((RvSdpCommonFields*)&(_msg)->iCommonFields,\
                                                 (_index),(_attrName))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMediaDescrGetNumOfAttrByName
 * ------------------------------------------------------------------------
 * General:
 *      Gets the number of attributes having the given name in the media 
 *      descriptor  attributes list.
 *
 * Return Value:
 *      Number of attributes with the given name.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      attrName - the name of the attribute to be retrieved.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSize_t rvSdpMediaDescrGetNumOfAttrByName(
            const RvSdpMediaDescr* descr,
            const RvChar* attrName);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetNumOfAttrByName(_descr,_attrName) \
			rvSdpGetNumOfAttrByName(&(_descr)->iCommonFields,(_attrName))
#endif /*RV_SDP_USE_MACROS*/


/***************************************************************************
 * rvSdpMediaDescrGetFirstAttributeByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the first attribute object with the given name defined 
 *      in the media descriptor. Also sets the list iterator for the further use. 
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      attribute with the given name in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      descr - a pointer to the RvSdpMediaDescr object.
 *      attrName - the name of the attribute to be retrieved.
 *      iter - pointer to RvSdpListIter to be used for further
 *             GetNext calls.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetFirstAttributeByName(
            RvSdpMediaDescr* descr,
            const RvChar* attrName,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetFirstAttributeByName(_descr,_attrName,_iter) \
			(RvSdpAttribute*)rvSdpGetFirstAttrByName(&(_descr)->iCommonFields,\
                                                      (_iter),(_attrName))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
 * rvSdpMediaDescrGetNextAttributeByName
 * ------------------------------------------------------------------------
 * General:
 *      Returns the next attribute object with the given name defined 
 *      in the media descriptor. The 'next' object is defined based on the list
 *      iterator state.
 *
 * Return Value:
 *      Pointer to the RvSdpAttribute object or the NULL pointer if there is no
 *      more attributes with the given name defined in the media descriptor.
 * ------------------------------------------------------------------------
 * Arguments:
 *      attrName - the name of the attribute to be retrieved.
 *      iter - pointer to RvSdpListIter set/modified by previous successfull call
 *             to GetFirst/GetNext function.
 ***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetNextAttributeByName(
            const RvChar* attrName,
            RvSdpListIter* iter);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetNextAttributeByName(_attrName,_iter) \
			(RvSdpAttribute*)rvSdpGetNextAttrByName((_iter),(_attrName))
#endif /*RV_SDP_USE_MACROS*/

/***************************************************************************
* rvSdpMediaDescrGetAttributeByName
* ------------------------------------------------------------------------
* General:
*      Gets an attribute object with the given name by index. 
*
* Return Value:
*      The requested attribute object.
* ------------------------------------------------------------------------
* Arguments:
*      descr - a pointer to the RvSdpMediaDescr object.
*      attrName - the name of the attribute to be retrieved.
*      index - the index. The index should start at zero (0) and must be smaller
*              than the number of elements in the list. The number of elements
*              in the list is retrieved by correspondent 
*              rvSdpMediaDescrGetNumOfAttrByName() call.
***************************************************************************/
#ifndef RV_SDP_USE_MACROS
RVSDPCOREAPI RvSdpAttribute* rvSdpMediaDescrGetAttributeByName(
            const RvSdpMediaDescr* descr,
            const RvChar* attrName,
            RvSize_t index);
#else /*RV_SDP_USE_MACROS*/
#define rvSdpMediaDescrGetAttributeByName(_descr,_attrName,_index)   \
			rvSdpGetAttrByName((RvSdpCommonFields*)&(_descr)->iCommonFields,\
                                                 (_index),(_attrName))
#endif /*RV_SDP_USE_MACROS*/

#endif

